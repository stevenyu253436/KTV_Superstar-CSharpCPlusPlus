/**
 * @license almond 0.3.1 Copyright (c) 2011-2014, The Dojo Foundation All Rights Reserved.
 * Available via the MIT or new BSD license.
 * see: http://github.com/jrburke/almond for details
 */

/*!
 * jQuery JavaScript Library v2.1.3
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 *
 * Copyright 2005, 2014 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2014-12-18T15:11Z
 */

/*!
 * Sizzle CSS Selector Engine v2.2.0-pre
 * http://sizzlejs.com/
 *
 * Copyright 2008, 2014 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2014-12-16
 */

/*! iScroll v5.1.3 ~ (c) 2008-2014 Matteo Spinelli ~ http://cubiq.org/license */

/*!
 * jquery.NatureFace.js JavaScript Library 
 * http://jquerynatureface.ksonglover.com/
 *
 * Copyright 2003~2015, jquerynatureFace.com
 *
 *  version : v2.15.16
 *
 * 此程式主要用途為產生互動式web應用程式之操作介面。
 * 並搭配一些簡單的操作，就可完成一個應用程式互動介面。
 * 此程式「使用創用CC 姓名標示─非商業性─禁止改作 3.0 台灣 授權條款」
 * 如做為商業用途，請利用Paypal進行付費授權，另外任何使用請保留此註記。
 * 
 */

/*
   Stomp Over WebSocket http://www.jmesnil.net/stomp-websocket/doc/ | Apache License V2.0

   Copyright (C) 2010-2013 [Jeff Mesnil](http://jmesnil.net/)
   Copyright (C) 2012 [FuseSource, Inc.](http://fusesource.com)
 */

/*!
 * jQuery Cycle Plugin (with Transition Definitions)
 * Examples and documentation at: http://jquery.malsup.com/cycle/
 * Copyright (c) 2007-2010 M. Alsup
 * Version: 2.9999.8 (26-OCT-2012)
 * Dual licensed under the MIT and GPL licenses.
 * http://jquery.malsup.com/license.html
 * Requires: jQuery v1.3.2 or later
 */

/*!
 * jQuery Cycle Plugin Transition Definitions
 * This script is a plugin for the jQuery Cycle Plugin
 * Examples and documentation at: http://malsup.com/jquery/cycle/
 * Copyright (c) 2007-2010 M. Alsup
 * Version:	 2.73
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 */

/*! jQuery UI - v1.11.2 - 2014-10-16
 * http://jqueryui.com
 * Includes: core.js, widget.js, mouse.js, position.js, accordion.js, autocomplete.js, button.js, datepicker.js, dialog.js, draggable.js, droppable.js, effect.js, effect-blind.js, effect-bounce.js, effect-clip.js, effect-drop.js, effect-explode.js, effect-fade.js, effect-fold.js, effect-highlight.js, effect-puff.js, effect-pulsate.js, effect-scale.js, effect-shake.js, effect-size.js, effect-slide.js, effect-transfer.js, menu.js, progressbar.js, resizable.js, selectable.js, selectmenu.js, slider.js, sortable.js, spinner.js, tabs.js, tooltip.js
 * Copyright 2014 jQuery Foundation and other contributors; Licensed MIT */

/*!
 * jQuery UI Core 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/category/ui-core/
 */

/*!
 * jQuery UI Widget 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/jQuery.widget/
 */

/*!
 * jQuery UI Mouse 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/mouse/
 */

/*!
 * jQuery UI Position 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/position/
 */

/*!
 * jQuery UI Accordion 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/accordion/
 */

/*!
 * jQuery UI Menu 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/menu/
 */

/*!
 * jQuery UI Autocomplete 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/autocomplete/
 */

/*!
 * jQuery UI Button 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/button/
 */

/*!
 * jQuery UI Datepicker 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/datepicker/
 */

/*!
 * jQuery UI Draggable 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/draggable/
 */

/*!
 * jQuery UI Resizable 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/resizable/
 */

/*!
 * jQuery UI Dialog 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/dialog/
 */

/*!
 * jQuery UI Droppable 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/droppable/
 */

/*!
 * jQuery UI Effects 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/category/effects-core/
 */

/*!
 * jQuery Color Animations v2.1.2
 * https://github.com/jquery/jquery-color
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * Date: Wed Jan 16 08:47:09 2013 -0600
 */

/*!
 * jQuery UI Effects Blind 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/blind-effect/
 */

/*!
 * jQuery UI Effects Bounce 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/bounce-effect/
 */

/*!
 * jQuery UI Effects Clip 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/clip-effect/
 */

/*!
 * jQuery UI Effects Drop 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/drop-effect/
 */

/*!
 * jQuery UI Effects Explode 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/explode-effect/
 */

/*!
 * jQuery UI Effects Fade 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/fade-effect/
 */

/*!
 * jQuery UI Effects Fold 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/fold-effect/
 */

/*!
 * jQuery UI Effects Highlight 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/highlight-effect/
 */

/*!
 * jQuery UI Effects Size 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/size-effect/
 */

/*!
 * jQuery UI Effects Scale 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/scale-effect/
 */

/*!
 * jQuery UI Effects Puff 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/puff-effect/
 */

/*!
 * jQuery UI Effects Pulsate 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/pulsate-effect/
 */

/*!
 * jQuery UI Effects Shake 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/shake-effect/
 */

/*!
 * jQuery UI Effects Slide 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/slide-effect/
 */

/*!
 * jQuery UI Effects Transfer 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/transfer-effect/
 */

/*!
 * jQuery UI Progressbar 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/progressbar/
 */

/*!
 * jQuery UI Selectable 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/selectable/
 */

/*!
 * jQuery UI Selectmenu 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/selectmenu
 */

/*!
 * jQuery UI Slider 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/slider/
 */

/*!
 * jQuery UI Sortable 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/sortable/
 */

/*!
 * jQuery UI Spinner 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/spinner/
 */

/*!
 * jQuery UI Tabs 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/tabs/
 */

/*!
 * jQuery UI Tooltip 1.11.2
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/tooltip/
 */

// Copyright (c) 2005  Tom Wu
// All Rights Reserved.
// See "LICENSE" for details.

// Copyright (c) 2005-2009  Tom Wu
// All Rights Reserved.
// See "LICENSE" for details.

//RSAKey.prototype.b64_decrypt = RSAB64Decrypt;
// Copyright (c) 2011  Kevin M Burns Jr.
// All Rights Reserved.
// See "LICENSE" for details.
//
// Extension to jsbn which adds facilities for asynchronous RSA key generation
// Primarily created to avoid execution timeout on mobile devices
//
// http://www-cs-students.stanford.edu/~tjw/jsbn/
//
// ---

/*! asn1-1.0.2.js (c) 2013 Kenji Urushima | kjur.github.com/jsrsasign/license
 */

/*
 * asn1.js - ASN.1 DER encoder classes
 *
 * Copyright (c) 2013 Kenji Urushima (kenji.urushima@gmail.com)
 *
 * This software is licensed under the terms of the MIT License.
 * http://kjur.github.com/jsrsasign/license
 *
 * The above copyright and license notice shall be 
 * included in all copies or substantial portions of the Software.
 */

/**
 * @fileOverview
 * @name asn1-1.0.js
 * @author Kenji Urushima kenji.urushima@gmail.com
 * @version 1.0.2 (2013-May-30)
 * @since 2.1
 * @license <a href="http://kjur.github.io/jsrsasign/license/">MIT License</a>
 */

// Hex JavaScript decoder
// Copyright (c) 2008-2013 Lapo Luchini <lapo@lapo.it>

// Permission to use, copy, modify, and/or distribute this software for any
// purpose with or without fee is hereby granted, provided that the above
// copyright notice and this permission notice appear in all copies.
// 
// THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
// WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
// ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
// ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
// OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

// Base64 JavaScript decoder
// Copyright (c) 2008-2013 Lapo Luchini <lapo@lapo.it>

// ASN.1 JavaScript decoder
// Copyright (c) 2008-2013 Lapo Luchini <lapo@lapo.it>

var requirejs, require, define;
(function(e) {
    function h(e, t) {
        return f.call(e, t)
    }

    function p(e, t) {
        var n, r, i, s, o, a, f, l, h, p, d, v = t && t.split("/"),
            m = u.map,
            g = m && m["*"] || {};
        if (e && e.charAt(0) === ".")
            if (t) {
                e = e.split("/"), o = e.length - 1, u.nodeIdCompat && c.test(e[o]) && (e[o] = e[o].replace(c, "")), e = v.slice(0, v.length - 1).concat(e);
                for (h = 0; h < e.length; h += 1) {
                    d = e[h];
                    if (d === ".") e.splice(h, 1), h -= 1;
                    else if (d === "..") {
                        if (h === 1 && (e[2] === ".." || e[0] === "..")) break;
                        h > 0 && (e.splice(h - 1, 2), h -= 2)
                    }
                }
                e = e.join("/")
            } else e.indexOf("./") === 0 && (e = e.substring(2));
        if ((v || g) && m) {
            n = e.split("/");
            for (h = n.length; h > 0; h -= 1) {
                r = n.slice(0, h).join("/");
                if (v)
                    for (p = v.length; p > 0; p -= 1) {
                        i = m[v.slice(0, p).join("/")];
                        if (i) {
                            i = i[r];
                            if (i) {
                                s = i, a = h;
                                break
                            }
                        }
                    }
                if (s) break;
                !f && g && g[r] && (f = g[r], l = h)
            }!s && f && (s = f, a = l), s && (n.splice(0, a, s), e = n.join("/"))
        }
        return e
    }

    function d(t, r) {
        return function() {
            var i = l.call(arguments, 0);
            return typeof i[0] != "string" && i.length === 1 && i.push(null), n.apply(e, i.concat([t, r]))
        }
    }

    function v(e) {
        return function(t) {
            return p(t, e)
        }
    }

    function m(e) {
        return function(t) {
            s[e] = t
        }
    }

    function g(n) {
        if (h(o, n)) {
            var r = o[n];
            delete o[n], a[n] = !0, t.apply(e, r)
        }
        if (!h(s, n) && !h(a, n)) throw new Error("No " + n);
        return s[n]
    }

    function y(e) {
        var t, n = e ? e.indexOf("!") : -1;
        return n > -1 && (t = e.substring(0, n), e = e.substring(n + 1, e.length)), [t, e]
    }

    function b(e) {
        return function() {
            return u && u.config && u.config[e] || {}
        }
    }
    var t, n, r, i, s = {},
        o = {},
        u = {},
        a = {},
        f = Object.prototype.hasOwnProperty,
        l = [].slice,
        c = /\.js$/;
    r = function(e, t) {
        var n, r = y(e),
            i = r[0];
        return e = r[1], i && (i = p(i, t), n = g(i)), i ? n && n.normalize ? e = n.normalize(e, v(t)) : e = p(e, t) : (e = p(e, t), r = y(e), i = r[0], e = r[1], i && (n = g(i))), {
            f: i ? i + "!" + e : e,
            n: e,
            pr: i,
            p: n
        }
    }, i = {
        require: function(e) {
            return d(e)
        },
        exports: function(e) {
            var t = s[e];
            return typeof t != "undefined" ? t : s[e] = {}
        },
        module: function(e) {
            return {
                id: e,
                uri: "",
                exports: s[e],
                config: b(e)
            }
        }
    }, t = function(t, n, u, f) {
        var l, c, p, v, y, b = [],
            w = typeof u,
            E;
        f = f || t;
        if (w === "undefined" || w === "function") {
            n = !n.length && u.length ? ["require", "exports", "module"] : n;
            for (y = 0; y < n.length; y += 1) {
                v = r(n[y], f), c = v.f;
                if (c === "require") b[y] = i.require(t);
                else if (c === "exports") b[y] = i.exports(t), E = !0;
                else if (c === "module") l = b[y] = i.module(t);
                else if (h(s, c) || h(o, c) || h(a, c)) b[y] = g(c);
                else {
                    if (!v.p) throw new Error(t + " missing " + c);
                    v.p.load(v.n, d(f, !0), m(c), {}), b[y] = s[c]
                }
            }
            p = u ? u.apply(s[t], b) : undefined;
            if (t)
                if (l && l.exports !== e && l.exports !== s[t]) s[t] = l.exports;
                else if (p !== e || !E) s[t] = p
        } else t && (s[t] = u)
    }, requirejs = require = n = function(s, o, a, f, l) {
        if (typeof s == "string") return i[s] ? i[s](o) : g(r(s, o).f);
        if (!s.splice) {
            u = s, u.deps && n(u.deps, u.callback);
            if (!o) return;
            o.splice ? (s = o, o = a, a = null) : s = e
        }
        return o = o || function() {}, typeof a == "function" && (a = f, f = l), f ? t(e, s, o, a) : setTimeout(function() {
            t(e, s, o, a)
        }, 4), n
    }, n.config = function(e) {
        return n(e)
    }, requirejs._defined = s, define = function(e, t, n) {
        if (typeof e != "string") throw new Error("See almond README: incorrect module build, no module name");
        t.splice || (n = t, t = []), !h(s, e) && !h(o, e) && (o[e] = [e, t, n])
    }, define.amd = {
        jQuery: !0
    }
})(), define("almond", function() {}),
    function(e, t) {
        typeof module == "object" && typeof module.exports == "object" ? module.exports = e.document ? t(e, !0) : function(e) {
            if (!e.document) throw new Error("jQuery requires a window with a document");
            return t(e)
        } : t(e)
    }(typeof window != "undefined" ? window : this, function(window, noGlobal) {
        function isArraylike(e) {
            var t = e.length,
                n = jQuery.type(e);
            return n === "function" || jQuery.isWindow(e) ? !1 : e.nodeType === 1 && t ? !0 : n === "array" || t === 0 || typeof t == "number" && t > 0 && t - 1 in e
        }

        function winnow(e, t, n) {
            if (jQuery.isFunction(t)) return jQuery.grep(e, function(e, r) {
                return !!t.call(e, r, e) !== n
            });
            if (t.nodeType) return jQuery.grep(e, function(e) {
                return e === t !== n
            });
            if (typeof t == "string") {
                if (risSimple.test(t)) return jQuery.filter(t, e, n);
                t = jQuery.filter(t, e)
            }
            return jQuery.grep(e, function(e) {
                return indexOf.call(t, e) >= 0 !== n
            })
        }

        function sibling(e, t) {
            while ((e = e[t]) && e.nodeType !== 1);
            return e
        }

        function createOptions(e) {
            var t = optionsCache[e] = {};
            return jQuery.each(e.match(rnotwhite) || [], function(e, n) {
                t[n] = !0
            }), t
        }

        function completed() {
            document.removeEventListener("DOMContentLoaded", completed, !1), window.removeEventListener("load", completed, !1), jQuery.ready()
        }

        function Data() {
            Object.defineProperty(this.cache = {}, 0, {
                get: function() {
                    return {}
                }
            }), this.expando = jQuery.expando + Data.uid++
        }

        function dataAttr(e, t, n) {
            var r;
            if (n === undefined && e.nodeType === 1) {
                r = "data-" + t.replace(rmultiDash, "-$1").toLowerCase(), n = e.getAttribute(r);
                if (typeof n == "string") {
                    try {
                        n = n === "true" ? !0 : n === "false" ? !1 : n === "null" ? null : +n + "" === n ? +n : rbrace.test(n) ? jQuery.parseJSON(n) : n
                    } catch (i) {}
                    data_user.set(e, t, n)
                } else n = undefined
            }
            return n
        }

        function returnTrue() {
            return !0
        }

        function returnFalse() {
            return !1
        }

        function safeActiveElement() {
            try {
                return document.activeElement
            } catch (e) {}
        }

        function manipulationTarget(e, t) {
            return jQuery.nodeName(e, "table") && jQuery.nodeName(t.nodeType !== 11 ? t : t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
        }

        function disableScript(e) {
            return e.type = (e.getAttribute("type") !== null) + "/" + e.type, e
        }

        function restoreScript(e) {
            var t = rscriptTypeMasked.exec(e.type);
            return t ? e.type = t[1] : e.removeAttribute("type"), e
        }

        function setGlobalEval(e, t) {
            var n = 0,
                r = e.length;
            for (; n < r; n++) data_priv.set(e[n], "globalEval", !t || data_priv.get(t[n], "globalEval"))
        }

        function cloneCopyEvent(e, t) {
            var n, r, i, s, o, u, a, f;
            if (t.nodeType !== 1) return;
            if (data_priv.hasData(e)) {
                s = data_priv.access(e), o = data_priv.set(t, s), f = s.events;
                if (f) {
                    delete o.handle, o.events = {};
                    for (i in f)
                        for (n = 0, r = f[i].length; n < r; n++) jQuery.event.add(t, i, f[i][n])
                }
            }
            data_user.hasData(e) && (u = data_user.access(e), a = jQuery.extend({}, u), data_user.set(t, a))
        }

        function getAll(e, t) {
            var n = e.getElementsByTagName ? e.getElementsByTagName(t || "*") : e.querySelectorAll ? e.querySelectorAll(t || "*") : [];
            return t === undefined || t && jQuery.nodeName(e, t) ? jQuery.merge([e], n) : n
        }

        function fixInput(e, t) {
            var n = t.nodeName.toLowerCase();
            if (n === "input" && rcheckableType.test(e.type)) t.checked = e.checked;
            else if (n === "input" || n === "textarea") t.defaultValue = e.defaultValue
        }

        function actualDisplay(e, t) {
            var n, r = jQuery(t.createElement(e)).appendTo(t.body),
                i = window.getDefaultComputedStyle && (n = window.getDefaultComputedStyle(r[0])) ? n.display : jQuery.css(r[0], "display");
            return r.detach(), i
        }

        function defaultDisplay(e) {
            var t = document,
                n = elemdisplay[e];
            if (!n) {
                n = actualDisplay(e, t);
                if (n === "none" || !n) iframe = (iframe || jQuery("<iframe frameborder='0' width='0' height='0'/>")).appendTo(t.documentElement), t = iframe[0].contentDocument, t.write(), t.close(), n = actualDisplay(e, t), iframe.detach();
                elemdisplay[e] = n
            }
            return n
        }

        function curCSS(e, t, n) {
            var r, i, s, o, u = e.style;
            return n = n || getStyles(e), n && (o = n.getPropertyValue(t) || n[t]), n && (o === "" && !jQuery.contains(e.ownerDocument, e) && (o = jQuery.style(e, t)), rnumnonpx.test(o) && rmargin.test(t) && (r = u.width, i = u.minWidth, s = u.maxWidth, u.minWidth = u.maxWidth = u.width = o, o = n.width, u.width = r, u.minWidth = i, u.maxWidth = s)), o !== undefined ? o + "" : o
        }

        function addGetHookIf(e, t) {
            return {
                get: function() {
                    if (e()) {
                        delete this.get;
                        return
                    }
                    return (this.get = t).apply(this, arguments)
                }
            }
        }

        function vendorPropName(e, t) {
            if (t in e) return t;
            var n = t[0].toUpperCase() + t.slice(1),
                r = t,
                i = cssPrefixes.length;
            while (i--) {
                t = cssPrefixes[i] + n;
                if (t in e) return t
            }
            return r
        }

        function setPositiveNumber(e, t, n) {
            var r = rnumsplit.exec(t);
            return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t
        }

        function augmentWidthOrHeight(e, t, n, r, i) {
            var s = n === (r ? "border" : "content") ? 4 : t === "width" ? 1 : 0,
                o = 0;
            for (; s < 4; s += 2) n === "margin" && (o += jQuery.css(e, n + cssExpand[s], !0, i)), r ? (n === "content" && (o -= jQuery.css(e, "padding" + cssExpand[s], !0, i)), n !== "margin" && (o -= jQuery.css(e, "border" + cssExpand[s] + "Width", !0, i))) : (o += jQuery.css(e, "padding" + cssExpand[s], !0, i), n !== "padding" && (o += jQuery.css(e, "border" + cssExpand[s] + "Width", !0, i)));
            return o
        }

        function getWidthOrHeight(e, t, n) {
            var r = !0,
                i = t === "width" ? e.offsetWidth : e.offsetHeight,
                s = getStyles(e),
                o = jQuery.css(e, "boxSizing", !1, s) === "border-box";
            if (i <= 0 || i == null) {
                i = curCSS(e, t, s);
                if (i < 0 || i == null) i = e.style[t];
                if (rnumnonpx.test(i)) return i;
                r = o && (support.boxSizingReliable() || i === e.style[t]), i = parseFloat(i) || 0
            }
            return i + augmentWidthOrHeight(e, t, n || (o ? "border" : "content"), r, s) + "px"
        }

        function showHide(e, t) {
            var n, r, i, s = [],
                o = 0,
                u = e.length;
            for (; o < u; o++) {
                r = e[o];
                if (!r.style) continue;
                s[o] = data_priv.get(r, "olddisplay"), n = r.style.display, t ? (!s[o] && n === "none" && (r.style.display = ""), r.style.display === "" && isHidden(r) && (s[o] = data_priv.access(r, "olddisplay", defaultDisplay(r.nodeName)))) : (i = isHidden(r), (n !== "none" || !i) && data_priv.set(r, "olddisplay", i ? n : jQuery.css(r, "display")))
            }
            for (o = 0; o < u; o++) {
                r = e[o];
                if (!r.style) continue;
                if (!t || r.style.display === "none" || r.style.display === "") r.style.display = t ? s[o] || "" : "none"
            }
            return e
        }

        function Tween(e, t, n, r, i) {
            return new Tween.prototype.init(e, t, n, r, i)
        }

        function createFxNow() {
            return setTimeout(function() {
                fxNow = undefined
            }), fxNow = jQuery.now()
        }

        function genFx(e, t) {
            var n, r = 0,
                i = {
                    height: e
                };
            t = t ? 1 : 0;
            for (; r < 4; r += 2 - t) n = cssExpand[r], i["margin" + n] = i["padding" + n] = e;
            return t && (i.opacity = i.width = e), i
        }

        function createTween(e, t, n) {
            var r, i = (tweeners[t] || []).concat(tweeners["*"]),
                s = 0,
                o = i.length;
            for (; s < o; s++)
                if (r = i[s].call(n, t, e)) return r
        }

        function defaultPrefilter(e, t, n) {
            var r, i, s, o, u, a, f, l, c = this,
                h = {},
                p = e.style,
                d = e.nodeType && isHidden(e),
                v = data_priv.get(e, "fxshow");
            n.queue || (u = jQuery._queueHooks(e, "fx"), u.unqueued == null && (u.unqueued = 0, a = u.empty.fire, u.empty.fire = function() {
                u.unqueued || a()
            }), u.unqueued++, c.always(function() {
                c.always(function() {
                    u.unqueued--, jQuery.queue(e, "fx").length || u.empty.fire()
                })
            })), e.nodeType === 1 && ("height" in t || "width" in t) && (n.overflow = [p.overflow, p.overflowX, p.overflowY], f = jQuery.css(e, "display"), l = f === "none" ? data_priv.get(e, "olddisplay") || defaultDisplay(e.nodeName) : f, l === "inline" && jQuery.css(e, "float") === "none" && (p.display = "inline-block")), n.overflow && (p.overflow = "hidden", c.always(function() {
                p.overflow = n.overflow[0], p.overflowX = n.overflow[1], p.overflowY = n.overflow[2]
            }));
            for (r in t) {
                i = t[r];
                if (rfxtypes.exec(i)) {
                    delete t[r], s = s || i === "toggle";
                    if (i === (d ? "hide" : "show")) {
                        if (i !== "show" || !v || v[r] === undefined) continue;
                        d = !0
                    }
                    h[r] = v && v[r] || jQuery.style(e, r)
                } else f = undefined
            }
            if (!jQuery.isEmptyObject(h)) {
                v ? "hidden" in v && (d = v.hidden) : v = data_priv.access(e, "fxshow", {}), s && (v.hidden = !d), d ? jQuery(e).show() : c.done(function() {
                    jQuery(e).hide()
                }), c.done(function() {
                    var t;
                    data_priv.remove(e, "fxshow");
                    for (t in h) jQuery.style(e, t, h[t])
                });
                for (r in h) o = createTween(d ? v[r] : 0, r, c), r in v || (v[r] = o.start, d && (o.end = o.start, o.start = r === "width" || r === "height" ? 1 : 0))
            } else(f === "none" ? defaultDisplay(e.nodeName) : f) === "inline" && (p.display = f)
        }

        function propFilter(e, t) {
            var n, r, i, s, o;
            for (n in e) {
                r = jQuery.camelCase(n), i = t[r], s = e[n], jQuery.isArray(s) && (i = s[1], s = e[n] = s[0]), n !== r && (e[r] = s, delete e[n]), o = jQuery.cssHooks[r];
                if (o && "expand" in o) {
                    s = o.expand(s), delete e[r];
                    for (n in s) n in e || (e[n] = s[n], t[n] = i)
                } else t[r] = i
            }
        }

        function Animation(e, t, n) {
            var r, i, s = 0,
                o = animationPrefilters.length,
                u = jQuery.Deferred().always(function() {
                    delete a.elem
                }),
                a = function() {
                    if (i) return !1;
                    var t = fxNow || createFxNow(),
                        n = Math.max(0, f.startTime + f.duration - t),
                        r = n / f.duration || 0,
                        s = 1 - r,
                        o = 0,
                        a = f.tweens.length;
                    for (; o < a; o++) f.tweens[o].run(s);
                    return u.notifyWith(e, [f, s, n]), s < 1 && a ? n : (u.resolveWith(e, [f]), !1)
                },
                f = u.promise({
                    elem: e,
                    props: jQuery.extend({}, t),
                    opts: jQuery.extend(!0, {
                        specialEasing: {}
                    }, n),
                    originalProperties: t,
                    originalOptions: n,
                    startTime: fxNow || createFxNow(),
                    duration: n.duration,
                    tweens: [],
                    createTween: function(t, n) {
                        var r = jQuery.Tween(e, f.opts, t, n, f.opts.specialEasing[t] || f.opts.easing);
                        return f.tweens.push(r), r
                    },
                    stop: function(t) {
                        var n = 0,
                            r = t ? f.tweens.length : 0;
                        if (i) return this;
                        i = !0;
                        for (; n < r; n++) f.tweens[n].run(1);
                        return t ? u.resolveWith(e, [f, t]) : u.rejectWith(e, [f, t]), this
                    }
                }),
                l = f.props;
            propFilter(l, f.opts.specialEasing);
            for (; s < o; s++) {
                r = animationPrefilters[s].call(f, e, l, f.opts);
                if (r) return r
            }
            return jQuery.map(l, createTween, f), jQuery.isFunction(f.opts.start) && f.opts.start.call(e, f), jQuery.fx.timer(jQuery.extend(a, {
                elem: e,
                anim: f,
                queue: f.opts.queue
            })), f.progress(f.opts.progress).done(f.opts.done, f.opts.complete).fail(f.opts.fail).always(f.opts.always)
        }

        function addToPrefiltersOrTransports(e) {
            return function(t, n) {
                typeof t != "string" && (n = t, t = "*");
                var r, i = 0,
                    s = t.toLowerCase().match(rnotwhite) || [];
                if (jQuery.isFunction(n))
                    while (r = s[i++]) r[0] === "+" ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
            }
        }

        function inspectPrefiltersOrTransports(e, t, n, r) {
            function o(u) {
                var a;
                return i[u] = !0, jQuery.each(e[u] || [], function(e, u) {
                    var f = u(t, n, r);
                    if (typeof f == "string" && !s && !i[f]) return t.dataTypes.unshift(f), o(f), !1;
                    if (s) return !(a = f)
                }), a
            }
            var i = {},
                s = e === transports;
            return o(t.dataTypes[0]) || !i["*"] && o("*")
        }

        function ajaxExtend(e, t) {
            var n, r, i = jQuery.ajaxSettings.flatOptions || {};
            for (n in t) t[n] !== undefined && ((i[n] ? e : r || (r = {}))[n] = t[n]);
            return r && jQuery.extend(!0, e, r), e
        }

        function ajaxHandleResponses(e, t, n) {
            var r, i, s, o, u = e.contents,
                a = e.dataTypes;
            while (a[0] === "*") a.shift(), r === undefined && (r = e.mimeType || t.getResponseHeader("Content-Type"));
            if (r)
                for (i in u)
                    if (u[i] && u[i].test(r)) {
                        a.unshift(i);
                        break
                    } if (a[0] in n) s = a[0];
            else {
                for (i in n) {
                    if (!a[0] || e.converters[i + " " + a[0]]) {
                        s = i;
                        break
                    }
                    o || (o = i)
                }
                s = s || o
            }
            if (s) return s !== a[0] && a.unshift(s), n[s]
        }

        function ajaxConvert(e, t, n, r) {
            var i, s, o, u, a, f = {},
                l = e.dataTypes.slice();
            if (l[1])
                for (o in e.converters) f[o.toLowerCase()] = e.converters[o];
            s = l.shift();
            while (s) {
                e.responseFields[s] && (n[e.responseFields[s]] = t), !a && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), a = s, s = l.shift();
                if (s)
                    if (s === "*") s = a;
                    else if (a !== "*" && a !== s) {
                    o = f[a + " " + s] || f["* " + s];
                    if (!o)
                        for (i in f) {
                            u = i.split(" ");
                            if (u[1] === s) {
                                o = f[a + " " + u[0]] || f["* " + u[0]];
                                if (o) {
                                    o === !0 ? o = f[i] : f[i] !== !0 && (s = u[0], l.unshift(u[1]));
                                    break
                                }
                            }
                        }
                    if (o !== !0)
                        if (o && e["throws"]) t = o(t);
                        else try {
                            t = o(t)
                        } catch (c) {
                            return {
                                state: "parsererror",
                                error: o ? c : "No conversion from " + a + " to " + s
                            }
                        }
                }
            }
            return {
                state: "success",
                data: t
            }
        }

        function buildParams(e, t, n, r) {
            var i;
            if (jQuery.isArray(t)) jQuery.each(t, function(t, i) {
                n || rbracket.test(e) ? r(e, i) : buildParams(e + "[" + (typeof i == "object" ? t : "") + "]", i, n, r)
            });
            else if (!n && jQuery.type(t) === "object")
                for (i in t) buildParams(e + "[" + i + "]", t[i], n, r);
            else r(e, t)
        }

        function getWindow(e) {
            return jQuery.isWindow(e) ? e : e.nodeType === 9 && e.defaultView
        }
        var arr = [],
            slice = arr.slice,
            concat = arr.concat,
            push = arr.push,
            indexOf = arr.indexOf,
            class2type = {},
            toString = class2type.toString,
            hasOwn = class2type.hasOwnProperty,
            support = {},
            document = window.document,
            version = "2.1.3",
            jQuery = function(e, t) {
                return new jQuery.fn.init(e, t)
            },
            rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
            rmsPrefix = /^-ms-/,
            rdashAlpha = /-([\da-z])/gi,
            fcamelCase = function(e, t) {
                return t.toUpperCase()
            };
        jQuery.fn = jQuery.prototype = {
            jquery: version,
            constructor: jQuery,
            selector: "",
            length: 0,
            toArray: function() {
                return slice.call(this)
            },
            get: function(e) {
                return e != null ? e < 0 ? this[e + this.length] : this[e] : slice.call(this)
            },
            pushStack: function(e) {
                var t = jQuery.merge(this.constructor(), e);
                return t.prevObject = this, t.context = this.context, t
            },
            each: function(e, t) {
                return jQuery.each(this, e, t)
            },
            map: function(e) {
                return this.pushStack(jQuery.map(this, function(t, n) {
                    return e.call(t, n, t)
                }))
            },
            slice: function() {
                return this.pushStack(slice.apply(this, arguments))
            },
            first: function() {
                return this.eq(0)
            },
            last: function() {
                return this.eq(-1)
            },
            eq: function(e) {
                var t = this.length,
                    n = +e + (e < 0 ? t : 0);
                return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
            },
            end: function() {
                return this.prevObject || this.constructor(null)
            },
            push: push,
            sort: arr.sort,
            splice: arr.splice
        }, jQuery.extend = jQuery.fn.extend = function() {
            var e, t, n, r, i, s, o = arguments[0] || {},
                u = 1,
                a = arguments.length,
                f = !1;
            typeof o == "boolean" && (f = o, o = arguments[u] || {}, u++), typeof o != "object" && !jQuery.isFunction(o) && (o = {}), u === a && (o = this, u--);
            for (; u < a; u++)
                if ((e = arguments[u]) != null)
                    for (t in e) {
                        n = o[t], r = e[t];
                        if (o === r) continue;
                        f && r && (jQuery.isPlainObject(r) || (i = jQuery.isArray(r))) ? (i ? (i = !1, s = n && jQuery.isArray(n) ? n : []) : s = n && jQuery.isPlainObject(n) ? n : {}, o[t] = jQuery.extend(f, s, r)) : r !== undefined && (o[t] = r)
                    }
            return o
        }, jQuery.extend({
            expando: "jQuery" + (version + Math.random()).replace(/\D/g, ""),
            isReady: !0,
            error: function(e) {
                throw new Error(e)
            },
            noop: function() {},
            isFunction: function(e) {
                return jQuery.type(e) === "function"
            },
            isArray: Array.isArray,
            isWindow: function(e) {
                return e != null && e === e.window
            },
            isNumeric: function(e) {
                return !jQuery.isArray(e) && e - parseFloat(e) + 1 >= 0
            },
            isPlainObject: function(e) {
                return jQuery.type(e) !== "object" || e.nodeType || jQuery.isWindow(e) ? !1 : e.constructor && !hasOwn.call(e.constructor.prototype, "isPrototypeOf") ? !1 : !0
            },
            isEmptyObject: function(e) {
                var t;
                for (t in e) return !1;
                return !0
            },
            type: function(e) {
                return e == null ? e + "" : typeof e == "object" || typeof e == "function" ? class2type[toString.call(e)] || "object" : typeof e
            },
            globalEval: function(code) {
                var script, indirect = eval;
                code = jQuery.trim(code), code && (code.indexOf("use strict") === 1 ? (script = document.createElement("script"), script.text = code, document.head.appendChild(script).parentNode.removeChild(script)) : indirect(code))
            },
            camelCase: function(e) {
                return e.replace(rmsPrefix, "ms-").replace(rdashAlpha, fcamelCase)
            },
            nodeName: function(e, t) {
                return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
            },
            each: function(e, t, n) {
                var r, i = 0,
                    s = e.length,
                    o = isArraylike(e);
                if (n)
                    if (o)
                        for (; i < s; i++) {
                            r = t.apply(e[i], n);
                            if (r === !1) break
                        } else
                            for (i in e) {
                                r = t.apply(e[i], n);
                                if (r === !1) break
                            } else if (o)
                                for (; i < s; i++) {
                                    r = t.call(e[i], i, e[i]);
                                    if (r === !1) break
                                } else
                                    for (i in e) {
                                        r = t.call(e[i], i, e[i]);
                                        if (r === !1) break
                                    }
                return e
            },
            trim: function(e) {
                return e == null ? "" : (e + "").replace(rtrim, "")
            },
            makeArray: function(e, t) {
                var n = t || [];
                return e != null && (isArraylike(Object(e)) ? jQuery.merge(n, typeof e == "string" ? [e] : e) : push.call(n, e)), n
            },
            inArray: function(e, t, n) {
                return t == null ? -1 : indexOf.call(t, e, n)
            },
            merge: function(e, t) {
                var n = +t.length,
                    r = 0,
                    i = e.length;
                for (; r < n; r++) e[i++] = t[r];
                return e.length = i, e
            },
            grep: function(e, t, n) {
                var r, i = [],
                    s = 0,
                    o = e.length,
                    u = !n;
                for (; s < o; s++) r = !t(e[s], s), r !== u && i.push(e[s]);
                return i
            },
            map: function(e, t, n) {
                var r, i = 0,
                    s = e.length,
                    o = isArraylike(e),
                    u = [];
                if (o)
                    for (; i < s; i++) r = t(e[i], i, n), r != null && u.push(r);
                else
                    for (i in e) r = t(e[i], i, n), r != null && u.push(r);
                return concat.apply([], u)
            },
            guid: 1,
            proxy: function(e, t) {
                var n, r, i;
                return typeof t == "string" && (n = e[t], t = e, e = n), jQuery.isFunction(e) ? (r = slice.call(arguments, 2), i = function() {
                    return e.apply(t || this, r.concat(slice.call(arguments)))
                }, i.guid = e.guid = e.guid || jQuery.guid++, i) : undefined
            },
            now: Date.now,
            support: support
        }), jQuery.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(e, t) {
            class2type["[object " + t + "]"] = t.toLowerCase()
        });
        var Sizzle = function(e) {
            function ot(e, t, r, i) {
                var s, u, f, l, c, d, g, y, S, x;
                (t ? t.ownerDocument || t : E) !== p && h(t), t = t || p, r = r || [], l = t.nodeType;
                if (typeof e != "string" || !e || l !== 1 && l !== 9 && l !== 11) return r;
                if (!i && v) {
                    if (l !== 11 && (s = Z.exec(e)))
                        if (f = s[1]) {
                            if (l === 9) {
                                u = t.getElementById(f);
                                if (!u || !u.parentNode) return r;
                                if (u.id === f) return r.push(u), r
                            } else if (t.ownerDocument && (u = t.ownerDocument.getElementById(f)) && b(t, u) && u.id === f) return r.push(u), r
                        } else {
                            if (s[2]) return D.apply(r, t.getElementsByTagName(e)), r;
                            if ((f = s[3]) && n.getElementsByClassName) return D.apply(r, t.getElementsByClassName(f)), r
                        } if (n.qsa && (!m || !m.test(e))) {
                        y = g = w, S = t, x = l !== 1 && e;
                        if (l === 1 && t.nodeName.toLowerCase() !== "object") {
                            d = o(e), (g = t.getAttribute("id")) ? y = g.replace(tt, "\\$&") : t.setAttribute("id", y), y = "[id='" + y + "'] ", c = d.length;
                            while (c--) d[c] = y + gt(d[c]);
                            S = et.test(e) && vt(t.parentNode) || t, x = d.join(",")
                        }
                        if (x) try {
                            return D.apply(r, S.querySelectorAll(x)), r
                        } catch (T) {} finally {
                            g || t.removeAttribute("id")
                        }
                    }
                }
                return a(e.replace(z, "$1"), t, r, i)
            }

            function ut() {
                function t(n, i) {
                    return e.push(n + " ") > r.cacheLength && delete t[e.shift()], t[n + " "] = i
                }
                var e = [];
                return t
            }

            function at(e) {
                return e[w] = !0, e
            }

            function ft(e) {
                var t = p.createElement("div");
                try {
                    return !!e(t)
                } catch (n) {
                    return !1
                } finally {
                    t.parentNode && t.parentNode.removeChild(t), t = null
                }
            }

            function lt(e, t) {
                var n = e.split("|"),
                    i = e.length;
                while (i--) r.attrHandle[n[i]] = t
            }

            function ct(e, t) {
                var n = t && e,
                    r = n && e.nodeType === 1 && t.nodeType === 1 && (~t.sourceIndex || L) - (~e.sourceIndex || L);
                if (r) return r;
                if (n)
                    while (n = n.nextSibling)
                        if (n === t) return -1;
                return e ? 1 : -1
            }

            function ht(e) {
                return function(t) {
                    var n = t.nodeName.toLowerCase();
                    return n === "input" && t.type === e
                }
            }

            function pt(e) {
                return function(t) {
                    var n = t.nodeName.toLowerCase();
                    return (n === "input" || n === "button") && t.type === e
                }
            }

            function dt(e) {
                return at(function(t) {
                    return t = +t, at(function(n, r) {
                        var i, s = e([], n.length, t),
                            o = s.length;
                        while (o--) n[i = s[o]] && (n[i] = !(r[i] = n[i]))
                    })
                })
            }

            function vt(e) {
                return e && typeof e.getElementsByTagName != "undefined" && e
            }

            function mt() {}

            function gt(e) {
                var t = 0,
                    n = e.length,
                    r = "";
                for (; t < n; t++) r += e[t].value;
                return r
            }

            function yt(e, t, n) {
                var r = t.dir,
                    i = n && r === "parentNode",
                    s = x++;
                return t.first ? function(t, n, s) {
                    while (t = t[r])
                        if (t.nodeType === 1 || i) return e(t, n, s)
                } : function(t, n, o) {
                    var u, a, f = [S, s];
                    if (o) {
                        while (t = t[r])
                            if (t.nodeType === 1 || i)
                                if (e(t, n, o)) return !0
                    } else
                        while (t = t[r])
                            if (t.nodeType === 1 || i) {
                                a = t[w] || (t[w] = {});
                                if ((u = a[r]) && u[0] === S && u[1] === s) return f[2] = u[2];
                                a[r] = f;
                                if (f[2] = e(t, n, o)) return !0
                            }
                }
            }

            function bt(e) {
                return e.length > 1 ? function(t, n, r) {
                    var i = e.length;
                    while (i--)
                        if (!e[i](t, n, r)) return !1;
                    return !0
                } : e[0]
            }

            function wt(e, t, n) {
                var r = 0,
                    i = t.length;
                for (; r < i; r++) ot(e, t[r], n);
                return n
            }

            function Et(e, t, n, r, i) {
                var s, o = [],
                    u = 0,
                    a = e.length,
                    f = t != null;
                for (; u < a; u++)
                    if (s = e[u])
                        if (!n || n(s, r, i)) o.push(s), f && t.push(u);
                return o
            }

            function St(e, t, n, r, i, s) {
                return r && !r[w] && (r = St(r)), i && !i[w] && (i = St(i, s)), at(function(s, o, u, a) {
                    var f, l, c, h = [],
                        p = [],
                        d = o.length,
                        v = s || wt(t || "*", u.nodeType ? [u] : u, []),
                        m = e && (s || !t) ? Et(v, h, e, u, a) : v,
                        g = n ? i || (s ? e : d || r) ? [] : o : m;
                    n && n(m, g, u, a);
                    if (r) {
                        f = Et(g, p), r(f, [], u, a), l = f.length;
                        while (l--)
                            if (c = f[l]) g[p[l]] = !(m[p[l]] = c)
                    }
                    if (s) {
                        if (i || e) {
                            if (i) {
                                f = [], l = g.length;
                                while (l--)(c = g[l]) && f.push(m[l] = c);
                                i(null, g = [], f, a)
                            }
                            l = g.length;
                            while (l--)(c = g[l]) && (f = i ? H(s, c) : h[l]) > -1 && (s[f] = !(o[f] = c))
                        }
                    } else g = Et(g === o ? g.splice(d, g.length) : g), i ? i(null, o, g, a) : D.apply(o, g)
                })
            }

            function xt(e) {
                var t, n, i, s = e.length,
                    o = r.relative[e[0].type],
                    u = o || r.relative[" "],
                    a = o ? 1 : 0,
                    l = yt(function(e) {
                        return e === t
                    }, u, !0),
                    c = yt(function(e) {
                        return H(t, e) > -1
                    }, u, !0),
                    h = [function(e, n, r) {
                        var i = !o && (r || n !== f) || ((t = n).nodeType ? l(e, n, r) : c(e, n, r));
                        return t = null, i
                    }];
                for (; a < s; a++)
                    if (n = r.relative[e[a].type]) h = [yt(bt(h), n)];
                    else {
                        n = r.filter[e[a].type].apply(null, e[a].matches);
                        if (n[w]) {
                            i = ++a;
                            for (; i < s; i++)
                                if (r.relative[e[i].type]) break;
                            return St(a > 1 && bt(h), a > 1 && gt(e.slice(0, a - 1).concat({
                                value: e[a - 2].type === " " ? "*" : ""
                            })).replace(z, "$1"), n, a < i && xt(e.slice(a, i)), i < s && xt(e = e.slice(i)), i < s && gt(e))
                        }
                        h.push(n)
                    } return bt(h)
            }

            function Tt(e, t) {
                var n = t.length > 0,
                    i = e.length > 0,
                    s = function(s, o, u, a, l) {
                        var c, h, d, v = 0,
                            m = "0",
                            g = s && [],
                            y = [],
                            b = f,
                            w = s || i && r.find.TAG("*", l),
                            E = S += b == null ? 1 : Math.random() || .1,
                            x = w.length;
                        l && (f = o !== p && o);
                        for (; m !== x && (c = w[m]) != null; m++) {
                            if (i && c) {
                                h = 0;
                                while (d = e[h++])
                                    if (d(c, o, u)) {
                                        a.push(c);
                                        break
                                    } l && (S = E)
                            }
                            n && ((c = !d && c) && v--, s && g.push(c))
                        }
                        v += m;
                        if (n && m !== v) {
                            h = 0;
                            while (d = t[h++]) d(g, y, o, u);
                            if (s) {
                                if (v > 0)
                                    while (m--) !g[m] && !y[m] && (y[m] = M.call(a));
                                y = Et(y)
                            }
                            D.apply(a, y), l && !s && y.length > 0 && v + t.length > 1 && ot.uniqueSort(a)
                        }
                        return l && (S = E, f = b), g
                    };
                return n ? at(s) : s
            }
            var t, n, r, i, s, o, u, a, f, l, c, h, p, d, v, m, g, y, b, w = "sizzle" + 1 * new Date,
                E = e.document,
                S = 0,
                x = 0,
                T = ut(),
                N = ut(),
                C = ut(),
                k = function(e, t) {
                    return e === t && (c = !0), 0
                },
                L = 1 << 31,
                A = {}.hasOwnProperty,
                O = [],
                M = O.pop,
                _ = O.push,
                D = O.push,
                P = O.slice,
                H = function(e, t) {
                    var n = 0,
                        r = e.length;
                    for (; n < r; n++)
                        if (e[n] === t) return n;
                    return -1
                },
                B = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                j = "[\\x20\\t\\r\\n\\f]",
                F = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
                I = F.replace("w", "w#"),
                q = "\\[" + j + "*(" + F + ")(?:" + j + "*([*^$|!~]?=)" + j + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + I + "))|)" + j + "*\\]",
                R = ":(" + F + ")(?:\\((" + "('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|" + "((?:\\\\.|[^\\\\()[\\]]|" + q + ")*)|" + ".*" + ")\\)|)",
                U = new RegExp(j + "+", "g"),
                z = new RegExp("^" + j + "+|((?:^|[^\\\\])(?:\\\\.)*)" + j + "+$", "g"),
                W = new RegExp("^" + j + "*," + j + "*"),
                X = new RegExp("^" + j + "*([>+~]|" + j + ")" + j + "*"),
                V = new RegExp("=" + j + "*([^\\]'\"]*?)" + j + "*\\]", "g"),
                $ = new RegExp(R),
                J = new RegExp("^" + I + "$"),
                K = {
                    ID: new RegExp("^#(" + F + ")"),
                    CLASS: new RegExp("^\\.(" + F + ")"),
                    TAG: new RegExp("^(" + F.replace("w", "w*") + ")"),
                    ATTR: new RegExp("^" + q),
                    PSEUDO: new RegExp("^" + R),
                    CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + j + "*(even|odd|(([+-]|)(\\d*)n|)" + j + "*(?:([+-]|)" + j + "*(\\d+)|))" + j + "*\\)|)", "i"),
                    bool: new RegExp("^(?:" + B + ")$", "i"),
                    needsContext: new RegExp("^" + j + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + j + "*((?:-\\d)?\\d*)" + j + "*\\)|)(?=[^-]|$)", "i")
                },
                Q = /^(?:input|select|textarea|button)$/i,
                G = /^h\d$/i,
                Y = /^[^{]+\{\s*\[native \w/,
                Z = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                et = /[+~]/,
                tt = /'|\\/g,
                nt = new RegExp("\\\\([\\da-f]{1,6}" + j + "?|(" + j + ")|.)", "ig"),
                rt = function(e, t, n) {
                    var r = "0x" + t - 65536;
                    return r !== r || n ? t : r < 0 ? String.fromCharCode(r + 65536) : String.fromCharCode(r >> 10 | 55296, r & 1023 | 56320)
                },
                it = function() {
                    h()
                };
            try {
                D.apply(O = P.call(E.childNodes), E.childNodes), O[E.childNodes.length].nodeType
            } catch (st) {
                D = {
                    apply: O.length ? function(e, t) {
                        _.apply(e, P.call(t))
                    } : function(e, t) {
                        var n = e.length,
                            r = 0;
                        while (e[n++] = t[r++]);
                        e.length = n - 1
                    }
                }
            }
            n = ot.support = {}, s = ot.isXML = function(e) {
                var t = e && (e.ownerDocument || e).documentElement;
                return t ? t.nodeName !== "HTML" : !1
            }, h = ot.setDocument = function(e) {
                var t, i, o = e ? e.ownerDocument || e : E;
                if (o === p || o.nodeType !== 9 || !o.documentElement) return p;
                p = o, d = o.documentElement, i = o.defaultView, i && i !== i.top && (i.addEventListener ? i.addEventListener("unload", it, !1) : i.attachEvent && i.attachEvent("onunload", it)), v = !s(o), n.attributes = ft(function(e) {
                    return e.className = "i", !e.getAttribute("className")
                }), n.getElementsByTagName = ft(function(e) {
                    return e.appendChild(o.createComment("")), !e.getElementsByTagName("*").length
                }), n.getElementsByClassName = Y.test(o.getElementsByClassName), n.getById = ft(function(e) {
                    return d.appendChild(e).id = w, !o.getElementsByName || !o.getElementsByName(w).length
                }), n.getById ? (r.find.ID = function(e, t) {
                    if (typeof t.getElementById != "undefined" && v) {
                        var n = t.getElementById(e);
                        return n && n.parentNode ? [n] : []
                    }
                }, r.filter.ID = function(e) {
                    var t = e.replace(nt, rt);
                    return function(e) {
                        return e.getAttribute("id") === t
                    }
                }) : (delete r.find.ID, r.filter.ID = function(e) {
                    var t = e.replace(nt, rt);
                    return function(e) {
                        var n = typeof e.getAttributeNode != "undefined" && e.getAttributeNode("id");
                        return n && n.value === t
                    }
                }), r.find.TAG = n.getElementsByTagName ? function(e, t) {
                    if (typeof t.getElementsByTagName != "undefined") return t.getElementsByTagName(e);
                    if (n.qsa) return t.querySelectorAll(e)
                } : function(e, t) {
                    var n, r = [],
                        i = 0,
                        s = t.getElementsByTagName(e);
                    if (e === "*") {
                        while (n = s[i++]) n.nodeType === 1 && r.push(n);
                        return r
                    }
                    return s
                }, r.find.CLASS = n.getElementsByClassName && function(e, t) {
                    if (v) return t.getElementsByClassName(e)
                }, g = [], m = [];
                if (n.qsa = Y.test(o.querySelectorAll)) ft(function(e) {
                    d.appendChild(e).innerHTML = "<a id='" + w + "'></a>" + "<select id='" + w + "-\f]' msallowcapture=''>" + "<option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && m.push("[*^$]=" + j + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || m.push("\\[" + j + "*(?:value|" + B + ")"), e.querySelectorAll("[id~=" + w + "-]").length || m.push("~="), e.querySelectorAll(":checked").length || m.push(":checked"), e.querySelectorAll("a#" + w + "+*").length || m.push(".#.+[+~]")
                }), ft(function(e) {
                    var t = o.createElement("input");
                    t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && m.push("name" + j + "*[*^$|!~]?="), e.querySelectorAll(":enabled").length || m.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), m.push(",.*:")
                });
                return (n.matchesSelector = Y.test(y = d.matches || d.webkitMatchesSelector || d.mozMatchesSelector || d.oMatchesSelector || d.msMatchesSelector)) && ft(function(e) {
                    n.disconnectedMatch = y.call(e, "div"), y.call(e, "[s!='']:x"), g.push("!=", R)
                }), m = m.length && new RegExp(m.join("|")), g = g.length && new RegExp(g.join("|")), t = Y.test(d.compareDocumentPosition), b = t || Y.test(d.contains) ? function(e, t) {
                    var n = e.nodeType === 9 ? e.documentElement : e,
                        r = t && t.parentNode;
                    return e === r || !!r && r.nodeType === 1 && !!(n.contains ? n.contains(r) : e.compareDocumentPosition && e.compareDocumentPosition(r) & 16)
                } : function(e, t) {
                    if (t)
                        while (t = t.parentNode)
                            if (t === e) return !0;
                    return !1
                }, k = t ? function(e, t) {
                    if (e === t) return c = !0, 0;
                    var r = !e.compareDocumentPosition - !t.compareDocumentPosition;
                    return r ? r : (r = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, r & 1 || !n.sortDetached && t.compareDocumentPosition(e) === r ? e === o || e.ownerDocument === E && b(E, e) ? -1 : t === o || t.ownerDocument === E && b(E, t) ? 1 : l ? H(l, e) - H(l, t) : 0 : r & 4 ? -1 : 1)
                } : function(e, t) {
                    if (e === t) return c = !0, 0;
                    var n, r = 0,
                        i = e.parentNode,
                        s = t.parentNode,
                        u = [e],
                        a = [t];
                    if (!i || !s) return e === o ? -1 : t === o ? 1 : i ? -1 : s ? 1 : l ? H(l, e) - H(l, t) : 0;
                    if (i === s) return ct(e, t);
                    n = e;
                    while (n = n.parentNode) u.unshift(n);
                    n = t;
                    while (n = n.parentNode) a.unshift(n);
                    while (u[r] === a[r]) r++;
                    return r ? ct(u[r], a[r]) : u[r] === E ? -1 : a[r] === E ? 1 : 0
                }, o
            }, ot.matches = function(e, t) {
                return ot(e, null, null, t)
            }, ot.matchesSelector = function(e, t) {
                (e.ownerDocument || e) !== p && h(e), t = t.replace(V, "='$1']");
                if (n.matchesSelector && v && (!g || !g.test(t)) && (!m || !m.test(t))) try {
                    var r = y.call(e, t);
                    if (r || n.disconnectedMatch || e.document && e.document.nodeType !== 11) return r
                } catch (i) {}
                return ot(t, p, null, [e]).length > 0
            }, ot.contains = function(e, t) {
                return (e.ownerDocument || e) !== p && h(e), b(e, t)
            }, ot.attr = function(e, t) {
                (e.ownerDocument || e) !== p && h(e);
                var i = r.attrHandle[t.toLowerCase()],
                    s = i && A.call(r.attrHandle, t.toLowerCase()) ? i(e, t, !v) : undefined;
                return s !== undefined ? s : n.attributes || !v ? e.getAttribute(t) : (s = e.getAttributeNode(t)) && s.specified ? s.value : null
            }, ot.error = function(e) {
                throw new Error("Syntax error, unrecognized expression: " + e)
            }, ot.uniqueSort = function(e) {
                var t, r = [],
                    i = 0,
                    s = 0;
                c = !n.detectDuplicates, l = !n.sortStable && e.slice(0), e.sort(k);
                if (c) {
                    while (t = e[s++]) t === e[s] && (i = r.push(s));
                    while (i--) e.splice(r[i], 1)
                }
                return l = null, e
            }, i = ot.getText = function(e) {
                var t, n = "",
                    r = 0,
                    s = e.nodeType;
                if (!s)
                    while (t = e[r++]) n += i(t);
                else if (s === 1 || s === 9 || s === 11) {
                    if (typeof e.textContent == "string") return e.textContent;
                    for (e = e.firstChild; e; e = e.nextSibling) n += i(e)
                } else if (s === 3 || s === 4) return e.nodeValue;
                return n
            }, r = ot.selectors = {
                cacheLength: 50,
                createPseudo: at,
                match: K,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(e) {
                        return e[1] = e[1].replace(nt, rt), e[3] = (e[3] || e[4] || e[5] || "").replace(nt, rt), e[2] === "~=" && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                    },
                    CHILD: function(e) {
                        return e[1] = e[1].toLowerCase(), e[1].slice(0, 3) === "nth" ? (e[3] || ot.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * (e[3] === "even" || e[3] === "odd")), e[5] = +(e[7] + e[8] || e[3] === "odd")) : e[3] && ot.error(e[0]), e
                    },
                    PSEUDO: function(e) {
                        var t, n = !e[6] && e[2];
                        return K.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && $.test(n) && (t = o(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(e) {
                        var t = e.replace(nt, rt).toLowerCase();
                        return e === "*" ? function() {
                            return !0
                        } : function(e) {
                            return e.nodeName && e.nodeName.toLowerCase() === t
                        }
                    },
                    CLASS: function(e) {
                        var t = T[e + " "];
                        return t || (t = new RegExp("(^|" + j + ")" + e + "(" + j + "|$)")) && T(e, function(e) {
                            return t.test(typeof e.className == "string" && e.className || typeof e.getAttribute != "undefined" && e.getAttribute("class") || "")
                        })
                    },
                    ATTR: function(e, t, n) {
                        return function(r) {
                            var i = ot.attr(r, e);
                            return i == null ? t === "!=" : t ? (i += "", t === "=" ? i === n : t === "!=" ? i !== n : t === "^=" ? n && i.indexOf(n) === 0 : t === "*=" ? n && i.indexOf(n) > -1 : t === "$=" ? n && i.slice(-n.length) === n : t === "~=" ? (" " + i.replace(U, " ") + " ").indexOf(n) > -1 : t === "|=" ? i === n || i.slice(0, n.length + 1) === n + "-" : !1) : !0
                        }
                    },
                    CHILD: function(e, t, n, r, i) {
                        var s = e.slice(0, 3) !== "nth",
                            o = e.slice(-4) !== "last",
                            u = t === "of-type";
                        return r === 1 && i === 0 ? function(e) {
                            return !!e.parentNode
                        } : function(t, n, a) {
                            var f, l, c, h, p, d, v = s !== o ? "nextSibling" : "previousSibling",
                                m = t.parentNode,
                                g = u && t.nodeName.toLowerCase(),
                                y = !a && !u;
                            if (m) {
                                if (s) {
                                    while (v) {
                                        c = t;
                                        while (c = c[v])
                                            if (u ? c.nodeName.toLowerCase() === g : c.nodeType === 1) return !1;
                                        d = v = e === "only" && !d && "nextSibling"
                                    }
                                    return !0
                                }
                                d = [o ? m.firstChild : m.lastChild];
                                if (o && y) {
                                    l = m[w] || (m[w] = {}), f = l[e] || [], p = f[0] === S && f[1], h = f[0] === S && f[2], c = p && m.childNodes[p];
                                    while (c = ++p && c && c[v] || (h = p = 0) || d.pop())
                                        if (c.nodeType === 1 && ++h && c === t) {
                                            l[e] = [S, p, h];
                                            break
                                        }
                                } else if (y && (f = (t[w] || (t[w] = {}))[e]) && f[0] === S) h = f[1];
                                else
                                    while (c = ++p && c && c[v] || (h = p = 0) || d.pop())
                                        if ((u ? c.nodeName.toLowerCase() === g : c.nodeType === 1) && ++h) {
                                            y && ((c[w] || (c[w] = {}))[e] = [S, h]);
                                            if (c === t) break
                                        } return h -= i, h === r || h % r === 0 && h / r >= 0
                            }
                        }
                    },
                    PSEUDO: function(e, t) {
                        var n, i = r.pseudos[e] || r.setFilters[e.toLowerCase()] || ot.error("unsupported pseudo: " + e);
                        return i[w] ? i(t) : i.length > 1 ? (n = [e, e, "", t], r.setFilters.hasOwnProperty(e.toLowerCase()) ? at(function(e, n) {
                            var r, s = i(e, t),
                                o = s.length;
                            while (o--) r = H(e, s[o]), e[r] = !(n[r] = s[o])
                        }) : function(e) {
                            return i(e, 0, n)
                        }) : i
                    }
                },
                pseudos: {
                    not: at(function(e) {
                        var t = [],
                            n = [],
                            r = u(e.replace(z, "$1"));
                        return r[w] ? at(function(e, t, n, i) {
                            var s, o = r(e, null, i, []),
                                u = e.length;
                            while (u--)
                                if (s = o[u]) e[u] = !(t[u] = s)
                        }) : function(e, i, s) {
                            return t[0] = e, r(t, null, s, n), t[0] = null, !n.pop()
                        }
                    }),
                    has: at(function(e) {
                        return function(t) {
                            return ot(e, t).length > 0
                        }
                    }),
                    contains: at(function(e) {
                        return e = e.replace(nt, rt),
                            function(t) {
                                return (t.textContent || t.innerText || i(t)).indexOf(e) > -1
                            }
                    }),
                    lang: at(function(e) {
                        return J.test(e || "") || ot.error("unsupported lang: " + e), e = e.replace(nt, rt).toLowerCase(),
                            function(t) {
                                var n;
                                do
                                    if (n = v ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return n = n.toLowerCase(), n === e || n.indexOf(e + "-") === 0; while ((t = t.parentNode) && t.nodeType === 1);
                                return !1
                            }
                    }),
                    target: function(t) {
                        var n = e.location && e.location.hash;
                        return n && n.slice(1) === t.id
                    },
                    root: function(e) {
                        return e === d
                    },
                    focus: function(e) {
                        return e === p.activeElement && (!p.hasFocus || p.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                    },
                    enabled: function(e) {
                        return e.disabled === !1
                    },
                    disabled: function(e) {
                        return e.disabled === !0
                    },
                    checked: function(e) {
                        var t = e.nodeName.toLowerCase();
                        return t === "input" && !!e.checked || t === "option" && !!e.selected
                    },
                    selected: function(e) {
                        return e.parentNode && e.parentNode.selectedIndex, e.selected === !0
                    },
                    empty: function(e) {
                        for (e = e.firstChild; e; e = e.nextSibling)
                            if (e.nodeType < 6) return !1;
                        return !0
                    },
                    parent: function(e) {
                        return !r.pseudos.empty(e)
                    },
                    header: function(e) {
                        return G.test(e.nodeName)
                    },
                    input: function(e) {
                        return Q.test(e.nodeName)
                    },
                    button: function(e) {
                        var t = e.nodeName.toLowerCase();
                        return t === "input" && e.type === "button" || t === "button"
                    },
                    text: function(e) {
                        var t;
                        return e.nodeName.toLowerCase() === "input" && e.type === "text" && ((t = e.getAttribute("type")) == null || t.toLowerCase() === "text")
                    },
                    first: dt(function() {
                        return [0]
                    }),
                    last: dt(function(e, t) {
                        return [t - 1]
                    }),
                    eq: dt(function(e, t, n) {
                        return [n < 0 ? n + t : n]
                    }),
                    even: dt(function(e, t) {
                        var n = 0;
                        for (; n < t; n += 2) e.push(n);
                        return e
                    }),
                    odd: dt(function(e, t) {
                        var n = 1;
                        for (; n < t; n += 2) e.push(n);
                        return e
                    }),
                    lt: dt(function(e, t, n) {
                        var r = n < 0 ? n + t : n;
                        for (; --r >= 0;) e.push(r);
                        return e
                    }),
                    gt: dt(function(e, t, n) {
                        var r = n < 0 ? n + t : n;
                        for (; ++r < t;) e.push(r);
                        return e
                    })
                }
            }, r.pseudos.nth = r.pseudos.eq;
            for (t in {
                    radio: !0,
                    checkbox: !0,
                    file: !0,
                    password: !0,
                    image: !0
                }) r.pseudos[t] = ht(t);
            for (t in {
                    submit: !0,
                    reset: !0
                }) r.pseudos[t] = pt(t);
            return mt.prototype = r.filters = r.pseudos, r.setFilters = new mt, o = ot.tokenize = function(e, t) {
                var n, i, s, o, u, a, f, l = N[e + " "];
                if (l) return t ? 0 : l.slice(0);
                u = e, a = [], f = r.preFilter;
                while (u) {
                    if (!n || (i = W.exec(u))) i && (u = u.slice(i[0].length) || u), a.push(s = []);
                    n = !1;
                    if (i = X.exec(u)) n = i.shift(), s.push({
                        value: n,
                        type: i[0].replace(z, " ")
                    }), u = u.slice(n.length);
                    for (o in r.filter)(i = K[o].exec(u)) && (!f[o] || (i = f[o](i))) && (n = i.shift(), s.push({
                        value: n,
                        type: o,
                        matches: i
                    }), u = u.slice(n.length));
                    if (!n) break
                }
                return t ? u.length : u ? ot.error(e) : N(e, a).slice(0)
            }, u = ot.compile = function(e, t) {
                var n, r = [],
                    i = [],
                    s = C[e + " "];
                if (!s) {
                    t || (t = o(e)), n = t.length;
                    while (n--) s = xt(t[n]), s[w] ? r.push(s) : i.push(s);
                    s = C(e, Tt(i, r)), s.selector = e
                }
                return s
            }, a = ot.select = function(e, t, i, s) {
                var a, f, l, c, h, p = typeof e == "function" && e,
                    d = !s && o(e = p.selector || e);
                i = i || [];
                if (d.length === 1) {
                    f = d[0] = d[0].slice(0);
                    if (f.length > 2 && (l = f[0]).type === "ID" && n.getById && t.nodeType === 9 && v && r.relative[f[1].type]) {
                        t = (r.find.ID(l.matches[0].replace(nt, rt), t) || [])[0];
                        if (!t) return i;
                        p && (t = t.parentNode), e = e.slice(f.shift().value.length)
                    }
                    a = K.needsContext.test(e) ? 0 : f.length;
                    while (a--) {
                        l = f[a];
                        if (r.relative[c = l.type]) break;
                        if (h = r.find[c])
                            if (s = h(l.matches[0].replace(nt, rt), et.test(f[0].type) && vt(t.parentNode) || t)) {
                                f.splice(a, 1), e = s.length && gt(f);
                                if (!e) return D.apply(i, s), i;
                                break
                            }
                    }
                }
                return (p || u(e, d))(s, t, !v, i, et.test(e) && vt(t.parentNode) || t), i
            }, n.sortStable = w.split("").sort(k).join("") === w, n.detectDuplicates = !!c, h(), n.sortDetached = ft(function(e) {
                return e.compareDocumentPosition(p.createElement("div")) & 1
            }), ft(function(e) {
                return e.innerHTML = "<a href='#'></a>", e.firstChild.getAttribute("href") === "#"
            }) || lt("type|href|height|width", function(e, t, n) {
                if (!n) return e.getAttribute(t, t.toLowerCase() === "type" ? 1 : 2)
            }), (!n.attributes || !ft(function(e) {
                return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), e.firstChild.getAttribute("value") === ""
            })) && lt("value", function(e, t, n) {
                if (!n && e.nodeName.toLowerCase() === "input") return e.defaultValue
            }), ft(function(e) {
                return e.getAttribute("disabled") == null
            }) || lt(B, function(e, t, n) {
                var r;
                if (!n) return e[t] === !0 ? t.toLowerCase() : (r = e.getAttributeNode(t)) && r.specified ? r.value : null
            }), ot
        }(window);
        jQuery.find = Sizzle, jQuery.expr = Sizzle.selectors, jQuery.expr[":"] = jQuery.expr.pseudos, jQuery.unique = Sizzle.uniqueSort, jQuery.text = Sizzle.getText, jQuery.isXMLDoc = Sizzle.isXML, jQuery.contains = Sizzle.contains;
        var rneedsContext = jQuery.expr.match.needsContext,
            rsingleTag = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
            risSimple = /^.[^:#\[\.,]*$/;
        jQuery.filter = function(e, t, n) {
            var r = t[0];
            return n && (e = ":not(" + e + ")"), t.length === 1 && r.nodeType === 1 ? jQuery.find.matchesSelector(r, e) ? [r] : [] : jQuery.find.matches(e, jQuery.grep(t, function(e) {
                return e.nodeType === 1
            }))
        }, jQuery.fn.extend({
            find: function(e) {
                var t, n = this.length,
                    r = [],
                    i = this;
                if (typeof e != "string") return this.pushStack(jQuery(e).filter(function() {
                    for (t = 0; t < n; t++)
                        if (jQuery.contains(i[t], this)) return !0
                }));
                for (t = 0; t < n; t++) jQuery.find(e, i[t], r);
                return r = this.pushStack(n > 1 ? jQuery.unique(r) : r), r.selector = this.selector ? this.selector + " " + e : e, r
            },
            filter: function(e) {
                return this.pushStack(winnow(this, e || [], !1))
            },
            not: function(e) {
                return this.pushStack(winnow(this, e || [], !0))
            },
            is: function(e) {
                return !!winnow(this, typeof e == "string" && rneedsContext.test(e) ? jQuery(e) : e || [], !1).length
            }
        });
        var rootjQuery, rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
            init = jQuery.fn.init = function(e, t) {
                var n, r;
                if (!e) return this;
                if (typeof e == "string") {
                    e[0] === "<" && e[e.length - 1] === ">" && e.length >= 3 ? n = [null, e, null] : n = rquickExpr.exec(e);
                    if (n && (n[1] || !t)) {
                        if (n[1]) {
                            t = t instanceof jQuery ? t[0] : t, jQuery.merge(this, jQuery.parseHTML(n[1], t && t.nodeType ? t.ownerDocument || t : document, !0));
                            if (rsingleTag.test(n[1]) && jQuery.isPlainObject(t))
                                for (n in t) jQuery.isFunction(this[n]) ? this[n](t[n]) : this.attr(n, t[n]);
                            return this
                        }
                        return r = document.getElementById(n[2]), r && r.parentNode && (this.length = 1, this[0] = r), this.context = document, this.selector = e, this
                    }
                    return !t || t.jquery ? (t || rootjQuery).find(e) : this.constructor(t).find(e)
                }
                return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : jQuery.isFunction(e) ? typeof rootjQuery.ready != "undefined" ? rootjQuery.ready(e) : e(jQuery) : (e.selector !== undefined && (this.selector = e.selector, this.context = e.context), jQuery.makeArray(e, this))
            };
        init.prototype = jQuery.fn, rootjQuery = jQuery(document);
        var rparentsprev = /^(?:parents|prev(?:Until|All))/,
            guaranteedUnique = {
                children: !0,
                contents: !0,
                next: !0,
                prev: !0
            };
        jQuery.extend({
            dir: function(e, t, n) {
                var r = [],
                    i = n !== undefined;
                while ((e = e[t]) && e.nodeType !== 9)
                    if (e.nodeType === 1) {
                        if (i && jQuery(e).is(n)) break;
                        r.push(e)
                    } return r
            },
            sibling: function(e, t) {
                var n = [];
                for (; e; e = e.nextSibling) e.nodeType === 1 && e !== t && n.push(e);
                return n
            }
        }), jQuery.fn.extend({
            has: function(e) {
                var t = jQuery(e, this),
                    n = t.length;
                return this.filter(function() {
                    var e = 0;
                    for (; e < n; e++)
                        if (jQuery.contains(this, t[e])) return !0
                })
            },
            closest: function(e, t) {
                var n, r = 0,
                    i = this.length,
                    s = [],
                    o = rneedsContext.test(e) || typeof e != "string" ? jQuery(e, t || this.context) : 0;
                for (; r < i; r++)
                    for (n = this[r]; n && n !== t; n = n.parentNode)
                        if (n.nodeType < 11 && (o ? o.index(n) > -1 : n.nodeType === 1 && jQuery.find.matchesSelector(n, e))) {
                            s.push(n);
                            break
                        } return this.pushStack(s.length > 1 ? jQuery.unique(s) : s)
            },
            index: function(e) {
                return e ? typeof e == "string" ? indexOf.call(jQuery(e), this[0]) : indexOf.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
            },
            add: function(e, t) {
                return this.pushStack(jQuery.unique(jQuery.merge(this.get(), jQuery(e, t))))
            },
            addBack: function(e) {
                return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
            }
        }), jQuery.each({
            parent: function(e) {
                var t = e.parentNode;
                return t && t.nodeType !== 11 ? t : null
            },
            parents: function(e) {
                return jQuery.dir(e, "parentNode")
            },
            parentsUntil: function(e, t, n) {
                return jQuery.dir(e, "parentNode", n)
            },
            next: function(e) {
                return sibling(e, "nextSibling")
            },
            prev: function(e) {
                return sibling(e, "previousSibling")
            },
            nextAll: function(e) {
                return jQuery.dir(e, "nextSibling")
            },
            prevAll: function(e) {
                return jQuery.dir(e, "previousSibling")
            },
            nextUntil: function(e, t, n) {
                return jQuery.dir(e, "nextSibling", n)
            },
            prevUntil: function(e, t, n) {
                return jQuery.dir(e, "previousSibling", n)
            },
            siblings: function(e) {
                return jQuery.sibling((e.parentNode || {}).firstChild, e)
            },
            children: function(e) {
                return jQuery.sibling(e.firstChild)
            },
            contents: function(e) {
                return e.contentDocument || jQuery.merge([], e.childNodes)
            }
        }, function(e, t) {
            jQuery.fn[e] = function(n, r) {
                var i = jQuery.map(this, t, n);
                return e.slice(-5) !== "Until" && (r = n), r && typeof r == "string" && (i = jQuery.filter(r, i)), this.length > 1 && (guaranteedUnique[e] || jQuery.unique(i), rparentsprev.test(e) && i.reverse()), this.pushStack(i)
            }
        });
        var rnotwhite = /\S+/g,
            optionsCache = {};
        jQuery.Callbacks = function(e) {
            e = typeof e == "string" ? optionsCache[e] || createOptions(e) : jQuery.extend({}, e);
            var t, n, r, i, s, o, u = [],
                a = !e.once && [],
                f = function(c) {
                    t = e.memory && c, n = !0, o = i || 0, i = 0, s = u.length, r = !0;
                    for (; u && o < s; o++)
                        if (u[o].apply(c[0], c[1]) === !1 && e.stopOnFalse) {
                            t = !1;
                            break
                        } r = !1, u && (a ? a.length && f(a.shift()) : t ? u = [] : l.disable())
                },
                l = {
                    add: function() {
                        if (u) {
                            var n = u.length;
                            (function o(t) {
                                jQuery.each(t, function(t, n) {
                                    var r = jQuery.type(n);
                                    r === "function" ? (!e.unique || !l.has(n)) && u.push(n) : n && n.length && r !== "string" && o(n)
                                })
                            })(arguments), r ? s = u.length : t && (i = n, f(t))
                        }
                        return this
                    },
                    remove: function() {
                        return u && jQuery.each(arguments, function(e, t) {
                            var n;
                            while ((n = jQuery.inArray(t, u, n)) > -1) u.splice(n, 1), r && (n <= s && s--, n <= o && o--)
                        }), this
                    },
                    has: function(e) {
                        return e ? jQuery.inArray(e, u) > -1 : !!u && !!u.length
                    },
                    empty: function() {
                        return u = [], s = 0, this
                    },
                    disable: function() {
                        return u = a = t = undefined, this
                    },
                    disabled: function() {
                        return !u
                    },
                    lock: function() {
                        return a = undefined, t || l.disable(), this
                    },
                    locked: function() {
                        return !a
                    },
                    fireWith: function(e, t) {
                        return u && (!n || a) && (t = t || [], t = [e, t.slice ? t.slice() : t], r ? a.push(t) : f(t)), this
                    },
                    fire: function() {
                        return l.fireWith(this, arguments), this
                    },
                    fired: function() {
                        return !!n
                    }
                };
            return l
        }, jQuery.extend({
            Deferred: function(e) {
                var t = [
                        ["resolve", "done", jQuery.Callbacks("once memory"), "resolved"],
                        ["reject", "fail", jQuery.Callbacks("once memory"), "rejected"],
                        ["notify", "progress", jQuery.Callbacks("memory")]
                    ],
                    n = "pending",
                    r = {
                        state: function() {
                            return n
                        },
                        always: function() {
                            return i.done(arguments).fail(arguments), this
                        },
                        then: function() {
                            var e = arguments;
                            return jQuery.Deferred(function(n) {
                                jQuery.each(t, function(t, s) {
                                    var o = jQuery.isFunction(e[t]) && e[t];
                                    i[s[1]](function() {
                                        var e = o && o.apply(this, arguments);
                                        e && jQuery.isFunction(e.promise) ? e.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[s[0] + "With"](this === r ? n.promise() : this, o ? [e] : arguments)
                                    })
                                }), e = null
                            }).promise()
                        },
                        promise: function(e) {
                            return e != null ? jQuery.extend(e, r) : r
                        }
                    },
                    i = {};
                return r.pipe = r.then, jQuery.each(t, function(e, s) {
                    var o = s[2],
                        u = s[3];
                    r[s[1]] = o.add, u && o.add(function() {
                        n = u
                    }, t[e ^ 1][2].disable, t[2][2].lock), i[s[0]] = function() {
                        return i[s[0] + "With"](this === i ? r : this, arguments), this
                    }, i[s[0] + "With"] = o.fireWith
                }), r.promise(i), e && e.call(i, i), i
            },
            when: function(e) {
                var t = 0,
                    n = slice.call(arguments),
                    r = n.length,
                    i = r !== 1 || e && jQuery.isFunction(e.promise) ? r : 0,
                    s = i === 1 ? e : jQuery.Deferred(),
                    o = function(e, t, n) {
                        return function(r) {
                            t[e] = this, n[e] = arguments.length > 1 ? slice.call(arguments) : r, n === u ? s.notifyWith(t, n) : --i || s.resolveWith(t, n)
                        }
                    },
                    u, a, f;
                if (r > 1) {
                    u = new Array(r), a = new Array(r), f = new Array(r);
                    for (; t < r; t++) n[t] && jQuery.isFunction(n[t].promise) ? n[t].promise().done(o(t, f, n)).fail(s.reject).progress(o(t, a, u)) : --i
                }
                return i || s.resolveWith(f, n), s.promise()
            }
        });
        var readyList;
        jQuery.fn.ready = function(e) {
            return jQuery.ready.promise().done(e), this
        }, jQuery.extend({
            isReady: !1,
            readyWait: 1,
            holdReady: function(e) {
                e ? jQuery.readyWait++ : jQuery.ready(!0)
            },
            ready: function(e) {
                if (e === !0 ? --jQuery.readyWait : jQuery.isReady) return;
                jQuery.isReady = !0;
                if (e !== !0 && --jQuery.readyWait > 0) return;
                readyList.resolveWith(document, [jQuery]), jQuery.fn.triggerHandler && (jQuery(document).triggerHandler("ready"), jQuery(document).off("ready"))
            }
        }), jQuery.ready.promise = function(e) {
            return readyList || (readyList = jQuery.Deferred(), document.readyState === "complete" ? setTimeout(jQuery.ready) : (document.addEventListener("DOMContentLoaded", completed, !1), window.addEventListener("load", completed, !1))), readyList.promise(e)
        }, jQuery.ready.promise();
        var access = jQuery.access = function(e, t, n, r, i, s, o) {
            var u = 0,
                a = e.length,
                f = n == null;
            if (jQuery.type(n) === "object") {
                i = !0;
                for (u in n) jQuery.access(e, t, u, n[u], !0, s, o)
            } else if (r !== undefined) {
                i = !0, jQuery.isFunction(r) || (o = !0), f && (o ? (t.call(e, r), t = null) : (f = t, t = function(e, t, n) {
                    return f.call(jQuery(e), n)
                }));
                if (t)
                    for (; u < a; u++) t(e[u], n, o ? r : r.call(e[u], u, t(e[u], n)))
            }
            return i ? e : f ? t.call(e) : a ? t(e[0], n) : s
        };
        jQuery.acceptData = function(e) {
            return e.nodeType === 1 || e.nodeType === 9 || !+e.nodeType
        }, Data.uid = 1, Data.accepts = jQuery.acceptData, Data.prototype = {
            key: function(e) {
                if (!Data.accepts(e)) return 0;
                var t = {},
                    n = e[this.expando];
                if (!n) {
                    n = Data.uid++;
                    try {
                        t[this.expando] = {
                            value: n
                        }, Object.defineProperties(e, t)
                    } catch (r) {
                        t[this.expando] = n, jQuery.extend(e, t)
                    }
                }
                return this.cache[n] || (this.cache[n] = {}), n
            },
            set: function(e, t, n) {
                var r, i = this.key(e),
                    s = this.cache[i];
                if (typeof t == "string") s[t] = n;
                else if (jQuery.isEmptyObject(s)) jQuery.extend(this.cache[i], t);
                else
                    for (r in t) s[r] = t[r];
                return s
            },
            get: function(e, t) {
                var n = this.cache[this.key(e)];
                return t === undefined ? n : n[t]
            },
            access: function(e, t, n) {
                var r;
                return t === undefined || t && typeof t == "string" && n === undefined ? (r = this.get(e, t), r !== undefined ? r : this.get(e, jQuery.camelCase(t))) : (this.set(e, t, n), n !== undefined ? n : t)
            },
            remove: function(e, t) {
                var n, r, i, s = this.key(e),
                    o = this.cache[s];
                if (t === undefined) this.cache[s] = {};
                else {
                    jQuery.isArray(t) ? r = t.concat(t.map(jQuery.camelCase)) : (i = jQuery.camelCase(t), t in o ? r = [t, i] : (r = i, r = r in o ? [r] : r.match(rnotwhite) || [])), n = r.length;
                    while (n--) delete o[r[n]]
                }
            },
            hasData: function(e) {
                return !jQuery.isEmptyObject(this.cache[e[this.expando]] || {})
            },
            discard: function(e) {
                e[this.expando] && delete this.cache[e[this.expando]]
            }
        };
        var data_priv = new Data,
            data_user = new Data,
            rbrace = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
            rmultiDash = /([A-Z])/g;
        jQuery.extend({
            hasData: function(e) {
                return data_user.hasData(e) || data_priv.hasData(e)
            },
            data: function(e, t, n) {
                return data_user.access(e, t, n)
            },
            removeData: function(e, t) {
                data_user.remove(e, t)
            },
            _data: function(e, t, n) {
                return data_priv.access(e, t, n)
            },
            _removeData: function(e, t) {
                data_priv.remove(e, t)
            }
        }), jQuery.fn.extend({
            data: function(e, t) {
                var n, r, i, s = this[0],
                    o = s && s.attributes;
                if (e === undefined) {
                    if (this.length) {
                        i = data_user.get(s);
                        if (s.nodeType === 1 && !data_priv.get(s, "hasDataAttrs")) {
                            n = o.length;
                            while (n--) o[n] && (r = o[n].name, r.indexOf("data-") === 0 && (r = jQuery.camelCase(r.slice(5)), dataAttr(s, r, i[r])));
                            data_priv.set(s, "hasDataAttrs", !0)
                        }
                    }
                    return i
                }
                return typeof e == "object" ? this.each(function() {
                    data_user.set(this, e)
                }) : access(this, function(t) {
                    var n, r = jQuery.camelCase(e);
                    if (s && t === undefined) {
                        n = data_user.get(s, e);
                        if (n !== undefined) return n;
                        n = data_user.get(s, r);
                        if (n !== undefined) return n;
                        n = dataAttr(s, r, undefined);
                        if (n !== undefined) return n;
                        return
                    }
                    this.each(function() {
                        var n = data_user.get(this, r);
                        data_user.set(this, r, t), e.indexOf("-") !== -1 && n !== undefined && data_user.set(this, e, t)
                    })
                }, null, t, arguments.length > 1, null, !0)
            },
            removeData: function(e) {
                return this.each(function() {
                    data_user.remove(this, e)
                })
            }
        }), jQuery.extend({
            queue: function(e, t, n) {
                var r;
                if (e) return t = (t || "fx") + "queue", r = data_priv.get(e, t), n && (!r || jQuery.isArray(n) ? r = data_priv.access(e, t, jQuery.makeArray(n)) : r.push(n)), r || []
            },
            dequeue: function(e, t) {
                t = t || "fx";
                var n = jQuery.queue(e, t),
                    r = n.length,
                    i = n.shift(),
                    s = jQuery._queueHooks(e, t),
                    o = function() {
                        jQuery.dequeue(e, t)
                    };
                i === "inprogress" && (i = n.shift(), r--), i && (t === "fx" && n.unshift("inprogress"), delete s.stop, i.call(e, o, s)), !r && s && s.empty.fire()
            },
            _queueHooks: function(e, t) {
                var n = t + "queueHooks";
                return data_priv.get(e, n) || data_priv.access(e, n, {
                    empty: jQuery.Callbacks("once memory").add(function() {
                        data_priv.remove(e, [t + "queue", n])
                    })
                })
            }
        }), jQuery.fn.extend({
            queue: function(e, t) {
                var n = 2;
                return typeof e != "string" && (t = e, e = "fx", n--), arguments.length < n ? jQuery.queue(this[0], e) : t === undefined ? this : this.each(function() {
                    var n = jQuery.queue(this, e, t);
                    jQuery._queueHooks(this, e), e === "fx" && n[0] !== "inprogress" && jQuery.dequeue(this, e)
                })
            },
            dequeue: function(e) {
                return this.each(function() {
                    jQuery.dequeue(this, e)
                })
            },
            clearQueue: function(e) {
                return this.queue(e || "fx", [])
            },
            promise: function(e, t) {
                var n, r = 1,
                    i = jQuery.Deferred(),
                    s = this,
                    o = this.length,
                    u = function() {
                        --r || i.resolveWith(s, [s])
                    };
                typeof e != "string" && (t = e, e = undefined), e = e || "fx";
                while (o--) n = data_priv.get(s[o], e + "queueHooks"), n && n.empty && (r++, n.empty.add(u));
                return u(), i.promise(t)
            }
        });
        var pnum = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
            cssExpand = ["Top", "Right", "Bottom", "Left"],
            isHidden = function(e, t) {
                return e = t || e, jQuery.css(e, "display") === "none" || !jQuery.contains(e.ownerDocument, e)
            },
            rcheckableType = /^(?:checkbox|radio)$/i;
        (function() {
            var e = document.createDocumentFragment(),
                t = e.appendChild(document.createElement("div")),
                n = document.createElement("input");
            n.setAttribute("type", "radio"), n.setAttribute("checked", "checked"), n.setAttribute("name", "t"), t.appendChild(n), support.checkClone = t.cloneNode(!0).cloneNode(!0).lastChild.checked, t.innerHTML = "<textarea>x</textarea>", support.noCloneChecked = !!t.cloneNode(!0).lastChild.defaultValue
        })();
        var strundefined = typeof undefined;
        support.focusinBubbles = "onfocusin" in window;
        var rkeyEvent = /^key/,
            rmouseEvent = /^(?:mouse|pointer|contextmenu)|click/,
            rfocusMorph = /^(?:focusinfocus|focusoutblur)$/,
            rtypenamespace = /^([^.]*)(?:\.(.+)|)$/;
        jQuery.event = {
            global: {},
            add: function(e, t, n, r, i) {
                var s, o, u, a, f, l, c, h, p, d, v, m = data_priv.get(e);
                if (!m) return;
                n.handler && (s = n, n = s.handler, i = s.selector), n.guid || (n.guid = jQuery.guid++), (a = m.events) || (a = m.events = {}), (o = m.handle) || (o = m.handle = function(t) {
                    return typeof jQuery !== strundefined && jQuery.event.triggered !== t.type ? jQuery.event.dispatch.apply(e, arguments) : undefined
                }), t = (t || "").match(rnotwhite) || [""], f = t.length;
                while (f--) {
                    u = rtypenamespace.exec(t[f]) || [], p = v = u[1], d = (u[2] || "").split(".").sort();
                    if (!p) continue;
                    c = jQuery.event.special[p] || {}, p = (i ? c.delegateType : c.bindType) || p, c = jQuery.event.special[p] || {}, l = jQuery.extend({
                        type: p,
                        origType: v,
                        data: r,
                        handler: n,
                        guid: n.guid,
                        selector: i,
                        needsContext: i && jQuery.expr.match.needsContext.test(i),
                        namespace: d.join(".")
                    }, s), (h = a[p]) || (h = a[p] = [], h.delegateCount = 0, (!c.setup || c.setup.call(e, r, d, o) === !1) && e.addEventListener && e.addEventListener(p, o, !1)), c.add && (c.add.call(e, l), l.handler.guid || (l.handler.guid = n.guid)), i ? h.splice(h.delegateCount++, 0, l) : h.push(l), jQuery.event.global[p] = !0
                }
            },
            remove: function(e, t, n, r, i) {
                var s, o, u, a, f, l, c, h, p, d, v, m = data_priv.hasData(e) && data_priv.get(e);
                if (!m || !(a = m.events)) return;
                t = (t || "").match(rnotwhite) || [""], f = t.length;
                while (f--) {
                    u = rtypenamespace.exec(t[f]) || [], p = v = u[1], d = (u[2] || "").split(".").sort();
                    if (!p) {
                        for (p in a) jQuery.event.remove(e, p + t[f], n, r, !0);
                        continue
                    }
                    c = jQuery.event.special[p] || {}, p = (r ? c.delegateType : c.bindType) || p, h = a[p] || [], u = u[2] && new RegExp("(^|\\.)" + d.join("\\.(?:.*\\.|)") + "(\\.|$)"), o = s = h.length;
                    while (s--) l = h[s], (i || v === l.origType) && (!n || n.guid === l.guid) && (!u || u.test(l.namespace)) && (!r || r === l.selector || r === "**" && l.selector) && (h.splice(s, 1), l.selector && h.delegateCount--, c.remove && c.remove.call(e, l));
                    o && !h.length && ((!c.teardown || c.teardown.call(e, d, m.handle) === !1) && jQuery.removeEvent(e, p, m.handle), delete a[p])
                }
                jQuery.isEmptyObject(a) && (delete m.handle, data_priv.remove(e, "events"))
            },
            trigger: function(e, t, n, r) {
                var i, s, o, u, a, f, l, c = [n || document],
                    h = hasOwn.call(e, "type") ? e.type : e,
                    p = hasOwn.call(e, "namespace") ? e.namespace.split(".") : [];
                s = o = n = n || document;
                if (n.nodeType === 3 || n.nodeType === 8) return;
                if (rfocusMorph.test(h + jQuery.event.triggered)) return;
                h.indexOf(".") >= 0 && (p = h.split("."), h = p.shift(), p.sort()), a = h.indexOf(":") < 0 && "on" + h, e = e[jQuery.expando] ? e : new jQuery.Event(h, typeof e == "object" && e), e.isTrigger = r ? 2 : 3, e.namespace = p.join("."), e.namespace_re = e.namespace ? new RegExp("(^|\\.)" + p.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = undefined, e.target || (e.target = n), t = t == null ? [e] : jQuery.makeArray(t, [e]), l = jQuery.event.special[h] || {};
                if (!r && l.trigger && l.trigger.apply(n, t) === !1) return;
                if (!r && !l.noBubble && !jQuery.isWindow(n)) {
                    u = l.delegateType || h, rfocusMorph.test(u + h) || (s = s.parentNode);
                    for (; s; s = s.parentNode) c.push(s), o = s;
                    o === (n.ownerDocument || document) && c.push(o.defaultView || o.parentWindow || window)
                }
                i = 0;
                while ((s = c[i++]) && !e.isPropagationStopped()) e.type = i > 1 ? u : l.bindType || h, f = (data_priv.get(s, "events") || {})[e.type] && data_priv.get(s, "handle"), f && f.apply(s, t), f = a && s[a], f && f.apply && jQuery.acceptData(s) && (e.result = f.apply(s, t), e.result === !1 && e.preventDefault());
                return e.type = h, !r && !e.isDefaultPrevented() && (!l._default || l._default.apply(c.pop(), t) === !1) && jQuery.acceptData(n) && a && jQuery.isFunction(n[h]) && !jQuery.isWindow(n) && (o = n[a], o && (n[a] = null), jQuery.event.triggered = h, n[h](), jQuery.event.triggered = undefined, o && (n[a] = o)), e.result
            },
            dispatch: function(e) {
                e = jQuery.event.fix(e);
                var t, n, r, i, s, o = [],
                    u = slice.call(arguments),
                    a = (data_priv.get(this, "events") || {})[e.type] || [],
                    f = jQuery.event.special[e.type] || {};
                u[0] = e, e.delegateTarget = this;
                if (f.preDispatch && f.preDispatch.call(this, e) === !1) return;
                o = jQuery.event.handlers.call(this, e, a), t = 0;
                while ((i = o[t++]) && !e.isPropagationStopped()) {
                    e.currentTarget = i.elem, n = 0;
                    while ((s = i.handlers[n++]) && !e.isImmediatePropagationStopped())
                        if (!e.namespace_re || e.namespace_re.test(s.namespace)) e.handleObj = s, e.data = s.data, r = ((jQuery.event.special[s.origType] || {}).handle || s.handler).apply(i.elem, u), r !== undefined && (e.result = r) === !1 && (e.preventDefault(), e.stopPropagation())
                }
                return f.postDispatch && f.postDispatch.call(this, e), e.result
            },
            handlers: function(e, t) {
                var n, r, i, s, o = [],
                    u = t.delegateCount,
                    a = e.target;
                if (u && a.nodeType && (!e.button || e.type !== "click"))
                    for (; a !== this; a = a.parentNode || this)
                        if (a.disabled !== !0 || e.type !== "click") {
                            r = [];
                            for (n = 0; n < u; n++) s = t[n], i = s.selector + " ", r[i] === undefined && (r[i] = s.needsContext ? jQuery(i, this).index(a) >= 0 : jQuery.find(i, this, null, [a]).length), r[i] && r.push(s);
                            r.length && o.push({
                                elem: a,
                                handlers: r
                            })
                        } return u < t.length && o.push({
                    elem: this,
                    handlers: t.slice(u)
                }), o
            },
            props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
            fixHooks: {},
            keyHooks: {
                props: "char charCode key keyCode".split(" "),
                filter: function(e, t) {
                    return e.which == null && (e.which = t.charCode != null ? t.charCode : t.keyCode), e
                }
            },
            mouseHooks: {
                props: "button buttons clientX clientY offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
                filter: function(e, t) {
                    var n, r, i, s = t.button;
                    return e.pageX == null && t.clientX != null && (n = e.target.ownerDocument || document, r = n.documentElement, i = n.body, e.pageX = t.clientX + (r && r.scrollLeft || i && i.scrollLeft || 0) - (r && r.clientLeft || i && i.clientLeft || 0), e.pageY = t.clientY + (r && r.scrollTop || i && i.scrollTop || 0) - (r && r.clientTop || i && i.clientTop || 0)), !e.which && s !== undefined && (e.which = s & 1 ? 1 : s & 2 ? 3 : s & 4 ? 2 : 0), e
                }
            },
            fix: function(e) {
                if (e[jQuery.expando]) return e;
                var t, n, r, i = e.type,
                    s = e,
                    o = this.fixHooks[i];
                o || (this.fixHooks[i] = o = rmouseEvent.test(i) ? this.mouseHooks : rkeyEvent.test(i) ? this.keyHooks : {}), r = o.props ? this.props.concat(o.props) : this.props, e = new jQuery.Event(s), t = r.length;
                while (t--) n = r[t], e[n] = s[n];
                return e.target || (e.target = document), e.target.nodeType === 3 && (e.target = e.target.parentNode), o.filter ? o.filter(e, s) : e
            },
            special: {
                load: {
                    noBubble: !0
                },
                focus: {
                    trigger: function() {
                        if (this !== safeActiveElement() && this.focus) return this.focus(), !1
                    },
                    delegateType: "focusin"
                },
                blur: {
                    trigger: function() {
                        if (this === safeActiveElement() && this.blur) return this.blur(), !1
                    },
                    delegateType: "focusout"
                },
                click: {
                    trigger: function() {
                        if (this.type === "checkbox" && this.click && jQuery.nodeName(this, "input")) return this.click(), !1
                    },
                    _default: function(e) {
                        return jQuery.nodeName(e.target, "a")
                    }
                },
                beforeunload: {
                    postDispatch: function(e) {
                        e.result !== undefined && e.originalEvent && (e.originalEvent.returnValue = e.result)
                    }
                }
            },
            simulate: function(e, t, n, r) {
                var i = jQuery.extend(new jQuery.Event, n, {
                    type: e,
                    isSimulated: !0,
                    originalEvent: {}
                });
                r ? jQuery.event.trigger(i, null, t) : jQuery.event.dispatch.call(t, i), i.isDefaultPrevented() && n.preventDefault()
            }
        }, jQuery.removeEvent = function(e, t, n) {
            e.removeEventListener && e.removeEventListener(t, n, !1)
        }, jQuery.Event = function(e, t) {
            if (!(this instanceof jQuery.Event)) return new jQuery.Event(e, t);
            e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || e.defaultPrevented === undefined && e.returnValue === !1 ? returnTrue : returnFalse) : this.type = e, t && jQuery.extend(this, t), this.timeStamp = e && e.timeStamp || jQuery.now(), this[jQuery.expando] = !0
        }, jQuery.Event.prototype = {
            isDefaultPrevented: returnFalse,
            isPropagationStopped: returnFalse,
            isImmediatePropagationStopped: returnFalse,
            preventDefault: function() {
                var e = this.originalEvent;
                this.isDefaultPrevented = returnTrue, e && e.preventDefault && e.preventDefault()
            },
            stopPropagation: function() {
                var e = this.originalEvent;
                this.isPropagationStopped = returnTrue, e && e.stopPropagation && e.stopPropagation()
            },
            stopImmediatePropagation: function() {
                var e = this.originalEvent;
                this.isImmediatePropagationStopped = returnTrue, e && e.stopImmediatePropagation && e.stopImmediatePropagation(), this.stopPropagation()
            }
        }, jQuery.each({
            mouseenter: "mouseover",
            mouseleave: "mouseout",
            pointerenter: "pointerover",
            pointerleave: "pointerout"
        }, function(e, t) {
            jQuery.event.special[e] = {
                delegateType: t,
                bindType: t,
                handle: function(e) {
                    var n, r = this,
                        i = e.relatedTarget,
                        s = e.handleObj;
                    if (!i || i !== r && !jQuery.contains(r, i)) e.type = s.origType, n = s.handler.apply(this, arguments), e.type = t;
                    return n
                }
            }
        }), support.focusinBubbles || jQuery.each({
            focus: "focusin",
            blur: "focusout"
        }, function(e, t) {
            var n = function(e) {
                jQuery.event.simulate(t, e.target, jQuery.event.fix(e), !0)
            };
            jQuery.event.special[t] = {
                setup: function() {
                    var r = this.ownerDocument || this,
                        i = data_priv.access(r, t);
                    i || r.addEventListener(e, n, !0), data_priv.access(r, t, (i || 0) + 1)
                },
                teardown: function() {
                    var r = this.ownerDocument || this,
                        i = data_priv.access(r, t) - 1;
                    i ? data_priv.access(r, t, i) : (r.removeEventListener(e, n, !0), data_priv.remove(r, t))
                }
            }
        }), jQuery.fn.extend({
            on: function(e, t, n, r, i) {
                var s, o;
                if (typeof e == "object") {
                    typeof t != "string" && (n = n || t, t = undefined);
                    for (o in e) this.on(o, t, n, e[o], i);
                    return this
                }
                n == null && r == null ? (r = t, n = t = undefined) : r == null && (typeof t == "string" ? (r = n, n = undefined) : (r = n, n = t, t = undefined));
                if (r === !1) r = returnFalse;
                else if (!r) return this;
                return i === 1 && (s = r, r = function(e) {
                    return jQuery().off(e), s.apply(this, arguments)
                }, r.guid = s.guid || (s.guid = jQuery.guid++)), this.each(function() {
                    jQuery.event.add(this, e, r, n, t)
                })
            },
            one: function(e, t, n, r) {
                return this.on(e, t, n, r, 1)
            },
            off: function(e, t, n) {
                var r, i;
                if (e && e.preventDefault && e.handleObj) return r = e.handleObj, jQuery(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
                if (typeof e == "object") {
                    for (i in e) this.off(i, t, e[i]);
                    return this
                }
                if (t === !1 || typeof t == "function") n = t, t = undefined;
                return n === !1 && (n = returnFalse), this.each(function() {
                    jQuery.event.remove(this, e, n, t)
                })
            },
            trigger: function(e, t) {
                return this.each(function() {
                    jQuery.event.trigger(e, t, this)
                })
            },
            triggerHandler: function(e, t) {
                var n = this[0];
                if (n) return jQuery.event.trigger(e, t, n, !0)
            }
        });
        var rxhtmlTag = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
            rtagName = /<([\w:]+)/,
            rhtml = /<|&#?\w+;/,
            rnoInnerhtml = /<(?:script|style|link)/i,
            rchecked = /checked\s*(?:[^=]|=\s*.checked.)/i,
            rscriptType = /^$|\/(?:java|ecma)script/i,
            rscriptTypeMasked = /^true\/(.*)/,
            rcleanScript = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
            wrapMap = {
                option: [1, "<select multiple='multiple'>", "</select>"],
                thead: [1, "<table>", "</table>"],
                col: [2, "<table><colgroup>", "</colgroup></table>"],
                tr: [2, "<table><tbody>", "</tbody></table>"],
                td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
                _default: [0, "", ""]
            };
        wrapMap.optgroup = wrapMap.option, wrapMap.tbody = wrapMap.tfoot = wrapMap.colgroup = wrapMap.caption = wrapMap.thead, wrapMap.th = wrapMap.td, jQuery.extend({
            clone: function(e, t, n) {
                var r, i, s, o, u = e.cloneNode(!0),
                    a = jQuery.contains(e.ownerDocument, e);
                if (!support.noCloneChecked && (e.nodeType === 1 || e.nodeType === 11) && !jQuery.isXMLDoc(e)) {
                    o = getAll(u), s = getAll(e);
                    for (r = 0, i = s.length; r < i; r++) fixInput(s[r], o[r])
                }
                if (t)
                    if (n) {
                        s = s || getAll(e), o = o || getAll(u);
                        for (r = 0, i = s.length; r < i; r++) cloneCopyEvent(s[r], o[r])
                    } else cloneCopyEvent(e, u);
                return o = getAll(u, "script"), o.length > 0 && setGlobalEval(o, !a && getAll(e, "script")), u
            },
            buildFragment: function(e, t, n, r) {
                var i, s, o, u, a, f, l = t.createDocumentFragment(),
                    c = [],
                    h = 0,
                    p = e.length;
                for (; h < p; h++) {
                    i = e[h];
                    if (i || i === 0)
                        if (jQuery.type(i) === "object") jQuery.merge(c, i.nodeType ? [i] : i);
                        else if (!rhtml.test(i)) c.push(t.createTextNode(i));
                    else {
                        s = s || l.appendChild(t.createElement("div")), o = (rtagName.exec(i) || ["", ""])[1].toLowerCase(), u = wrapMap[o] || wrapMap._default, s.innerHTML = u[1] + i.replace(rxhtmlTag, "<$1></$2>") + u[2], f = u[0];
                        while (f--) s = s.lastChild;
                        jQuery.merge(c, s.childNodes), s = l.firstChild, s.textContent = ""
                    }
                }
                l.textContent = "", h = 0;
                while (i = c[h++]) {
                    if (r && jQuery.inArray(i, r) !== -1) continue;
                    a = jQuery.contains(i.ownerDocument, i), s = getAll(l.appendChild(i), "script"), a && setGlobalEval(s);
                    if (n) {
                        f = 0;
                        while (i = s[f++]) rscriptType.test(i.type || "") && n.push(i)
                    }
                }
                return l
            },
            cleanData: function(e) {
                var t, n, r, i, s = jQuery.event.special,
                    o = 0;
                for (;
                    (n = e[o]) !== undefined; o++) {
                    if (jQuery.acceptData(n)) {
                        i = n[data_priv.expando];
                        if (i && (t = data_priv.cache[i])) {
                            if (t.events)
                                for (r in t.events) s[r] ? jQuery.event.remove(n, r) : jQuery.removeEvent(n, r, t.handle);
                            data_priv.cache[i] && delete data_priv.cache[i]
                        }
                    }
                    delete data_user.cache[n[data_user.expando]]
                }
            }
        }), jQuery.fn.extend({
            text: function(e) {
                return access(this, function(e) {
                    return e === undefined ? jQuery.text(this) : this.empty().each(function() {
                        if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) this.textContent = e
                    })
                }, null, e, arguments.length)
            },
            append: function() {
                return this.domManip(arguments, function(e) {
                    if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
                        var t = manipulationTarget(this, e);
                        t.appendChild(e)
                    }
                })
            },
            prepend: function() {
                return this.domManip(arguments, function(e) {
                    if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
                        var t = manipulationTarget(this, e);
                        t.insertBefore(e, t.firstChild)
                    }
                })
            },
            before: function() {
                return this.domManip(arguments, function(e) {
                    this.parentNode && this.parentNode.insertBefore(e, this)
                })
            },
            after: function() {
                return this.domManip(arguments, function(e) {
                    this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
                })
            },
            remove: function(e, t) {
                var n, r = e ? jQuery.filter(e, this) : this,
                    i = 0;
                for (;
                    (n = r[i]) != null; i++) !t && n.nodeType === 1 && jQuery.cleanData(getAll(n)), n.parentNode && (t && jQuery.contains(n.ownerDocument, n) && setGlobalEval(getAll(n, "script")), n.parentNode.removeChild(n));
                return this
            },
            empty: function() {
                var e, t = 0;
                for (;
                    (e = this[t]) != null; t++) e.nodeType === 1 && (jQuery.cleanData(getAll(e, !1)), e.textContent = "");
                return this
            },
            clone: function(e, t) {
                return e = e == null ? !1 : e, t = t == null ? e : t, this.map(function() {
                    return jQuery.clone(this, e, t)
                })
            },
            html: function(e) {
                return access(this, function(e) {
                    var t = this[0] || {},
                        n = 0,
                        r = this.length;
                    if (e === undefined && t.nodeType === 1) return t.innerHTML;
                    if (typeof e == "string" && !rnoInnerhtml.test(e) && !wrapMap[(rtagName.exec(e) || ["", ""])[1].toLowerCase()]) {
                        e = e.replace(rxhtmlTag, "<$1></$2>");
                        try {
                            for (; n < r; n++) t = this[n] || {}, t.nodeType === 1 && (jQuery.cleanData(getAll(t, !1)), t.innerHTML = e);
                            t = 0
                        } catch (i) {}
                    }
                    t && this.empty().append(e)
                }, null, e, arguments.length)
            },
            replaceWith: function() {
                var e = arguments[0];
                return this.domManip(arguments, function(t) {
                    e = this.parentNode, jQuery.cleanData(getAll(this)), e && e.replaceChild(t, this)
                }), e && (e.length || e.nodeType) ? this : this.remove()
            },
            detach: function(e) {
                return this.remove(e, !0)
            },
            domManip: function(e, t) {
                e = concat.apply([], e);
                var n, r, i, s, o, u, a = 0,
                    f = this.length,
                    l = this,
                    c = f - 1,
                    h = e[0],
                    p = jQuery.isFunction(h);
                if (p || f > 1 && typeof h == "string" && !support.checkClone && rchecked.test(h)) return this.each(function(n) {
                    var r = l.eq(n);
                    p && (e[0] = h.call(this, n, r.html())), r.domManip(e, t)
                });
                if (f) {
                    n = jQuery.buildFragment(e, this[0].ownerDocument, !1, this), r = n.firstChild, n.childNodes.length === 1 && (n = r);
                    if (r) {
                        i = jQuery.map(getAll(n, "script"), disableScript), s = i.length;
                        for (; a < f; a++) o = n, a !== c && (o = jQuery.clone(o, !0, !0), s && jQuery.merge(i, getAll(o, "script"))), t.call(this[a], o, a);
                        if (s) {
                            u = i[i.length - 1].ownerDocument, jQuery.map(i, restoreScript);
                            for (a = 0; a < s; a++) o = i[a], rscriptType.test(o.type || "") && !data_priv.access(o, "globalEval") && jQuery.contains(u, o) && (o.src ? jQuery._evalUrl && jQuery._evalUrl(o.src) : jQuery.globalEval(o.textContent.replace(rcleanScript, "")))
                        }
                    }
                }
                return this
            }
        }), jQuery.each({
            appendTo: "append",
            prependTo: "prepend",
            insertBefore: "before",
            insertAfter: "after",
            replaceAll: "replaceWith"
        }, function(e, t) {
            jQuery.fn[e] = function(e) {
                var n, r = [],
                    i = jQuery(e),
                    s = i.length - 1,
                    o = 0;
                for (; o <= s; o++) n = o === s ? this : this.clone(!0), jQuery(i[o])[t](n), push.apply(r, n.get());
                return this.pushStack(r)
            }
        });
        var iframe, elemdisplay = {},
            rmargin = /^margin/,
            rnumnonpx = new RegExp("^(" + pnum + ")(?!px)[a-z%]+$", "i"),
            getStyles = function(e) {
                return e.ownerDocument.defaultView.opener ? e.ownerDocument.defaultView.getComputedStyle(e, null) : window.getComputedStyle(e, null)
            };
        (function() {
            function s() {
                i.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute", i.innerHTML = "", n.appendChild(r);
                var s = window.getComputedStyle(i, null);
                e = s.top !== "1%", t = s.width === "4px", n.removeChild(r)
            }
            var e, t, n = document.documentElement,
                r = document.createElement("div"),
                i = document.createElement("div");
            if (!i.style) return;
            i.style.backgroundClip = "content-box", i.cloneNode(!0).style.backgroundClip = "", support.clearCloneStyle = i.style.backgroundClip === "content-box", r.style.cssText = "border:0;width:0;height:0;top:0;left:-9999px;margin-top:1px;position:absolute", r.appendChild(i), window.getComputedStyle && jQuery.extend(support, {
                pixelPosition: function() {
                    return s(), e
                },
                boxSizingReliable: function() {
                    return t == null && s(), t
                },
                reliableMarginRight: function() {
                    var e, t = i.appendChild(document.createElement("div"));
                    return t.style.cssText = i.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0", t.style.marginRight = t.style.width = "0", i.style.width = "1px", n.appendChild(r), e = !parseFloat(window.getComputedStyle(t, null).marginRight), n.removeChild(r), i.removeChild(t), e
                }
            })
        })(), jQuery.swap = function(e, t, n, r) {
            var i, s, o = {};
            for (s in t) o[s] = e.style[s], e.style[s] = t[s];
            i = n.apply(e, r || []);
            for (s in t) e.style[s] = o[s];
            return i
        };
        var rdisplayswap = /^(none|table(?!-c[ea]).+)/,
            rnumsplit = new RegExp("^(" + pnum + ")(.*)$", "i"),
            rrelNum = new RegExp("^([+-])=(" + pnum + ")", "i"),
            cssShow = {
                position: "absolute",
                visibility: "hidden",
                display: "block"
            },
            cssNormalTransform = {
                letterSpacing: "0",
                fontWeight: "400"
            },
            cssPrefixes = ["Webkit", "O", "Moz", "ms"];
        jQuery.extend({
            cssHooks: {
                opacity: {
                    get: function(e, t) {
                        if (t) {
                            var n = curCSS(e, "opacity");
                            return n === "" ? "1" : n
                        }
                    }
                }
            },
            cssNumber: {
                columnCount: !0,
                fillOpacity: !0,
                flexGrow: !0,
                flexShrink: !0,
                fontWeight: !0,
                lineHeight: !0,
                opacity: !0,
                order: !0,
                orphans: !0,
                widows: !0,
                zIndex: !0,
                zoom: !0
            },
            cssProps: {
                "float": "cssFloat"
            },
            style: function(e, t, n, r) {
                if (!e || e.nodeType === 3 || e.nodeType === 8 || !e.style) return;
                var i, s, o, u = jQuery.camelCase(t),
                    a = e.style;
                t = jQuery.cssProps[u] || (jQuery.cssProps[u] = vendorPropName(a, u)), o = jQuery.cssHooks[t] || jQuery.cssHooks[u];
                if (n === undefined) return o && "get" in o && (i = o.get(e, !1, r)) !== undefined ? i : a[t];
                s = typeof n, s === "string" && (i = rrelNum.exec(n)) && (n = (i[1] + 1) * i[2] + parseFloat(jQuery.css(e, t)), s = "number");
                if (n == null || n !== n) return;
                s === "number" && !jQuery.cssNumber[u] && (n += "px"), !support.clearCloneStyle && n === "" && t.indexOf("background") === 0 && (a[t] = "inherit");
                if (!o || !("set" in o) || (n = o.set(e, n, r)) !== undefined) a[t] = n
            },
            css: function(e, t, n, r) {
                var i, s, o, u = jQuery.camelCase(t);
                return t = jQuery.cssProps[u] || (jQuery.cssProps[u] = vendorPropName(e.style, u)), o = jQuery.cssHooks[t] || jQuery.cssHooks[u], o && "get" in o && (i = o.get(e, !0, n)), i === undefined && (i = curCSS(e, t, r)), i === "normal" && t in cssNormalTransform && (i = cssNormalTransform[t]), n === "" || n ? (s = parseFloat(i), n === !0 || jQuery.isNumeric(s) ? s || 0 : i) : i
            }
        }), jQuery.each(["height", "width"], function(e, t) {
            jQuery.cssHooks[t] = {
                get: function(e, n, r) {
                    if (n) return rdisplayswap.test(jQuery.css(e, "display")) && e.offsetWidth === 0 ? jQuery.swap(e, cssShow, function() {
                        return getWidthOrHeight(e, t, r)
                    }) : getWidthOrHeight(e, t, r)
                },
                set: function(e, n, r) {
                    var i = r && getStyles(e);
                    return setPositiveNumber(e, n, r ? augmentWidthOrHeight(e, t, r, jQuery.css(e, "boxSizing", !1, i) === "border-box", i) : 0)
                }
            }
        }), jQuery.cssHooks.marginRight = addGetHookIf(support.reliableMarginRight, function(e, t) {
            if (t) return jQuery.swap(e, {
                display: "inline-block"
            }, curCSS, [e, "marginRight"])
        }), jQuery.each({
            margin: "",
            padding: "",
            border: "Width"
        }, function(e, t) {
            jQuery.cssHooks[e + t] = {
                expand: function(n) {
                    var r = 0,
                        i = {},
                        s = typeof n == "string" ? n.split(" ") : [n];
                    for (; r < 4; r++) i[e + cssExpand[r] + t] = s[r] || s[r - 2] || s[0];
                    return i
                }
            }, rmargin.test(e) || (jQuery.cssHooks[e + t].set = setPositiveNumber)
        }), jQuery.fn.extend({
            css: function(e, t) {
                return access(this, function(e, t, n) {
                    var r, i, s = {},
                        o = 0;
                    if (jQuery.isArray(t)) {
                        r = getStyles(e), i = t.length;
                        for (; o < i; o++) s[t[o]] = jQuery.css(e, t[o], !1, r);
                        return s
                    }
                    return n !== undefined ? jQuery.style(e, t, n) : jQuery.css(e, t)
                }, e, t, arguments.length > 1)
            },
            show: function() {
                return showHide(this, !0)
            },
            hide: function() {
                return showHide(this)
            },
            toggle: function(e) {
                return typeof e == "boolean" ? e ? this.show() : this.hide() : this.each(function() {
                    isHidden(this) ? jQuery(this).show() : jQuery(this).hide()
                })
            }
        }), jQuery.Tween = Tween, Tween.prototype = {
            constructor: Tween,
            init: function(e, t, n, r, i, s) {
                this.elem = e, this.prop = n, this.easing = i || "swing", this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = s || (jQuery.cssNumber[n] ? "" : "px")
            },
            cur: function() {
                var e = Tween.propHooks[this.prop];
                return e && e.get ? e.get(this) : Tween.propHooks._default.get(this)
            },
            run: function(e) {
                var t, n = Tween.propHooks[this.prop];
                return this.options.duration ? this.pos = t = jQuery.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : Tween.propHooks._default.set(this), this
            }
        }, Tween.prototype.init.prototype = Tween.prototype, Tween.propHooks = {
            _default: {
                get: function(e) {
                    var t;
                    return e.elem[e.prop] == null || !!e.elem.style && e.elem.style[e.prop] != null ? (t = jQuery.css(e.elem, e.prop, ""), !t || t === "auto" ? 0 : t) : e.elem[e.prop]
                },
                set: function(e) {
                    jQuery.fx.step[e.prop] ? jQuery.fx.step[e.prop](e) : e.elem.style && (e.elem.style[jQuery.cssProps[e.prop]] != null || jQuery.cssHooks[e.prop]) ? jQuery.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
                }
            }
        }, Tween.propHooks.scrollTop = Tween.propHooks.scrollLeft = {
            set: function(e) {
                e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
            }
        }, jQuery.easing = {
            linear: function(e) {
                return e
            },
            swing: function(e) {
                return .5 - Math.cos(e * Math.PI) / 2
            }
        }, jQuery.fx = Tween.prototype.init, jQuery.fx.step = {};
        var fxNow, timerId, rfxtypes = /^(?:toggle|show|hide)$/,
            rfxnum = new RegExp("^(?:([+-])=|)(" + pnum + ")([a-z%]*)$", "i"),
            rrun = /queueHooks$/,
            animationPrefilters = [defaultPrefilter],
            tweeners = {
                "*": [function(e, t) {
                    var n = this.createTween(e, t),
                        r = n.cur(),
                        i = rfxnum.exec(t),
                        s = i && i[3] || (jQuery.cssNumber[e] ? "" : "px"),
                        o = (jQuery.cssNumber[e] || s !== "px" && +r) && rfxnum.exec(jQuery.css(n.elem, e)),
                        u = 1,
                        a = 20;
                    if (o && o[3] !== s) {
                        s = s || o[3], i = i || [], o = +r || 1;
                        do u = u || ".5", o /= u, jQuery.style(n.elem, e, o + s); while (u !== (u = n.cur() / r) && u !== 1 && --a)
                    }
                    return i && (o = n.start = +o || +r || 0, n.unit = s, n.end = i[1] ? o + (i[1] + 1) * i[2] : +i[2]), n
                }]
            };
        jQuery.Animation = jQuery.extend(Animation, {
                tweener: function(e, t) {
                    jQuery.isFunction(e) ? (t = e, e = ["*"]) : e = e.split(" ");
                    var n, r = 0,
                        i = e.length;
                    for (; r < i; r++) n = e[r], tweeners[n] = tweeners[n] || [], tweeners[n].unshift(t)
                },
                prefilter: function(e, t) {
                    t ? animationPrefilters.unshift(e) : animationPrefilters.push(e)
                }
            }), jQuery.speed = function(e, t, n) {
                var r = e && typeof e == "object" ? jQuery.extend({}, e) : {
                    complete: n || !n && t || jQuery.isFunction(e) && e,
                    duration: e,
                    easing: n && t || t && !jQuery.isFunction(t) && t
                };
                r.duration = jQuery.fx.off ? 0 : typeof r.duration == "number" ? r.duration : r.duration in jQuery.fx.speeds ? jQuery.fx.speeds[r.duration] : jQuery.fx.speeds._default;
                if (r.queue == null || r.queue === !0) r.queue = "fx";
                return r.old = r.complete, r.complete = function() {
                    jQuery.isFunction(r.old) && r.old.call(this), r.queue && jQuery.dequeue(this, r.queue)
                }, r
            }, jQuery.fn.extend({
                fadeTo: function(e, t, n, r) {
                    return this.filter(isHidden).css("opacity", 0).show().end().animate({
                        opacity: t
                    }, e, n, r)
                },
                animate: function(e, t, n, r) {
                    var i = jQuery.isEmptyObject(e),
                        s = jQuery.speed(t, n, r),
                        o = function() {
                            var t = Animation(this, jQuery.extend({}, e), s);
                            (i || data_priv.get(this, "finish")) && t.stop(!0)
                        };
                    return o.finish = o, i || s.queue === !1 ? this.each(o) : this.queue(s.queue, o)
                },
                stop: function(e, t, n) {
                    var r = function(e) {
                        var t = e.stop;
                        delete e.stop, t(n)
                    };
                    return typeof e != "string" && (n = t, t = e, e = undefined), t && e !== !1 && this.queue(e || "fx", []), this.each(function() {
                        var t = !0,
                            i = e != null && e + "queueHooks",
                            s = jQuery.timers,
                            o = data_priv.get(this);
                        if (i) o[i] && o[i].stop && r(o[i]);
                        else
                            for (i in o) o[i] && o[i].stop && rrun.test(i) && r(o[i]);
                        for (i = s.length; i--;) s[i].elem === this && (e == null || s[i].queue === e) && (s[i].anim.stop(n), t = !1, s.splice(i, 1));
                        (t || !n) && jQuery.dequeue(this, e)
                    })
                },
                finish: function(e) {
                    return e !== !1 && (e = e || "fx"), this.each(function() {
                        var t, n = data_priv.get(this),
                            r = n[e + "queue"],
                            i = n[e + "queueHooks"],
                            s = jQuery.timers,
                            o = r ? r.length : 0;
                        n.finish = !0, jQuery.queue(this, e, []), i && i.stop && i.stop.call(this, !0);
                        for (t = s.length; t--;) s[t].elem === this && s[t].queue === e && (s[t].anim.stop(!0), s.splice(t, 1));
                        for (t = 0; t < o; t++) r[t] && r[t].finish && r[t].finish.call(this);
                        delete n.finish
                    })
                }
            }), jQuery.each(["toggle", "show", "hide"], function(e, t) {
                var n = jQuery.fn[t];
                jQuery.fn[t] = function(e, r, i) {
                    return e == null || typeof e == "boolean" ? n.apply(this, arguments) : this.animate(genFx(t, !0), e, r, i)
                }
            }), jQuery.each({
                slideDown: genFx("show"),
                slideUp: genFx("hide"),
                slideToggle: genFx("toggle"),
                fadeIn: {
                    opacity: "show"
                },
                fadeOut: {
                    opacity: "hide"
                },
                fadeToggle: {
                    opacity: "toggle"
                }
            }, function(e, t) {
                jQuery.fn[e] = function(e, n, r) {
                    return this.animate(t, e, n, r)
                }
            }), jQuery.timers = [], jQuery.fx.tick = function() {
                var e, t = 0,
                    n = jQuery.timers;
                fxNow = jQuery.now();
                for (; t < n.length; t++) e = n[t], !e() && n[t] === e && n.splice(t--, 1);
                n.length || jQuery.fx.stop(), fxNow = undefined
            }, jQuery.fx.timer = function(e) {
                jQuery.timers.push(e), e() ? jQuery.fx.start() : jQuery.timers.pop()
            }, jQuery.fx.interval = 13, jQuery.fx.start = function() {
                timerId || (timerId = setInterval(jQuery.fx.tick, jQuery.fx.interval))
            }, jQuery.fx.stop = function() {
                clearInterval(timerId), timerId = null
            }, jQuery.fx.speeds = {
                slow: 600,
                fast: 200,
                _default: 400
            }, jQuery.fn.delay = function(e, t) {
                return e = jQuery.fx ? jQuery.fx.speeds[e] || e : e, t = t || "fx", this.queue(t, function(t, n) {
                    var r = setTimeout(t, e);
                    n.stop = function() {
                        clearTimeout(r)
                    }
                })
            },
            function() {
                var e = document.createElement("input"),
                    t = document.createElement("select"),
                    n = t.appendChild(document.createElement("option"));
                e.type = "checkbox", support.checkOn = e.value !== "", support.optSelected = n.selected, t.disabled = !0, support.optDisabled = !n.disabled, e = document.createElement("input"), e.value = "t", e.type = "radio", support.radioValue = e.value === "t"
            }();
        var nodeHook, boolHook, attrHandle = jQuery.expr.attrHandle;
        jQuery.fn.extend({
            attr: function(e, t) {
                return access(this, jQuery.attr, e, t, arguments.length > 1)
            },
            removeAttr: function(e) {
                return this.each(function() {
                    jQuery.removeAttr(this, e)
                })
            }
        }), jQuery.extend({
            attr: function(e, t, n) {
                var r, i, s = e.nodeType;
                if (!e || s === 3 || s === 8 || s === 2) return;
                if (typeof e.getAttribute === strundefined) return jQuery.prop(e, t, n);
                if (s !== 1 || !jQuery.isXMLDoc(e)) t = t.toLowerCase(), r = jQuery.attrHooks[t] || (jQuery.expr.match.bool.test(t) ? boolHook : nodeHook);
                if (n === undefined) return r && "get" in r && (i = r.get(e, t)) !== null ? i : (i = jQuery.find.attr(e, t), i == null ? undefined : i);
                if (n !== null) return r && "set" in r && (i = r.set(e, n, t)) !== undefined ? i : (e.setAttribute(t, n + ""), n);
                jQuery.removeAttr(e, t)
            },
            removeAttr: function(e, t) {
                var n, r, i = 0,
                    s = t && t.match(rnotwhite);
                if (s && e.nodeType === 1)
                    while (n = s[i++]) r = jQuery.propFix[n] || n, jQuery.expr.match.bool.test(n) && (e[r] = !1), e.removeAttribute(n)
            },
            attrHooks: {
                type: {
                    set: function(e, t) {
                        if (!support.radioValue && t === "radio" && jQuery.nodeName(e, "input")) {
                            var n = e.value;
                            return e.setAttribute("type", t), n && (e.value = n), t
                        }
                    }
                }
            }
        }), boolHook = {
            set: function(e, t, n) {
                return t === !1 ? jQuery.removeAttr(e, n) : e.setAttribute(n, n), n
            }
        }, jQuery.each(jQuery.expr.match.bool.source.match(/\w+/g), function(e, t) {
            var n = attrHandle[t] || jQuery.find.attr;
            attrHandle[t] = function(e, t, r) {
                var i, s;
                return r || (s = attrHandle[t], attrHandle[t] = i, i = n(e, t, r) != null ? t.toLowerCase() : null, attrHandle[t] = s), i
            }
        });
        var rfocusable = /^(?:input|select|textarea|button)$/i;
        jQuery.fn.extend({
            prop: function(e, t) {
                return access(this, jQuery.prop, e, t, arguments.length > 1)
            },
            removeProp: function(e) {
                return this.each(function() {
                    delete this[jQuery.propFix[e] || e]
                })
            }
        }), jQuery.extend({
            propFix: {
                "for": "htmlFor",
                "class": "className"
            },
            prop: function(e, t, n) {
                var r, i, s, o = e.nodeType;
                if (!e || o === 3 || o === 8 || o === 2) return;
                return s = o !== 1 || !jQuery.isXMLDoc(e), s && (t = jQuery.propFix[t] || t, i = jQuery.propHooks[t]), n !== undefined ? i && "set" in i && (r = i.set(e, n, t)) !== undefined ? r : e[t] = n : i && "get" in i && (r = i.get(e, t)) !== null ? r : e[t]
            },
            propHooks: {
                tabIndex: {
                    get: function(e) {
                        return e.hasAttribute("tabindex") || rfocusable.test(e.nodeName) || e.href ? e.tabIndex : -1
                    }
                }
            }
        }), support.optSelected || (jQuery.propHooks.selected = {
            get: function(e) {
                var t = e.parentNode;
                return t && t.parentNode && t.parentNode.selectedIndex, null
            }
        }), jQuery.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
            jQuery.propFix[this.toLowerCase()] = this
        });
        var rclass = /[\t\r\n\f]/g;
        jQuery.fn.extend({
            addClass: function(e) {
                var t, n, r, i, s, o, u = typeof e == "string" && e,
                    a = 0,
                    f = this.length;
                if (jQuery.isFunction(e)) return this.each(function(t) {
                    jQuery(this).addClass(e.call(this, t, this.className))
                });
                if (u) {
                    t = (e || "").match(rnotwhite) || [];
                    for (; a < f; a++) {
                        n = this[a], r = n.nodeType === 1 && (n.className ? (" " + n.className + " ").replace(rclass, " ") : " ");
                        if (r) {
                            s = 0;
                            while (i = t[s++]) r.indexOf(" " + i + " ") < 0 && (r += i + " ");
                            o = jQuery.trim(r), n.className !== o && (n.className = o)
                        }
                    }
                }
                return this
            },
            removeClass: function(e) {
                var t, n, r, i, s, o, u = arguments.length === 0 || typeof e == "string" && e,
                    a = 0,
                    f = this.length;
                if (jQuery.isFunction(e)) return this.each(function(t) {
                    jQuery(this).removeClass(e.call(this, t, this.className))
                });
                if (u) {
                    t = (e || "").match(rnotwhite) || [];
                    for (; a < f; a++) {
                        n = this[a], r = n.nodeType === 1 && (n.className ? (" " + n.className + " ").replace(rclass, " ") : "");
                        if (r) {
                            s = 0;
                            while (i = t[s++])
                                while (r.indexOf(" " + i + " ") >= 0) r = r.replace(" " + i + " ", " ");
                            o = e ? jQuery.trim(r) : "", n.className !== o && (n.className = o)
                        }
                    }
                }
                return this
            },
            toggleClass: function(e, t) {
                var n = typeof e;
                return typeof t == "boolean" && n === "string" ? t ? this.addClass(e) : this.removeClass(e) : jQuery.isFunction(e) ? this.each(function(n) {
                    jQuery(this).toggleClass(e.call(this, n, this.className, t), t)
                }) : this.each(function() {
                    if (n === "string") {
                        var t, r = 0,
                            i = jQuery(this),
                            s = e.match(rnotwhite) || [];
                        while (t = s[r++]) i.hasClass(t) ? i.removeClass(t) : i.addClass(t)
                    } else if (n === strundefined || n === "boolean") this.className && data_priv.set(this, "__className__", this.className), this.className = this.className || e === !1 ? "" : data_priv.get(this, "__className__") || ""
                })
            },
            hasClass: function(e) {
                var t = " " + e + " ",
                    n = 0,
                    r = this.length;
                for (; n < r; n++)
                    if (this[n].nodeType === 1 && (" " + this[n].className + " ").replace(rclass, " ").indexOf(t) >= 0) return !0;
                return !1
            }
        });
        var rreturn = /\r/g;
        jQuery.fn.extend({
            val: function(e) {
                var t, n, r, i = this[0];
                if (!arguments.length) {
                    if (i) return t = jQuery.valHooks[i.type] || jQuery.valHooks[i.nodeName.toLowerCase()], t && "get" in t && (n = t.get(i, "value")) !== undefined ? n : (n = i.value, typeof n == "string" ? n.replace(rreturn, "") : n == null ? "" : n);
                    return
                }
                return r = jQuery.isFunction(e), this.each(function(n) {
                    var i;
                    if (this.nodeType !== 1) return;
                    r ? i = e.call(this, n, jQuery(this).val()) : i = e, i == null ? i = "" : typeof i == "number" ? i += "" : jQuery.isArray(i) && (i = jQuery.map(i, function(e) {
                        return e == null ? "" : e + ""
                    })), t = jQuery.valHooks[this.type] || jQuery.valHooks[this.nodeName.toLowerCase()];
                    if (!t || !("set" in t) || t.set(this, i, "value") === undefined) this.value = i
                })
            }
        }), jQuery.extend({
            valHooks: {
                option: {
                    get: function(e) {
                        var t = jQuery.find.attr(e, "value");
                        return t != null ? t : jQuery.trim(jQuery.text(e))
                    }
                },
                select: {
                    get: function(e) {
                        var t, n, r = e.options,
                            i = e.selectedIndex,
                            s = e.type === "select-one" || i < 0,
                            o = s ? null : [],
                            u = s ? i + 1 : r.length,
                            a = i < 0 ? u : s ? i : 0;
                        for (; a < u; a++) {
                            n = r[a];
                            if ((n.selected || a === i) && (support.optDisabled ? !n.disabled : n.getAttribute("disabled") === null) && (!n.parentNode.disabled || !jQuery.nodeName(n.parentNode, "optgroup"))) {
                                t = jQuery(n).val();
                                if (s) return t;
                                o.push(t)
                            }
                        }
                        return o
                    },
                    set: function(e, t) {
                        var n, r, i = e.options,
                            s = jQuery.makeArray(t),
                            o = i.length;
                        while (o--) {
                            r = i[o];
                            if (r.selected = jQuery.inArray(r.value, s) >= 0) n = !0
                        }
                        return n || (e.selectedIndex = -1), s
                    }
                }
            }
        }), jQuery.each(["radio", "checkbox"], function() {
            jQuery.valHooks[this] = {
                set: function(e, t) {
                    if (jQuery.isArray(t)) return e.checked = jQuery.inArray(jQuery(e).val(), t) >= 0
                }
            }, support.checkOn || (jQuery.valHooks[this].get = function(e) {
                return e.getAttribute("value") === null ? "on" : e.value
            })
        }), jQuery.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(e, t) {
            jQuery.fn[t] = function(e, n) {
                return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
            }
        }), jQuery.fn.extend({
            hover: function(e, t) {
                return this.mouseenter(e).mouseleave(t || e)
            },
            bind: function(e, t, n) {
                return this.on(e, null, t, n)
            },
            unbind: function(e, t) {
                return this.off(e, null, t)
            },
            delegate: function(e, t, n, r) {
                return this.on(t, e, n, r)
            },
            undelegate: function(e, t, n) {
                return arguments.length === 1 ? this.off(e, "**") : this.off(t, e || "**", n)
            }
        });
        var nonce = jQuery.now(),
            rquery = /\?/;
        jQuery.parseJSON = function(e) {
            return JSON.parse(e + "")
        }, jQuery.parseXML = function(e) {
            var t, n;
            if (!e || typeof e != "string") return null;
            try {
                n = new DOMParser, t = n.parseFromString(e, "text/xml")
            } catch (r) {
                t = undefined
            }
            return (!t || t.getElementsByTagName("parsererror").length) && jQuery.error("Invalid XML: " + e), t
        };
        var rhash = /#.*$/,
            rts = /([?&])_=[^&]*/,
            rheaders = /^(.*?):[ \t]*([^\r\n]*)$/mg,
            rlocalProtocol = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
            rnoContent = /^(?:GET|HEAD)$/,
            rprotocol = /^\/\//,
            rurl = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
            prefilters = {},
            transports = {},
            allTypes = "*/".concat("*"),
            ajaxLocation = window.location.href,
            ajaxLocParts = rurl.exec(ajaxLocation.toLowerCase()) || [];
        jQuery.extend({
            active: 0,
            lastModified: {},
            etag: {},
            ajaxSettings: {
                url: ajaxLocation,
                type: "GET",
                isLocal: rlocalProtocol.test(ajaxLocParts[1]),
                global: !0,
                processData: !0,
                async: !0,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                accepts: {
                    "*": allTypes,
                    text: "text/plain",
                    html: "text/html",
                    xml: "application/xml, text/xml",
                    json: "application/json, text/javascript"
                },
                contents: {
                    xml: /xml/,
                    html: /html/,
                    json: /json/
                },
                responseFields: {
                    xml: "responseXML",
                    text: "responseText",
                    json: "responseJSON"
                },
                converters: {
                    "* text": String,
                    "text html": !0,
                    "text json": jQuery.parseJSON,
                    "text xml": jQuery.parseXML
                },
                flatOptions: {
                    url: !0,
                    context: !0
                }
            },
            ajaxSetup: function(e, t) {
                return t ? ajaxExtend(ajaxExtend(e, jQuery.ajaxSettings), t) : ajaxExtend(jQuery.ajaxSettings, e)
            },
            ajaxPrefilter: addToPrefiltersOrTransports(prefilters),
            ajaxTransport: addToPrefiltersOrTransports(transports),
            ajax: function(e, t) {
                function S(e, t, s, u) {
                    var f, m, g, b, E, S = t;
                    if (y === 2) return;
                    y = 2, o && clearTimeout(o), n = undefined, i = u || "", w.readyState = e > 0 ? 4 : 0, f = e >= 200 && e < 300 || e === 304, s && (b = ajaxHandleResponses(l, w, s)), b = ajaxConvert(l, b, w, f);
                    if (f) l.ifModified && (E = w.getResponseHeader("Last-Modified"), E && (jQuery.lastModified[r] = E), E = w.getResponseHeader("etag"), E && (jQuery.etag[r] = E)), e === 204 || l.type === "HEAD" ? S = "nocontent" : e === 304 ? S = "notmodified" : (S = b.state, m = b.data, g = b.error, f = !g);
                    else {
                        g = S;
                        if (e || !S) S = "error", e < 0 && (e = 0)
                    }
                    w.status = e, w.statusText = (t || S) + "", f ? p.resolveWith(c, [m, S, w]) : p.rejectWith(c, [w, S, g]), w.statusCode(v), v = undefined, a && h.trigger(f ? "ajaxSuccess" : "ajaxError", [w, l, f ? m : g]), d.fireWith(c, [w, S]), a && (h.trigger("ajaxComplete", [w, l]), --jQuery.active || jQuery.event.trigger("ajaxStop"))
                }
                typeof e == "object" && (t = e, e = undefined), t = t || {};
                var n, r, i, s, o, u, a, f, l = jQuery.ajaxSetup({}, t),
                    c = l.context || l,
                    h = l.context && (c.nodeType || c.jquery) ? jQuery(c) : jQuery.event,
                    p = jQuery.Deferred(),
                    d = jQuery.Callbacks("once memory"),
                    v = l.statusCode || {},
                    m = {},
                    g = {},
                    y = 0,
                    b = "canceled",
                    w = {
                        readyState: 0,
                        getResponseHeader: function(e) {
                            var t;
                            if (y === 2) {
                                if (!s) {
                                    s = {};
                                    while (t = rheaders.exec(i)) s[t[1].toLowerCase()] = t[2]
                                }
                                t = s[e.toLowerCase()]
                            }
                            return t == null ? null : t
                        },
                        getAllResponseHeaders: function() {
                            return y === 2 ? i : null
                        },
                        setRequestHeader: function(e, t) {
                            var n = e.toLowerCase();
                            return y || (e = g[n] = g[n] || e, m[e] = t), this
                        },
                        overrideMimeType: function(e) {
                            return y || (l.mimeType = e), this
                        },
                        statusCode: function(e) {
                            var t;
                            if (e)
                                if (y < 2)
                                    for (t in e) v[t] = [v[t], e[t]];
                                else w.always(e[w.status]);
                            return this
                        },
                        abort: function(e) {
                            var t = e || b;
                            return n && n.abort(t), S(0, t), this
                        }
                    };
                p.promise(w).complete = d.add, w.success = w.done, w.error = w.fail, l.url = ((e || l.url || ajaxLocation) + "").replace(rhash, "").replace(rprotocol, ajaxLocParts[1] + "//"), l.type = t.method || t.type || l.method || l.type, l.dataTypes = jQuery.trim(l.dataType || "*").toLowerCase().match(rnotwhite) || [""], l.crossDomain == null && (u = rurl.exec(l.url.toLowerCase()), l.crossDomain = !(!u || u[1] === ajaxLocParts[1] && u[2] === ajaxLocParts[2] && (u[3] || (u[1] === "http:" ? "80" : "443")) === (ajaxLocParts[3] || (ajaxLocParts[1] === "http:" ? "80" : "443")))), l.data && l.processData && typeof l.data != "string" && (l.data = jQuery.param(l.data, l.traditional)), inspectPrefiltersOrTransports(prefilters, l, t, w);
                if (y === 2) return w;
                a = jQuery.event && l.global, a && jQuery.active++ === 0 && jQuery.event.trigger("ajaxStart"), l.type = l.type.toUpperCase(), l.hasContent = !rnoContent.test(l.type), r = l.url, l.hasContent || (l.data && (r = l.url += (rquery.test(r) ? "&" : "?") + l.data, delete l.data), l.cache === !1 && (l.url = rts.test(r) ? r.replace(rts, "$1_=" + nonce++) : r + (rquery.test(r) ? "&" : "?") + "_=" + nonce++)), l.ifModified && (jQuery.lastModified[r] && w.setRequestHeader("If-Modified-Since", jQuery.lastModified[r]), jQuery.etag[r] && w.setRequestHeader("If-None-Match", jQuery.etag[r])), (l.data && l.hasContent && l.contentType !== !1 || t.contentType) && w.setRequestHeader("Content-Type", l.contentType), w.setRequestHeader("Accept", l.dataTypes[0] && l.accepts[l.dataTypes[0]] ? l.accepts[l.dataTypes[0]] + (l.dataTypes[0] !== "*" ? ", " + allTypes + "; q=0.01" : "") : l.accepts["*"]);
                for (f in l.headers) w.setRequestHeader(f, l.headers[f]);
                if (!l.beforeSend || l.beforeSend.call(c, w, l) !== !1 && y !== 2) {
                    b = "abort";
                    for (f in {
                            success: 1,
                            error: 1,
                            complete: 1
                        }) w[f](l[f]);
                    n = inspectPrefiltersOrTransports(transports, l, t, w);
                    if (!n) S(-1, "No Transport");
                    else {
                        w.readyState = 1, a && h.trigger("ajaxSend", [w, l]), l.async && l.timeout > 0 && (o = setTimeout(function() {
                            w.abort("timeout")
                        }, l.timeout));
                        try {
                            y = 1, n.send(m, S)
                        } catch (E) {
                            if (!(y < 2)) throw E;
                            S(-1, E)
                        }
                    }
                    return w
                }
                return w.abort()
            },
            getJSON: function(e, t, n) {
                return jQuery.get(e, t, n, "json")
            },
            getScript: function(e, t) {
                return jQuery.get(e, undefined, t, "script")
            }
        }), jQuery.each(["get", "post"], function(e, t) {
            jQuery[t] = function(e, n, r, i) {
                return jQuery.isFunction(n) && (i = i || r, r = n, n = undefined), jQuery.ajax({
                    url: e,
                    type: t,
                    dataType: i,
                    data: n,
                    success: r
                })
            }
        }), jQuery._evalUrl = function(e) {
            return jQuery.ajax({
                url: e,
                type: "GET",
                dataType: "script",
                async: !1,
                global: !1,
                "throws": !0
            })
        }, jQuery.fn.extend({
            wrapAll: function(e) {
                var t;
                return jQuery.isFunction(e) ? this.each(function(t) {
                    jQuery(this).wrapAll(e.call(this, t))
                }) : (this[0] && (t = jQuery(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map(function() {
                    var e = this;
                    while (e.firstElementChild) e = e.firstElementChild;
                    return e
                }).append(this)), this)
            },
            wrapInner: function(e) {
                return jQuery.isFunction(e) ? this.each(function(t) {
                    jQuery(this).wrapInner(e.call(this, t))
                }) : this.each(function() {
                    var t = jQuery(this),
                        n = t.contents();
                    n.length ? n.wrapAll(e) : t.append(e)
                })
            },
            wrap: function(e) {
                var t = jQuery.isFunction(e);
                return this.each(function(n) {
                    jQuery(this).wrapAll(t ? e.call(this, n) : e)
                })
            },
            unwrap: function() {
                return this.parent().each(function() {
                    jQuery.nodeName(this, "body") || jQuery(this).replaceWith(this.childNodes)
                }).end()
            }
        }), jQuery.expr.filters.hidden = function(e) {
            return e.offsetWidth <= 0 && e.offsetHeight <= 0
        }, jQuery.expr.filters.visible = function(e) {
            return !jQuery.expr.filters.hidden(e)
        };
        var r20 = /%20/g,
            rbracket = /\[\]$/,
            rCRLF = /\r?\n/g,
            rsubmitterTypes = /^(?:submit|button|image|reset|file)$/i,
            rsubmittable = /^(?:input|select|textarea|keygen)/i;
        jQuery.param = function(e, t) {
            var n, r = [],
                i = function(e, t) {
                    t = jQuery.isFunction(t) ? t() : t == null ? "" : t, r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
                };
            t === undefined && (t = jQuery.ajaxSettings && jQuery.ajaxSettings.traditional);
            if (jQuery.isArray(e) || e.jquery && !jQuery.isPlainObject(e)) jQuery.each(e, function() {
                i(this.name, this.value)
            });
            else
                for (n in e) buildParams(n, e[n], t, i);
            return r.join("&").replace(r20, "+")
        }, jQuery.fn.extend({
            serialize: function() {
                return jQuery.param(this.serializeArray())
            },
            serializeArray: function() {
                return this.map(function() {
                    var e = jQuery.prop(this, "elements");
                    return e ? jQuery.makeArray(e) : this
                }).filter(function() {
                    var e = this.type;
                    return this.name && !jQuery(this).is(":disabled") && rsubmittable.test(this.nodeName) && !rsubmitterTypes.test(e) && (this.checked || !rcheckableType.test(e))
                }).map(function(e, t) {
                    var n = jQuery(this).val();
                    return n == null ? null : jQuery.isArray(n) ? jQuery.map(n, function(e) {
                        return {
                            name: t.name,
                            value: e.replace(rCRLF, "\r\n")
                        }
                    }) : {
                        name: t.name,
                        value: n.replace(rCRLF, "\r\n")
                    }
                }).get()
            }
        }), jQuery.ajaxSettings.xhr = function() {
            try {
                return new XMLHttpRequest
            } catch (e) {}
        };
        var xhrId = 0,
            xhrCallbacks = {},
            xhrSuccessStatus = {
                0: 200,
                1223: 204
            },
            xhrSupported = jQuery.ajaxSettings.xhr();
        window.attachEvent && window.attachEvent("onunload", function() {
            for (var e in xhrCallbacks) xhrCallbacks[e]()
        }), support.cors = !!xhrSupported && "withCredentials" in xhrSupported, support.ajax = xhrSupported = !!xhrSupported, jQuery.ajaxTransport(function(e) {
            var t;
            if (support.cors || xhrSupported && !e.crossDomain) return {
                send: function(n, r) {
                    var i, s = e.xhr(),
                        o = ++xhrId;
                    s.open(e.type, e.url, e.async, e.username, e.password);
                    if (e.xhrFields)
                        for (i in e.xhrFields) s[i] = e.xhrFields[i];
                    e.mimeType && s.overrideMimeType && s.overrideMimeType(e.mimeType), !e.crossDomain && !n["X-Requested-With"] && (n["X-Requested-With"] = "XMLHttpRequest");
                    for (i in n) s.setRequestHeader(i, n[i]);
                    t = function(e) {
                        return function() {
                            t && (delete xhrCallbacks[o], t = s.onload = s.onerror = null, e === "abort" ? s.abort() : e === "error" ? r(s.status, s.statusText) : r(xhrSuccessStatus[s.status] || s.status, s.statusText, typeof s.responseText == "string" ? {
                                text: s.responseText
                            } : undefined, s.getAllResponseHeaders()))
                        }
                    }, s.onload = t(), s.onerror = t("error"), t = xhrCallbacks[o] = t("abort");
                    try {
                        s.send(e.hasContent && e.data || null)
                    } catch (u) {
                        if (t) throw u
                    }
                },
                abort: function() {
                    t && t()
                }
            }
        }), jQuery.ajaxSetup({
            accepts: {
                script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
            },
            contents: {
                script: /(?:java|ecma)script/
            },
            converters: {
                "text script": function(e) {
                    return jQuery.globalEval(e), e
                }
            }
        }), jQuery.ajaxPrefilter("script", function(e) {
            e.cache === undefined && (e.cache = !1), e.crossDomain && (e.type = "GET")
        }), jQuery.ajaxTransport("script", function(e) {
            if (e.crossDomain) {
                var t, n;
                return {
                    send: function(r, i) {
                        t = jQuery("<script>").prop({
                            async: !0,
                            charset: e.scriptCharset,
                            src: e.url
                        }).on("load error", n = function(e) {
                            t.remove(), n = null, e && i(e.type === "error" ? 404 : 200, e.type)
                        }), document.head.appendChild(t[0])
                    },
                    abort: function() {
                        n && n()
                    }
                }
            }
        });
        var oldCallbacks = [],
            rjsonp = /(=)\?(?=&|$)|\?\?/;
        jQuery.ajaxSetup({
            jsonp: "callback",
            jsonpCallback: function() {
                var e = oldCallbacks.pop() || jQuery.expando + "_" + nonce++;
                return this[e] = !0, e
            }
        }), jQuery.ajaxPrefilter("json jsonp", function(e, t, n) {
            var r, i, s, o = e.jsonp !== !1 && (rjsonp.test(e.url) ? "url" : typeof e.data == "string" && !(e.contentType || "").indexOf("application/x-www-form-urlencoded") && rjsonp.test(e.data) && "data");
            if (o || e.dataTypes[0] === "jsonp") return r = e.jsonpCallback = jQuery.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, o ? e[o] = e[o].replace(rjsonp, "$1" + r) : e.jsonp !== !1 && (e.url += (rquery.test(e.url) ? "&" : "?") + e.jsonp + "=" + r), e.converters["script json"] = function() {
                return s || jQuery.error(r + " was not called"), s[0]
            }, e.dataTypes[0] = "json", i = window[r], window[r] = function() {
                s = arguments
            }, n.always(function() {
                window[r] = i, e[r] && (e.jsonpCallback = t.jsonpCallback, oldCallbacks.push(r)), s && jQuery.isFunction(i) && i(s[0]), s = i = undefined
            }), "script"
        }), jQuery.parseHTML = function(e, t, n) {
            if (!e || typeof e != "string") return null;
            typeof t == "boolean" && (n = t, t = !1), t = t || document;
            var r = rsingleTag.exec(e),
                i = !n && [];
            return r ? [t.createElement(r[1])] : (r = jQuery.buildFragment([e], t, i), i && i.length && jQuery(i).remove(), jQuery.merge([], r.childNodes))
        };
        var _load = jQuery.fn.load;
        jQuery.fn.load = function(e, t, n) {
            if (typeof e != "string" && _load) return _load.apply(this, arguments);
            var r, i, s, o = this,
                u = e.indexOf(" ");
            return u >= 0 && (r = jQuery.trim(e.slice(u)), e = e.slice(0, u)), jQuery.isFunction(t) ? (n = t, t = undefined) : t && typeof t == "object" && (i = "POST"), o.length > 0 && jQuery.ajax({
                url: e,
                type: i,
                dataType: "html",
                data: t
            }).done(function(e) {
                s = arguments, o.html(r ? jQuery("<div>").append(jQuery.parseHTML(e)).find(r) : e)
            }).complete(n && function(e, t) {
                o.each(n, s || [e.responseText, t, e])
            }), this
        }, jQuery.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, t) {
            jQuery.fn[t] = function(e) {
                return this.on(t, e)
            }
        }), jQuery.expr.filters.animated = function(e) {
            return jQuery.grep(jQuery.timers, function(t) {
                return e === t.elem
            }).length
        };
        var docElem = window.document.documentElement;
        jQuery.offset = {
            setOffset: function(e, t, n) {
                var r, i, s, o, u, a, f, l = jQuery.css(e, "position"),
                    c = jQuery(e),
                    h = {};
                l === "static" && (e.style.position = "relative"), u = c.offset(), s = jQuery.css(e, "top"), a = jQuery.css(e, "left"), f = (l === "absolute" || l === "fixed") && (s + a).indexOf("auto") > -1, f ? (r = c.position(), o = r.top, i = r.left) : (o = parseFloat(s) || 0, i = parseFloat(a) || 0), jQuery.isFunction(t) && (t = t.call(e, n, u)), t.top != null && (h.top = t.top - u.top + o), t.left != null && (h.left = t.left - u.left + i), "using" in t ? t.using.call(e, h) : c.css(h)
            }
        }, jQuery.fn.extend({
            offset: function(e) {
                if (arguments.length) return e === undefined ? this : this.each(function(t) {
                    jQuery.offset.setOffset(this, e, t)
                });
                var t, n, r = this[0],
                    i = {
                        top: 0,
                        left: 0
                    },
                    s = r && r.ownerDocument;
                if (!s) return;
                return t = s.documentElement, jQuery.contains(t, r) ? (typeof r.getBoundingClientRect !== strundefined && (i = r.getBoundingClientRect()), n = getWindow(s), {
                    top: i.top + n.pageYOffset - t.clientTop,
                    left: i.left + n.pageXOffset - t.clientLeft
                }) : i
            },
            position: function() {
                if (!this[0]) return;
                var e, t, n = this[0],
                    r = {
                        top: 0,
                        left: 0
                    };
                return jQuery.css(n, "position") === "fixed" ? t = n.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), jQuery.nodeName(e[0], "html") || (r = e.offset()), r.top += jQuery.css(e[0], "borderTopWidth", !0), r.left += jQuery.css(e[0], "borderLeftWidth", !0)), {
                    top: t.top - r.top - jQuery.css(n, "marginTop", !0),
                    left: t.left - r.left - jQuery.css(n, "marginLeft", !0)
                }
            },
            offsetParent: function() {
                return this.map(function() {
                    var e = this.offsetParent || docElem;
                    while (e && !jQuery.nodeName(e, "html") && jQuery.css(e, "position") === "static") e = e.offsetParent;
                    return e || docElem
                })
            }
        }), jQuery.each({
            scrollLeft: "pageXOffset",
            scrollTop: "pageYOffset"
        }, function(e, t) {
            var n = "pageYOffset" === t;
            jQuery.fn[e] = function(r) {
                return access(this, function(e, r, i) {
                    var s = getWindow(e);
                    if (i === undefined) return s ? s[t] : e[r];
                    s ? s.scrollTo(n ? window.pageXOffset : i, n ? i : window.pageYOffset) : e[r] = i
                }, e, r, arguments.length, null)
            }
        }), jQuery.each(["top", "left"], function(e, t) {
            jQuery.cssHooks[t] = addGetHookIf(support.pixelPosition, function(e, n) {
                if (n) return n = curCSS(e, t), rnumnonpx.test(n) ? jQuery(e).position()[t] + "px" : n
            })
        }), jQuery.each({
            Height: "height",
            Width: "width"
        }, function(e, t) {
            jQuery.each({
                padding: "inner" + e,
                content: t,
                "": "outer" + e
            }, function(n, r) {
                jQuery.fn[r] = function(r, i) {
                    var s = arguments.length && (n || typeof r != "boolean"),
                        o = n || (r === !0 || i === !0 ? "margin" : "border");
                    return access(this, function(t, n, r) {
                        var i;
                        return jQuery.isWindow(t) ? t.document.documentElement["client" + e] : t.nodeType === 9 ? (i = t.documentElement, Math.max(t.body["scroll" + e], i["scroll" + e], t.body["offset" + e], i["offset" + e], i["client" + e])) : r === undefined ? jQuery.css(t, n, o) : jQuery.style(t, n, r, o)
                    }, t, s ? r : undefined, s, null)
                }
            })
        }), jQuery.fn.size = function() {
            return this.length
        }, jQuery.fn.andSelf = jQuery.fn.addBack, typeof define == "function" && define.amd && define("jquery", [], function() {
            return jQuery
        });
        var _jQuery = window.jQuery,
            _$ = window.$;
        return jQuery.noConflict = function(e) {
            return window.$ === jQuery && (window.$ = _$), e && window.jQuery === jQuery && (window.jQuery = _jQuery), jQuery
        }, typeof noGlobal === strundefined && (window.jQuery = window.$ = jQuery), jQuery
    }),
    function(e, t, n) {
        function s(e, n) {
            this.wrapper = typeof e == "string" ? t.querySelector(e) : e, this.scroller = this.wrapper.children[0], this.scrollerStyle = this.scroller.style, this.options = {
                resizeScrollbars: !0,
                mouseWheelSpeed: 20,
                snapThreshold: .334,
                startX: 0,
                startY: 0,
                scrollY: !0,
                directionLockThreshold: 5,
                momentum: !0,
                bounce: !0,
                bounceTime: 600,
                bounceEasing: "",
                preventDefault: !0,
                preventDefaultException: {
                    tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT)$/
                },
                HWCompositing: !0,
                useTransition: !0,
                useTransform: !0
            };
            for (var r in n) this.options[r] = n[r];
            this.translateZ = this.options.HWCompositing && i.hasPerspective ? " translateZ(0)" : "", this.options.useTransition = i.hasTransition && this.options.useTransition, this.options.useTransform = i.hasTransform && this.options.useTransform, this.options.eventPassthrough = this.options.eventPassthrough === !0 ? "vertical" : this.options.eventPassthrough, this.options.preventDefault = !this.options.eventPassthrough && this.options.preventDefault, this.options.scrollY = this.options.eventPassthrough == "vertical" ? !1 : this.options.scrollY, this.options.scrollX = this.options.eventPassthrough == "horizontal" ? !1 : this.options.scrollX, this.options.freeScroll = this.options.freeScroll && !this.options.eventPassthrough, this.options.directionLockThreshold = this.options.eventPassthrough ? 0 : this.options.directionLockThreshold, this.options.bounceEasing = typeof this.options.bounceEasing == "string" ? i.ease[this.options.bounceEasing] || i.ease.circular : this.options.bounceEasing, this.options.resizePolling = this.options.resizePolling === undefined ? 60 : this.options.resizePolling, this.options.tap === !0 && (this.options.tap = "tap"), this.options.shrinkScrollbars == "scale" && (this.options.useTransition = !1), this.options.invertWheelDirection = this.options.invertWheelDirection ? -1 : 1, this.x = 0, this.y = 0, this.directionX = 0, this.directionY = 0, this._events = {}, this._init(), this.refresh(), this.scrollTo(this.options.startX, this.options.startY), this.enable()
        }

        function o(e, n, r) {
            var i = t.createElement("div"),
                s = t.createElement("div");
            return r === !0 && (i.style.cssText = "position:absolute;z-index:9999", s.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.9);border-radius:3px"), s.className = "iScrollIndicator", e == "h" ? (r === !0 && (i.style.cssText += ";height:7px;left:2px;right:2px;bottom:0", s.style.height = "100%"), i.className = "iScrollHorizontalScrollbar") : (r === !0 && (i.style.cssText += ";width:7px;bottom:2px;top:2px;right:1px", s.style.width = "100%"), i.className = "iScrollVerticalScrollbar"), i.style.cssText += ";overflow:hidden", n || (i.style.pointerEvents = "none"), i.appendChild(s), i
        }

        function u(n, r) {
            this.wrapper = typeof r.el == "string" ? t.querySelector(r.el) : r.el, this.wrapperStyle = this.wrapper.style, this.indicator = this.wrapper.children[0], this.indicatorStyle = this.indicator.style, this.scroller = n, this.options = {
                listenX: !0,
                listenY: !0,
                interactive: !1,
                resize: !0,
                defaultScrollbars: !1,
                shrink: !1,
                fade: !1,
                speedRatioX: 0,
                speedRatioY: 0
            };
            for (var s in r) this.options[s] = r[s];
            this.sizeRatioX = 1, this.sizeRatioY = 1, this.maxPosX = 0, this.maxPosY = 0, this.options.interactive && (this.options.disableTouch || (i.addEvent(this.indicator, "touchstart", this), i.addEvent(e, "touchend", this)), this.options.disablePointer || (i.addEvent(this.indicator, i.prefixPointerEvent("pointerdown"), this), i.addEvent(e, i.prefixPointerEvent("pointerup"), this)), this.options.disableMouse || (i.addEvent(this.indicator, "mousedown", this), i.addEvent(e, "mouseup", this))), this.options.fade && (this.wrapperStyle[i.style.transform] = this.scroller.translateZ, this.wrapperStyle[i.style.transitionDuration] = i.isBadAndroid ? "0.001s" : "0ms", this.wrapperStyle.opacity = "0")
        }
        var r = e.requestAnimationFrame || e.webkitRequestAnimationFrame || e.mozRequestAnimationFrame || e.oRequestAnimationFrame || e.msRequestAnimationFrame || function(t) {
                e.setTimeout(t, 1e3 / 60)
            },
            i = function() {
                function o(e) {
                    return s === !1 ? !1 : s === "" ? e : s + e.charAt(0).toUpperCase() + e.substr(1)
                }
                var r = {},
                    i = t.createElement("div").style,
                    s = function() {
                        var e = ["t", "webkitT", "MozT", "msT", "OT"],
                            t, n = 0,
                            r = e.length;
                        for (; n < r; n++) {
                            t = e[n] + "ransform";
                            if (t in i) return e[n].substr(0, e[n].length - 1)
                        }
                        return !1
                    }();
                r.getTime = Date.now || function() {
                    return (new Date).getTime()
                }, r.extend = function(e, t) {
                    for (var n in t) e[n] = t[n]
                }, r.addEvent = function(e, t, n, r) {
                    e.addEventListener(t, n, !!r)
                }, r.removeEvent = function(e, t, n, r) {
                    e.removeEventListener(t, n, !!r)
                }, r.prefixPointerEvent = function(t) {
                    return e.MSPointerEvent ? "MSPointer" + t.charAt(9).toUpperCase() + t.substr(10) : t
                }, r.momentum = function(e, t, r, i, s, o) {
                    var u = e - t,
                        a = n.abs(u) / r,
                        f, l;
                    return o = o === undefined ? 6e-4 : o, f = e + a * a / (2 * o) * (u < 0 ? -1 : 1), l = a / o, f < i ? (f = s ? i - s / 2.5 * (a / 8) : i, u = n.abs(f - e), l = u / a) : f > 0 && (f = s ? s / 2.5 * (a / 8) : 0, u = n.abs(e) + f, l = u / a), {
                        destination: n.round(f),
                        duration: l
                    }
                };
                var u = o("transform");
                return r.extend(r, {
                    hasTransform: u !== !1,
                    hasPerspective: o("perspective") in i,
                    hasTouch: "ontouchstart" in e,
                    hasPointer: e.PointerEvent || e.MSPointerEvent,
                    hasTransition: o("transition") in i
                }), r.isBadAndroid = /Android /.test(e.navigator.appVersion) && !/Chrome\/\d/.test(e.navigator.appVersion), r.extend(r.style = {}, {
                    transform: u,
                    transitionTimingFunction: o("transitionTimingFunction"),
                    transitionDuration: o("transitionDuration"),
                    transitionDelay: o("transitionDelay"),
                    transformOrigin: o("transformOrigin")
                }), r.hasClass = function(e, t) {
                    var n = new RegExp("(^|\\s)" + t + "(\\s|$)");
                    return n.test(e.className)
                }, r.addClass = function(e, t) {
                    if (r.hasClass(e, t)) return;
                    var n = e.className.split(" ");
                    n.push(t), e.className = n.join(" ")
                }, r.removeClass = function(e, t) {
                    if (!r.hasClass(e, t)) return;
                    var n = new RegExp("(^|\\s)" + t + "(\\s|$)", "g");
                    e.className = e.className.replace(n, " ")
                }, r.offset = function(e) {
                    var t = -e.offsetLeft,
                        n = -e.offsetTop;
                    while (e = e.offsetParent) t -= e.offsetLeft, n -= e.offsetTop;
                    return {
                        left: t,
                        top: n
                    }
                }, r.preventDefaultException = function(e, t) {
                    for (var n in t)
                        if (t[n].test(e[n])) return !0;
                    return !1
                }, r.extend(r.eventType = {}, {
                    touchstart: 1,
                    touchmove: 1,
                    touchend: 1,
                    mousedown: 2,
                    mousemove: 2,
                    mouseup: 2,
                    pointerdown: 3,
                    pointermove: 3,
                    pointerup: 3,
                    MSPointerDown: 3,
                    MSPointerMove: 3,
                    MSPointerUp: 3
                }), r.extend(r.ease = {}, {
                    quadratic: {
                        style: "cubic-bezier(0.25, 0.46, 0.45, 0.94)",
                        fn: function(e) {
                            return e * (2 - e)
                        }
                    },
                    circular: {
                        style: "cubic-bezier(0.1, 0.57, 0.1, 1)",
                        fn: function(e) {
                            return n.sqrt(1 - --e * e)
                        }
                    },
                    back: {
                        style: "cubic-bezier(0.175, 0.885, 0.32, 1.275)",
                        fn: function(e) {
                            var t = 4;
                            return (e -= 1) * e * ((t + 1) * e + t) + 1
                        }
                    },
                    bounce: {
                        style: "",
                        fn: function(e) {
                            return (e /= 1) < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375
                        }
                    },
                    elastic: {
                        style: "",
                        fn: function(e) {
                            var t = .22,
                                r = .4;
                            return e === 0 ? 0 : e == 1 ? 1 : r * n.pow(2, -10 * e) * n.sin((e - t / 4) * 2 * n.PI / t) + 1
                        }
                    }
                }), r.tap = function(e, n) {
                    var r = t.createEvent("Event");
                    r.initEvent(n, !0, !0), r.pageX = e.pageX, r.pageY = e.pageY, e.target.dispatchEvent(r)
                }, r.click = function(e) {
                    var n = e.target,
                        r;
                    /(SELECT|INPUT|TEXTAREA)/i.test(n.tagName) || (r = t.createEvent("MouseEvents"), r.initMouseEvent("click", !0, !0, e.view, 1, n.screenX, n.screenY, n.clientX, n.clientY, e.ctrlKey, e.altKey, e.shiftKey, e.metaKey, 0, null), r._constructed = !0, n.dispatchEvent(r))
                }, r
            }();
        s.prototype = {
            version: "5.1.3",
            _init: function() {
                this._initEvents(), (this.options.scrollbars || this.options.indicators) && this._initIndicators(), this.options.mouseWheel && this._initWheel(), this.options.snap && this._initSnap(), this.options.keyBindings && this._initKeys()
            },
            destroy: function() {
                this._initEvents(!0), this._execEvent("destroy")
            },
            _transitionEnd: function(e) {
                if (e.target != this.scroller || !this.isInTransition) return;
                this._transitionTime(), this.resetPosition(this.options.bounceTime) || (this.isInTransition = !1, this._execEvent("scrollEnd"))
            },
            _start: function(e) {
                if (i.eventType[e.type] != 1 && e.button !== 0) return;
                if (!this.enabled || this.initiated && i.eventType[e.type] !== this.initiated) return;
                this.options.preventDefault && !i.isBadAndroid && !i.preventDefaultException(e.target, this.options.preventDefaultException) && e.preventDefault();
                var t = e.touches ? e.touches[0] : e,
                    r;
                this.initiated = i.eventType[e.type], this.moved = !1, this.distX = 0, this.distY = 0, this.directionX = 0, this.directionY = 0, this.directionLocked = 0, this._transitionTime(), this.startTime = i.getTime(), this.options.useTransition && this.isInTransition ? (this.isInTransition = !1, r = this.getComputedPosition(), this._translate(n.round(r.x), n.round(r.y)), this._execEvent("scrollEnd")) : !this.options.useTransition && this.isAnimating && (this.isAnimating = !1, this._execEvent("scrollEnd")), this.startX = this.x, this.startY = this.y, this.absStartX = this.x, this.absStartY = this.y, this.pointX = t.pageX, this.pointY = t.pageY, this._execEvent("beforeScrollStart")
            },
            _move: function(e) {
                if (!this.enabled || i.eventType[e.type] !== this.initiated) return;
                this.options.preventDefault && e.preventDefault();
                var t = e.touches ? e.touches[0] : e,
                    r = t.pageX - this.pointX,
                    s = t.pageY - this.pointY,
                    o = i.getTime(),
                    u, a, f, l;
                this.pointX = t.pageX, this.pointY = t.pageY, this.distX += r, this.distY += s, f = n.abs(this.distX), l = n.abs(this.distY);
                if (o - this.endTime > 300 && f < 10 && l < 10) return;
                !this.directionLocked && !this.options.freeScroll && (f > l + this.options.directionLockThreshold ? this.directionLocked = "h" : l >= f + this.options.directionLockThreshold ? this.directionLocked = "v" : this.directionLocked = "n");
                if (this.directionLocked == "h") {
                    if (this.options.eventPassthrough == "vertical") e.preventDefault();
                    else if (this.options.eventPassthrough == "horizontal") {
                        this.initiated = !1;
                        return
                    }
                    s = 0
                } else if (this.directionLocked == "v") {
                    if (this.options.eventPassthrough == "horizontal") e.preventDefault();
                    else if (this.options.eventPassthrough == "vertical") {
                        this.initiated = !1;
                        return
                    }
                    r = 0
                }
                r = this.hasHorizontalScroll ? r : 0, s = this.hasVerticalScroll ? s : 0, u = this.x + r, a = this.y + s;
                if (u > 0 || u < this.maxScrollX) u = this.options.bounce ? this.x + r / 3 : u > 0 ? 0 : this.maxScrollX;
                if (a > 0 || a < this.maxScrollY) a = this.options.bounce ? this.y + s / 3 : a > 0 ? 0 : this.maxScrollY;
                this.directionX = r > 0 ? -1 : r < 0 ? 1 : 0, this.directionY = s > 0 ? -1 : s < 0 ? 1 : 0, this.moved || this._execEvent("scrollStart"), this.moved = !0, this._translate(u, a), o - this.startTime > 300 && (this.startTime = o, this.startX = this.x, this.startY = this.y)
            },
            _end: function(e) {
                if (!this.enabled || i.eventType[e.type] !== this.initiated) return;
                this.options.preventDefault && !i.preventDefaultException(e.target, this.options.preventDefaultException) && e.preventDefault();
                var t = e.changedTouches ? e.changedTouches[0] : e,
                    r, s, o = i.getTime() - this.startTime,
                    u = n.round(this.x),
                    a = n.round(this.y),
                    f = n.abs(u - this.startX),
                    l = n.abs(a - this.startY),
                    c = 0,
                    h = "";
                this.isInTransition = 0, this.initiated = 0, this.endTime = i.getTime();
                if (this.resetPosition(this.options.bounceTime)) return;
                this.scrollTo(u, a);
                if (!this.moved) {
                    this.options.tap && i.tap(e, this.options.tap), this.options.click && i.click(e), this._execEvent("scrollCancel");
                    return
                }
                if (this._events.flick && o < 200 && f < 100 && l < 100) {
                    this._execEvent("flick");
                    return
                }
                this.options.momentum && o < 300 && (r = this.hasHorizontalScroll ? i.momentum(this.x, this.startX, o, this.maxScrollX, this.options.bounce ? this.wrapperWidth : 0, this.options.deceleration) : {
                    destination: u,
                    duration: 0
                }, s = this.hasVerticalScroll ? i.momentum(this.y, this.startY, o, this.maxScrollY, this.options.bounce ? this.wrapperHeight : 0, this.options.deceleration) : {
                    destination: a,
                    duration: 0
                }, u = r.destination, a = s.destination, c = n.max(r.duration, s.duration), this.isInTransition = 1);
                if (this.options.snap) {
                    var p = this._nearestSnap(u, a);
                    this.currentPage = p, c = this.options.snapSpeed || n.max(n.max(n.min(n.abs(u - p.x), 1e3), n.min(n.abs(a - p.y), 1e3)), 300), u = p.x, a = p.y, this.directionX = 0, this.directionY = 0, h = this.options.bounceEasing
                }
                if (u != this.x || a != this.y) {
                    if (u > 0 || u < this.maxScrollX || a > 0 || a < this.maxScrollY) h = i.ease.quadratic;
                    this.scrollTo(u, a, c, h);
                    return
                }
                this._execEvent("scrollEnd")
            },
            _resize: function() {
                var e = this;
                clearTimeout(this.resizeTimeout), this.resizeTimeout = setTimeout(function() {
                    e.refresh()
                }, this.options.resizePolling)
            },
            resetPosition: function(e) {
                var t = this.x,
                    n = this.y;
                return e = e || 0, !this.hasHorizontalScroll || this.x > 0 ? t = 0 : this.x < this.maxScrollX && (t = this.maxScrollX), !this.hasVerticalScroll || this.y > 0 ? n = 0 : this.y < this.maxScrollY && (n = this.maxScrollY), t == this.x && n == this.y ? !1 : (this.scrollTo(t, n, e, this.options.bounceEasing), !0)
            },
            disable: function() {
                this.enabled = !1
            },
            enable: function() {
                this.enabled = !0
            },
            refresh: function() {
                var e = this.wrapper.offsetHeight;
                this.wrapperWidth = this.wrapper.clientWidth, this.wrapperHeight = this.wrapper.clientHeight, this.scrollerWidth = this.scroller.offsetWidth, this.scrollerHeight = this.scroller.offsetHeight, this.maxScrollX = this.wrapperWidth - this.scrollerWidth, this.maxScrollY = this.wrapperHeight - this.scrollerHeight, this.hasHorizontalScroll = this.options.scrollX && this.maxScrollX < 0, this.hasVerticalScroll = this.options.scrollY && this.maxScrollY < 0, this.hasHorizontalScroll || (this.maxScrollX = 0, this.scrollerWidth = this.wrapperWidth), this.hasVerticalScroll || (this.maxScrollY = 0, this.scrollerHeight = this.wrapperHeight), this.endTime = 0, this.directionX = 0, this.directionY = 0, this.wrapperOffset = i.offset(this.wrapper), this._execEvent("refresh"), this.resetPosition()
            },
            on: function(e, t) {
                this._events[e] || (this._events[e] = []), this._events[e].push(t)
            },
            off: function(e, t) {
                if (!this._events[e]) return;
                var n = this._events[e].indexOf(t);
                n > -1 && this._events[e].splice(n, 1)
            },
            _execEvent: function(e) {
                if (!this._events[e]) return;
                var t = 0,
                    n = this._events[e].length;
                if (!n) return;
                for (; t < n; t++) this._events[e][t].apply(this, [].slice.call(arguments, 1))
            },
            scrollBy: function(e, t, n, r) {
                e = this.x + e, t = this.y + t, n = n || 0, this.scrollTo(e, t, n, r)
            },
            scrollTo: function(e, t, n, r) {
                r = r || i.ease.circular, this.isInTransition = this.options.useTransition && n > 0, !n || this.options.useTransition && r.style ? (this._transitionTimingFunction(r.style), this._transitionTime(n), this._translate(e, t)) : this._animate(e, t, n, r.fn)
            },
            scrollToElement: function(e, t, r, s, o) {
                e = e.nodeType ? e : this.scroller.querySelector(e);
                if (!e) return;
                var u = i.offset(e);
                u.left -= this.wrapperOffset.left, u.top -= this.wrapperOffset.top, r === !0 && (r = n.round(e.offsetWidth / 2 - this.wrapper.offsetWidth / 2)), s === !0 && (s = n.round(e.offsetHeight / 2 - this.wrapper.offsetHeight / 2)), u.left -= r || 0, u.top -= s || 0, u.left = u.left > 0 ? 0 : u.left < this.maxScrollX ? this.maxScrollX : u.left, u.top = u.top > 0 ? 0 : u.top < this.maxScrollY ? this.maxScrollY : u.top, t = t === undefined || t === null || t === "auto" ? n.max(n.abs(this.x - u.left), n.abs(this.y - u.top)) : t, this.scrollTo(u.left, u.top, t, o)
            },
            _transitionTime: function(e) {
                e = e || 0, this.scrollerStyle[i.style.transitionDuration] = e + "ms", !e && i.isBadAndroid && (this.scrollerStyle[i.style.transitionDuration] = "0.001s");
                if (this.indicators)
                    for (var t = this.indicators.length; t--;) this.indicators[t].transitionTime(e)
            },
            _transitionTimingFunction: function(e) {
                this.scrollerStyle[i.style.transitionTimingFunction] = e;
                if (this.indicators)
                    for (var t = this.indicators.length; t--;) this.indicators[t].transitionTimingFunction(e)
            },
            _translate: function(e, t) {
                this.options.useTransform ? this.scrollerStyle[i.style.transform] = "translate(" + e + "px," + t + "px)" + this.translateZ : (e = n.round(e), t = n.round(t), this.scrollerStyle.left = e + "px", this.scrollerStyle.top = t + "px"), this.x = e, this.y = t;
                if (this.indicators)
                    for (var r = this.indicators.length; r--;) this.indicators[r].updatePosition()
            },
            _initEvents: function(t) {
                var n = t ? i.removeEvent : i.addEvent,
                    r = this.options.bindToWrapper ? this.wrapper : e;
                n(e, "orientationchange", this), n(e, "resize", this), this.options.click && n(this.wrapper, "click", this, !0), this.options.disableMouse || (n(this.wrapper, "mousedown", this), n(r, "mousemove", this), n(r, "mousecancel", this), n(r, "mouseup", this)), i.hasPointer && !this.options.disablePointer && (n(this.wrapper, i.prefixPointerEvent("pointerdown"), this), n(r, i.prefixPointerEvent("pointermove"), this), n(r, i.prefixPointerEvent("pointercancel"), this), n(r, i.prefixPointerEvent("pointerup"), this)), i.hasTouch && !this.options.disableTouch && (n(this.wrapper, "touchstart", this), n(r, "touchmove", this), n(r, "touchcancel", this), n(r, "touchend", this)), n(this.scroller, "transitionend", this), n(this.scroller, "webkitTransitionEnd", this), n(this.scroller, "oTransitionEnd", this), n(this.scroller, "MSTransitionEnd", this)
            },
            getComputedPosition: function() {
                var t = e.getComputedStyle(this.scroller, null),
                    n, r;
                return this.options.useTransform ? (t = t[i.style.transform].split(")")[0].split(", "), n = +(t[12] || t[4]), r = +(t[13] || t[5])) : (n = +t.left.replace(/[^-\d.]/g, ""), r = +t.top.replace(/[^-\d.]/g, "")), {
                    x: n,
                    y: r
                }
            },
            _initIndicators: function() {
                function a(e) {
                    for (var t = i.indicators.length; t--;) e.call(i.indicators[t])
                }
                var e = this.options.interactiveScrollbars,
                    t = typeof this.options.scrollbars != "string",
                    n = [],
                    r, i = this;
                this.indicators = [], this.options.scrollbars && (this.options.scrollY && (r = {
                    el: o("v", e, this.options.scrollbars),
                    interactive: e,
                    defaultScrollbars: !0,
                    customStyle: t,
                    resize: this.options.resizeScrollbars,
                    shrink: this.options.shrinkScrollbars,
                    fade: this.options.fadeScrollbars,
                    listenX: !1
                }, this.wrapper.appendChild(r.el), n.push(r)), this.options.scrollX && (r = {
                    el: o("h", e, this.options.scrollbars),
                    interactive: e,
                    defaultScrollbars: !0,
                    customStyle: t,
                    resize: this.options.resizeScrollbars,
                    shrink: this.options.shrinkScrollbars,
                    fade: this.options.fadeScrollbars,
                    listenY: !1
                }, this.wrapper.appendChild(r.el), n.push(r))), this.options.indicators && (n = n.concat(this.options.indicators));
                for (var s = n.length; s--;) this.indicators.push(new u(this, n[s]));
                this.options.fadeScrollbars && (this.on("scrollEnd", function() {
                    a(function() {
                        this.fade()
                    })
                }), this.on("scrollCancel", function() {
                    a(function() {
                        this.fade()
                    })
                }), this.on("scrollStart", function() {
                    a(function() {
                        this.fade(1)
                    })
                }), this.on("beforeScrollStart", function() {
                    a(function() {
                        this.fade(1, !0)
                    })
                })), this.on("refresh", function() {
                    a(function() {
                        this.refresh()
                    })
                }), this.on("destroy", function() {
                    a(function() {
                        this.destroy()
                    }), delete this.indicators
                })
            },
            _initWheel: function() {
                i.addEvent(this.wrapper, "wheel", this), i.addEvent(this.wrapper, "mousewheel", this), i.addEvent(this.wrapper, "DOMMouseScroll", this), this.on("destroy", function() {
                    i.removeEvent(this.wrapper, "wheel", this), i.removeEvent(this.wrapper, "mousewheel", this), i.removeEvent(this.wrapper, "DOMMouseScroll", this)
                })
            },
            _wheel: function(e) {
                if (!this.enabled) return;
                e.preventDefault(), e.stopPropagation();
                var t, r, i, s, o = this;
                this.wheelTimeout === undefined && o._execEvent("scrollStart"), clearTimeout(this.wheelTimeout), this.wheelTimeout = setTimeout(function() {
                    o._execEvent("scrollEnd"), o.wheelTimeout = undefined
                }, 400);
                if ("deltaX" in e) e.deltaMode === 1 ? (t = -e.deltaX * this.options.mouseWheelSpeed, r = -e.deltaY * this.options.mouseWheelSpeed) : (t = -e.deltaX, r = -e.deltaY);
                else if ("wheelDeltaX" in e) t = e.wheelDeltaX / 120 * this.options.mouseWheelSpeed, r = e.wheelDeltaY / 120 * this.options.mouseWheelSpeed;
                else if ("wheelDelta" in e) t = r = e.wheelDelta / 120 * this.options.mouseWheelSpeed;
                else {
                    if (!("detail" in e)) return;
                    t = r = -e.detail / 3 * this.options.mouseWheelSpeed
                }
                t *= this.options.invertWheelDirection, r *= this.options.invertWheelDirection, this.hasVerticalScroll || (t = r, r = 0);
                if (this.options.snap) {
                    i = this.currentPage.pageX, s = this.currentPage.pageY, t > 0 ? i-- : t < 0 && i++, r > 0 ? s-- : r < 0 && s++, this.goToPage(i, s);
                    return
                }
                i = this.x + n.round(this.hasHorizontalScroll ? t : 0), s = this.y + n.round(this.hasVerticalScroll ? r : 0), i > 0 ? i = 0 : i < this.maxScrollX && (i = this.maxScrollX), s > 0 ? s = 0 : s < this.maxScrollY && (s = this.maxScrollY), this.scrollTo(i, s, 0)
            },
            _initSnap: function() {
                this.currentPage = {}, typeof this.options.snap == "string" && (this.options.snap = this.scroller.querySelectorAll(this.options.snap)), this.on("refresh", function() {
                    var e = 0,
                        t, r = 0,
                        i, s, o, u = 0,
                        a, f = this.options.snapStepX || this.wrapperWidth,
                        l = this.options.snapStepY || this.wrapperHeight,
                        c;
                    this.pages = [];
                    if (!this.wrapperWidth || !this.wrapperHeight || !this.scrollerWidth || !this.scrollerHeight) return;
                    if (this.options.snap === !0) {
                        s = n.round(f / 2), o = n.round(l / 2);
                        while (u > -this.scrollerWidth) {
                            this.pages[e] = [], t = 0, a = 0;
                            while (a > -this.scrollerHeight) this.pages[e][t] = {
                                x: n.max(u, this.maxScrollX),
                                y: n.max(a, this.maxScrollY),
                                width: f,
                                height: l,
                                cx: u - s,
                                cy: a - o
                            }, a -= l, t++;
                            u -= f, e++
                        }
                    } else {
                        c = this.options.snap, t = c.length, i = -1;
                        for (; e < t; e++) {
                            if (e === 0 || c[e].offsetLeft <= c[e - 1].offsetLeft) r = 0, i++;
                            this.pages[r] || (this.pages[r] = []), u = n.max(-c[e].offsetLeft, this.maxScrollX), a = n.max(-c[e].offsetTop, this.maxScrollY), s = u - n.round(c[e].offsetWidth / 2), o = a - n.round(c[e].offsetHeight / 2), this.pages[r][i] = {
                                x: u,
                                y: a,
                                width: c[e].offsetWidth,
                                height: c[e].offsetHeight,
                                cx: s,
                                cy: o
                            }, u > this.maxScrollX && r++
                        }
                    }
                    this.goToPage(this.currentPage.pageX || 0, this.currentPage.pageY || 0, 0), this.options.snapThreshold % 1 === 0 ? (this.snapThresholdX = this.options.snapThreshold, this.snapThresholdY = this.options.snapThreshold) : (this.snapThresholdX = n.round(this.pages[this.currentPage.pageX][this.currentPage.pageY].width * this.options.snapThreshold), this.snapThresholdY = n.round(this.pages[this.currentPage.pageX][this.currentPage.pageY].height * this.options.snapThreshold))
                }), this.on("flick", function() {
                    var e = this.options.snapSpeed || n.max(n.max(n.min(n.abs(this.x - this.startX), 1e3), n.min(n.abs(this.y - this.startY), 1e3)), 300);
                    this.goToPage(this.currentPage.pageX + this.directionX, this.currentPage.pageY + this.directionY, e)
                })
            },
            _nearestSnap: function(e, t) {
                if (!this.pages.length) return {
                    x: 0,
                    y: 0,
                    pageX: 0,
                    pageY: 0
                };
                var r = 0,
                    i = this.pages.length,
                    s = 0;
                if (n.abs(e - this.absStartX) < this.snapThresholdX && n.abs(t - this.absStartY) < this.snapThresholdY) return this.currentPage;
                e > 0 ? e = 0 : e < this.maxScrollX && (e = this.maxScrollX), t > 0 ? t = 0 : t < this.maxScrollY && (t = this.maxScrollY);
                for (; r < i; r++)
                    if (e >= this.pages[r][0].cx) {
                        e = this.pages[r][0].x;
                        break
                    } i = this.pages[r].length;
                for (; s < i; s++)
                    if (t >= this.pages[0][s].cy) {
                        t = this.pages[0][s].y;
                        break
                    } return r == this.currentPage.pageX && (r += this.directionX, r < 0 ? r = 0 : r >= this.pages.length && (r = this.pages.length - 1), e = this.pages[r][0].x), s == this.currentPage.pageY && (s += this.directionY, s < 0 ? s = 0 : s >= this.pages[0].length && (s = this.pages[0].length - 1), t = this.pages[0][s].y), {
                    x: e,
                    y: t,
                    pageX: r,
                    pageY: s
                }
            },
            goToPage: function(e, t, r, i) {
                i = i || this.options.bounceEasing, e >= this.pages.length ? e = this.pages.length - 1 : e < 0 && (e = 0), t >= this.pages[e].length ? t = this.pages[e].length - 1 : t < 0 && (t = 0);
                var s = this.pages[e][t].x,
                    o = this.pages[e][t].y;
                r = r === undefined ? this.options.snapSpeed || n.max(n.max(n.min(n.abs(s - this.x), 1e3), n.min(n.abs(o - this.y), 1e3)), 300) : r, this.currentPage = {
                    x: s,
                    y: o,
                    pageX: e,
                    pageY: t
                }, this.scrollTo(s, o, r, i)
            },
            next: function(e, t) {
                var n = this.currentPage.pageX,
                    r = this.currentPage.pageY;
                n++, n >= this.pages.length && this.hasVerticalScroll && (n = 0, r++), this.goToPage(n, r, e, t)
            },
            prev: function(e, t) {
                var n = this.currentPage.pageX,
                    r = this.currentPage.pageY;
                n--, n < 0 && this.hasVerticalScroll && (n = 0, r--), this.goToPage(n, r, e, t)
            },
            _initKeys: function(t) {
                var n = {
                        pageUp: 33,
                        pageDown: 34,
                        end: 35,
                        home: 36,
                        left: 37,
                        up: 38,
                        right: 39,
                        down: 40
                    },
                    r;
                if (typeof this.options.keyBindings == "object")
                    for (r in this.options.keyBindings) typeof this.options.keyBindings[r] == "string" && (this.options.keyBindings[r] = this.options.keyBindings[r].toUpperCase().charCodeAt(0));
                else this.options.keyBindings = {};
                for (r in n) this.options.keyBindings[r] = this.options.keyBindings[r] || n[r];
                i.addEvent(e, "keydown", this), this.on("destroy", function() {
                    i.removeEvent(e, "keydown", this)
                })
            },
            _key: function(e) {
                if (!this.enabled) return;
                var t = this.options.snap,
                    r = t ? this.currentPage.pageX : this.x,
                    s = t ? this.currentPage.pageY : this.y,
                    o = i.getTime(),
                    u = this.keyTime || 0,
                    a = .25,
                    f;
                this.options.useTransition && this.isInTransition && (f = this.getComputedPosition(), this._translate(n.round(f.x), n.round(f.y)), this.isInTransition = !1), this.keyAcceleration = o - u < 200 ? n.min(this.keyAcceleration + a, 50) : 0;
                switch (e.keyCode) {
                    case this.options.keyBindings.pageUp:
                        this.hasHorizontalScroll && !this.hasVerticalScroll ? r += t ? 1 : this.wrapperWidth : s += t ? 1 : this.wrapperHeight;
                        break;
                    case this.options.keyBindings.pageDown:
                        this.hasHorizontalScroll && !this.hasVerticalScroll ? r -= t ? 1 : this.wrapperWidth : s -= t ? 1 : this.wrapperHeight;
                        break;
                    case this.options.keyBindings.end:
                        r = t ? this.pages.length - 1 : this.maxScrollX, s = t ? this.pages[0].length - 1 : this.maxScrollY;
                        break;
                    case this.options.keyBindings.home:
                        r = 0, s = 0;
                        break;
                    case this.options.keyBindings.left:
                        r += t ? -1 : 5 + this.keyAcceleration >> 0;
                        break;
                    case this.options.keyBindings.up:
                        s += t ? 1 : 5 + this.keyAcceleration >> 0;
                        break;
                    case this.options.keyBindings.right:
                        r -= t ? -1 : 5 + this.keyAcceleration >> 0;
                        break;
                    case this.options.keyBindings.down:
                        s -= t ? 1 : 5 + this.keyAcceleration >> 0;
                        break;
                    default:
                        return
                }
                if (t) {
                    this.goToPage(r, s);
                    return
                }
                r > 0 ? (r = 0, this.keyAcceleration = 0) : r < this.maxScrollX && (r = this.maxScrollX, this.keyAcceleration = 0), s > 0 ? (s = 0, this.keyAcceleration = 0) : s < this.maxScrollY && (s = this.maxScrollY, this.keyAcceleration = 0), this.scrollTo(r, s, 0), this.keyTime = o
            },
            _animate: function(e, t, n, s) {
                function c() {
                    var h = i.getTime(),
                        p, d, v;
                    if (h >= l) {
                        o.isAnimating = !1, o._translate(e, t), o.resetPosition(o.options.bounceTime) || o._execEvent("scrollEnd");
                        return
                    }
                    h = (h - f) / n, v = s(h), p = (e - u) * v + u, d = (t - a) * v + a, o._translate(p, d), o.isAnimating && r(c)
                }
                var o = this,
                    u = this.x,
                    a = this.y,
                    f = i.getTime(),
                    l = f + n;
                this.isAnimating = !0, c()
            },
            handleEvent: function(e) {
                switch (e.type) {
                    case "touchstart":
                    case "pointerdown":
                    case "MSPointerDown":
                    case "mousedown":
                        this._start(e);
                        break;
                    case "touchmove":
                    case "pointermove":
                    case "MSPointerMove":
                    case "mousemove":
                        this._move(e);
                        break;
                    case "touchend":
                    case "pointerup":
                    case "MSPointerUp":
                    case "mouseup":
                    case "touchcancel":
                    case "pointercancel":
                    case "MSPointerCancel":
                    case "mousecancel":
                        this._end(e);
                        break;
                    case "orientationchange":
                    case "resize":
                        this._resize();
                        break;
                    case "transitionend":
                    case "webkitTransitionEnd":
                    case "oTransitionEnd":
                    case "MSTransitionEnd":
                        this._transitionEnd(e);
                        break;
                    case "wheel":
                    case "DOMMouseScroll":
                    case "mousewheel":
                        this._wheel(e);
                        break;
                    case "keydown":
                        this._key(e);
                        break;
                    case "click":
                        e._constructed || (e.preventDefault(), e.stopPropagation())
                }
            }
        }, u.prototype = {
            handleEvent: function(e) {
                switch (e.type) {
                    case "touchstart":
                    case "pointerdown":
                    case "MSPointerDown":
                    case "mousedown":
                        this._start(e);
                        break;
                    case "touchmove":
                    case "pointermove":
                    case "MSPointerMove":
                    case "mousemove":
                        this._move(e);
                        break;
                    case "touchend":
                    case "pointerup":
                    case "MSPointerUp":
                    case "mouseup":
                    case "touchcancel":
                    case "pointercancel":
                    case "MSPointerCancel":
                    case "mousecancel":
                        this._end(e)
                }
            },
            destroy: function() {
                this.options.interactive && (i.removeEvent(this.indicator, "touchstart", this), i.removeEvent(this.indicator, i.prefixPointerEvent("pointerdown"), this), i.removeEvent(this.indicator, "mousedown", this), i.removeEvent(e, "touchmove", this), i.removeEvent(e, i.prefixPointerEvent("pointermove"), this), i.removeEvent(e, "mousemove", this), i.removeEvent(e, "touchend", this), i.removeEvent(e, i.prefixPointerEvent("pointerup"), this), i.removeEvent(e, "mouseup", this)), this.options.defaultScrollbars && this.wrapper.parentNode.removeChild(this.wrapper)
            },
            _start: function(t) {
                var n = t.touches ? t.touches[0] : t;
                t.preventDefault(), t.stopPropagation(), this.transitionTime(), this.initiated = !0, this.moved = !1, this.lastPointX = n.pageX, this.lastPointY = n.pageY, this.startTime = i.getTime(), this.options.disableTouch || i.addEvent(e, "touchmove", this), this.options.disablePointer || i.addEvent(e, i.prefixPointerEvent("pointermove"), this), this.options.disableMouse || i.addEvent(e, "mousemove", this), this.scroller._execEvent("beforeScrollStart")
            },
            _move: function(e) {
                var t = e.touches ? e.touches[0] : e,
                    n, r, s, o, u = i.getTime();
                this.moved || this.scroller._execEvent("scrollStart"), this.moved = !0, n = t.pageX - this.lastPointX, this.lastPointX = t.pageX, r = t.pageY - this.lastPointY, this.lastPointY = t.pageY, s = this.x + n, o = this.y + r, this._pos(s, o), e.preventDefault(), e.stopPropagation()
            },
            _end: function(t) {
                if (!this.initiated) return;
                this.initiated = !1, t.preventDefault(), t.stopPropagation(), i.removeEvent(e, "touchmove", this), i.removeEvent(e, i.prefixPointerEvent("pointermove"), this), i.removeEvent(e, "mousemove", this);
                if (this.scroller.options.snap) {
                    var r = this.scroller._nearestSnap(this.scroller.x, this.scroller.y),
                        s = this.options.snapSpeed || n.max(n.max(n.min(n.abs(this.scroller.x - r.x), 1e3), n.min(n.abs(this.scroller.y - r.y), 1e3)), 300);
                    if (this.scroller.x != r.x || this.scroller.y != r.y) this.scroller.directionX = 0, this.scroller.directionY = 0, this.scroller.currentPage = r, this.scroller.scrollTo(r.x, r.y, s, this.scroller.options.bounceEasing)
                }
                this.moved && this.scroller._execEvent("scrollEnd")
            },
            transitionTime: function(e) {
                e = e || 0, this.indicatorStyle[i.style.transitionDuration] = e + "ms", !e && i.isBadAndroid && (this.indicatorStyle[i.style.transitionDuration] = "0.001s")
            },
            transitionTimingFunction: function(e) {
                this.indicatorStyle[i.style.transitionTimingFunction] = e
            },
            refresh: function() {
                this.transitionTime(), this.options.listenX && !this.options.listenY ? this.indicatorStyle.display = this.scroller.hasHorizontalScroll ? "block" : "none" : this.options.listenY && !this.options.listenX ? this.indicatorStyle.display = this.scroller.hasVerticalScroll ? "block" : "none" : this.indicatorStyle.display = this.scroller.hasHorizontalScroll || this.scroller.hasVerticalScroll ? "block" : "none", this.scroller.hasHorizontalScroll && this.scroller.hasVerticalScroll ? (i.addClass(this.wrapper, "iScrollBothScrollbars"), i.removeClass(this.wrapper, "iScrollLoneScrollbar"), this.options.defaultScrollbars && this.options.customStyle && (this.options.listenX ? this.wrapper.style.right = "8px" : this.wrapper.style.bottom = "8px")) : (i.removeClass(this.wrapper, "iScrollBothScrollbars"), i.addClass(this.wrapper, "iScrollLoneScrollbar"), this.options.defaultScrollbars && this.options.customStyle && (this.options.listenX ? this.wrapper.style.right = "2px" : this.wrapper.style.bottom = "2px"));
                var e = this.wrapper.offsetHeight;
                this.options.listenX && (this.wrapperWidth = this.wrapper.clientWidth, this.options.resize ? (this.indicatorWidth = n.max(n.round(this.wrapperWidth * this.wrapperWidth / (this.scroller.scrollerWidth || this.wrapperWidth || 1)), 8), this.indicatorStyle.width = this.indicatorWidth + "px") : this.indicatorWidth = this.indicator.clientWidth, this.maxPosX = this.wrapperWidth - this.indicatorWidth, this.options.shrink == "clip" ? (this.minBoundaryX = -this.indicatorWidth + 8, this.maxBoundaryX = this.wrapperWidth - 8) : (this.minBoundaryX = 0, this.maxBoundaryX = this.maxPosX), this.sizeRatioX = this.options.speedRatioX || this.scroller.maxScrollX && this.maxPosX / this.scroller.maxScrollX), this.options.listenY && (this.wrapperHeight = this.wrapper.clientHeight, this.options.resize ? (this.indicatorHeight = n.max(n.round(this.wrapperHeight * this.wrapperHeight / (this.scroller.scrollerHeight || this.wrapperHeight || 1)), 8), this.indicatorStyle.height = this.indicatorHeight + "px") : this.indicatorHeight = this.indicator.clientHeight, this.maxPosY = this.wrapperHeight - this.indicatorHeight, this.options.shrink == "clip" ? (this.minBoundaryY = -this.indicatorHeight + 8, this.maxBoundaryY = this.wrapperHeight - 8) : (this.minBoundaryY = 0, this.maxBoundaryY = this.maxPosY), this.maxPosY = this.wrapperHeight - this.indicatorHeight, this.sizeRatioY = this.options.speedRatioY || this.scroller.maxScrollY && this.maxPosY / this.scroller.maxScrollY), this.updatePosition()
            },
            updatePosition: function() {
                var e = this.options.listenX && n.round(this.sizeRatioX * this.scroller.x) || 0,
                    t = this.options.listenY && n.round(this.sizeRatioY * this.scroller.y) || 0;
                this.options.ignoreBoundaries || (e < this.minBoundaryX ? (this.options.shrink == "scale" && (this.width = n.max(this.indicatorWidth + e, 8), this.indicatorStyle.width = this.width + "px"), e = this.minBoundaryX) : e > this.maxBoundaryX ? this.options.shrink == "scale" ? (this.width = n.max(this.indicatorWidth - (e - this.maxPosX), 8), this.indicatorStyle.width = this.width + "px", e = this.maxPosX + this.indicatorWidth - this.width) : e = this.maxBoundaryX : this.options.shrink == "scale" && this.width != this.indicatorWidth && (this.width = this.indicatorWidth, this.indicatorStyle.width = this.width + "px"), t < this.minBoundaryY ? (this.options.shrink == "scale" && (this.height = n.max(this.indicatorHeight + t * 3, 8), this.indicatorStyle.height = this.height + "px"), t = this.minBoundaryY) : t > this.maxBoundaryY ? this.options.shrink == "scale" ? (this.height = n.max(this.indicatorHeight - (t - this.maxPosY) * 3, 8), this.indicatorStyle.height = this.height + "px", t = this.maxPosY + this.indicatorHeight - this.height) : t = this.maxBoundaryY : this.options.shrink == "scale" && this.height != this.indicatorHeight && (this.height = this.indicatorHeight, this.indicatorStyle.height = this.height + "px")), this.x = e, this.y = t, this.scroller.options.useTransform ? this.indicatorStyle[i.style.transform] = "translate(" + e + "px," + t + "px)" + this.scroller.translateZ : (this.indicatorStyle.left = e + "px", this.indicatorStyle.top = t + "px")
            },
            _pos: function(e, t) {
                e < 0 ? e = 0 : e > this.maxPosX && (e = this.maxPosX), t < 0 ? t = 0 : t > this.maxPosY && (t = this.maxPosY), e = this.options.listenX ? n.round(e / this.sizeRatioX) : this.scroller.x, t = this.options.listenY ? n.round(t / this.sizeRatioY) : this.scroller.y, this.scroller.scrollTo(e, t)
            },
            fade: function(e, t) {
                if (t && !this.visible) return;
                clearTimeout(this.fadeTimeout), this.fadeTimeout = null;
                var n = e ? 250 : 500,
                    r = e ? 0 : 300;
                e = e ? "1" : "0", this.wrapperStyle[i.style.transitionDuration] = n + "ms", this.fadeTimeout = setTimeout(function(e) {
                    this.wrapperStyle.opacity = e, this.visible = +e
                }.bind(this, e), r)
            }
        }, s.utils = i, typeof module != "undefined" && module.exports ? module.exports = s : e.IScroll = s
    }(window, document, Math), define("iscroll", function() {});
var NatureFaceOrig = function() {
    function e(e, t, n, r, i, s, o, u, a, f, l) {
        this.init(e, t, n, r, i, s, o, u, a, f, l)
    }
    return $.event.special.target == undefined && ($.extend($.event.special, {
        refresh: {
            listeners: [],
            setup: function() {
                var e = this,
                    t = $(e);
                $.event.special.refresh.listeners.push(t)
            },
            teardown: function() {
                var e = this,
                    t = $(e);
                $.event.special.refresh.listeners = $.grep($.event.special.refresh.listeners, function(e, n) {
                    return t[0] != e[0]
                })
            }
        },
        target: {
            listeners: [],
            setup: function() {
                var e = this,
                    t = $(e);
                $.event.special.target.listeners.push(t)
            },
            teardown: function() {
                var e = this,
                    t = $(e);
                $.event.special.target.listeners = $.grep($.event.special.target.listeners, function(e, n) {
                    return t[0] != e[0]
                })
            }
        },
        preEnter: {
            listeners: [],
            setup: function() {
                var e = this,
                    t = $(e);
                $.event.special.preEnter.listeners.push(t)
            },
            teardown: function() {
                var e = this,
                    t = $(e);
                $.event.special.preEnter.listeners = $.grep($.event.special.preEnter.listeners, function(e, n) {
                    return t[0] != e[0]
                })
            }
        },
        postEnter: {
            listeners: [],
            setup: function() {
                var e = this,
                    t = $(e);
                $.event.special.postEnter.listeners.push(t)
            },
            teardown: function() {
                var e = this,
                    t = $(e);
                $.event.special.postEnter.listeners = $.grep($.event.special.postEnter.listeners, function(e, n) {
                    return t[0] != e[0]
                })
            }
        },
        preExit: {
            listeners: [],
            setup: function() {
                var e = this,
                    t = $(e);
                $.event.special.preExit.listeners.push(t)
            },
            teardown: function() {
                var e = this,
                    t = $(e);
                $.event.special.preExit.listeners = $.grep($.event.special.preExit.listeners, function(e, n) {
                    return t[0] != e[0]
                })
            }
        },
        postExit: {
            listeners: [],
            setup: function() {
                var e = this,
                    t = $(e);
                $.event.special.postExit.listeners.push(t)
            },
            teardown: function() {
                var e = this,
                    t = $(e);
                $.event.special.postExit.listeners = $.grep($.event.special.postExit.listeners, function(e, n) {
                    return t[0] != e[0]
                })
            }
        }
    }), $.fn.autofill == undefined && ($.fn.autofill = function(e) {
        var t = {
                maxFontPixels: 40,
                minFontPixels: 4,
                innerTag: "div"
            },
            n = $.extend(t, e);
        return this.each(function() {
            if (!$(this).is(":visible")) return;
            var e = parseInt($(this).css("font-size") || n.maxFontPixels);
            $(this).css({
                "line-height": ""
            });
            var t = $(this).height(),
                r = $(this).width();
            $(n.innerTag, this).each(function() {
                fontSize = e, $(this).css({
                    width: ""
                });
                var i, s;
                do $(this).css({
                    "font-size": fontSize + "px"
                }), i = $(this).height(), s = $(this).width(), fontSize -= 1; while ((i > t || s > r) && fontSize > n.minFontPixels);
                $(this).parent().css("text-align") == "right" ? $(this).css({
                    left: r - s + "px",
                    top: (t - i) / 2 + "px"
                }) : $(this).parent().css("text-align") == "center" ? $(this).css({
                    left: (r - s) / 2 + "px",
                    top: (t - i) / 2 + "px"
                }) : $(this).css({
                    left: "0px",
                    top: (t - i) / 2 + "px"
                })
            })
        })
    })), e.prototype = {
        settings: {},
        init: function(e, t, n, r, i, s, o, u, a, f, l, c) {
            if (typeof e == "string") return this.start(e, t, n, r, i, s, o, u, a, f, l, c);
            if (typeof e == "object") return this.start(e.theme, e.fullscreen, e.prefix, e.firsttarget, e.touch, e.top, e.left, e.width, e.height, e.rootdiv, e.zindex, e.html, e.pages, e.disablejs, e.transparent);
            return
        },
        start: function(e, t, n, r, i, s, o, u, a, f, l, c, h, p, d) {
            var v = !1;
            this.settings = {
                theme: e,
                fullscreen: t,
                prefix: n ? n : "",
                firsttarget: r ? r : e,
                touch: typeof i != "undefined" ? i : "undefined" != typeof document.documentElement.ontouchstart,
                top: s && !t ? s : 0,
                left: o && !t ? o : 0,
                width: u && a && !t ? function() {
                    return v = !0, parseInt(u)
                }.call() : $(window).width(),
                height: u && a && !t ? parseInt(a) : $(window).height(),
                zindex: l ? l : 1,
                html: c,
                pages: h,
                disablejs: p,
                transparent: d ? d : !1,
                divName: f ? f : "NatureFace_" + e,
                div: "#" + (f ? f : "NatureFace_" + e),
                hasSize: v,
                noname: 0,
                sizeH: 1,
                sizeW: 1,
                elements: {},
                files: [],
                groups: {},
                listeners: {},
                self: this,
                hide: !1,
                globalLoadingTarget: "NatureFaceGlobalLoadingGlassBoard",
                spinners: {},
                loadingOpts: {
                    lines: 13,
                    length: 7,
                    width: 4,
                    radius: 10,
                    corners: 1,
                    rotate: 0,
                    color: "#ffff00",
                    speed: 1,
                    trail: 60,
                    shadow: !1,
                    hwaccel: !1,
                    className: "spinner",
                    zIndex: 2e9,
                    top: "auto",
                    left: "auto"
                }
            };
            var m = this.settings;
            return $("body").css({
                margin: "0px",
                overflow: "hidden"
            }), $(m.div).length == 0 && $("body").append('<div id="' + m.divName + '"/>'), $(m.div).css({
                "-moz-user-select": "none",
                top: m.top,
                left: m.left,
                position: "absolute"
            }).append('<div id="template"/><div id="layer"/><div id="' + m.globalLoadingTarget + '"/>'), $("#" + m.globalLoadingTarget, m.div).css({
                width: m.width + "px",
                height: m.height + "px",
                top: m.top,
                left: m.left,
                opacity: .7,
                "z-index": 2e9,
                position: "absolute",
                display: "none"
            }), $(m.div).get(0).onselectstart = function() {
                return !1
            }, m.html ? this.parseHTML(m.html) : m.pages ? $.each(m.pages, function(e, t) {
                m.self.loadfile(t, m.prefix)
            }) : this.loadfile(e, m.prefix), this.convertTags(), this.initLayer().target(m.firsttarget), this.autofill(), this
        },
        loading: function(e, t, n) {
            var r = this.settings;
            t || (t = r.globalLoadingTarget);
            if (window.Spinner)
                if (e) {
                    $("#" + t, r.div).show();
                    if (r.spinners[t]) r.spinners[t].spin(document.getElementById(t));
                    else {
                        var i = document.getElementById(t);
                        n ? r.spinners[t] = (new Spinner(n)).spin(i) : r.spinners[t] = (new Spinner(r.loadingOpts)).spin(i)
                    }
                } else t == r.globalLoadingTarget && $("#" + t, r.div).hide(), r.spinners[t] && r.spinners[t].stop()
        },
        refresh: function() {
            var e = this.settings;
            return e.fullscreen && e.height != 0 && e.width != 0 && (e.sizeH = $(window).height() / e.height, e.sizeW = $(window).width() / e.width, e.height = $(window).height(), e.width = $(window).width(), $("#" + e.globalLoadingTarget, e.div).css({
                width: e.width,
                height: e.height
            }), $("[id^=_backgroupimage_]", e.div).css({
                width: e.width,
                height: e.height
            }), $(".NatureObject", e.div).each(function() {
                var t = {
                    top: parseFloat($(this).css("top")) * e.sizeH,
                    left: parseFloat($(this).css("left")) * e.sizeW,
                    width: parseFloat($(this).css("width")) * e.sizeW,
                    height: parseFloat($(this).css("height")) * e.sizeH
                };
                $.extend(t, {
                    "line-height": t.height - 2,
                    "background-position": e.transparent ? "" : "-" + t.left + "px -" + t.top + "px",
                    "background-size": e.transparent ? "" : e.width + "px " + e.height + "px"
                }), $(this).hasClass("NatureGroupObject") && $.extend(t, {
                    "line-height": ""
                }), $(this).css(t)
            }), this.triggerEvent("refresh", $.event.special.refresh, this.layer())), this.autofill(), this
        },
        time: function(e, t) {
            var n = this.settings;
            if (!e) return;
            var r = (new Date).getTime();
            console.timeCounters || (console.timeCounters = {});
            var i = "KEY" + e.toString();
            if (!t && console.timeCounters[i]) return;
            console.timeCounters[i] = r
        },
        timeEnd: function(e) {
            var t = this.settings,
                n = (new Date).getTime();
            if (!console.timeCounters) return;
            var r = "KEY" + e.toString(),
                i = console.timeCounters[r];
            if (i) {
                var s = n - i,
                    o = e + ": " + s + "ms";
                delete console.timeCounters[r]
            }
            return s
        },
        script: function(e) {
            var t = this.settings;
            if (t.disablejs) return;
            var n = document.createElement("script");
            n.type = "text/javascript", n.src = e;
            try {
                $("body").append(n)
            } catch (r) {}
        },
        parseHTML: function(e) {
            var t = this.settings;
            e = e.replace(/\ src=\"/ig, ' imgsrc="'), $("#template", t.div).html(e.replace(/\<area /ig, "<div ")).hide().children("img[imgsrc]").each(function() {
                $(this).is('[imgsrc^="data:image/png"]') ? $(this).attr("src", $(this).attr("imgsrc")).removeAttr("imgsrc") : $(this).attr("src", t.currentPrefix + $(this).attr("imgsrc")).removeAttr("imgsrc")
            }), $("#template", t.div).children("page[imgsrc]").each(function() {
                $(this).attr("src", $(this).attr("imgsrc")).removeAttr("imgsrc")
            }), typeof $("#layer", t.div).attr("value") == "undefined" && (typeof $("#template", t.div).find("layer").attr("default") != "undefined" ? $("#layer", t.div).attr("value", $("#template", t.div).find("layer").attr("default")) : $("#layer", t.div).attr("value", "0")), typeof $("#template", t.div).find("layer").attr("target") != "undefined" ? $("#layer", t.div).attr("target", $("#template", t.div).find("layer").attr("target")) : $("#layer", t.div).removeAttr("target");
            var n = $("#template > img", t.div);
            if (t.fullscreen || t.hasSize) {
                var r = n.attr("height");
                t.sizeH = t.height / parseInt(n.attr("height")), t.sizeW = t.width / parseInt(n.attr("width")), n.css({
                    width: t.width + "px",
                    height: t.height + "px"
                })
            } else $("#" + t.globalLoadingTarget, t.div).css({
                width: parseInt(n.attr("width")) + "px",
                height: parseInt(n.attr("height")) + "px"
            });
            var i = "_backgroupimage_" + t.zindex++;
            $("#_backgroupimage_", t.div).length == 0 ? (i = "_backgroupimage_", n.appendTo($(t.div)).attr("id", i)) : n.appendTo($(t.div)).attr("id", i).hide();
            var s = $("#" + i, t.div).attr("src"),
                o = s.substring(0, s.length - 4),
                u = s.substring(o.length),
                a = o + ".mouseover" + u,
                f = o + ".mousedown" + u,
                l = typeof $("#" + i, t.div).attr("mousedown") == "undefined" ? !1 : !0,
                c = typeof $("#" + i, t.div).attr("mouseover") == "undefined" ? !1 : !0,
                h = {};
            return $("#template", t.div).find("debug").attr("value") == "true" && $.extend(h, {
                "border-style": "solid",
                "border-width": "1px",
                "border-color": "#0000ff"
            }), $("#template > map > div", t.div).remove().appendTo(t.div).each(function() {
                var e = !1;
                typeof $(this).attr("href") == "undefined" ? (e = "Unknow" + t.noname, t.noname = t.noname + 1) : e = $(this).attr("href"), $(this).attr("id", e.replace(".", "_")).addClass("NatureObject");
                var n = t.elements[$(this).attr("id")] = {};
                n.imgsrc = s, n.imgsrc_over = a, n.imgsrc_down = f, n.imgsrc_down = f, n.mousedown = l, n.mouseover = c, typeof $(this).attr("target") == "undefined" && typeof $("#layer", t.div).attr("target") != "undefined" && $(this).attr("target", $("#layer", t.div).attr("target")), typeof $(this).attr("layer") == "undefined" && typeof $("#template", t.div).find("layer").attr("default") != "undefined" && $(this).attr("layer", $("#template", t.div).find("layer").attr("default"));
                var r = $(this).attr("coords").split(",");
                r[0] = parseInt(r[0] * t.sizeW), r[1] = parseInt(r[1] * t.sizeH), r[2] = parseInt(r[2] * t.sizeW), r[3] = parseInt(r[3] * t.sizeH);
                var i = r[2] - r[0] + "",
                    o = r[3] - r[1] + "",
                    u = $.extend({}, h, {
                        position: "absolute",
                        left: r[0] + "px",
                        top: r[1] + "px",
                        width: i + "px",
                        "line-height": o - 2 + "px",
                        height: o + "px",
                        overflow: "hidden",
                        "z-index": t.zindex++
                    });
                typeof $(this).attr("font") != "undefined" && $.extend(u, {
                    "font-family": $(this).attr("font")
                }), typeof $(this).attr("size") != "undefined" && $.extend(u, {
                    "font-size": parseInt($(this).attr("size")) + "px"
                }), typeof $(this).attr("color") != "undefined" && $.extend(u, {
                    color: $(this).attr("color")
                });
                var p = $(this).attr("align");
                typeof p == "undefined" ? $.extend(u, {
                    "text-align": "left",
                    valign: "middle"
                }) : p == "topcenter" ? $.extend(u, {
                    "text-align": "center",
                    valign: "text-top"
                }) : p == "topleft" ? $.extend(u, {
                    "text-align": "left",
                    valign: "text-top"
                }) : p == "topright" ? $.extend(u, {
                    "text-align": "right",
                    valign: "text-top"
                }) : p == "middlecenter" ? $.extend(u, {
                    "text-align": "center",
                    valign: "middle"
                }) : p == "middleleft" ? $.extend(u, {
                    "text-align": "left",
                    valign: "middle"
                }) : p == "middleright" ? $.extend(u, {
                    "text-align": "right",
                    valign: "middle"
                }) : p == "bottomcenter" ? $.extend(u, {
                    "text-align": "center",
                    valign: "text-bottom"
                }) : p == "bottomleft" ? $.extend(u, {
                    "text-align": "left",
                    valign: "text-bottom"
                }) : p == "bottomright" && $.extend(u, {
                    "text-align": "right",
                    valign: "text-bottom"
                }), $(this).removeAttr("font").removeAttr("size").removeAttr("color").removeAttr("coords").removeAttr("shape").removeAttr("href").removeAttr("align"), $.extend(u, {
                    "-webkit-tap-highlight-color": "rgba(0, 0, 0, 0)",
                    "-webkit-box-shadow": "none",
                    "-webkit-backface-visibility": "hidden"
                }), $(this).css(u);
                if (typeof $(this).attr("group") != "undefined") {
                    var v = typeof $(this).attr("rows") == "undefined" ? 1 : $(this).attr("rows"),
                        y = typeof $(this).attr("cols") == "undefined" ? 1 : $(this).attr("cols");
                    t.self.groupResize($(this).attr("group"), v, y, $(this))
                } else t.self.convertButton($(this)), $(this).hide()
            }), $("#template > page", t.div).remove().each(function() {
                if (typeof $(this).attr("src") != "undefined")
                    if ($(this).attr("prefix")) {
                        var e = t.currentPrefix;
                        t.self.loadfile($(this).attr("src"), $(this).attr("prefix")), t.currentPrefix = e
                    } else t.self.loadfile($(this).attr("src"), t.currentPrefix)
            }), $("#template", t.div).empty(), t.self
        },
        groupResize: function(e, t, n, r) {
            var i = this.settings,
                s = "group_" + e + "_div",
                o = s + "_container",
                u = typeof r == "undefined" ? $("#" + o, i.div).css("top") : parseInt(r.css("top")),
                a = typeof r == "undefined" ? $("#" + o, i.div).css("left") : parseInt(r.css("left")),
                f = typeof r == "undefined" ? $("#" + o, i.div).width() : r.width(),
                l = typeof r == "undefined" ? $("#" + o, i.div).height() : r.height(),
                c = typeof r == "undefined" ? $("#" + o, i.div).attr("layer") : r.attr("layer");
            r = typeof r == "undefined" ? $("div[group=" + e + "]", "#" + o).first() : r, $("#" + o, i.div).remove(), $(i.div).append('<div id="' + o + '" style="display:none; position: absolute; overflow-y: hidden; overflow-x: hidden;" groupname="' + e + '" ><ul style="position: absolute; margin: 0 0 0 0;margin: 0; padding: 0"><li id="' + s + '" style="float: left; list-style-type: none;  margin: 0 0px 0 0;"></li></ul></div>'), $("#" + s, i.div).css({
                left: "0px",
                top: "0px"
            }).css("z-index", i.zindex++), $("#" + o, i.div).css({
                left: a,
                top: u
            }).attr("layer", c).css("z-index", i.zindex++);
            for (var h = 0; h < t; h++)
                for (var p = 0; p < n; p++) {
                    var d = r.clone(!0);
                    d.css({
                        top: l * h,
                        left: f * p
                    }), d.appendTo($("#" + s, i.div)), d.attr("id", e + "_" + (h * n + p)), d.removeAttr("cols").removeAttr("layer").removeAttr("rows").removeAttr("opacity").removeClass("NatureObject").attr("groupid", s)
                }
            var v = $("#" + o, i.div);
            return $("#" + s, i.div).attr("rows", t).attr("cols", n).css("height", l * t + "px").css("width", f * n + "px"), v.css("height", l * t + "px").css("width", f * n + "px").addClass("NatureObject NatureGroupObject").attr("layer", r.attr("layer")), r.remove(), v
        },
        loadfile: function(e, t) {
            var n = this.settings;
            n.currentPrefix = t;
            var r = n.currentPrefix + e + ".html";
            return $.inArray(r, n.files) != -1 ? this : (n.files.push(r), $.ajax({
                url: r,
                dataType: "html",
                async: !1,
                error: function(e) {},
                success: function(e) {
                    n.self.parseHTML(e)
                }
            }), n.self.script(n.currentPrefix + e + ".js"), n.self)
        },
        istouch: function() {
            return this.settings.touch
        },
        convertButton: function(e) {
            var t = this.settings,
                n = e.attr("id");
            if (e.hasClass("marquee") || e.hasClass("video") || e.hasClass("player") || e.hasClass("iframe") || e.hasClass("image") || e.hasClass("input") || e.hasClass("textarea") || e.hasClass("flash")) return t.self;
            var r = t.elements[e.attr("id")];
            if (typeof e.attr("opacity") != "undefined") {
                var i = e.attr("opacity").split(",");
                for (var s = 0; s < 3; s++) s < i.length && parseInt(i[s]) >= 1 ? i[s] = .99 : s >= i.length - 1 && i.push(i[0]);
                r.opacity = i
            } else r.opacity = [.99, .99, .99];
            e.removeAttr("opacity").css("opacity", r.opacity[0]), t.transparent || e.hasClass("label") || (e.css("background-position", "-" + e.css("left") + " -" + e.css("top")), (t.fullscreen || t.hasSize) && e.css("background-size", t.width + "px " + t.height + "px"), e.css("background-image", "url(" + r.imgsrc + ")")), typeof e.attr("value") != "undefined" && e.text(e.attr("value")), e.removeAttr("value"), e.hasClass("label") && e.click(function() {
                typeof $(this).attr("target") != "undefined" && t.self.target($(this).attr("target"))
            });
            if (e.hasClass("label") || e.hasClass("background")) return t.self;
            var o = function(e, n, r, i) {
                if (typeof e.attr("layerdisable") != "undefined" && r != 0) {
                    var s = e.attr("layerdisable").split(",");
                    if ($.inArray(t.self.layer(), s) != -1) return
                }
                var o = t.elements[e.attr("id")];
                $("#" + t.globalLoadingTarget, t.div).show(), e.css("opacity", o.opacity[r]);
                try {
                    e.css("background-image") != "url(" + o["imgsrc" + n] + ")" && (o.mouseover && n == "_over" || o.mousedown && n == "_down" || n == "") && (t.transparent || e.css("background-image", "url(" + o["imgsrc" + n] + ")"))
                } catch (u) {}
                $("#" + t.globalLoadingTarget, t.div).hide(), i && (typeof e.attr("target") != "undefined" && t.self.target(e.attr("target")), e.trigger("binding"))
            };
            if (!t.touch) e.hover(function() {
                o($(this), "_over", 1, !1)
            }, function() {
                o($(this), "", 0, !1)
            }).click(function() {
                o($(this), "_over", 1, !0)
            }).mousedown(function() {
                o($(this), "_down", 2, !1)
            }).mouseup(function() {
                o($(this), "_over", 1, !1)
            });
            else {
                var u = function(e, t) {
                    var n = t.originalEvent.touches;
                    for (var r = 0; r < n.length; r++);
                    n = t.originalEvent.targetTouches;
                    for (var r = 0; r < n.length; r++);
                    n = t.originalEvent.changedTouches;
                    for (var r = 0; r < n.length; r++);
                };
                e.bind("touchstart", function(e) {
                    if (e.originalEvent.touches.length > 1) {
                        var n = e.originalEvent.touches;
                        for (var r = 0; r < n.length; r++) o($("#" + n[r].target.id, t.div), "", 0, !1)
                    } else o($(this), "_down", 2, !1)
                }), e.bind("touchmove", function(e) {
                    o($(this), "", 0, !1)
                }), e.bind("touchend", function(e) {
                    o($(this), "", 0, !0)
                }), e.bind("touchcancel", function(e) {
                    o($(this), "", 0, !1)
                })
            }
            return t.self
        },
        convertTags: function() {
            var e = this.settings,
                t = function(e, t, n, r) {
                    if (e.hasClass(t)) {
                        var i = "<" + t + " " + n + ' id="' + e.attr("id") + '"></' + t + ">";
                        e.removeAttr("id").append(i), e.children(t).attr("style", e.attr("style")).css({
                            outline: "none",
                            "-webkit-user-modify": "read-write-plaintext-only",
                            display: "",
                            position: ""
                        }).attr("placeholder", e.attr("placeholder"))
                    }
                };
            return $(".video", e.div).each(function() {
                t($(this), "video", 'playid="0" autoplay="autoplay"', "inline")
            }), $(".iframe", e.div).each(function() {
                t($(this), "iframe", "")
            }), $(".image", e.div).each(function() {
                t($(this), "image", "", "inline")
            }), $(".input", e.div).each(function() {
                t($(this), "input", "")
            }), $(".textarea", e.div).each(function() {
                t($(this), "textarea")
            }), e.self
        },
        initLayer: function() {
            var e = this.settings;
            return $("div.NatureObject", e.div).each(function() {
                if (typeof $(this).attr("layer") == "undefined" || $(this).attr("layer") == "") $(this).show(), $(this).trigger("show"), $(this).removeAttr("layer")
            }), e.self
        },
        show: function() {
            var e = this.settings;
            e.hide = !1, $(e.div).show(), this.target(this.layer())
        },
        hide: function() {
            var e = this.settings;
            $("div.NatureObject[layer]", e.div).each(function() {
                $(this).css("display", "none"), $(this).trigger("hide")
            }), $(e.div).css("display", "none"), e.hide = !0
        },
        layer: function() {
            var e = this.settings;
            return $("#layer", e.div).attr("value")
        },
        target: function(e) {
            var t = this.settings;
            if (!this.triggerEvent("preExit", $.event.special.preExit, this.layer())) return;
            e += "", t.self.time("target [" + e + "]", !0), this.triggerEvent("postExit", $.event.special.postExit, this.layer()), $("#layer", t.div).attr("value", e);
            if (t.hide) return;
            return this.triggerEvent("preEnter", $.event.special.preEnter, e), $("div.NatureObject[layer]", t.div).each(function() {
                var n = $(this).attr("layer").split(",");
                if ($.inArray(e, n) != -1) {
                    $(this).show();
                    if ($(this).hasClass("NatureGroupObject") && typeof $(this).attr("groupname") != "undefined") var r = $(this).attr("groupname");
                    typeof t.groups[r] == "object" && t.groups[r].refresh != undefined && t.groups[r].refresh(), $(this).trigger("show")
                } else $(this).css("display", "none"), $(this).trigger("hide")
            }), t.self.timeEnd("target [" + e + "]"), this.fireEvent("target", e), this.triggerEvent("target", $.event.special.target, e), this.triggerEvent("postEnter", $.event.special.postEnter, e), this.autofill(), t.self
        },
        eventValue: !0,
        triggerEvent: function(e, t, n) {
            var r = !0;
            this.eventValue = !0;
            try {
                for (var i in t.listeners) t.listeners[i].trigger(e, [this, n]), r = r && this.eventValue
            } catch (s) {}
            return r && e == "preExit"
        },
        fireEvent: function(e, t) {
            var n = this.settings;
            if (typeof n.listeners[e] != "undefined") {
                var r = n.listeners[e];
                for (var i in r) try {
                    r[i](t)
                } catch (s) {}
            }
        },
        listener: function(e, t) {
            var n = this.settings;
            if (typeof t == "function")
                if (typeof n.listeners[e] != "undefined") {
                    var r = n.listeners[e];
                    r.push(t)
                } else {
                    var r = new Array;
                    r.push(t), this.removeListener(e), n.listeners[e] = r
                }
        },
        removeListener: function(e, t) {
            var n = this.settings;
            if (typeof n.listeners[e] != "undefined") {
                var r = n.listeners[e];
                if (r.length == 1) delete n.listeners[e];
                else {
                    var i = new Array;
                    for (var s in r) r[s] != t && i.push(r[s]);
                    delete n.listeners[e], n.listeners[e] = i
                }
            }
        },
        marquee: function(e, t) {
            var n = this.settings,
                r = 0;
            return n.self.marquee.effect = "fade", n.self.marquee.speed = 3e3, n.self.marquee.delay = 1e3, n.self.marquee.timeout = 6e3, typeof t == "function" && (n.self.marquee.handler = t), $.ajax({
                url: e,
                dataType: "json",
                cache: !1,
                async: !1,
                handler: t,
                success: function(e) {
                    $(".marquee", n.div).unbind(), $(".marquee", n.div).html(""), n.self.marqueeItem("　");
                    if (typeof this.handler == "function") this.handler(e);
                    else {
                        try {
                            n.self.marquee.effect = e.effect, n.self.marquee.speed = e.speed, n.self.marquee.delay = e.delay, n.self.marquee.timeout = e.timeout
                        } catch (t) {}
                        try {
                            var i = e.items;
                            if (i.length > 0)
                                for (var s = 0; s < i.length; s++) n.self.marqueeItem(i[s].msg)
                        } catch (t) {}
                    }
                    $(".marquee", n.div).html() == "" && n.self.marqueeItem("demo"), $(".marquee > div", n.div).length == 1 && $(".marquee", n.div).append($(".marquee", n.div).html()), $(".marquee", n.div).cycle({
                        fx: n.self.marquee.effect,
                        speed: n.self.marquee.speed,
                        delay: n.self.marquee.delay,
                        timeout: n.self.marquee.timeout,
                        after: function() {
                            r += 1, r > $(".marquee > div", n.div).size() && n.self.marquee(n.self.marquee.url, n.self.marquee.handler)
                        }
                    })
                }
            }), n.self
        },
        marqueeItem: function(e) {
            var t = this.settings;
            return e != "　" && (e == "demo" ? $(".marquee", t.div).html("<div>\n$.NatureFace.js plugin demo.\n</div>") : $(".marquee", t.div).append("<div>\n" + e + "\n</div>")), t.self
        },
        subscribe: function(e, t, n, r) {
            var i = this.settings;
            return $(document).everyTime(n, e, function() {
                $.ajax({
                    url: t,
                    dataType: "json",
                    cache: !1,
                    async: !1,
                    success: function(e) {
                        e.length > 0 && typeof r == "function" && r(e)
                    }
                })
            }), i.self
        },
        unsubscribe: function(e) {
            var t = this.settings;
            return $(document).stopTime(e), t.self
        },
        jsonListing: function(e, t, n) {
            var r = this.settings,
                i = $("#group_" + e + "_div", r.div),
                s = $("[group=" + e + "]:eq(0)", r.div),
                o, u = parseInt(i.attr("cols")) > 0 ? parseInt(i.attr("cols")) : 1,
                a = $("#group_" + e + "_div_container", r.div);
            $('[group="' + e + '"]', r.div).filter(":not(:eq(0))").remove(), s.empty();
            for (var f = 0; f < t.length; f++) {
                f >= 1 ? o = s.clone().empty() : o = s, o.attr("id", s.attr("group") + "_" + f);
                var l = Math.ceil((f + 1) / u) - 1,
                    c = f % u,
                    h = parseInt(s.css("top")) + parseInt(s.height()) * l + "px",
                    p = parseInt(s.css("left")) + parseInt(s.width()) * c + "px";
                o.css({
                    top: h,
                    left: p
                }), f != 0 && o.appendTo(i), typeof n == "function" && n(o, t[f])
            }
            t.length > 0 && (i.css("height", parseInt(o.css("top")) + o.height() + 1 + "px"), i.parent().css("height", i.height() + 1)), typeof r.groups[e] == "undefined" && (r.groups[e] = new iScroll(a.attr("id"), {
                hScrollbar: !1,
                hScroll: !1,
                onTouchEnd: function() {
                    a.trigger("onTouchEnd")
                },
                onScrollEnd: function() {
                    a.trigger("onTouchEnd")
                }
            })), r.groups[e].refresh()
        },
        listing: function(e, t, n, r, i) {
            var s = this.settings;
            return i || (i = 1), $.ajax({
                groupname: e,
                url: t + i,
                subupdate: n,
                subpage: r,
                page: i,
                dataType: "json",
                cache: !1,
                async: !1,
                pureurl: t,
                success: function(e) {
                    var t = this.groupname,
                        n = $("[group=" + t + "]", s.div),
                        r = $("#group_" + t + "_div", s.div),
                        i = $("#group_" + t + "_div_container", s.div),
                        o = this.pureurl,
                        u = this.page,
                        a = this.subupdate,
                        f = this.subpage,
                        l, c = n.last(),
                        h = n;
                    for (var p = 0; p < e.items.length; p++) {
                        var v = e.absoluteposition + p - 1;
                        v >= n.length ? (l = c.clone().empty(), l.attr("id", c.attr("group") + "_" + v), l.css({
                            top: parseInt(c.css("top")) + c.height() + "px",
                            height: parseInt(l.css("line-height")) + 2 + "px"
                        }).appendTo(r), typeof a == "function" && a(l, e.items[p])) : (l = $(n[v]), typeof a == "function" && a(l, e.items[p]), v >= 1 && (c = $("#" + $(n[v]).attr("group") + "_" + (v - 1), s.div), l.css("top", parseInt(c.css("top")) + c.height()))), c = l
                    }
                    e.items.length > 0 && (r.css("height", parseInt(l.css("top")) + l.height() + 1 + "px"), r.parent().css("height", r.height() + 1)), u < e.pagecount && i.one("onTouchEnd", function() {
                        s.self.listing(t, o, a, f, u + 1)
                    }), typeof s.groups[t] == "undefined" && (s.groups[t] = new iScroll(i.attr("id"), {
                        hScrollbar: !1,
                        hScroll: !1,
                        onTouchEnd: function() {
                            i.trigger("onTouchEnd")
                        },
                        onScrollEnd: function() {
                            i.trigger("onTouchEnd")
                        }
                    })), s.groups[t].refresh()
                }
            }), s.self
        },
        autofill: function() {
            setTimeout('$("div[autofill]", "' + this.settings.div + '").autofill()', 3)
        },
        jsonTable: function(e, t, n, r, s) {
            var o = this.settings;
            typeof o.groups[e] != "undefined" && delete o.groups[e];
            var u = $(".NatureObject[binding=" + e + "\\.left]", o.div),
                a = $(".NatureObject[binding=" + e + "\\.right]", o.div),
                f = $("[group=" + e + "]", o.div),
                l = f.length > 0 ? Math.ceil(t.length / f.length) : 1;
            s || (s = l);
            var c = s > l ? l : s;
            o.groups[e] = t, o.groups[e].subupdate = n, o.groups[e].subclear = r, o.groups[e].page = c;
            for (i = 0; i < f.length; i++) {
                $(f[i]).empty();
                var h = (c - 1) * f.length + i;
                h < t.length ? n($(f[i]), t[h], c, l) : r($(f[i]), {}, c, l)
            }
            u.length > 0 && (u.unbind("binding"), c > 1 && u.bind("binding", function() {
                var e = $(this).attr("binding"),
                    t = e.substring(0, e.length - 5),
                    n = o.groups[t];
                o.self.jsonTable(t, n, n.subupdate, n.subclear, n.page - 1)
            })), a.length > 0 && (a.unbind("binding"), l > c && a.bind("binding", function() {
                var e = $(this).attr("binding"),
                    t = e.substring(0, e.length - 6),
                    n = o.groups[t];
                o.self.jsonTable(t, n, n.subupdate, n.subclear, n.page + 1)
            }))
        },
        binding: function(e, t, n, r, i) {
            var s = this.settings;
            return i || (i = 1), $.ajax({
                group: e,
                url: t + i,
                subupdate: n,
                subclear: r,
                page: i,
                dataType: "json",
                cache: !1,
                async: !1,
                pureurl: t,
                success: function(e) {
                    typeof s.groups[this.group] != "undefined" && delete s.groups[this.group];
                    var t = $(".NatureObject[binding=" + this.group + "\\.left]", s.div),
                        n = $(".NatureObject[binding=" + this.group + "\\.right]", s.div),
                        r = $(".NatureObject[binding=" + this.group + "\\.pageinfo]", s.div),
                        i = $("[group=" + this.group + "]", s.div);
                    e.url = this.pureurl, e.subupdate = this.subupdate, e.subclear = this.subclear, s.groups[this.group] = e, e.pagecount > 1 && r.length > 0 ? $(r).text(e.absolutepage + "頁／" + e.pagecount + "頁") : r.length > 0 && $(r).text("1頁／1頁");
                    var o = 0;
                    for (o = 0; o < e.items.length; o++) typeof e.subupdate == "function" && ($(i[o]).empty(), e.subupdate($(i[o]), e.items[o]));
                    for (var u = o; u < i.length; u++) typeof e.subclear == "function" && e.subclear($(i[u]));
                    t.length > 0 && (t.unbind("binding"), t.bind("binding", function() {
                        var e = $(this).attr("binding"),
                            t = e.substring(0, e.length - 5),
                            n = s.groups[t];
                        s.self.binding(t, n.url, n.subupdate, n.subclear, n.absolutepage - 1)
                    })), n.length > 0 && (n.unbind("binding"), n.bind("binding", function() {
                        var e = $(this).attr("binding"),
                            t = e.substring(0, e.length - 6),
                            n = s.groups[t];
                        s.self.binding(t, n.url, n.subupdate, n.subclear, n.absolutepage + 1)
                    }))
                }
            }), s.self
        }
    }, $.extend({
        NatureFace: {
            init: function(t, n, r, i, s) {
                return $.NatureFace = new e(t, n, r, i, s), $.NatureFace
            }
        }
    })(), window.NatureFace = e
};
typeof define == "function" ? define("natureface", NatureFaceOrig) : NatureFaceOrig(), define("dbhandler", ["jquery"], function(e) {
        return e.extend({
            dbhandler: {
                migrations: [],
                database: !1,
                connect: function(e, t, n) {
                    try {
                        window.openDatabase ? (this.database = openDatabase(e, "", n, t), this.database || console.info("無法開始本地資料庫，可能沒有空間。")) : console.info("此瀏灠器沒有支援Web Storage Database")
                    } catch (r) {}
                    return this.database
                },
                transaction: function(e) {
                    if (!this.database) return;
                    this.database.transaction(e)
                },
                query: function(t, n) {
                    if (!this.database) return;
                    e.dbhandler.transaction(function(e) {
                        e.executeSql(t, [], function(e, t) {
                            typeof n == "function" && n(t)
                        }, function(e, t) {
                            console.info(t)
                        })
                    })
                },
                migration: function(e, t) {
                    if (!this.database) return;
                    this.migrations[e] = t
                },
                doMigrationItem: function(t) {
                    if (!this.database) return;
                    e.dbhandler.migrations[t] && e.dbhandler.database.changeVersion(this.database.version, String(t), function(n) {
                        e.dbhandler.migrations[t](n)
                    }, function(e) {
                        console.error && console.error("Error!: %o", e)
                    }, function() {
                        e.dbhandler.doMigration(t + 1)
                    })
                },
                doMigration: function() {
                    var e = parseInt(this.database.version) || 0;
                    try {
                        this.doMigrationItem(e + 1)
                    } catch (t) {
                        console.error && console.error(t)
                    }
                }
            }
        })(), window.dbhandler = e.dbhandler
    }), define("global", [], function() {
        return {
            gapikey: "AIzaSyCfHrdY2w8KMGL1rCFhtBPEwvp9wyXhO5c",
            firsttarget: "default",
            theme: "ksonglover"
        }
    }), define("deferred", ["jquery"], function(e) {
        "use strict";
        return function(t, n) {
            var r = {
                    promise: function(t) {
                        return typeof t == "undefined" ? r : e.extend(t, r)
                    }
                },
                i = {};
            for (var s = 0, o = t.length; s < o; s++) {
                var u = t[s],
                    a = e.Callbacks(u[2]);
                r[u[0]] = a.add, i[u[1]] = a.fire, i[u[1] + "With"] = a.fireWith
            }
            return r.promise(i), e.isFunction(n) && n.call(i, i), i
        }
    }), define("library", ["jquery", "deferred"], function(e, t) {
        "use strict";
        return String.prototype.format = String.prototype.f = function() {
            var e = this,
                t = arguments.length;
            while (t--) e = e.replace(new RegExp("\\{" + t + "\\}", "gm"), arguments[t]);
            return e
        }, String.format || (String.format = String.f = function(e) {
            var t = Array.prototype.slice.call(arguments, 1);
            return e.replace(/{(\d+)}/g, function(e, n) {
                return typeof t[n] != "undefined" ? t[n] : e
            })
        }), {
            padZero: function(e, t) {
                var n = e.length;
                return t > n ? (new Array(t - n + 1)).join("0") + e : e
            },
            urlencode: function(e) {
                var t = e.split("/").pop(),
                    n = e.substring(0, e.lastIndexOf("/"));
                return n + "/" + encodeURI(t)
            },
            options: function(t) {
                return e.extend({}, t.defaults, t.options)
            },
            type: function(e) {
                return Object.prototype.toString.call(e)
            },
            isFunction: function(e) {
                return this.type(e) === "[object Function]"
            },
            isObject: function(e) {
                return this.type(e) === "[object Object]"
            },
            isBoolean: function(e) {
                return this.type(e) === "[object Boolean]"
            },
            isArray: function(e) {
                return this.type(e) === "[object Array]"
            },
            isString: function(e) {
                return this.type(e) === "[object String]"
            },
            funcExists: function(e, t) {
                return typeof t == "undefined" ? this.isFunction(e) : t[e] && this.isFunction(t[e])
            },
            countdown: function(e) {
                var n = null;
                return t([
                    ["every", "update", "memory"],
                    ["end", "resolve", "memory once"]
                ], function(t) {
                    n = setInterval(function() {
                        t.update(e), --e <= 0 && (t.resolve(), clearInterval(n))
                    }, 1e3)
                }).promise({
                    stop: function() {
                        clearInterval(n)
                    }
                })
            },
            interval: function(e) {
                var n = null,
                    r = 0;
                return t([
                    ["notify", "update", "memory"]
                ], function(t) {
                    n = setInterval(function() {
                        r += e, t.update(r)
                    }, e * 1e3)
                }).promise({
                    stop: function() {
                        clearInterval(n)
                    }
                })
            },
            counter: function(n) {
                var r = t([
                        ["notify", "progress", "memory"],
                        ["done", "resolve", "memory once"]
                    ]),
                    i = {};
                return r.promise({
                    minus: function(t) {
                        this.minusWith(this, e.extend(i, t))
                    },
                    minusWith: function(t, s) {
                        e.extend(i, s), r.progressWith(t, [i]), --n === 0 && r.resolveWith(t, [i])
                    }
                })
            },
            wait: function() {
                var e = Array.slice(arguments),
                    n = t([
                        ["then", "resolve", "memory once"]
                    ]),
                    r = 0;
                return this.each(e, function(e, t) {
                    r++, t.done(function(e) {
                        --r || n.resolve()
                    })
                }), n.promise()
            },
            each: function(e, t) {
                for (var n in e)
                    if (e.hasOwnProperty(n) && t.call(e[n], n, e[n]) === !1) break
            },
            getFuncParamNames: function(e) {
                var t = /((\/\/.*$)|(\/\*[\s\S]*?\*\/))/mg,
                    n = /([^\s,]+)/g,
                    r = e.toString().replace(t, ""),
                    i = r.slice(r.indexOf("(") + 1, r.indexOf(")")).match(n);
                return i === null && (i = []), i
            },
            getParameterByName: function(e, t) {
                e = e.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
                var n = new RegExp("[\\?&]" + e + "=([^&#]*)"),
                    r = n.exec(location.search);
                return r === null ? t : decodeURIComponent(r[1].replace(/\+/g, " "))
            },
            uniqueid: function(e) {
                return typeof e == "undefined" && (e = ""), e + Math.random().toString(36).substr(2, 9)
            },
            guid: function() {
                function e() {
                    return Math.floor((1 + Math.random()) * 65536).toString(16).substring(1)
                }
                return e() + e() + "-" + e() + "-" + e() + "-" + e() + "-" + e() + e() + e()
            },
            getTime: function(e) {
                return e ? parseInt(e.getTime() / 1e3) : parseInt((new Date).getTime() / 1e3)
            },
            ipvalid: function(e) {
                return /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(e) ? !0 : !1
            },
            set: function(e, t, n) {
                var r = {};
                r[e] = t, chrome.storage.local.set(r, function() {
                    n && n()
                })
            },
            get: function(e, t) {
                chrome.storage.local.get(e, function(n) {
                    t && (n.hasOwnProperty(e) ? t(n[e]) : t(n))
                })
            },
            remove: function(e, t) {
                chrome.storage.local.remove(e, function(e) {
                    t && t(e)
                })
            }
        }
    }), define("eventhub", ["jquery", "library"], function(e, t) {
        "use strict";
        return {
            init: function(n) {
                var r = "ALL",
                    i = this,
                    s = {};
                t.isObject(n) && t.each(n, function(t, n) {
                    typeof s[t] == "undefined" && (s[t] = e.Callbacks(n))
                }), s[r] = e.Callbacks("unique");
                var o = {
                        on: function() {
                            var t = Array.prototype.slice.call(arguments);
                            if (e.isFunction(t[0])) {
                                var n = t[0];
                                s[r].add(n)
                            } else if (e.type(t[0]) === "string") {
                                var i = t[0],
                                    o = t[1],
                                    u = i.split(" ");
                                for (var a = 0, f = u.length; a < f; a++) {
                                    var l = u[a];
                                    typeof s[l] == "undefined" && (s[l] = e.Callbacks("unique"));
                                    if (!o) continue;
                                    s[l].add(o)
                                }
                            }
                            return this
                        },
                        addEventListener: function(e, t) {
                            return this.on.call(this, e, t)
                        },
                        off: function(e, t) {
                            return typeof t != "undefined" ? s[e].remove(t) : delete s[e], this
                        },
                        removeEventListener: function(e, t) {
                            return this.off(e, t)
                        }
                    },
                    u = {
                        triggerWith: function() {
                            var e = Array.prototype.slice.call(arguments),
                                t = e[1],
                                n = e.slice(2),
                                i = s[t];
                            typeof i != "undefined" && i.fireWith(e[0], n), s[r].fire.apply(e[0], e.slice(1))
                        },
                        trigger: function() {
                            var e = Array.prototype.slice.call(arguments);
                            e.unshift(i), u.triggerWith.apply(this, e)
                        },
                        list: function() {
                            return Object.keys(s)
                        },
                        promise: function(t) {
                            if (t) {
                                i = t;
                                var n = {};
                                return n = {
                                    trigger: this.trigger,
                                    triggerWith: this.triggerWith
                                }, e.extend(t, o, n)
                            }
                            return o
                        }
                    };
                return u.promise(u), u
            }
        }
    }), define("logger", ["library"], function(e) {
        function t() {
            try {
                throw Error("")
            } catch (e) {
                return e
            }
        }
        return {
            debug: !0,
            lastlog: !1,
            prefix: "file:///android_asset/www/",
            info: function() {
                if (!this.debug) return;
                this.lastlog || (this.lastlog = (new Date).getTime());
                var e = [];
                for (var n = 0, r = arguments.length; n < r; n++) e.push(arguments[n]);
                var i = arguments.callee.caller.toString();
                callerFuncName = $.trim(i.substring(i.indexOf("function") + 8, i.indexOf("("))) || "anoynmous";
                var s = t(),
                    o = s.stack.split("\n")[3],
                    u = o.indexOf(this.prefix),
                    a = o.lastIndexOf(":"),
                    f = o.slice(u + this.prefix.length, o.length - 1),
                    l = String.format(" - {1} ({0}ms)", (new Date).getTime() - this.lastlog, this.debug ? f : "");
                return e.push(l), console.info.apply(console, e), this.lastlog = (new Date).getTime(), this.lastlog
            },
            error: function() {
                if (!this.debug) return;
                this.lastlog || (this.lastlog = (new Date).getTime());
                var e = [];
                for (var n = 0, r = arguments.length; n < r; n++) e.push(arguments[n]);
                var i = arguments.callee.caller.toString();
                callerFuncName = $.trim(i.substring(i.indexOf("function") + 8, i.indexOf("("))) || "anoynmous";
                var s = t(),
                    o = s.stack.split("\n")[3],
                    u = o.indexOf(this.prefix),
                    a = o.lastIndexOf(":"),
                    f = o.slice(u + this.prefix.length, a - 1),
                    l = String.format(" - {1} ({0}ms)", (new Date).getTime() - this.lastlog, this.debug ? f : "");
                return e.push(l), console.error.apply(console, e), this.lastlog = (new Date).getTime(), this.lastlog
            }
        }
    }),
    function() {
        var e, t, n, r, i = {}.hasOwnProperty,
            s = [].slice;
        e = {
            LF: "\n",
            NULL: "\0"
        }, n = function() {
            function n(e, t, n) {
                this.command = e, this.headers = t != null ? t : {}, this.body = n != null ? n : ""
            }
            var t;
            return n.prototype.toString = function() {
                var t, r, s, o, u;
                t = [this.command], s = this.headers["content-length"] === !1 ? !0 : !1, s && delete this.headers["content-length"], u = this.headers;
                for (r in u) {
                    if (!i.call(u, r)) continue;
                    o = u[r], t.push("" + r + ":" + o)
                }
                return this.body && !s && t.push("content-length:" + n.sizeOfUTF8(this.body)), t.push(e.LF + this.body), t.join(e.LF)
            }, n.sizeOfUTF8 = function(e) {
                return e ? encodeURI(e).match(/%..|./g).length : 0
            }, t = function(t) {
                var r, i, s, o, u, a, f, l, c, h, p, d, v, m, g, y, b;
                o = t.search(RegExp("" + e.LF + e.LF)), u = t.substring(0, o).split(e.LF), s = u.shift(), a = {}, d = function(e) {
                    return e.replace(/^\s+|\s+$/g, "")
                }, y = u.reverse();
                for (v = 0, g = y.length; v < g; v++) h = y[v], l = h.indexOf(":"), a[d(h.substring(0, l))] = d(h.substring(l + 1));
                r = "", p = o + 2;
                if (a["content-length"]) c = parseInt(a["content-length"]), r = ("" + t).substring(p, p + c);
                else {
                    i = null;
                    for (f = m = p, b = t.length; p <= b ? m < b : m > b; f = p <= b ? ++m : --m) {
                        i = t.charAt(f);
                        if (i === e.NULL) break;
                        r += i
                    }
                }
                return new n(s, a, r)
            }, n.unmarshall = function(n) {
                var r, i, s, o;
                return i = n.split(RegExp("" + e.NULL + e.LF + "*")), o = {
                    frames: [],
                    partial: ""
                }, o.frames = function() {
                    var e, n, s, o;
                    s = i.slice(0, -1), o = [];
                    for (e = 0, n = s.length; e < n; e++) r = s[e], o.push(t(r));
                    return o
                }(), s = i.slice(-1)[0], s === e.LF || s.search(RegExp("" + e.NULL + e.LF + "*$")) !== -1 ? o.frames.push(t(s)) : o.partial = s, o
            }, n.marshall = function(t, r, i) {
                var s;
                return s = new n(t, r, i), s.toString() + e.NULL
            }, n
        }(), t = function() {
            function i(e) {
                this.ws = e, this.ws.binaryType = "arraybuffer", this.counter = 0, this.connected = !1, this.heartbeat = {
                    outgoing: 1e4,
                    incoming: 1e4
                }, this.maxWebSocketFrameSize = 16384, this.subscriptions = {}, this.partialData = ""
            }
            var t;
            return i.prototype.debug = function(e) {
                var t;
                return typeof window != "undefined" && window !== null ? (t = window.console) != null ? t.log(e) : void 0 : void 0
            }, t = function() {
                return Date.now ? Date.now() : (new Date).valueOf
            }, i.prototype._transmit = function(e, t, r) {
                var i;
                i = n.marshall(e, t, r), typeof this.debug == "function" && this.debug(">>> " + i);
                for (;;) {
                    if (!(i.length > this.maxWebSocketFrameSize)) return this.ws.send(i);
                    this.ws.send(i.substring(0, this.maxWebSocketFrameSize)), i = i.substring(this.maxWebSocketFrameSize), typeof this.debug == "function" && this.debug("remaining = " + i.length)
                }
            }, i.prototype._setupHeartbeat = function(n) {
                var i, s, o, u, a, f;
                if ((a = n.version) !== r.VERSIONS.V1_1 && a !== r.VERSIONS.V1_2) return;
                f = function() {
                    var e, t, r, i;
                    r = n["heart-beat"].split(","), i = [];
                    for (e = 0, t = r.length; e < t; e++) u = r[e], i.push(parseInt(u));
                    return i
                }(), s = f[0], i = f[1], this.heartbeat.outgoing !== 0 && i !== 0 && (o = Math.max(this.heartbeat.outgoing, i), typeof this.debug == "function" && this.debug("send PING every " + o + "ms"), this.pinger = r.setInterval(o, function(t) {
                    return function() {
                        return t.ws.send(e.LF), typeof t.debug == "function" ? t.debug(">>> PING") : void 0
                    }
                }(this)));
                if (this.heartbeat.incoming !== 0 && s !== 0) return o = Math.max(this.heartbeat.incoming, s), typeof this.debug == "function" && this.debug("check PONG every " + o + "ms"), this.ponger = r.setInterval(o, function(e) {
                    return function() {
                        var n;
                        n = t() - e.serverActivity;
                        if (n > o * 2) return typeof e.debug == "function" && e.debug("did not receive server activity for the last " + n + "ms"), e.ws.close()
                    }
                }(this))
            }, i.prototype._parseConnect = function() {
                var e, t, n, r;
                e = 1 <= arguments.length ? s.call(arguments, 0) : [], r = {};
                switch (e.length) {
                    case 2:
                        r = e[0], t = e[1];
                        break;
                    case 3:
                        e[1] instanceof Function ? (r = e[0], t = e[1], n = e[2]) : (r.login = e[0], r.passcode = e[1], t = e[2]);
                        break;
                    case 4:
                        r.login = e[0], r.passcode = e[1], t = e[2], n = e[3];
                        break;
                    default:
                        r.login = e[0], r.passcode = e[1], t = e[2], n = e[3], r.host = e[4]
                }
                return [r, t, n]
            }, i.prototype.connect = function() {
                var i, o, u, a;
                return i = 1 <= arguments.length ? s.call(arguments, 0) : [], a = this._parseConnect.apply(this, i), u = a[0], this.connectCallback = a[1], o = a[2], typeof this.debug == "function" && this.debug("Opening Web Socket..."), this.ws.onmessage = function(r) {
                    return function(i) {
                        var s, u, a, f, l, c, h, p, d, v, m, g, y;
                        f = typeof ArrayBuffer != "undefined" && i.data instanceof ArrayBuffer ? (s = new Uint8Array(i.data), typeof r.debug == "function" ? r.debug("--- got data length: " + s.length) : void 0, function() {
                            var e, t, n;
                            n = [];
                            for (e = 0, t = s.length; e < t; e++) u = s[e], n.push(String.fromCharCode(u));
                            return n
                        }().join("")) : i.data, r.serverActivity = t();
                        if (f === e.LF) {
                            typeof r.debug == "function" && r.debug("<<< PONG");
                            return
                        }
                        typeof r.debug == "function" && r.debug("<<< " + f), d = n.unmarshall(r.partialData + f), r.partialData = d.partial, g = d.frames, y = [];
                        for (v = 0, m = g.length; v < m; v++) {
                            l = g[v];
                            switch (l.command) {
                                case "CONNECTED":
                                    typeof r.debug == "function" && r.debug("connected to server " + l.headers.server), r.connected = !0, r._setupHeartbeat(l.headers), y.push(typeof r.connectCallback == "function" ? r.connectCallback(l) : void 0);
                                    break;
                                case "MESSAGE":
                                    p = l.headers.subscription, h = r.subscriptions[p] || r.onreceive, h ? (a = r, c = l.headers["message-id"], l.ack = function(e) {
                                        return e == null && (e = {}), a.ack(c, p, e)
                                    }, l.nack = function(e) {
                                        return e == null && (e = {}), a.nack(c, p, e)
                                    }, y.push(h(l))) : y.push(typeof r.debug == "function" ? r.debug("Unhandled received MESSAGE: " + l) : void 0);
                                    break;
                                case "RECEIPT":
                                    y.push(typeof r.onreceipt == "function" ? r.onreceipt(l) : void 0);
                                    break;
                                case "ERROR":
                                    y.push(typeof o == "function" ? o(l) : void 0);
                                    break;
                                default:
                                    y.push(typeof r.debug == "function" ? r.debug("Unhandled frame: " + l) : void 0)
                            }
                        }
                        return y
                    }
                }(this), this.ws.onclose = function(e) {
                    return function() {
                        var t;
                        return t = "Whoops! Lost connection to " + e.ws.url, typeof e.debug == "function" && e.debug(t), e._cleanUp(), typeof o == "function" ? o(t) : void 0
                    }
                }(this), this.ws.onopen = function(e) {
                    return function() {
                        return typeof e.debug == "function" && e.debug("Web Socket Opened..."), u["accept-version"] = r.VERSIONS.supportedVersions(), u["heart-beat"] = [e.heartbeat.outgoing, e.heartbeat.incoming].join(","), e._transmit("CONNECT", u)
                    }
                }(this)
            }, i.prototype.disconnect = function(e, t) {
                return t == null && (t = {}), this._transmit("DISCONNECT", t), this.ws.onclose = null, this.ws.close(), this._cleanUp(), typeof e == "function" ? e() : void 0
            }, i.prototype._cleanUp = function() {
                this.connected = !1, this.pinger && r.clearInterval(this.pinger);
                if (this.ponger) return r.clearInterval(this.ponger)
            }, i.prototype.send = function(e, t, n) {
                return t == null && (t = {}), n == null && (n = ""), t.destination = e, this._transmit("SEND", t, n)
            }, i.prototype.subscribe = function(e, t, n) {
                var r;
                return n == null && (n = {}), n.id || (n.id = "sub-" + this.counter++), n.destination = e, this.subscriptions[n.id] = t, this._transmit("SUBSCRIBE", n), r = this, {
                    id: n.id,
                    unsubscribe: function() {
                        return r.unsubscribe(n.id)
                    }
                }
            }, i.prototype.unsubscribe = function(e) {
                return delete this.subscriptions[e], this._transmit("UNSUBSCRIBE", {
                    id: e
                })
            }, i.prototype.begin = function(e) {
                var t, n;
                return n = e || "tx-" + this.counter++, this._transmit("BEGIN", {
                    transaction: n
                }), t = this, {
                    id: n,
                    commit: function() {
                        return t.commit(n)
                    },
                    abort: function() {
                        return t.abort(n)
                    }
                }
            }, i.prototype.commit = function(e) {
                return this._transmit("COMMIT", {
                    transaction: e
                })
            }, i.prototype.abort = function(e) {
                return this._transmit("ABORT", {
                    transaction: e
                })
            }, i.prototype.ack = function(e, t, n) {
                return n == null && (n = {}), n["message-id"] = e, n.subscription = t, this._transmit("ACK", n)
            }, i.prototype.nack = function(e, t, n) {
                return n == null && (n = {}), n["message-id"] = e, n.subscription = t, this._transmit("NACK", n)
            }, i
        }(), r = {
            VERSIONS: {
                V1_0: "1.0",
                V1_1: "1.1",
                V1_2: "1.2",
                supportedVersions: function() {
                    return "1.1,1.0"
                }
            },
            client: function(e, n) {
                var i, s;
                return n == null && (n = ["v10.stomp", "v11.stomp"]), i = r.WebSocketClass || WebSocket, s = new i(e, n), new t(s)
            },
            over: function(e) {
                return new t(e)
            },
            Frame: n
        }, typeof exports != "undefined" && exports !== null && (exports.Stomp = r), typeof window != "undefined" && window !== null ? (r.setInterval = function(e, t) {
            return window.setInterval(t, e)
        }, r.clearInterval = function(e) {
            return window.clearInterval(e)
        }, window.Stomp = r) : exports || (self.Stomp = r)
    }.call(this), define("stomp", function() {}), jQuery.fn.extend({
        everyTime: function(e, t, n, r) {
            return this.each(function() {
                jQuery.timer.add(this, e, t, n, r)
            })
        },
        oneTime: function(e, t, n) {
            return this.each(function() {
                jQuery.timer.add(this, e, t, n, 1)
            })
        },
        stopTime: function(e, t) {
            return this.each(function() {
                jQuery.timer.remove(this, e, t)
            })
        }
    }), jQuery.extend({
        timer: {
            global: [],
            guid: 1,
            dataKey: "jQuery.timer",
            regex: /^([0-9]+(?:\.[0-9]*)?)\s*(.*s)?$/,
            powers: {
                ms: 1,
                cs: 10,
                ds: 100,
                s: 1e3,
                das: 1e4,
                hs: 1e5,
                ks: 1e6
            },
            timeParse: function(e) {
                if (e == undefined || e == null) return null;
                var t = this.regex.exec(jQuery.trim(e.toString()));
                if (t[2]) {
                    var n = parseFloat(t[1]),
                        r = this.powers[t[2]] || 1;
                    return n * r
                }
                return e
            },
            add: function(e, t, n, r, i) {
                var s = 0;
                jQuery.isFunction(n) && (i || (i = r), r = n, n = t), t = jQuery.timer.timeParse(t);
                if (typeof t != "number" || isNaN(t) || t < 0) return;
                if (typeof i != "number" || isNaN(i) || i < 0) i = 0;
                i = i || 0;
                var o = jQuery.data(e, this.dataKey) || jQuery.data(e, this.dataKey, {});
                o[n] || (o[n] = {}), r.timerID = r.timerID || this.guid++;
                var u = function() {
                    (++s > i && i !== 0 || r.call(e, s) === !1) && jQuery.timer.remove(e, n, r)
                };
                u.timerID = r.timerID, o[n][r.timerID] || (o[n][r.timerID] = window.setInterval(u, t)), this.global.push(e)
            },
            remove: function(e, t, n) {
                var r = jQuery.data(e, this.dataKey),
                    i;
                if (r) {
                    if (!t)
                        for (t in r) this.remove(e, t, n);
                    else if (r[t]) {
                        if (n) n.timerID && (window.clearInterval(r[t][n.timerID]), delete r[t][n.timerID]);
                        else
                            for (var n in r[t]) window.clearInterval(r[t][n]), delete r[t][n];
                        for (i in r[t]) break;
                        i || (i = null, delete r[t])
                    }
                    for (i in r) break;
                    i || jQuery.removeData(e, this.dataKey)
                }
            }
        }
    }), jQuery(window).bind("unload", function() {
        jQuery.each(jQuery.timer.global, function(e, t) {
            jQuery.timer.remove(t)
        })
    }), define("timers", function() {}), define("mq", ["jquery", "eventhub", "logger", "library", "stomp", "timers"], function(e, t, n, r) {
        var i = t.init(),
            s = {
                props: {},
                client: null,
                response: null,
                connected: !1,
                logout: function() {
                    var e = this;
                    e.props = {}, e.connected = !1, e.disconnect()
                },
                login: function(t, s, o) {
                    var u = this;
                    try {
                        e.extend(u.props, t, {
                            channel: t.channel,
                            port: "61614",
                            user: "ksonglover",
                            password: "3YKdea232sTsqBb4qf"
                        }), n.info("mq connect start...", u.props), u.client = Stomp.client(String.format("ws://{0}:{1}/stomp", u.props.server, u.props.port)), u.client.heartbeat.outgoing = 2e4, u.client.heartbeat.incoming = 0, n.info("start connect..."), u.client.connect(u.props.user, u.props.password, function() {
                            u.connected = !0, u.response = r.guid(), i.trigger("logon"), r.isFunction(s) && s()
                        }, function() {
                            n.info("fail"), r.isFunction(o) && o()
                        })
                    } catch (a) {
                        n.error(a)
                    }
                    return u
                },
                ajax: function(t) {
                    i.trigger("loading");
                    var n = e.Deferred(),
                        r = this;
                    return r.send(t, function(e) {
                        n.resolve(e), i.trigger("loaded")
                    }, function(e) {
                        i.trigger("loaded"), n.reject(e)
                    }), n.promise()
                },
                timeout: 5e3,
                send: function(t, i, s) {
                    var o = this;
                    r.isFunction(s) || (s = function() {}), r.isFunction(i) || (i = function() {}), this.client && this.client.ws.readyState == this.client.ws.CLOSED && (o.connected = !1);
                    if (!o.connected) {
                        n.info("MQ未連線, 以原參數嘗試連接~"), o.login(o.props, function() {
                            o.send(t, i, s)
                        }, function() {
                            s({
                                code: "500",
                                message: "MQ Disconnected."
                            })
                        });
                        return
                    }
                    e.extend(t, {
                        response: o.response,
                        uuid: device.uuid
                    });
                    var u;
                    return n.info("SUBSCRIBE[DATA]", t), u = o.client.subscribe("/topic/" + o.response, function(t) {
                        try {
                            i(JSON.parse(t.body)), o.trigger("response")
                        } catch (n) {
                            s(t)
                        }
                        u.unsubscribe(), e(window).stopTime(o.response)
                    }), n.info("SET TIMEOUT:", t), e(window).oneTime(o.timeout, o.response, function() {
                        s({
                            code: "408",
                            message: "未回應，MQ連線設為中斷必須重連."
                        })
                    }), n.info("SEND[DATA]", JSON.stringify(t), this.props.channel), this.client.send(this.props.channel, {}, JSON.stringify(t)), o
                },
                disconnect: function() {
                    var e = this;
                    return this.client.disconnect(function() {
                        e.connected = !1, i.trigger("disconnected")
                    }), e
                }
            };
        return i.promise(s)
    }),
    function(e, t) {
        "use strict";

        function r(t) {
            e.fn.cycle.debug && i(t)
        }

        function i() {
            window.console && console.log && console.log("[cycle] " + Array.prototype.join.call(arguments, " "))
        }

        function s(t, n, r) {
            var i = e(t).data("cycle.opts");
            if (!i) return;
            var s = !!t.cyclePause;
            s && i.paused ? i.paused(t, i, n, r) : !s && i.resumed && i.resumed(t, i, n, r)
        }

        function o(n, r, o) {
            function l(t, n, r) {
                if (!t && n === !0) {
                    var s = e(r).data("cycle.opts");
                    if (!s) return i("options not found, can not resume"), !1;
                    r.cycleTimeout && (clearTimeout(r.cycleTimeout), r.cycleTimeout = 0), p(s.elements, s, 1, !s.backwards)
                }
            }
            n.cycleStop === t && (n.cycleStop = 0);
            if (r === t || r === null) r = {};
            if (r.constructor == String) {
                switch (r) {
                    case "destroy":
                    case "stop":
                        var u = e(n).data("cycle.opts");
                        if (!u) return !1;
                        return n.cycleStop++, n.cycleTimeout && clearTimeout(n.cycleTimeout), n.cycleTimeout = 0, u.elements && e(u.elements).stop(), e(n).removeData("cycle.opts"), r == "destroy" && a(n, u), !1;
                    case "toggle":
                        return n.cyclePause = n.cyclePause === 1 ? 0 : 1, l(n.cyclePause, o, n), s(n), !1;
                    case "pause":
                        return n.cyclePause = 1, s(n), !1;
                    case "resume":
                        return n.cyclePause = 0, l(!1, o, n), s(n), !1;
                    case "prev":
                    case "next":
                        u = e(n).data("cycle.opts");
                        if (!u) return i('options not found, "prev/next" ignored'), !1;
                        return e.fn.cycle[r](u), !1;
                    default:
                        r = {
                            fx: r
                        }
                }
                return r
            }
            if (r.constructor == Number) {
                var f = r;
                return r = e(n).data("cycle.opts"), r ? f < 0 || f >= r.elements.length ? (i("invalid slide index: " + f), !1) : (r.nextSlide = f, n.cycleTimeout && (clearTimeout(n.cycleTimeout), n.cycleTimeout = 0), typeof o == "string" && (r.oneTimeFx = o), p(r.elements, r, 1, f >= r.currSlide), !1) : (i("options not found, can not advance slide"), !1)
            }
            return r
        }

        function u(t, n) {
            if (!e.support.opacity && n.cleartype && t.style.filter) try {
                t.style.removeAttribute("filter")
            } catch (r) {}
        }

        function a(t, n) {
            n.next && e(n.next).unbind(n.prevNextEvent), n.prev && e(n.prev).unbind(n.prevNextEvent), (n.pager || n.pagerAnchorBuilder) && e.each(n.pagerAnchors || [], function() {
                this.unbind().remove()
            }), n.pagerAnchors = null, e(t).unbind("mouseenter.cycle mouseleave.cycle"), n.destroy && n.destroy(n)
        }

        function f(n, r, o, a, f) {
            var d, y = e.extend({}, e.fn.cycle.defaults, a || {}, e.metadata ? n.metadata() : e.meta ? n.data() : {}),
                b = e.isFunction(n.data) ? n.data(y.metaAttr) : null;
            b && (y = e.extend(y, b)), y.autostop && (y.countdown = y.autostopCount || o.length);
            var w = n[0];
            n.data("cycle.opts", y), y.$cont = n, y.stopCount = w.cycleStop, y.elements = o, y.before = y.before ? [y.before] : [], y.after = y.after ? [y.after] : [], !e.support.opacity && y.cleartype && y.after.push(function() {
                u(this, y)
            }), y.continuous && y.after.push(function() {
                p(o, y, 0, !y.backwards)
            }), l(y), !e.support.opacity && y.cleartype && !y.cleartypeNoBg && g(r), n.css("position") == "static" && n.css("position", "relative"), y.width && n.width(y.width), y.height && y.height != "auto" && n.height(y.height), y.startingSlide !== t ? (y.startingSlide = parseInt(y.startingSlide, 10), y.startingSlide >= o.length || y.startSlide < 0 ? y.startingSlide = 0 : d = !0) : y.backwards ? y.startingSlide = o.length - 1 : y.startingSlide = 0;
            if (y.random) {
                y.randomMap = [];
                for (var E = 0; E < o.length; E++) y.randomMap.push(E);
                y.randomMap.sort(function(e, t) {
                    return Math.random() - .5
                });
                if (d)
                    for (var S = 0; S < o.length; S++) y.startingSlide == y.randomMap[S] && (y.randomIndex = S);
                else y.randomIndex = 1, y.startingSlide = y.randomMap[1]
            } else y.startingSlide >= o.length && (y.startingSlide = 0);
            y.currSlide = y.startingSlide || 0;
            var x = y.startingSlide;
            r.css({
                position: "absolute",
                top: 0,
                left: 0
            }).hide().each(function(t) {
                var n;
                y.backwards ? n = x ? t <= x ? o.length + (t - x) : x - t : o.length - t : n = x ? t >= x ? o.length - (t - x) : x - t : o.length - t, e(this).css("z-index", n)
            }), e(o[x]).css("opacity", 1).show(), u(o[x], y), y.fit && (y.aspect ? r.each(function() {
                var t = e(this),
                    n = y.aspect === !0 ? t.width() / t.height() : y.aspect;
                y.width && t.width() != y.width && (t.width(y.width), t.height(y.width / n)), y.height && t.height() < y.height && (t.height(y.height), t.width(y.height * n))
            }) : (y.width && r.width(y.width), y.height && y.height != "auto" && r.height(y.height))), y.center && (!y.fit || y.aspect) && r.each(function() {
                var t = e(this);
                t.css({
                    "margin-left": y.width ? (y.width - t.width()) / 2 + "px" : 0,
                    "margin-top": y.height ? (y.height - t.height()) / 2 + "px" : 0
                })
            }), y.center && !y.fit && !y.slideResize && r.each(function() {
                var t = e(this);
                t.css({
                    "margin-left": y.width ? (y.width - t.width()) / 2 + "px" : 0,
                    "margin-top": y.height ? (y.height - t.height()) / 2 + "px" : 0
                })
            });
            var T = (y.containerResize || y.containerResizeHeight) && !n.innerHeight();
            if (T) {
                var N = 0,
                    C = 0;
                for (var k = 0; k < o.length; k++) {
                    var L = e(o[k]),
                        A = L[0],
                        O = L.outerWidth(),
                        M = L.outerHeight();
                    O || (O = A.offsetWidth || A.width || L.attr("width")), M || (M = A.offsetHeight || A.height || L.attr("height")), N = O > N ? O : N, C = M > C ? M : C
                }
                y.containerResize && N > 0 && C > 0 && n.css({
                    width: N + "px",
                    height: C + "px"
                }), y.containerResizeHeight && C > 0 && n.css({
                    height: C + "px"
                })
            }
            var _ = !1;
            y.pause && n.bind("mouseenter.cycle", function() {
                _ = !0, this.cyclePause++, s(w, !0)
            }).bind("mouseleave.cycle", function() {
                _ && this.cyclePause--, s(w, !0)
            });
            if (c(y) === !1) return !1;
            var D = !1;
            a.requeueAttempts = a.requeueAttempts || 0, r.each(function() {
                var t = e(this);
                this.cycleH = y.fit && y.height ? y.height : t.height() || this.offsetHeight || this.height || t.attr("height") || 0, this.cycleW = y.fit && y.width ? y.width : t.width() || this.offsetWidth || this.width || t.attr("width") || 0;
                if (t.is("img")) {
                    var n = e.browser.msie && this.cycleW == 28 && this.cycleH == 30 && !this.complete,
                        r = e.browser.mozilla && this.cycleW == 34 && this.cycleH == 19 && !this.complete,
                        s = e.browser.opera && (this.cycleW == 42 && this.cycleH == 19 || this.cycleW == 37 && this.cycleH == 17) && !this.complete,
                        o = this.cycleH === 0 && this.cycleW === 0 && !this.complete;
                    if (n || r || s || o) {
                        if (f.s && y.requeueOnImageNotLoaded && ++a.requeueAttempts < 100) return i(a.requeueAttempts, " - img slide not loaded, requeuing slideshow: ", this.src, this.cycleW, this.cycleH), setTimeout(function() {
                            e(f.s, f.c).cycle(a)
                        }, y.requeueTimeout), D = !0, !1;
                        i("could not determine size of image: " + this.src, this.cycleW, this.cycleH)
                    }
                }
                return !0
            });
            if (D) return !1;
            y.cssBefore = y.cssBefore || {}, y.cssAfter = y.cssAfter || {}, y.cssFirst = y.cssFirst || {}, y.animIn = y.animIn || {}, y.animOut = y.animOut || {}, r.not(":eq(" + x + ")").css(y.cssBefore), e(r[x]).css(y.cssFirst);
            if (y.timeout) {
                y.timeout = parseInt(y.timeout, 10), y.speed.constructor == String && (y.speed = e.fx.speeds[y.speed] || parseInt(y.speed, 10)), y.sync || (y.speed = y.speed / 2);
                var P = y.fx == "none" ? 0 : y.fx == "shuffle" ? 500 : 250;
                while (y.timeout - y.speed < P) y.timeout += y.speed
            }
            y.easing && (y.easeIn = y.easeOut = y.easing), y.speedIn || (y.speedIn = y.speed), y.speedOut || (y.speedOut = y.speed), y.slideCount = o.length, y.currSlide = y.lastSlide = x, y.random ? (++y.randomIndex == o.length && (y.randomIndex = 0), y.nextSlide = y.randomMap[y.randomIndex]) : y.backwards ? y.nextSlide = y.startingSlide === 0 ? o.length - 1 : y.startingSlide - 1 : y.nextSlide = y.startingSlide >= o.length - 1 ? 0 : y.startingSlide + 1;
            if (!y.multiFx) {
                var H = e.fn.cycle.transitions[y.fx];
                if (e.isFunction(H)) H(n, r, y);
                else if (y.fx != "custom" && !y.multiFx) return i("unknown transition: " + y.fx, "; slideshow terminating"), !1
            }
            var B = r[x];
            return y.skipInitializationCallbacks || (y.before.length && y.before[0].apply(B, [B, B, y, !0]), y.after.length && y.after[0].apply(B, [B, B, y, !0])), y.next && e(y.next).bind(y.prevNextEvent, function() {
                return v(y, 1)
            }), y.prev && e(y.prev).bind(y.prevNextEvent, function() {
                return v(y, 0)
            }), (y.pager || y.pagerAnchorBuilder) && m(o, y), h(y, o), y
        }

        function l(t) {
            t.original = {
                before: [],
                after: []
            }, t.original.cssBefore = e.extend({}, t.cssBefore), t.original.cssAfter = e.extend({}, t.cssAfter), t.original.animIn = e.extend({}, t.animIn), t.original.animOut = e.extend({}, t.animOut), e.each(t.before, function() {
                t.original.before.push(this)
            }), e.each(t.after, function() {
                t.original.after.push(this)
            })
        }

        function c(t) {
            var n, s, o = e.fn.cycle.transitions;
            if (t.fx.indexOf(",") > 0) {
                t.multiFx = !0, t.fxs = t.fx.replace(/\s*/g, "").split(",");
                for (n = 0; n < t.fxs.length; n++) {
                    var u = t.fxs[n];
                    s = o[u];
                    if (!s || !o.hasOwnProperty(u) || !e.isFunction(s)) i("discarding unknown transition: ", u), t.fxs.splice(n, 1), n--
                }
                if (!t.fxs.length) return i("No valid transitions named; slideshow terminating."), !1
            } else if (t.fx == "all") {
                t.multiFx = !0, t.fxs = [];
                for (var a in o) o.hasOwnProperty(a) && (s = o[a], o.hasOwnProperty(a) && e.isFunction(s) && t.fxs.push(a))
            }
            if (t.multiFx && t.randomizeEffects) {
                var f = Math.floor(Math.random() * 20) + 30;
                for (n = 0; n < f; n++) {
                    var l = Math.floor(Math.random() * t.fxs.length);
                    t.fxs.push(t.fxs.splice(l, 1)[0])
                }
                r("randomized fx sequence: ", t.fxs)
            }
            return !0
        }

        function h(t, n) {
            t.addSlide = function(r, i) {
                var s = e(r),
                    o = s[0];
                t.autostopCount || t.countdown++, n[i ? "unshift" : "push"](o), t.els && t.els[i ? "unshift" : "push"](o), t.slideCount = n.length, t.random && (t.randomMap.push(t.slideCount - 1), t.randomMap.sort(function(e, t) {
                    return Math.random() - .5
                })), s.css("position", "absolute"), s[i ? "prependTo" : "appendTo"](t.$cont), i && (t.currSlide++, t.nextSlide++), !e.support.opacity && t.cleartype && !t.cleartypeNoBg && g(s), t.fit && t.width && s.width(t.width), t.fit && t.height && t.height != "auto" && s.height(t.height), o.cycleH = t.fit && t.height ? t.height : s.height(), o.cycleW = t.fit && t.width ? t.width : s.width(), s.css(t.cssBefore), (t.pager || t.pagerAnchorBuilder) && e.fn.cycle.createPagerAnchor(n.length - 1, o, e(t.pager), n, t), e.isFunction(t.onAddSlide) ? t.onAddSlide(s) : s.hide()
            }
        }

        function p(n, i, s, o) {
            function m() {
                var e = 0,
                    t = i.timeout;
                i.timeout && !i.continuous ? (e = d(n[i.currSlide], n[i.nextSlide], i, o), i.fx == "shuffle" && (e -= i.speedOut)) : i.continuous && u.cyclePause && (e = 10), e > 0 && (u.cycleTimeout = setTimeout(function() {
                    p(n, i, 0, !i.backwards)
                }, e))
            }
            var u = i.$cont[0],
                a = n[i.currSlide],
                f = n[i.nextSlide];
            s && i.busy && i.manualTrump && (r("manualTrump in go(), stopping active transition"), e(n).stop(!0, !0), i.busy = 0, clearTimeout(u.cycleTimeout));
            if (i.busy) {
                r("transition active, ignoring new tx request");
                return
            }
            if (u.cycleStop != i.stopCount || u.cycleTimeout === 0 && !s) return;
            if (!s && !u.cyclePause && !i.bounce && (i.autostop && --i.countdown <= 0 || i.nowrap && !i.random && i.nextSlide < i.currSlide)) {
                i.end && i.end(i);
                return
            }
            var l = !1;
            if ((s || !u.cyclePause) && i.nextSlide != i.currSlide) {
                l = !0;
                var c = i.fx;
                a.cycleH = a.cycleH || e(a).height(), a.cycleW = a.cycleW || e(a).width(), f.cycleH = f.cycleH || e(f).height(), f.cycleW = f.cycleW || e(f).width(), i.multiFx && (o && (i.lastFx === t || ++i.lastFx >= i.fxs.length) ? i.lastFx = 0 : !o && (i.lastFx === t || --i.lastFx < 0) && (i.lastFx = i.fxs.length - 1), c = i.fxs[i.lastFx]), i.oneTimeFx && (c = i.oneTimeFx, i.oneTimeFx = null), e.fn.cycle.resetState(i, c), i.before.length && e.each(i.before, function(e, t) {
                    if (u.cycleStop != i.stopCount) return;
                    t.apply(f, [a, f, i, o])
                });
                var h = function() {
                    i.busy = 0, e.each(i.after, function(e, t) {
                        if (u.cycleStop != i.stopCount) return;
                        t.apply(f, [a, f, i, o])
                    }), u.cycleStop || m()
                };
                r("tx firing(" + c + "); currSlide: " + i.currSlide + "; nextSlide: " + i.nextSlide), i.busy = 1, i.fxFn ? i.fxFn(a, f, i, h, o, s && i.fastOnEvent) : e.isFunction(e.fn.cycle[i.fx]) ? e.fn.cycle[i.fx](a, f, i, h, o, s && i.fastOnEvent) : e.fn.cycle.custom(a, f, i, h, o, s && i.fastOnEvent)
            } else m();
            if (l || i.nextSlide == i.currSlide) {
                var v;
                i.lastSlide = i.currSlide, i.random ? (i.currSlide = i.nextSlide, ++i.randomIndex == n.length && (i.randomIndex = 0, i.randomMap.sort(function(e, t) {
                    return Math.random() - .5
                })), i.nextSlide = i.randomMap[i.randomIndex], i.nextSlide == i.currSlide && (i.nextSlide = i.currSlide == i.slideCount - 1 ? 0 : i.currSlide + 1)) : i.backwards ? (v = i.nextSlide - 1 < 0, v && i.bounce ? (i.backwards = !i.backwards, i.nextSlide = 1, i.currSlide = 0) : (i.nextSlide = v ? n.length - 1 : i.nextSlide - 1, i.currSlide = v ? 0 : i.nextSlide + 1)) : (v = i.nextSlide + 1 == n.length, v && i.bounce ? (i.backwards = !i.backwards, i.nextSlide = n.length - 2, i.currSlide = n.length - 1) : (i.nextSlide = v ? 0 : i.nextSlide + 1, i.currSlide = v ? n.length - 1 : i.nextSlide - 1))
            }
            l && i.pager && i.updateActivePagerLink(i.pager, i.currSlide, i.activePagerClass)
        }

        function d(e, t, n, i) {
            if (n.timeoutFn) {
                var s = n.timeoutFn.call(e, e, t, n, i);
                while (n.fx != "none" && s - n.speed < 250) s += n.speed;
                r("calculated timeout: " + s + "; speed: " + n.speed);
                if (s !== !1) return s
            }
            return n.timeout
        }

        function v(t, n) {
            var r = n ? 1 : -1,
                i = t.elements,
                s = t.$cont[0],
                o = s.cycleTimeout;
            o && (clearTimeout(o), s.cycleTimeout = 0);
            if (t.random && r < 0) t.randomIndex--, --t.randomIndex == -2 ? t.randomIndex = i.length - 2 : t.randomIndex == -1 && (t.randomIndex = i.length - 1), t.nextSlide = t.randomMap[t.randomIndex];
            else if (t.random) t.nextSlide = t.randomMap[t.randomIndex];
            else {
                t.nextSlide = t.currSlide + r;
                if (t.nextSlide < 0) {
                    if (t.nowrap) return !1;
                    t.nextSlide = i.length - 1
                } else if (t.nextSlide >= i.length) {
                    if (t.nowrap) return !1;
                    t.nextSlide = 0
                }
            }
            var u = t.onPrevNextEvent || t.prevNextClick;
            return e.isFunction(u) && u(r > 0, t.nextSlide, i[t.nextSlide]), p(i, t, 1, n), !1
        }

        function m(t, n) {
            var r = e(n.pager);
            e.each(t, function(i, s) {
                e.fn.cycle.createPagerAnchor(i, s, r, t, n)
            }), n.updateActivePagerLink(n.pager, n.startingSlide, n.activePagerClass)
        }

        function g(t) {
            function n(e) {
                return e = parseInt(e, 10).toString(16), e.length < 2 ? "0" + e : e
            }

            function i(t) {
                for (; t && t.nodeName.toLowerCase() != "html"; t = t.parentNode) {
                    var r = e.css(t, "background-color");
                    if (r && r.indexOf("rgb") >= 0) {
                        var i = r.match(/\d+/g);
                        return "#" + n(i[0]) + n(i[1]) + n(i[2])
                    }
                    if (r && r != "transparent") return r
                }
                return "#ffffff"
            }
            r("applying clearType background-color hack"), t.each(function() {
                e(this).css("background-color", i(this))
            })
        }
        var n = "2.9999.8";
        e.support === t && (e.support = {
            opacity: !e.browser.msie
        }), e.expr[":"].paused = function(e) {
            return e.cyclePause
        }, e.fn.cycle = function(t, n) {
            var s = {
                s: this.selector,
                c: this.context
            };
            return this.length === 0 && t != "stop" ? !e.isReady && s.s ? (i("DOM not ready, queuing slideshow"), e(function() {
                e(s.s, s.c).cycle(t, n)
            }), this) : (i("terminating; zero elements found by selector" + (e.isReady ? "" : " (DOM not ready)")), this) : this.each(function() {
                var u = o(this, t, n);
                if (u === !1) return;
                u.updateActivePagerLink = u.updateActivePagerLink || e.fn.cycle.updateActivePagerLink, this.cycleTimeout && clearTimeout(this.cycleTimeout), this.cycleTimeout = this.cyclePause = 0, this.cycleStop = 0;
                var a = e(this),
                    l = u.slideExpr ? e(u.slideExpr, this) : a.children(),
                    c = l.get();
                if (c.length < 2) {
                    i("terminating; too few slides: " + c.length);
                    return
                }
                var h = f(a, l, c, u, s);
                if (h === !1) return;
                var v = h.continuous ? 10 : d(c[h.currSlide], c[h.nextSlide], h, !h.backwards);
                v && (v += h.delay || 0, v < 10 && (v = 10), r("first timeout: " + v), this.cycleTimeout = setTimeout(function() {
                    p(c, h, 0, !u.backwards)
                }, v))
            })
        }, e.fn.cycle.resetState = function(t, n) {
            n = n || t.fx, t.before = [], t.after = [], t.cssBefore = e.extend({}, t.original.cssBefore), t.cssAfter = e.extend({}, t.original.cssAfter), t.animIn = e.extend({}, t.original.animIn), t.animOut = e.extend({}, t.original.animOut), t.fxFn = null, e.each(t.original.before, function() {
                t.before.push(this)
            }), e.each(t.original.after, function() {
                t.after.push(this)
            });
            var r = e.fn.cycle.transitions[n];
            e.isFunction(r) && r(t.$cont, e(t.elements), t)
        }, e.fn.cycle.updateActivePagerLink = function(t, n, r) {
            e(t).each(function() {
                e(this).children().removeClass(r).eq(n).addClass(r)
            })
        }, e.fn.cycle.next = function(e) {
            v(e, 1)
        }, e.fn.cycle.prev = function(e) {
            v(e, 0)
        }, e.fn.cycle.createPagerAnchor = function(t, n, i, o, u) {
            var a;
            e.isFunction(u.pagerAnchorBuilder) ? (a = u.pagerAnchorBuilder(t, n), r("pagerAnchorBuilder(" + t + ", el) returned: " + a)) : a = '<a href="#">' + (t + 1) + "</a>";
            if (!a) return;
            var f = e(a);
            if (f.parents("body").length === 0) {
                var l = [];
                i.length > 1 ? (i.each(function() {
                    var t = f.clone(!0);
                    e(this).append(t), l.push(t[0])
                }), f = e(l)) : f.appendTo(i)
            }
            u.pagerAnchors = u.pagerAnchors || [], u.pagerAnchors.push(f);
            var c = function(n) {
                n.preventDefault(), u.nextSlide = t;
                var r = u.$cont[0],
                    i = r.cycleTimeout;
                i && (clearTimeout(i), r.cycleTimeout = 0);
                var s = u.onPagerEvent || u.pagerClick;
                e.isFunction(s) && s(u.nextSlide, o[u.nextSlide]), p(o, u, 1, u.currSlide < t)
            };
            /mouseenter|mouseover/i.test(u.pagerEvent) ? f.hover(c, function() {}) : f.bind(u.pagerEvent, c), !/^click/.test(u.pagerEvent) && !u.allowPagerClickBubble && f.bind("click.cycle", function() {
                return !1
            });
            var h = u.$cont[0],
                d = !1;
            u.pauseOnPagerHover && f.hover(function() {
                d = !0, h.cyclePause++, s(h, !0, !0)
            }, function() {
                d && h.cyclePause--, s(h, !0, !0)
            })
        }, e.fn.cycle.hopsFromLast = function(e, t) {
            var n, r = e.lastSlide,
                i = e.currSlide;
            return t ? n = i > r ? i - r : e.slideCount - r : n = i < r ? r - i : r + e.slideCount - i, n
        }, e.fn.cycle.commonReset = function(t, n, r, i, s, o) {
            e(r.elements).not(t).hide(), typeof r.cssBefore.opacity == "undefined" && (r.cssBefore.opacity = 1), r.cssBefore.display = "block", r.slideResize && i !== !1 && n.cycleW > 0 && (r.cssBefore.width = n.cycleW), r.slideResize && s !== !1 && n.cycleH > 0 && (r.cssBefore.height = n.cycleH), r.cssAfter = r.cssAfter || {}, r.cssAfter.display = "none", e(t).css("zIndex", r.slideCount + (o === !0 ? 1 : 0)), e(n).css("zIndex", r.slideCount + (o === !0 ? 0 : 1))
        }, e.fn.cycle.custom = function(t, n, r, i, s, o) {
            var u = e(t),
                a = e(n),
                f = r.speedIn,
                l = r.speedOut,
                c = r.easeIn,
                h = r.easeOut;
            a.css(r.cssBefore), o && (typeof o == "number" ? f = l = o : f = l = 1, c = h = null);
            var p = function() {
                a.animate(r.animIn, f, c, function() {
                    i()
                })
            };
            u.animate(r.animOut, l, h, function() {
                u.css(r.cssAfter), r.sync || p()
            }), r.sync && p()
        }, e.fn.cycle.transitions = {
            fade: function(t, n, r) {
                n.not(":eq(" + r.currSlide + ")").css("opacity", 0), r.before.push(function(t, n, r) {
                    e.fn.cycle.commonReset(t, n, r), r.cssBefore.opacity = 0
                }), r.animIn = {
                    opacity: 1
                }, r.animOut = {
                    opacity: 0
                }, r.cssBefore = {
                    top: 0,
                    left: 0
                }
            }
        }, e.fn.cycle.ver = function() {
            return n
        }, e.fn.cycle.defaults = {
            activePagerClass: "activeSlide",
            after: null,
            allowPagerClickBubble: !1,
            animIn: null,
            animOut: null,
            aspect: !1,
            autostop: 0,
            autostopCount: 0,
            backwards: !1,
            before: null,
            center: null,
            cleartype: !e.support.opacity,
            cleartypeNoBg: !1,
            containerResize: 1,
            containerResizeHeight: 0,
            continuous: 0,
            cssAfter: null,
            cssBefore: null,
            delay: 0,
            easeIn: null,
            easeOut: null,
            easing: null,
            end: null,
            fastOnEvent: 0,
            fit: 0,
            fx: "fade",
            fxFn: null,
            height: "auto",
            manualTrump: !0,
            metaAttr: "cycle",
            next: null,
            nowrap: 0,
            onPagerEvent: null,
            onPrevNextEvent: null,
            pager: null,
            pagerAnchorBuilder: null,
            pagerEvent: "click.cycle",
            pause: 0,
            pauseOnPagerHover: 0,
            prev: null,
            prevNextEvent: "click.cycle",
            random: 0,
            randomizeEffects: 1,
            requeueOnImageNotLoaded: !0,
            requeueTimeout: 250,
            rev: 0,
            shuffle: null,
            skipInitializationCallbacks: !1,
            slideExpr: null,
            slideResize: 1,
            speed: 1e3,
            speedIn: null,
            speedOut: null,
            startingSlide: t,
            sync: 1,
            timeout: 4e3,
            timeoutFn: null,
            updateActivePagerLink: null,
            width: null
        }
    }(jQuery),
    function(e) {
        "use strict";
        e.fn.cycle.transitions.none = function(t, n, r) {
            r.fxFn = function(t, n, r, i) {
                e(n).show(), e(t).hide(), i()
            }
        }, e.fn.cycle.transitions.fadeout = function(t, n, r) {
            n.not(":eq(" + r.currSlide + ")").css({
                display: "block",
                opacity: 1
            }), r.before.push(function(t, n, r, i, s, o) {
                e(t).css("zIndex", r.slideCount + (o !== !0 ? 1 : 0)), e(n).css("zIndex", r.slideCount + (o !== !0 ? 0 : 1))
            }), r.animIn.opacity = 1, r.animOut.opacity = 0, r.cssBefore.opacity = 1, r.cssBefore.display = "block", r.cssAfter.zIndex = 0
        }, e.fn.cycle.transitions.scrollUp = function(t, n, r) {
            t.css("overflow", "hidden"), r.before.push(e.fn.cycle.commonReset);
            var i = t.height();
            r.cssBefore.top = i, r.cssBefore.left = 0, r.cssFirst.top = 0, r.animIn.top = 0, r.animOut.top = -i
        }, e.fn.cycle.transitions.scrollDown = function(t, n, r) {
            t.css("overflow", "hidden"), r.before.push(e.fn.cycle.commonReset);
            var i = t.height();
            r.cssFirst.top = 0, r.cssBefore.top = -i, r.cssBefore.left = 0, r.animIn.top = 0, r.animOut.top = i
        }, e.fn.cycle.transitions.scrollLeft = function(t, n, r) {
            t.css("overflow", "hidden"), r.before.push(e.fn.cycle.commonReset);
            var i = t.width();
            r.cssFirst.left = 0, r.cssBefore.left = i, r.cssBefore.top = 0, r.animIn.left = 0, r.animOut.left = 0 - i
        }, e.fn.cycle.transitions.scrollRight = function(t, n, r) {
            t.css("overflow", "hidden"), r.before.push(e.fn.cycle.commonReset);
            var i = t.width();
            r.cssFirst.left = 0, r.cssBefore.left = -i, r.cssBefore.top = 0, r.animIn.left = 0, r.animOut.left = i
        }, e.fn.cycle.transitions.scrollHorz = function(t, n, r) {
            t.css("overflow", "hidden").width(), r.before.push(function(t, n, r, i) {
                r.rev && (i = !i), e.fn.cycle.commonReset(t, n, r), r.cssBefore.left = i ? n.cycleW - 1 : 1 - n.cycleW, r.animOut.left = i ? -t.cycleW : t.cycleW
            }), r.cssFirst.left = 0, r.cssBefore.top = 0, r.animIn.left = 0, r.animOut.top = 0
        }, e.fn.cycle.transitions.scrollVert = function(t, n, r) {
            t.css("overflow", "hidden"), r.before.push(function(t, n, r, i) {
                r.rev && (i = !i), e.fn.cycle.commonReset(t, n, r), r.cssBefore.top = i ? 1 - n.cycleH : n.cycleH - 1, r.animOut.top = i ? t.cycleH : -t.cycleH
            }), r.cssFirst.top = 0, r.cssBefore.left = 0, r.animIn.top = 0, r.animOut.left = 0
        }, e.fn.cycle.transitions.slideX = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e(r.elements).not(t).hide(), e.fn.cycle.commonReset(t, n, r, !1, !0), r.animIn.width = n.cycleW
            }), r.cssBefore.left = 0, r.cssBefore.top = 0, r.cssBefore.width = 0, r.animIn.width = "show", r.animOut.width = 0
        }, e.fn.cycle.transitions.slideY = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e(r.elements).not(t).hide(), e.fn.cycle.commonReset(t, n, r, !0, !1), r.animIn.height = n.cycleH
            }), r.cssBefore.left = 0, r.cssBefore.top = 0, r.cssBefore.height = 0, r.animIn.height = "show", r.animOut.height = 0
        }, e.fn.cycle.transitions.shuffle = function(t, n, r) {
            var i, s = t.css("overflow", "visible").width();
            n.css({
                left: 0,
                top: 0
            }), r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !0, !0, !0)
            }), r.speedAdjusted || (r.speed = r.speed / 2, r.speedAdjusted = !0), r.random = 0, r.shuffle = r.shuffle || {
                left: -s,
                top: 15
            }, r.els = [];
            for (i = 0; i < n.length; i++) r.els.push(n[i]);
            for (i = 0; i < r.currSlide; i++) r.els.push(r.els.shift());
            r.fxFn = function(t, n, r, i, s) {
                r.rev && (s = !s);
                var o = s ? e(t) : e(n);
                e(n).css(r.cssBefore);
                var u = r.slideCount;
                o.animate(r.shuffle, r.speedIn, r.easeIn, function() {
                    var n = e.fn.cycle.hopsFromLast(r, s);
                    for (var a = 0; a < n; a++) s ? r.els.push(r.els.shift()) : r.els.unshift(r.els.pop());
                    if (s)
                        for (var f = 0, l = r.els.length; f < l; f++) e(r.els[f]).css("z-index", l - f + u);
                    else {
                        var c = e(t).css("z-index");
                        o.css("z-index", parseInt(c, 10) + 1 + u)
                    }
                    o.animate({
                        left: 0,
                        top: 0
                    }, r.speedOut, r.easeOut, function() {
                        e(s ? this : t).hide(), i && i()
                    })
                })
            }, e.extend(r.cssBefore, {
                display: "block",
                opacity: 1,
                top: 0,
                left: 0
            })
        }, e.fn.cycle.transitions.turnUp = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !0, !1), r.cssBefore.top = n.cycleH, r.animIn.height = n.cycleH, r.animOut.width = n.cycleW
            }), r.cssFirst.top = 0, r.cssBefore.left = 0, r.cssBefore.height = 0, r.animIn.top = 0, r.animOut.height = 0
        }, e.fn.cycle.transitions.turnDown = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !0, !1), r.animIn.height = n.cycleH, r.animOut.top = t.cycleH
            }), r.cssFirst.top = 0, r.cssBefore.left = 0, r.cssBefore.top = 0, r.cssBefore.height = 0, r.animOut.height = 0
        }, e.fn.cycle.transitions.turnLeft = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !1, !0), r.cssBefore.left = n.cycleW, r.animIn.width = n.cycleW
            }), r.cssBefore.top = 0, r.cssBefore.width = 0, r.animIn.left = 0, r.animOut.width = 0
        }, e.fn.cycle.transitions.turnRight = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !1, !0), r.animIn.width = n.cycleW, r.animOut.left = t.cycleW
            }), e.extend(r.cssBefore, {
                top: 0,
                left: 0,
                width: 0
            }), r.animIn.left = 0, r.animOut.width = 0
        }, e.fn.cycle.transitions.zoom = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !1, !1, !0), r.cssBefore.top = n.cycleH / 2, r.cssBefore.left = n.cycleW / 2, e.extend(r.animIn, {
                    top: 0,
                    left: 0,
                    width: n.cycleW,
                    height: n.cycleH
                }), e.extend(r.animOut, {
                    width: 0,
                    height: 0,
                    top: t.cycleH / 2,
                    left: t.cycleW / 2
                })
            }), r.cssFirst.top = 0, r.cssFirst.left = 0, r.cssBefore.width = 0, r.cssBefore.height = 0
        }, e.fn.cycle.transitions.fadeZoom = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !1, !1), r.cssBefore.left = n.cycleW / 2, r.cssBefore.top = n.cycleH / 2, e.extend(r.animIn, {
                    top: 0,
                    left: 0,
                    width: n.cycleW,
                    height: n.cycleH
                })
            }), r.cssBefore.width = 0, r.cssBefore.height = 0, r.animOut.opacity = 0
        }, e.fn.cycle.transitions.blindX = function(t, n, r) {
            var i = t.css("overflow", "hidden").width();
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r), r.animIn.width = n.cycleW, r.animOut.left = t.cycleW
            }), r.cssBefore.left = i, r.cssBefore.top = 0, r.animIn.left = 0, r.animOut.left = i
        }, e.fn.cycle.transitions.blindY = function(t, n, r) {
            var i = t.css("overflow", "hidden").height();
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r), r.animIn.height = n.cycleH, r.animOut.top = t.cycleH
            }), r.cssBefore.top = i, r.cssBefore.left = 0, r.animIn.top = 0, r.animOut.top = i
        }, e.fn.cycle.transitions.blindZ = function(t, n, r) {
            var i = t.css("overflow", "hidden").height(),
                s = t.width();
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r), r.animIn.height = n.cycleH, r.animOut.top = t.cycleH
            }), r.cssBefore.top = i, r.cssBefore.left = s, r.animIn.top = 0, r.animIn.left = 0, r.animOut.top = i, r.animOut.left = s
        }, e.fn.cycle.transitions.growX = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !1, !0), r.cssBefore.left = this.cycleW / 2, r.animIn.left = 0, r.animIn.width = this.cycleW, r.animOut.left = 0
            }), r.cssBefore.top = 0, r.cssBefore.width = 0
        }, e.fn.cycle.transitions.growY = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !0, !1), r.cssBefore.top = this.cycleH / 2, r.animIn.top = 0, r.animIn.height = this.cycleH, r.animOut.top = 0
            }), r.cssBefore.height = 0, r.cssBefore.left = 0
        }, e.fn.cycle.transitions.curtainX = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !1, !0, !0), r.cssBefore.left = n.cycleW / 2, r.animIn.left = 0, r.animIn.width = this.cycleW, r.animOut.left = t.cycleW / 2, r.animOut.width = 0
            }), r.cssBefore.top = 0, r.cssBefore.width = 0
        }, e.fn.cycle.transitions.curtainY = function(t, n, r) {
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !0, !1, !0), r.cssBefore.top = n.cycleH / 2, r.animIn.top = 0, r.animIn.height = n.cycleH, r.animOut.top = t.cycleH / 2, r.animOut.height = 0
            }), r.cssBefore.height = 0, r.cssBefore.left = 0
        }, e.fn.cycle.transitions.cover = function(t, n, r) {
            var i = r.direction || "left",
                s = t.css("overflow", "hidden").width(),
                o = t.height();
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r), r.cssAfter.display = "", i == "right" ? r.cssBefore.left = -s : i == "up" ? r.cssBefore.top = o : i == "down" ? r.cssBefore.top = -o : r.cssBefore.left = s
            }), r.animIn.left = 0, r.animIn.top = 0, r.cssBefore.top = 0, r.cssBefore.left = 0
        }, e.fn.cycle.transitions.uncover = function(t, n, r) {
            var i = r.direction || "left",
                s = t.css("overflow", "hidden").width(),
                o = t.height();
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !0, !0, !0), i == "right" ? r.animOut.left = s : i == "up" ? r.animOut.top = -o : i == "down" ? r.animOut.top = o : r.animOut.left = -s
            }), r.animIn.left = 0, r.animIn.top = 0, r.cssBefore.top = 0, r.cssBefore.left = 0
        }, e.fn.cycle.transitions.toss = function(t, n, r) {
            var i = t.css("overflow", "visible").width(),
                s = t.height();
            r.before.push(function(t, n, r) {
                e.fn.cycle.commonReset(t, n, r, !0, !0, !0), !r.animOut.left && !r.animOut.top ? e.extend(r.animOut, {
                    left: i * 2,
                    top: -s / 2,
                    opacity: 0
                }) : r.animOut.opacity = 0
            }), r.cssBefore.left = 0, r.cssBefore.top = 0, r.animIn.left = 0
        }, e.fn.cycle.transitions.wipe = function(t, n, r) {
            var i = t.css("overflow", "hidden").width(),
                s = t.height();
            r.cssBefore = r.cssBefore || {};
            var o;
            if (r.clip)
                if (/l2r/.test(r.clip)) o = "rect(0px 0px " + s + "px 0px)";
                else if (/r2l/.test(r.clip)) o = "rect(0px " + i + "px " + s + "px " + i + "px)";
            else if (/t2b/.test(r.clip)) o = "rect(0px " + i + "px 0px 0px)";
            else if (/b2t/.test(r.clip)) o = "rect(" + s + "px " + i + "px " + s + "px 0px)";
            else if (/zoom/.test(r.clip)) {
                var u = parseInt(s / 2, 10),
                    a = parseInt(i / 2, 10);
                o = "rect(" + u + "px " + a + "px " + u + "px " + a + "px)"
            }
            r.cssBefore.clip = r.cssBefore.clip || o || "rect(0px 0px 0px 0px)";
            var f = r.cssBefore.clip.match(/(\d+)/g),
                l = parseInt(f[0], 10),
                c = parseInt(f[1], 10),
                h = parseInt(f[2], 10),
                p = parseInt(f[3], 10);
            r.before.push(function(t, n, r) {
                if (t == n) return;
                var o = e(t),
                    u = e(n);
                e.fn.cycle.commonReset(t, n, r, !0, !0, !1), r.cssAfter.display = "block";
                var a = 1,
                    f = parseInt(r.speedIn / 13, 10) - 1;
                (function d() {
                    var e = l ? l - parseInt(a * (l / f), 10) : 0,
                        t = p ? p - parseInt(a * (p / f), 10) : 0,
                        n = h < s ? h + parseInt(a * ((s - h) / f || 1), 10) : s,
                        r = c < i ? c + parseInt(a * ((i - c) / f || 1), 10) : i;
                    u.css({
                        clip: "rect(" + e + "px " + r + "px " + n + "px " + t + "px)"
                    }), a++ <= f ? setTimeout(d, 13) : o.css("display", "none")
                })()
            }), e.extend(r.cssBefore, {
                display: "block",
                opacity: 1,
                top: 0,
                left: 0
            }), r.animIn = {
                left: 0
            }, r.animOut = {
                left: 0
            }
        }
    }(jQuery), define("cycle", ["jquery"], function(e) {
        return function() {
            var t, n;
            return t || e.jQuery.fn.cycle
        }
    }(this)),
    function(e) {
        typeof define == "function" && define.amd ? define("jqueryui", ["jquery"], e) : e(jQuery)
    }(function(e) {
        function t(t, r) {
            var i, s, o, u = t.nodeName.toLowerCase();
            return "area" === u ? (i = t.parentNode, s = i.name, !t.href || !s || i.nodeName.toLowerCase() !== "map" ? !1 : (o = e("img[usemap='#" + s + "']")[0], !!o && n(o))) : (/input|select|textarea|button|object/.test(u) ? !t.disabled : "a" === u ? t.href || r : r) && n(t)
        }

        function n(t) {
            return e.expr.filters.visible(t) && !e(t).parents().addBack().filter(function() {
                return e.css(this, "visibility") === "hidden"
            }).length
        }

        function b(e) {
            var t, n;
            while (e.length && e[0] !== document) {
                t = e.css("position");
                if (t === "absolute" || t === "relative" || t === "fixed") {
                    n = parseInt(e.css("zIndex"), 10);
                    if (!isNaN(n) && n !== 0) return n
                }
                e = e.parent()
            }
            return 0
        }

        function w() {
            this._curInst = null, this._keyEvent = !1, this._disabledInputs = [], this._datepickerShowing = !1, this._inDialog = !1, this._mainDivId = "ui-datepicker-div", this._inlineClass = "ui-datepicker-inline", this._appendClass = "ui-datepicker-append", this._triggerClass = "ui-datepicker-trigger", this._dialogClass = "ui-datepicker-dialog", this._disableClass = "ui-datepicker-disabled", this._unselectableClass = "ui-datepicker-unselectable", this._currentClass = "ui-datepicker-current-day", this._dayOverClass = "ui-datepicker-days-cell-over", this.regional = [], this.regional[""] = {
                closeText: "Done",
                prevText: "Prev",
                nextText: "Next",
                currentText: "Today",
                monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                weekHeader: "Wk",
                dateFormat: "mm/dd/yy",
                firstDay: 0,
                isRTL: !1,
                showMonthAfterYear: !1,
                yearSuffix: ""
            }, this._defaults = {
                showOn: "focus",
                showAnim: "fadeIn",
                showOptions: {},
                defaultDate: null,
                appendText: "",
                buttonText: "...",
                buttonImage: "",
                buttonImageOnly: !1,
                hideIfNoPrevNext: !1,
                navigationAsDateFormat: !1,
                gotoCurrent: !1,
                changeMonth: !1,
                changeYear: !1,
                yearRange: "c-10:c+10",
                showOtherMonths: !1,
                selectOtherMonths: !1,
                showWeek: !1,
                calculateWeek: this.iso8601Week,
                shortYearCutoff: "+10",
                minDate: null,
                maxDate: null,
                duration: "fast",
                beforeShowDay: null,
                beforeShow: null,
                onSelect: null,
                onChangeMonthYear: null,
                onClose: null,
                numberOfMonths: 1,
                showCurrentAtPos: 0,
                stepMonths: 1,
                stepBigMonths: 12,
                altField: "",
                altFormat: "",
                constrainInput: !0,
                showButtonPanel: !1,
                autoSize: !1,
                disabled: !1
            }, e.extend(this._defaults, this.regional[""]), this.regional.en = e.extend(!0, {}, this.regional[""]), this.regional["en-US"] = e.extend(!0, {}, this.regional.en), this.dpDiv = E(e("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>"))
        }

        function E(t) {
            var n = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
            return t.delegate(n, "mouseout", function() {
                e(this).removeClass("ui-state-hover"), this.className.indexOf("ui-datepicker-prev") !== -1 && e(this).removeClass("ui-datepicker-prev-hover"), this.className.indexOf("ui-datepicker-next") !== -1 && e(this).removeClass("ui-datepicker-next-hover")
            }).delegate(n, "mouseover", S)
        }

        function S() {
            e.datepicker._isDisabledDatepicker(y.inline ? y.dpDiv.parent()[0] : y.input[0]) || (e(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"), e(this).addClass("ui-state-hover"), this.className.indexOf("ui-datepicker-prev") !== -1 && e(this).addClass("ui-datepicker-prev-hover"), this.className.indexOf("ui-datepicker-next") !== -1 && e(this).addClass("ui-datepicker-next-hover"))
        }

        function x(t, n) {
            e.extend(t, n);
            for (var r in n) n[r] == null && (t[r] = n[r]);
            return t
        }

        function Y(e) {
            return function() {
                var t = this.element.val();
                e.apply(this, arguments), this._refresh(), t !== this.element.val() && this._trigger("change")
            }
        }
        e.ui = e.ui || {}, e.extend(e.ui, {
            version: "1.11.2",
            keyCode: {
                BACKSPACE: 8,
                COMMA: 188,
                DELETE: 46,
                DOWN: 40,
                END: 35,
                ENTER: 13,
                ESCAPE: 27,
                HOME: 36,
                LEFT: 37,
                PAGE_DOWN: 34,
                PAGE_UP: 33,
                PERIOD: 190,
                RIGHT: 39,
                SPACE: 32,
                TAB: 9,
                UP: 38
            }
        }), e.fn.extend({
            scrollParent: function(t) {
                var n = this.css("position"),
                    r = n === "absolute",
                    i = t ? /(auto|scroll|hidden)/ : /(auto|scroll)/,
                    s = this.parents().filter(function() {
                        var t = e(this);
                        return r && t.css("position") === "static" ? !1 : i.test(t.css("overflow") + t.css("overflow-y") + t.css("overflow-x"))
                    }).eq(0);
                return n === "fixed" || !s.length ? e(this[0].ownerDocument || document) : s
            },
            uniqueId: function() {
                var e = 0;
                return function() {
                    return this.each(function() {
                        this.id || (this.id = "ui-id-" + ++e)
                    })
                }
            }(),
            removeUniqueId: function() {
                return this.each(function() {
                    /^ui-id-\d+$/.test(this.id) && e(this).removeAttr("id")
                })
            }
        }), e.extend(e.expr[":"], {
            data: e.expr.createPseudo ? e.expr.createPseudo(function(t) {
                return function(n) {
                    return !!e.data(n, t)
                }
            }) : function(t, n, r) {
                return !!e.data(t, r[3])
            },
            focusable: function(n) {
                return t(n, !isNaN(e.attr(n, "tabindex")))
            },
            tabbable: function(n) {
                var r = e.attr(n, "tabindex"),
                    i = isNaN(r);
                return (i || r >= 0) && t(n, !i)
            }
        }), e("<a>").outerWidth(1).jquery || e.each(["Width", "Height"], function(t, n) {
            function o(t, n, i, s) {
                return e.each(r, function() {
                    n -= parseFloat(e.css(t, "padding" + this)) || 0, i && (n -= parseFloat(e.css(t, "border" + this + "Width")) || 0), s && (n -= parseFloat(e.css(t, "margin" + this)) || 0)
                }), n
            }
            var r = n === "Width" ? ["Left", "Right"] : ["Top", "Bottom"],
                i = n.toLowerCase(),
                s = {
                    innerWidth: e.fn.innerWidth,
                    innerHeight: e.fn.innerHeight,
                    outerWidth: e.fn.outerWidth,
                    outerHeight: e.fn.outerHeight
                };
            e.fn["inner" + n] = function(t) {
                return t === undefined ? s["inner" + n].call(this) : this.each(function() {
                    e(this).css(i, o(this, t) + "px")
                })
            }, e.fn["outer" + n] = function(t, r) {
                return typeof t != "number" ? s["outer" + n].call(this, t) : this.each(function() {
                    e(this).css(i, o(this, t, !0, r) + "px")
                })
            }
        }), e.fn.addBack || (e.fn.addBack = function(e) {
            return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
        }), e("<a>").data("a-b", "a").removeData("a-b").data("a-b") && (e.fn.removeData = function(t) {
            return function(n) {
                return arguments.length ? t.call(this, e.camelCase(n)) : t.call(this)
            }
        }(e.fn.removeData)), e.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()), e.fn.extend({
            focus: function(t) {
                return function(n, r) {
                    return typeof n == "number" ? this.each(function() {
                        var t = this;
                        setTimeout(function() {
                            e(t).focus(), r && r.call(t)
                        }, n)
                    }) : t.apply(this, arguments)
                }
            }(e.fn.focus),
            disableSelection: function() {
                var e = "onselectstart" in document.createElement("div") ? "selectstart" : "mousedown";
                return function() {
                    return this.bind(e + ".ui-disableSelection", function(e) {
                        e.preventDefault()
                    })
                }
            }(),
            enableSelection: function() {
                return this.unbind(".ui-disableSelection")
            },
            zIndex: function(t) {
                if (t !== undefined) return this.css("zIndex", t);
                if (this.length) {
                    var n = e(this[0]),
                        r, i;
                    while (n.length && n[0] !== document) {
                        r = n.css("position");
                        if (r === "absolute" || r === "relative" || r === "fixed") {
                            i = parseInt(n.css("zIndex"), 10);
                            if (!isNaN(i) && i !== 0) return i
                        }
                        n = n.parent()
                    }
                }
                return 0
            }
        }), e.ui.plugin = {
            add: function(t, n, r) {
                var i, s = e.ui[t].prototype;
                for (i in r) s.plugins[i] = s.plugins[i] || [], s.plugins[i].push([n, r[i]])
            },
            call: function(e, t, n, r) {
                var i, s = e.plugins[t];
                if (!s) return;
                if (!r && (!e.element[0].parentNode || e.element[0].parentNode.nodeType === 11)) return;
                for (i = 0; i < s.length; i++) e.options[s[i][0]] && s[i][1].apply(e.element, n)
            }
        };
        var r = 0,
            i = Array.prototype.slice;
        e.cleanData = function(t) {
            return function(n) {
                var r, i, s;
                for (s = 0;
                    (i = n[s]) != null; s++) try {
                    r = e._data(i, "events"), r && r.remove && e(i).triggerHandler("remove")
                } catch (o) {}
                t(n)
            }
        }(e.cleanData), e.widget = function(t, n, r) {
            var i, s, o, u, a = {},
                f = t.split(".")[0];
            return t = t.split(".")[1], i = f + "-" + t, r || (r = n, n = e.Widget), e.expr[":"][i.toLowerCase()] = function(t) {
                return !!e.data(t, i)
            }, e[f] = e[f] || {}, s = e[f][t], o = e[f][t] = function(e, t) {
                if (!this._createWidget) return new o(e, t);
                arguments.length && this._createWidget(e, t)
            }, e.extend(o, s, {
                version: r.version,
                _proto: e.extend({}, r),
                _childConstructors: []
            }), u = new n, u.options = e.widget.extend({}, u.options), e.each(r, function(t, r) {
                if (!e.isFunction(r)) {
                    a[t] = r;
                    return
                }
                a[t] = function() {
                    var e = function() {
                            return n.prototype[t].apply(this, arguments)
                        },
                        i = function(e) {
                            return n.prototype[t].apply(this, e)
                        };
                    return function() {
                        var t = this._super,
                            n = this._superApply,
                            s;
                        return this._super = e, this._superApply = i, s = r.apply(this, arguments), this._super = t, this._superApply = n, s
                    }
                }()
            }), o.prototype = e.widget.extend(u, {
                widgetEventPrefix: s ? u.widgetEventPrefix || t : t
            }, a, {
                constructor: o,
                namespace: f,
                widgetName: t,
                widgetFullName: i
            }), s ? (e.each(s._childConstructors, function(t, n) {
                var r = n.prototype;
                e.widget(r.namespace + "." + r.widgetName, o, n._proto)
            }), delete s._childConstructors) : n._childConstructors.push(o), e.widget.bridge(t, o), o
        }, e.widget.extend = function(t) {
            var n = i.call(arguments, 1),
                r = 0,
                s = n.length,
                o, u;
            for (; r < s; r++)
                for (o in n[r]) u = n[r][o], n[r].hasOwnProperty(o) && u !== undefined && (e.isPlainObject(u) ? t[o] = e.isPlainObject(t[o]) ? e.widget.extend({}, t[o], u) : e.widget.extend({}, u) : t[o] = u);
            return t
        }, e.widget.bridge = function(t, n) {
            var r = n.prototype.widgetFullName || t;
            e.fn[t] = function(s) {
                var o = typeof s == "string",
                    u = i.call(arguments, 1),
                    a = this;
                return s = !o && u.length ? e.widget.extend.apply(null, [s].concat(u)) : s, o ? this.each(function() {
                    var n, i = e.data(this, r);
                    if (s === "instance") return a = i, !1;
                    if (!i) return e.error("cannot call methods on " + t + " prior to initialization; " + "attempted to call method '" + s + "'");
                    if (!e.isFunction(i[s]) || s.charAt(0) === "_") return e.error("no such method '" + s + "' for " + t + " widget instance");
                    n = i[s].apply(i, u);
                    if (n !== i && n !== undefined) return a = n && n.jquery ? a.pushStack(n.get()) : n, !1
                }) : this.each(function() {
                    var t = e.data(this, r);
                    t ? (t.option(s || {}), t._init && t._init()) : e.data(this, r, new n(s, this))
                }), a
            }
        }, e.Widget = function() {}, e.Widget._childConstructors = [], e.Widget.prototype = {
            widgetName: "widget",
            widgetEventPrefix: "",
            defaultElement: "<div>",
            options: {
                disabled: !1,
                create: null
            },
            _createWidget: function(t, n) {
                n = e(n || this.defaultElement || this)[0], this.element = e(n), this.uuid = r++, this.eventNamespace = "." + this.widgetName + this.uuid, this.bindings = e(), this.hoverable = e(), this.focusable = e(), n !== this && (e.data(n, this.widgetFullName, this), this._on(!0, this.element, {
                    remove: function(e) {
                        e.target === n && this.destroy()
                    }
                }), this.document = e(n.style ? n.ownerDocument : n.document || n), this.window = e(this.document[0].defaultView || this.document[0].parentWindow)), this.options = e.widget.extend({}, this.options, this._getCreateOptions(), t), this._create(), this._trigger("create", null, this._getCreateEventData()), this._init()
            },
            _getCreateOptions: e.noop,
            _getCreateEventData: e.noop,
            _create: e.noop,
            _init: e.noop,
            destroy: function() {
                this._destroy(), this.element.unbind(this.eventNamespace).removeData(this.widgetFullName).removeData(e.camelCase(this.widgetFullName)), this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName + "-disabled " + "ui-state-disabled"), this.bindings.unbind(this.eventNamespace), this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus")
            },
            _destroy: e.noop,
            widget: function() {
                return this.element
            },
            option: function(t, n) {
                var r = t,
                    i, s, o;
                if (arguments.length === 0) return e.widget.extend({}, this.options);
                if (typeof t == "string") {
                    r = {}, i = t.split("."), t = i.shift();
                    if (i.length) {
                        s = r[t] = e.widget.extend({}, this.options[t]);
                        for (o = 0; o < i.length - 1; o++) s[i[o]] = s[i[o]] || {}, s = s[i[o]];
                        t = i.pop();
                        if (arguments.length === 1) return s[t] === undefined ? null : s[t];
                        s[t] = n
                    } else {
                        if (arguments.length === 1) return this.options[t] === undefined ? null : this.options[t];
                        r[t] = n
                    }
                }
                return this._setOptions(r), this
            },
            _setOptions: function(e) {
                var t;
                for (t in e) this._setOption(t, e[t]);
                return this
            },
            _setOption: function(e, t) {
                return this.options[e] = t, e === "disabled" && (this.widget().toggleClass(this.widgetFullName + "-disabled", !!t), t && (this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus"))), this
            },
            enable: function() {
                return this._setOptions({
                    disabled: !1
                })
            },
            disable: function() {
                return this._setOptions({
                    disabled: !0
                })
            },
            _on: function(t, n, r) {
                var i, s = this;
                typeof t != "boolean" && (r = n, n = t, t = !1), r ? (n = i = e(n), this.bindings = this.bindings.add(n)) : (r = n, n = this.element, i = this.widget()), e.each(r, function(r, o) {
                    function u() {
                        if (!t && (s.options.disabled === !0 || e(this).hasClass("ui-state-disabled"))) return;
                        return (typeof o == "string" ? s[o] : o).apply(s, arguments)
                    }
                    typeof o != "string" && (u.guid = o.guid = o.guid || u.guid || e.guid++);
                    var a = r.match(/^([\w:-]*)\s*(.*)$/),
                        f = a[1] + s.eventNamespace,
                        l = a[2];
                    l ? i.delegate(l, f, u) : n.bind(f, u)
                })
            },
            _off: function(t, n) {
                n = (n || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, t.unbind(n).undelegate(n), this.bindings = e(this.bindings.not(t).get()), this.focusable = e(this.focusable.not(t).get()), this.hoverable = e(this.hoverable.not(t).get())
            },
            _delay: function(e, t) {
                function n() {
                    return (typeof e == "string" ? r[e] : e).apply(r, arguments)
                }
                var r = this;
                return setTimeout(n, t || 0)
            },
            _hoverable: function(t) {
                this.hoverable = this.hoverable.add(t), this._on(t, {
                    mouseenter: function(t) {
                        e(t.currentTarget).addClass("ui-state-hover")
                    },
                    mouseleave: function(t) {
                        e(t.currentTarget).removeClass("ui-state-hover")
                    }
                })
            },
            _focusable: function(t) {
                this.focusable = this.focusable.add(t), this._on(t, {
                    focusin: function(t) {
                        e(t.currentTarget).addClass("ui-state-focus")
                    },
                    focusout: function(t) {
                        e(t.currentTarget).removeClass("ui-state-focus")
                    }
                })
            },
            _trigger: function(t, n, r) {
                var i, s, o = this.options[t];
                r = r || {}, n = e.Event(n), n.type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase(), n.target = this.element[0], s = n.originalEvent;
                if (s)
                    for (i in s) i in n || (n[i] = s[i]);
                return this.element.trigger(n, r), !(e.isFunction(o) && o.apply(this.element[0], [n].concat(r)) === !1 || n.isDefaultPrevented())
            }
        }, e.each({
            show: "fadeIn",
            hide: "fadeOut"
        }, function(t, n) {
            e.Widget.prototype["_" + t] = function(r, i, s) {
                typeof i == "string" && (i = {
                    effect: i
                });
                var o, u = i ? i === !0 || typeof i == "number" ? n : i.effect || n : t;
                i = i || {}, typeof i == "number" && (i = {
                    duration: i
                }), o = !e.isEmptyObject(i), i.complete = s, i.delay && r.delay(i.delay), o && e.effects && e.effects.effect[u] ? r[t](i) : u !== t && r[u] ? r[u](i.duration, i.easing, s) : r.queue(function(n) {
                    e(this)[t](), s && s.call(r[0]), n()
                })
            }
        });
        var s = e.widget,
            o = !1;
        e(document).mouseup(function() {
            o = !1
        });
        var u = e.widget("ui.mouse", {
            version: "1.11.2",
            options: {
                cancel: "input,textarea,button,select,option",
                distance: 1,
                delay: 0
            },
            _mouseInit: function() {
                var t = this;
                this.element.bind("mousedown." + this.widgetName, function(e) {
                    return t._mouseDown(e)
                }).bind("click." + this.widgetName, function(n) {
                    if (!0 === e.data(n.target, t.widgetName + ".preventClickEvent")) return e.removeData(n.target, t.widgetName + ".preventClickEvent"), n.stopImmediatePropagation(), !1
                }), this.started = !1
            },
            _mouseDestroy: function() {
                this.element.unbind("." + this.widgetName), this._mouseMoveDelegate && this.document.unbind("mousemove." + this.widgetName, this._mouseMoveDelegate).unbind("mouseup." + this.widgetName, this._mouseUpDelegate)
            },
            _mouseDown: function(t) {
                if (o) return;
                this._mouseMoved = !1, this._mouseStarted && this._mouseUp(t), this._mouseDownEvent = t;
                var n = this,
                    r = t.which === 1,
                    i = typeof this.options.cancel == "string" && t.target.nodeName ? e(t.target).closest(this.options.cancel).length : !1;
                if (!r || i || !this._mouseCapture(t)) return !0;
                this.mouseDelayMet = !this.options.delay, this.mouseDelayMet || (this._mouseDelayTimer = setTimeout(function() {
                    n.mouseDelayMet = !0
                }, this.options.delay));
                if (this._mouseDistanceMet(t) && this._mouseDelayMet(t)) {
                    this._mouseStarted = this._mouseStart(t) !== !1;
                    if (!this._mouseStarted) return t.preventDefault(), !0
                }
                return !0 === e.data(t.target, this.widgetName + ".preventClickEvent") && e.removeData(t.target, this.widgetName + ".preventClickEvent"), this._mouseMoveDelegate = function(e) {
                    return n._mouseMove(e)
                }, this._mouseUpDelegate = function(e) {
                    return n._mouseUp(e)
                }, this.document.bind("mousemove." + this.widgetName, this._mouseMoveDelegate).bind("mouseup." + this.widgetName, this._mouseUpDelegate), t.preventDefault(), o = !0, !0
            },
            _mouseMove: function(t) {
                if (this._mouseMoved) {
                    if (e.ui.ie && (!document.documentMode || document.documentMode < 9) && !t.button) return this._mouseUp(t);
                    if (!t.which) return this._mouseUp(t)
                }
                if (t.which || t.button) this._mouseMoved = !0;
                return this._mouseStarted ? (this._mouseDrag(t), t.preventDefault()) : (this._mouseDistanceMet(t) && this._mouseDelayMet(t) && (this._mouseStarted = this._mouseStart(this._mouseDownEvent, t) !== !1, this._mouseStarted ? this._mouseDrag(t) : this._mouseUp(t)), !this._mouseStarted)
            },
            _mouseUp: function(t) {
                return this.document.unbind("mousemove." + this.widgetName, this._mouseMoveDelegate).unbind("mouseup." + this.widgetName, this._mouseUpDelegate), this._mouseStarted && (this._mouseStarted = !1, t.target === this._mouseDownEvent.target && e.data(t.target, this.widgetName + ".preventClickEvent", !0), this._mouseStop(t)), o = !1, !1
            },
            _mouseDistanceMet: function(e) {
                return Math.max(Math.abs(this._mouseDownEvent.pageX - e.pageX), Math.abs(this._mouseDownEvent.pageY - e.pageY)) >= this.options.distance
            },
            _mouseDelayMet: function() {
                return this.mouseDelayMet
            },
            _mouseStart: function() {},
            _mouseDrag: function() {},
            _mouseStop: function() {},
            _mouseCapture: function() {
                return !0
            }
        });
        (function() {
            function h(e, t, n) {
                return [parseFloat(e[0]) * (l.test(e[0]) ? t / 100 : 1), parseFloat(e[1]) * (l.test(e[1]) ? n / 100 : 1)]
            }

            function p(t, n) {
                return parseInt(e.css(t, n), 10) || 0
            }

            function d(t) {
                var n = t[0];
                return n.nodeType === 9 ? {
                    width: t.width(),
                    height: t.height(),
                    offset: {
                        top: 0,
                        left: 0
                    }
                } : e.isWindow(n) ? {
                    width: t.width(),
                    height: t.height(),
                    offset: {
                        top: t.scrollTop(),
                        left: t.scrollLeft()
                    }
                } : n.preventDefault ? {
                    width: 0,
                    height: 0,
                    offset: {
                        top: n.pageY,
                        left: n.pageX
                    }
                } : {
                    width: t.outerWidth(),
                    height: t.outerHeight(),
                    offset: t.offset()
                }
            }
            e.ui = e.ui || {};
            var t, n, r = Math.max,
                i = Math.abs,
                s = Math.round,
                o = /left|center|right/,
                u = /top|center|bottom/,
                a = /[\+\-]\d+(\.[\d]+)?%?/,
                f = /^\w+/,
                l = /%$/,
                c = e.fn.position;
            e.position = {
                    scrollbarWidth: function() {
                        if (t !== undefined) return t;
                        var n, r, i = e("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),
                            s = i.children()[0];
                        return e("body").append(i), n = s.offsetWidth, i.css("overflow", "scroll"), r = s.offsetWidth, n === r && (r = i[0].clientWidth), i.remove(), t = n - r
                    },
                    getScrollInfo: function(t) {
                        var n = t.isWindow || t.isDocument ? "" : t.element.css("overflow-x"),
                            r = t.isWindow || t.isDocument ? "" : t.element.css("overflow-y"),
                            i = n === "scroll" || n === "auto" && t.width < t.element[0].scrollWidth,
                            s = r === "scroll" || r === "auto" && t.height < t.element[0].scrollHeight;
                        return {
                            width: s ? e.position.scrollbarWidth() : 0,
                            height: i ? e.position.scrollbarWidth() : 0
                        }
                    },
                    getWithinInfo: function(t) {
                        var n = e(t || window),
                            r = e.isWindow(n[0]),
                            i = !!n[0] && n[0].nodeType === 9;
                        return {
                            element: n,
                            isWindow: r,
                            isDocument: i,
                            offset: n.offset() || {
                                left: 0,
                                top: 0
                            },
                            scrollLeft: n.scrollLeft(),
                            scrollTop: n.scrollTop(),
                            width: r || i ? n.width() : n.outerWidth(),
                            height: r || i ? n.height() : n.outerHeight()
                        }
                    }
                }, e.fn.position = function(t) {
                    if (!t || !t.of) return c.apply(this, arguments);
                    t = e.extend({}, t);
                    var l, v, m, g, y, b, w = e(t.of),
                        E = e.position.getWithinInfo(t.within),
                        S = e.position.getScrollInfo(E),
                        x = (t.collision || "flip").split(" "),
                        T = {};
                    return b = d(w), w[0].preventDefault && (t.at = "left top"), v = b.width, m = b.height, g = b.offset, y = e.extend({}, g), e.each(["my", "at"], function() {
                        var e = (t[this] || "").split(" "),
                            n, r;
                        e.length === 1 && (e = o.test(e[0]) ? e.concat(["center"]) : u.test(e[0]) ? ["center"].concat(e) : ["center", "center"]), e[0] = o.test(e[0]) ? e[0] : "center", e[1] = u.test(e[1]) ? e[1] : "center", n = a.exec(e[0]), r = a.exec(e[1]), T[this] = [n ? n[0] : 0, r ? r[0] : 0], t[this] = [f.exec(e[0])[0], f.exec(e[1])[0]]
                    }), x.length === 1 && (x[1] = x[0]), t.at[0] === "right" ? y.left += v : t.at[0] === "center" && (y.left += v / 2), t.at[1] === "bottom" ? y.top += m : t.at[1] === "center" && (y.top += m / 2), l = h(T.at, v, m), y.left += l[0], y.top += l[1], this.each(function() {
                        var o, u, a = e(this),
                            f = a.outerWidth(),
                            c = a.outerHeight(),
                            d = p(this, "marginLeft"),
                            b = p(this, "marginTop"),
                            N = f + d + p(this, "marginRight") + S.width,
                            C = c + b + p(this, "marginBottom") + S.height,
                            k = e.extend({}, y),
                            L = h(T.my, a.outerWidth(), a.outerHeight());
                        t.my[0] === "right" ? k.left -= f : t.my[0] === "center" && (k.left -= f / 2), t.my[1] === "bottom" ? k.top -= c : t.my[1] === "center" && (k.top -= c / 2), k.left += L[0], k.top += L[1], n || (k.left = s(k.left), k.top = s(k.top)), o = {
                            marginLeft: d,
                            marginTop: b
                        }, e.each(["left", "top"], function(n, r) {
                            e.ui.position[x[n]] && e.ui.position[x[n]][r](k, {
                                targetWidth: v,
                                targetHeight: m,
                                elemWidth: f,
                                elemHeight: c,
                                collisionPosition: o,
                                collisionWidth: N,
                                collisionHeight: C,
                                offset: [l[0] + L[0], l[1] + L[1]],
                                my: t.my,
                                at: t.at,
                                within: E,
                                elem: a
                            })
                        }), t.using && (u = function(e) {
                            var n = g.left - k.left,
                                s = n + v - f,
                                o = g.top - k.top,
                                u = o + m - c,
                                l = {
                                    target: {
                                        element: w,
                                        left: g.left,
                                        top: g.top,
                                        width: v,
                                        height: m
                                    },
                                    element: {
                                        element: a,
                                        left: k.left,
                                        top: k.top,
                                        width: f,
                                        height: c
                                    },
                                    horizontal: s < 0 ? "left" : n > 0 ? "right" : "center",
                                    vertical: u < 0 ? "top" : o > 0 ? "bottom" : "middle"
                                };
                            v < f && i(n + s) < v && (l.horizontal = "center"), m < c && i(o + u) < m && (l.vertical = "middle"), r(i(n), i(s)) > r(i(o), i(u)) ? l.important = "horizontal" : l.important = "vertical", t.using.call(this, e, l)
                        }), a.offset(e.extend(k, {
                            using: u
                        }))
                    })
                }, e.ui.position = {
                    fit: {
                        left: function(e, t) {
                            var n = t.within,
                                i = n.isWindow ? n.scrollLeft : n.offset.left,
                                s = n.width,
                                o = e.left - t.collisionPosition.marginLeft,
                                u = i - o,
                                a = o + t.collisionWidth - s - i,
                                f;
                            t.collisionWidth > s ? u > 0 && a <= 0 ? (f = e.left + u + t.collisionWidth - s - i, e.left += u - f) : a > 0 && u <= 0 ? e.left = i : u > a ? e.left = i + s - t.collisionWidth : e.left = i : u > 0 ? e.left += u : a > 0 ? e.left -= a : e.left = r(e.left - o, e.left)
                        },
                        top: function(e, t) {
                            var n = t.within,
                                i = n.isWindow ? n.scrollTop : n.offset.top,
                                s = t.within.height,
                                o = e.top - t.collisionPosition.marginTop,
                                u = i - o,
                                a = o + t.collisionHeight - s - i,
                                f;
                            t.collisionHeight > s ? u > 0 && a <= 0 ? (f = e.top + u + t.collisionHeight - s - i, e.top += u - f) : a > 0 && u <= 0 ? e.top = i : u > a ? e.top = i + s - t.collisionHeight : e.top = i : u > 0 ? e.top += u : a > 0 ? e.top -= a : e.top = r(e.top - o, e.top)
                        }
                    },
                    flip: {
                        left: function(e, t) {
                            var n = t.within,
                                r = n.offset.left + n.scrollLeft,
                                s = n.width,
                                o = n.isWindow ? n.scrollLeft : n.offset.left,
                                u = e.left - t.collisionPosition.marginLeft,
                                a = u - o,
                                f = u + t.collisionWidth - s - o,
                                l = t.my[0] === "left" ? -t.elemWidth : t.my[0] === "right" ? t.elemWidth : 0,
                                c = t.at[0] === "left" ? t.targetWidth : t.at[0] === "right" ? -t.targetWidth : 0,
                                h = -2 * t.offset[0],
                                p, d;
                            if (a < 0) {
                                p = e.left + l + c + h + t.collisionWidth - s - r;
                                if (p < 0 || p < i(a)) e.left += l + c + h
                            } else if (f > 0) {
                                d = e.left - t.collisionPosition.marginLeft + l + c + h - o;
                                if (d > 0 || i(d) < f) e.left += l + c + h
                            }
                        },
                        top: function(e, t) {
                            var n = t.within,
                                r = n.offset.top + n.scrollTop,
                                s = n.height,
                                o = n.isWindow ? n.scrollTop : n.offset.top,
                                u = e.top - t.collisionPosition.marginTop,
                                a = u - o,
                                f = u + t.collisionHeight - s - o,
                                l = t.my[1] === "top",
                                c = l ? -t.elemHeight : t.my[1] === "bottom" ? t.elemHeight : 0,
                                h = t.at[1] === "top" ? t.targetHeight : t.at[1] === "bottom" ? -t.targetHeight : 0,
                                p = -2 * t.offset[1],
                                d, v;
                            a < 0 ? (v = e.top + c + h + p + t.collisionHeight - s - r, e.top + c + h + p > a && (v < 0 || v < i(a)) && (e.top += c + h + p)) : f > 0 && (d = e.top - t.collisionPosition.marginTop + c + h + p - o, e.top + c + h + p > f && (d > 0 || i(d) < f) && (e.top += c + h + p))
                        }
                    },
                    flipfit: {
                        left: function() {
                            e.ui.position.flip.left.apply(this, arguments), e.ui.position.fit.left.apply(this, arguments)
                        },
                        top: function() {
                            e.ui.position.flip.top.apply(this, arguments), e.ui.position.fit.top.apply(this, arguments)
                        }
                    }
                },
                function() {
                    var t, r, i, s, o, u = document.getElementsByTagName("body")[0],
                        a = document.createElement("div");
                    t = document.createElement(u ? "div" : "body"), i = {
                        visibility: "hidden",
                        width: 0,
                        height: 0,
                        border: 0,
                        margin: 0,
                        background: "none"
                    }, u && e.extend(i, {
                        position: "absolute",
                        left: "-1000px",
                        top: "-1000px"
                    });
                    for (o in i) t.style[o] = i[o];
                    t.appendChild(a), r = u || document.documentElement, r.insertBefore(t, r.firstChild), a.style.cssText = "position: absolute; left: 10.7432222px;", s = e(a).offset().left, n = s > 10 && s < 11, t.innerHTML = "", r.removeChild(t)
                }()
        })();
        var a = e.ui.position,
            f = e.widget("ui.accordion", {
                version: "1.11.2",
                options: {
                    active: 0,
                    animate: {},
                    collapsible: !1,
                    event: "click",
                    header: "> li > :first-child,> :not(li):even",
                    heightStyle: "auto",
                    icons: {
                        activeHeader: "ui-icon-triangle-1-s",
                        header: "ui-icon-triangle-1-e"
                    },
                    activate: null,
                    beforeActivate: null
                },
                hideProps: {
                    borderTopWidth: "hide",
                    borderBottomWidth: "hide",
                    paddingTop: "hide",
                    paddingBottom: "hide",
                    height: "hide"
                },
                showProps: {
                    borderTopWidth: "show",
                    borderBottomWidth: "show",
                    paddingTop: "show",
                    paddingBottom: "show",
                    height: "show"
                },
                _create: function() {
                    var t = this.options;
                    this.prevShow = this.prevHide = e(), this.element.addClass("ui-accordion ui-widget ui-helper-reset").attr("role", "tablist"), !t.collapsible && (t.active === !1 || t.active == null) && (t.active = 0), this._processPanels(), t.active < 0 && (t.active += this.headers.length), this._refresh()
                },
                _getCreateEventData: function() {
                    return {
                        header: this.active,
                        panel: this.active.length ? this.active.next() : e()
                    }
                },
                _createIcons: function() {
                    var t = this.options.icons;
                    t && (e("<span>").addClass("ui-accordion-header-icon ui-icon " + t.header).prependTo(this.headers), this.active.children(".ui-accordion-header-icon").removeClass(t.header).addClass(t.activeHeader), this.headers.addClass("ui-accordion-icons"))
                },
                _destroyIcons: function() {
                    this.headers.removeClass("ui-accordion-icons").children(".ui-accordion-header-icon").remove()
                },
                _destroy: function() {
                    var e;
                    this.element.removeClass("ui-accordion ui-widget ui-helper-reset").removeAttr("role"), this.headers.removeClass("ui-accordion-header ui-accordion-header-active ui-state-default ui-corner-all ui-state-active ui-state-disabled ui-corner-top").removeAttr("role").removeAttr("aria-expanded").removeAttr("aria-selected").removeAttr("aria-controls").removeAttr("tabIndex").removeUniqueId(), this._destroyIcons(), e = this.headers.next().removeClass("ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content ui-accordion-content-active ui-state-disabled").css("display", "").removeAttr("role").removeAttr("aria-hidden").removeAttr("aria-labelledby").removeUniqueId(), this.options.heightStyle !== "content" && e.css("height", "")
                },
                _setOption: function(e, t) {
                    if (e === "active") {
                        this._activate(t);
                        return
                    }
                    e === "event" && (this.options.event && this._off(this.headers, this.options.event), this._setupEvents(t)), this._super(e, t), e === "collapsible" && !t && this.options.active === !1 && this._activate(0), e === "icons" && (this._destroyIcons(), t && this._createIcons()), e === "disabled" && (this.element.toggleClass("ui-state-disabled", !!t).attr("aria-disabled", t), this.headers.add(this.headers.next()).toggleClass("ui-state-disabled", !!t))
                },
                _keydown: function(t) {
                    if (t.altKey || t.ctrlKey) return;
                    var n = e.ui.keyCode,
                        r = this.headers.length,
                        i = this.headers.index(t.target),
                        s = !1;
                    switch (t.keyCode) {
                        case n.RIGHT:
                        case n.DOWN:
                            s = this.headers[(i + 1) % r];
                            break;
                        case n.LEFT:
                        case n.UP:
                            s = this.headers[(i - 1 + r) % r];
                            break;
                        case n.SPACE:
                        case n.ENTER:
                            this._eventHandler(t);
                            break;
                        case n.HOME:
                            s = this.headers[0];
                            break;
                        case n.END:
                            s = this.headers[r - 1]
                    }
                    s && (e(t.target).attr("tabIndex", -1), e(s).attr("tabIndex", 0), s.focus(), t.preventDefault())
                },
                _panelKeyDown: function(t) {
                    t.keyCode === e.ui.keyCode.UP && t.ctrlKey && e(t.currentTarget).prev().focus()
                },
                refresh: function() {
                    var t = this.options;
                    this._processPanels(), t.active === !1 && t.collapsible === !0 || !this.headers.length ? (t.active = !1, this.active = e()) : t.active === !1 ? this._activate(0) : this.active.length && !e.contains(this.element[0], this.active[0]) ? this.headers.length === this.headers.find(".ui-state-disabled").length ? (t.active = !1, this.active = e()) : this._activate(Math.max(0, t.active - 1)) : t.active = this.headers.index(this.active), this._destroyIcons(), this._refresh()
                },
                _processPanels: function() {
                    var e = this.headers,
                        t = this.panels;
                    this.headers = this.element.find(this.options.header).addClass("ui-accordion-header ui-state-default ui-corner-all"), this.panels = this.headers.next().addClass("ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom").filter(":not(.ui-accordion-content-active)").hide(), t && (this._off(e.not(this.headers)), this._off(t.not(this.panels)))
                },
                _refresh: function() {
                    var t, n = this.options,
                        r = n.heightStyle,
                        i = this.element.parent();
                    this.active = this._findActive(n.active).addClass("ui-accordion-header-active ui-state-active ui-corner-top").removeClass("ui-corner-all"), this.active.next().addClass("ui-accordion-content-active").show(), this.headers.attr("role", "tab").each(function() {
                        var t = e(this),
                            n = t.uniqueId().attr("id"),
                            r = t.next(),
                            i = r.uniqueId().attr("id");
                        t.attr("aria-controls", i), r.attr("aria-labelledby", n)
                    }).next().attr("role", "tabpanel"), this.headers.not(this.active).attr({
                        "aria-selected": "false",
                        "aria-expanded": "false",
                        tabIndex: -1
                    }).next().attr({
                        "aria-hidden": "true"
                    }).hide(), this.active.length ? this.active.attr({
                        "aria-selected": "true",
                        "aria-expanded": "true",
                        tabIndex: 0
                    }).next().attr({
                        "aria-hidden": "false"
                    }) : this.headers.eq(0).attr("tabIndex", 0), this._createIcons(), this._setupEvents(n.event), r === "fill" ? (t = i.height(), this.element.siblings(":visible").each(function() {
                        var n = e(this),
                            r = n.css("position");
                        if (r === "absolute" || r === "fixed") return;
                        t -= n.outerHeight(!0)
                    }), this.headers.each(function() {
                        t -= e(this).outerHeight(!0)
                    }), this.headers.next().each(function() {
                        e(this).height(Math.max(0, t - e(this).innerHeight() + e(this).height()))
                    }).css("overflow", "auto")) : r === "auto" && (t = 0, this.headers.next().each(function() {
                        t = Math.max(t, e(this).css("height", "").height())
                    }).height(t))
                },
                _activate: function(t) {
                    var n = this._findActive(t)[0];
                    if (n === this.active[0]) return;
                    n = n || this.active[0], this._eventHandler({
                        target: n,
                        currentTarget: n,
                        preventDefault: e.noop
                    })
                },
                _findActive: function(t) {
                    return typeof t == "number" ? this.headers.eq(t) : e()
                },
                _setupEvents: function(t) {
                    var n = {
                        keydown: "_keydown"
                    };
                    t && e.each(t.split(" "), function(e, t) {
                        n[t] = "_eventHandler"
                    }), this._off(this.headers.add(this.headers.next())), this._on(this.headers, n), this._on(this.headers.next(), {
                        keydown: "_panelKeyDown"
                    }), this._hoverable(this.headers), this._focusable(this.headers)
                },
                _eventHandler: function(t) {
                    var n = this.options,
                        r = this.active,
                        i = e(t.currentTarget),
                        s = i[0] === r[0],
                        o = s && n.collapsible,
                        u = o ? e() : i.next(),
                        a = r.next(),
                        f = {
                            oldHeader: r,
                            oldPanel: a,
                            newHeader: o ? e() : i,
                            newPanel: u
                        };
                    t.preventDefault();
                    if (s && !n.collapsible || this._trigger("beforeActivate", t, f) === !1) return;
                    n.active = o ? !1 : this.headers.index(i), this.active = s ? e() : i, this._toggle(f), r.removeClass("ui-accordion-header-active ui-state-active"), n.icons && r.children(".ui-accordion-header-icon").removeClass(n.icons.activeHeader).addClass(n.icons.header), s || (i.removeClass("ui-corner-all").addClass("ui-accordion-header-active ui-state-active ui-corner-top"), n.icons && i.children(".ui-accordion-header-icon").removeClass(n.icons.header).addClass(n.icons.activeHeader), i.next().addClass("ui-accordion-content-active"))
                },
                _toggle: function(t) {
                    var n = t.newPanel,
                        r = this.prevShow.length ? this.prevShow : t.oldPanel;
                    this.prevShow.add(this.prevHide).stop(!0, !0), this.prevShow = n, this.prevHide = r, this.options.animate ? this._animate(n, r, t) : (r.hide(), n.show(), this._toggleComplete(t)), r.attr({
                        "aria-hidden": "true"
                    }), r.prev().attr("aria-selected", "false"), n.length && r.length ? r.prev().attr({
                        tabIndex: -1,
                        "aria-expanded": "false"
                    }) : n.length && this.headers.filter(function() {
                        return e(this).attr("tabIndex") === 0
                    }).attr("tabIndex", -1), n.attr("aria-hidden", "false").prev().attr({
                        "aria-selected": "true",
                        tabIndex: 0,
                        "aria-expanded": "true"
                    })
                },
                _animate: function(e, t, n) {
                    var r, i, s, o = this,
                        u = 0,
                        a = e.length && (!t.length || e.index() < t.index()),
                        f = this.options.animate || {},
                        l = a && f.down || f,
                        c = function() {
                            o._toggleComplete(n)
                        };
                    typeof l == "number" && (s = l), typeof l == "string" && (i = l), i = i || l.easing || f.easing, s = s || l.duration || f.duration;
                    if (!t.length) return e.animate(this.showProps, s, i, c);
                    if (!e.length) return t.animate(this.hideProps, s, i, c);
                    r = e.show().outerHeight(), t.animate(this.hideProps, {
                        duration: s,
                        easing: i,
                        step: function(e, t) {
                            t.now = Math.round(e)
                        }
                    }), e.hide().animate(this.showProps, {
                        duration: s,
                        easing: i,
                        complete: c,
                        step: function(e, n) {
                            n.now = Math.round(e), n.prop !== "height" ? u += n.now : o.options.heightStyle !== "content" && (n.now = Math.round(r - t.outerHeight() - u), u = 0)
                        }
                    })
                },
                _toggleComplete: function(e) {
                    var t = e.oldPanel;
                    t.removeClass("ui-accordion-content-active").prev().removeClass("ui-corner-top").addClass("ui-corner-all"), t.length && (t.parent()[0].className = t.parent()[0].className), this._trigger("activate", null, e)
                }
            }),
            l = e.widget("ui.menu", {
                version: "1.11.2",
                defaultElement: "<ul>",
                delay: 300,
                options: {
                    icons: {
                        submenu: "ui-icon-carat-1-e"
                    },
                    items: "> *",
                    menus: "ul",
                    position: {
                        my: "left-1 top",
                        at: "right top"
                    },
                    role: "menu",
                    blur: null,
                    focus: null,
                    select: null
                },
                _create: function() {
                    this.activeMenu = this.element, this.mouseHandled = !1, this.element.uniqueId().addClass("ui-menu ui-widget ui-widget-content").toggleClass("ui-menu-icons", !!this.element.find(".ui-icon").length).attr({
                        role: this.options.role,
                        tabIndex: 0
                    }), this.options.disabled && this.element.addClass("ui-state-disabled").attr("aria-disabled", "true"), this._on({
                        "mousedown .ui-menu-item": function(e) {
                            e.preventDefault()
                        },
                        "click .ui-menu-item": function(t) {
                            var n = e(t.target);
                            !this.mouseHandled && n.not(".ui-state-disabled").length && (this.select(t), t.isPropagationStopped() || (this.mouseHandled = !0), n.has(".ui-menu").length ? this.expand(t) : !this.element.is(":focus") && e(this.document[0].activeElement).closest(".ui-menu").length && (this.element.trigger("focus", [!0]), this.active && this.active.parents(".ui-menu").length === 1 && clearTimeout(this.timer)))
                        },
                        "mouseenter .ui-menu-item": function(t) {
                            if (this.previousFilter) return;
                            var n = e(t.currentTarget);
                            n.siblings(".ui-state-active").removeClass("ui-state-active"), this.focus(t, n)
                        },
                        mouseleave: "collapseAll",
                        "mouseleave .ui-menu": "collapseAll",
                        focus: function(e, t) {
                            var n = this.active || this.element.find(this.options.items).eq(0);
                            t || this.focus(e, n)
                        },
                        blur: function(t) {
                            this._delay(function() {
                                e.contains(this.element[0], this.document[0].activeElement) || this.collapseAll(t)
                            })
                        },
                        keydown: "_keydown"
                    }), this.refresh(), this._on(this.document, {
                        click: function(e) {
                            this._closeOnDocumentClick(e) && this.collapseAll(e), this.mouseHandled = !1
                        }
                    })
                },
                _destroy: function() {
                    this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeClass("ui-menu ui-widget ui-widget-content ui-menu-icons ui-front").removeAttr("role").removeAttr("tabIndex").removeAttr("aria-labelledby").removeAttr("aria-expanded").removeAttr("aria-hidden").removeAttr("aria-disabled").removeUniqueId().show(), this.element.find(".ui-menu-item").removeClass("ui-menu-item").removeAttr("role").removeAttr("aria-disabled").removeUniqueId().removeClass("ui-state-hover").removeAttr("tabIndex").removeAttr("role").removeAttr("aria-haspopup").children().each(function() {
                        var t = e(this);
                        t.data("ui-menu-submenu-carat") && t.remove()
                    }), this.element.find(".ui-menu-divider").removeClass("ui-menu-divider ui-widget-content")
                },
                _keydown: function(t) {
                    var n, r, i, s, o = !0;
                    switch (t.keyCode) {
                        case e.ui.keyCode.PAGE_UP:
                            this.previousPage(t);
                            break;
                        case e.ui.keyCode.PAGE_DOWN:
                            this.nextPage(t);
                            break;
                        case e.ui.keyCode.HOME:
                            this._move("first", "first", t);
                            break;
                        case e.ui.keyCode.END:
                            this._move("last", "last", t);
                            break;
                        case e.ui.keyCode.UP:
                            this.previous(t);
                            break;
                        case e.ui.keyCode.DOWN:
                            this.next(t);
                            break;
                        case e.ui.keyCode.LEFT:
                            this.collapse(t);
                            break;
                        case e.ui.keyCode.RIGHT:
                            this.active && !this.active.is(".ui-state-disabled") && this.expand(t);
                            break;
                        case e.ui.keyCode.ENTER:
                        case e.ui.keyCode.SPACE:
                            this._activate(t);
                            break;
                        case e.ui.keyCode.ESCAPE:
                            this.collapse(t);
                            break;
                        default:
                            o = !1, r = this.previousFilter || "", i = String.fromCharCode(t.keyCode), s = !1, clearTimeout(this.filterTimer), i === r ? s = !0 : i = r + i, n = this._filterMenuItems(i), n = s && n.index(this.active.next()) !== -1 ? this.active.nextAll(".ui-menu-item") : n, n.length || (i = String.fromCharCode(t.keyCode), n = this._filterMenuItems(i)), n.length ? (this.focus(t, n), this.previousFilter = i, this.filterTimer = this._delay(function() {
                                delete this.previousFilter
                            }, 1e3)) : delete this.previousFilter
                    }
                    o && t.preventDefault()
                },
                _activate: function(e) {
                    this.active.is(".ui-state-disabled") || (this.active.is("[aria-haspopup='true']") ? this.expand(e) : this.select(e))
                },
                refresh: function() {
                    var t, n, r = this,
                        i = this.options.icons.submenu,
                        s = this.element.find(this.options.menus);
                    this.element.toggleClass("ui-menu-icons", !!this.element.find(".ui-icon").length), s.filter(":not(.ui-menu)").addClass("ui-menu ui-widget ui-widget-content ui-front").hide().attr({
                        role: this.options.role,
                        "aria-hidden": "true",
                        "aria-expanded": "false"
                    }).each(function() {
                        var t = e(this),
                            n = t.parent(),
                            r = e("<span>").addClass("ui-menu-icon ui-icon " + i).data("ui-menu-submenu-carat", !0);
                        n.attr("aria-haspopup", "true").prepend(r), t.attr("aria-labelledby", n.attr("id"))
                    }), t = s.add(this.element), n = t.find(this.options.items), n.not(".ui-menu-item").each(function() {
                        var t = e(this);
                        r._isDivider(t) && t.addClass("ui-widget-content ui-menu-divider")
                    }), n.not(".ui-menu-item, .ui-menu-divider").addClass("ui-menu-item").uniqueId().attr({
                        tabIndex: -1,
                        role: this._itemRole()
                    }), n.filter(".ui-state-disabled").attr("aria-disabled", "true"), this.active && !e.contains(this.element[0], this.active[0]) && this.blur()
                },
                _itemRole: function() {
                    return {
                        menu: "menuitem",
                        listbox: "option"
                    } [this.options.role]
                },
                _setOption: function(e, t) {
                    e === "icons" && this.element.find(".ui-menu-icon").removeClass(this.options.icons.submenu).addClass(t.submenu), e === "disabled" && this.element.toggleClass("ui-state-disabled", !!t).attr("aria-disabled", t), this._super(e, t)
                },
                focus: function(e, t) {
                    var n, r;
                    this.blur(e, e && e.type === "focus"), this._scrollIntoView(t), this.active = t.first(), r = this.active.addClass("ui-state-focus").removeClass("ui-state-active"), this.options.role && this.element.attr("aria-activedescendant", r.attr("id")), this.active.parent().closest(".ui-menu-item").addClass("ui-state-active"), e && e.type === "keydown" ? this._close() : this.timer = this._delay(function() {
                        this._close()
                    }, this.delay), n = t.children(".ui-menu"), n.length && e && /^mouse/.test(e.type) && this._startOpening(n), this.activeMenu = t.parent(), this._trigger("focus", e, {
                        item: t
                    })
                },
                _scrollIntoView: function(t) {
                    var n, r, i, s, o, u;
                    this._hasScroll() && (n = parseFloat(e.css(this.activeMenu[0], "borderTopWidth")) || 0, r = parseFloat(e.css(this.activeMenu[0], "paddingTop")) || 0, i = t.offset().top - this.activeMenu.offset().top - n - r, s = this.activeMenu.scrollTop(), o = this.activeMenu.height(), u = t.outerHeight(), i < 0 ? this.activeMenu.scrollTop(s + i) : i + u > o && this.activeMenu.scrollTop(s + i - o + u))
                },
                blur: function(e, t) {
                    t || clearTimeout(this.timer);
                    if (!this.active) return;
                    this.active.removeClass("ui-state-focus"), this.active = null, this._trigger("blur", e, {
                        item: this.active
                    })
                },
                _startOpening: function(e) {
                    clearTimeout(this.timer);
                    if (e.attr("aria-hidden") !== "true") return;
                    this.timer = this._delay(function() {
                        this._close(), this._open(e)
                    }, this.delay)
                },
                _open: function(t) {
                    var n = e.extend({
                        of: this.active
                    }, this.options.position);
                    clearTimeout(this.timer), this.element.find(".ui-menu").not(t.parents(".ui-menu")).hide().attr("aria-hidden", "true"), t.show().removeAttr("aria-hidden").attr("aria-expanded", "true").position(n)
                },
                collapseAll: function(t, n) {
                    clearTimeout(this.timer), this.timer = this._delay(function() {
                        var r = n ? this.element : e(t && t.target).closest(this.element.find(".ui-menu"));
                        r.length || (r = this.element), this._close(r), this.blur(t), this.activeMenu = r
                    }, this.delay)
                },
                _close: function(e) {
                    e || (e = this.active ? this.active.parent() : this.element), e.find(".ui-menu").hide().attr("aria-hidden", "true").attr("aria-expanded", "false").end().find(".ui-state-active").not(".ui-state-focus").removeClass("ui-state-active")
                },
                _closeOnDocumentClick: function(t) {
                    return !e(t.target).closest(".ui-menu").length
                },
                _isDivider: function(e) {
                    return !/[^\-\u2014\u2013\s]/.test(e.text())
                },
                collapse: function(e) {
                    var t = this.active && this.active.parent().closest(".ui-menu-item", this.element);
                    t && t.length && (this._close(), this.focus(e, t))
                },
                expand: function(e) {
                    var t = this.active && this.active.children(".ui-menu ").find(this.options.items).first();
                    t && t.length && (this._open(t.parent()), this._delay(function() {
                        this.focus(e, t)
                    }))
                },
                next: function(e) {
                    this._move("next", "first", e)
                },
                previous: function(e) {
                    this._move("prev", "last", e)
                },
                isFirstItem: function() {
                    return this.active && !this.active.prevAll(".ui-menu-item").length
                },
                isLastItem: function() {
                    return this.active && !this.active.nextAll(".ui-menu-item").length
                },
                _move: function(e, t, n) {
                    var r;
                    this.active && (e === "first" || e === "last" ? r = this.active[e === "first" ? "prevAll" : "nextAll"](".ui-menu-item").eq(-1) : r = this.active[e + "All"](".ui-menu-item").eq(0));
                    if (!r || !r.length || !this.active) r = this.activeMenu.find(this.options.items)[t]();
                    this.focus(n, r)
                },
                nextPage: function(t) {
                    var n, r, i;
                    if (!this.active) {
                        this.next(t);
                        return
                    }
                    if (this.isLastItem()) return;
                    this._hasScroll() ? (r = this.active.offset().top, i = this.element.height(), this.active.nextAll(".ui-menu-item").each(function() {
                        return n = e(this), n.offset().top - r - i < 0
                    }), this.focus(t, n)) : this.focus(t, this.activeMenu.find(this.options.items)[this.active ? "last" : "first"]())
                },
                previousPage: function(t) {
                    var n, r, i;
                    if (!this.active) {
                        this.next(t);
                        return
                    }
                    if (this.isFirstItem()) return;
                    this._hasScroll() ? (r = this.active.offset().top, i = this.element.height(), this.active.prevAll(".ui-menu-item").each(function() {
                        return n = e(this), n.offset().top - r + i > 0
                    }), this.focus(t, n)) : this.focus(t, this.activeMenu.find(this.options.items).first())
                },
                _hasScroll: function() {
                    return this.element.outerHeight() < this.element.prop("scrollHeight")
                },
                select: function(t) {
                    this.active = this.active || e(t.target).closest(".ui-menu-item");
                    var n = {
                        item: this.active
                    };
                    this.active.has(".ui-menu").length || this.collapseAll(t, !0), this._trigger("select", t, n)
                },
                _filterMenuItems: function(t) {
                    var n = t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&"),
                        r = new RegExp("^" + n, "i");
                    return this.activeMenu.find(this.options.items).filter(".ui-menu-item").filter(function() {
                        return r.test(e.trim(e(this).text()))
                    })
                }
            });
        e.widget("ui.autocomplete", {
            version: "1.11.2",
            defaultElement: "<input>",
            options: {
                appendTo: null,
                autoFocus: !1,
                delay: 300,
                minLength: 1,
                position: {
                    my: "left top",
                    at: "left bottom",
                    collision: "none"
                },
                source: null,
                change: null,
                close: null,
                focus: null,
                open: null,
                response: null,
                search: null,
                select: null
            },
            requestIndex: 0,
            pending: 0,
            _create: function() {
                var t, n, r, i = this.element[0].nodeName.toLowerCase(),
                    s = i === "textarea",
                    o = i === "input";
                this.isMultiLine = s ? !0 : o ? !1 : this.element.prop("isContentEditable"), this.valueMethod = this.element[s || o ? "val" : "text"], this.isNewMenu = !0, this.element.addClass("ui-autocomplete-input").attr("autocomplete", "off"), this._on(this.element, {
                    keydown: function(i) {
                        if (this.element.prop("readOnly")) {
                            t = !0, r = !0, n = !0;
                            return
                        }
                        t = !1, r = !1, n = !1;
                        var s = e.ui.keyCode;
                        switch (i.keyCode) {
                            case s.PAGE_UP:
                                t = !0, this._move("previousPage", i);
                                break;
                            case s.PAGE_DOWN:
                                t = !0, this._move("nextPage", i);
                                break;
                            case s.UP:
                                t = !0, this._keyEvent("previous", i);
                                break;
                            case s.DOWN:
                                t = !0, this._keyEvent("next", i);
                                break;
                            case s.ENTER:
                                this.menu.active && (t = !0, i.preventDefault(), this.menu.select(i));
                                break;
                            case s.TAB:
                                this.menu.active && this.menu.select(i);
                                break;
                            case s.ESCAPE:
                                this.menu.element.is(":visible") && (this.isMultiLine || this._value(this.term), this.close(i), i.preventDefault());
                                break;
                            default:
                                n = !0, this._searchTimeout(i)
                        }
                    },
                    keypress: function(r) {
                        if (t) {
                            t = !1, (!this.isMultiLine || this.menu.element.is(":visible")) && r.preventDefault();
                            return
                        }
                        if (n) return;
                        var i = e.ui.keyCode;
                        switch (r.keyCode) {
                            case i.PAGE_UP:
                                this._move("previousPage", r);
                                break;
                            case i.PAGE_DOWN:
                                this._move("nextPage", r);
                                break;
                            case i.UP:
                                this._keyEvent("previous", r);
                                break;
                            case i.DOWN:
                                this._keyEvent("next", r)
                        }
                    },
                    input: function(e) {
                        if (r) {
                            r = !1, e.preventDefault();
                            return
                        }
                        this._searchTimeout(e)
                    },
                    focus: function() {
                        this.selectedItem = null, this.previous = this._value()
                    },
                    blur: function(e) {
                        if (this.cancelBlur) {
                            delete this.cancelBlur;
                            return
                        }
                        clearTimeout(this.searching), this.close(e), this._change(e)
                    }
                }), this._initSource(), this.menu = e("<ul>").addClass("ui-autocomplete ui-front").appendTo(this._appendTo()).menu({
                    role: null
                }).hide().menu("instance"), this._on(this.menu.element, {
                    mousedown: function(t) {
                        t.preventDefault(), this.cancelBlur = !0, this._delay(function() {
                            delete this.cancelBlur
                        });
                        var n = this.menu.element[0];
                        e(t.target).closest(".ui-menu-item").length || this._delay(function() {
                            var t = this;
                            this.document.one("mousedown", function(r) {
                                r.target !== t.element[0] && r.target !== n && !e.contains(n, r.target) && t.close()
                            })
                        })
                    },
                    menufocus: function(t, n) {
                        var r, i;
                        if (this.isNewMenu) {
                            this.isNewMenu = !1;
                            if (t.originalEvent && /^mouse/.test(t.originalEvent.type)) {
                                this.menu.blur(), this.document.one("mousemove", function() {
                                    e(t.target).trigger(t.originalEvent)
                                });
                                return
                            }
                        }
                        i = n.item.data("ui-autocomplete-item"), !1 !== this._trigger("focus", t, {
                            item: i
                        }) && t.originalEvent && /^key/.test(t.originalEvent.type) && this._value(i.value), r = n.item.attr("aria-label") || i.value, r && e.trim(r).length && (this.liveRegion.children().hide(), e("<div>").text(r).appendTo(this.liveRegion))
                    },
                    menuselect: function(e, t) {
                        var n = t.item.data("ui-autocomplete-item"),
                            r = this.previous;
                        this.element[0] !== this.document[0].activeElement && (this.element.focus(), this.previous = r, this._delay(function() {
                            this.previous = r, this.selectedItem = n
                        })), !1 !== this._trigger("select", e, {
                            item: n
                        }) && this._value(n.value), this.term = this._value(), this.close(e), this.selectedItem = n
                    }
                }), this.liveRegion = e("<span>", {
                    role: "status",
                    "aria-live": "assertive",
                    "aria-relevant": "additions"
                }).addClass("ui-helper-hidden-accessible").appendTo(this.document[0].body), this._on(this.window, {
                    beforeunload: function() {
                        this.element.removeAttr("autocomplete")
                    }
                })
            },
            _destroy: function() {
                clearTimeout(this.searching), this.element.removeClass("ui-autocomplete-input").removeAttr("autocomplete"), this.menu.element.remove(), this.liveRegion.remove()
            },
            _setOption: function(e, t) {
                this._super(e, t), e === "source" && this._initSource(), e === "appendTo" && this.menu.element.appendTo(this._appendTo()), e === "disabled" && t && this.xhr && this.xhr.abort()
            },
            _appendTo: function() {
                var t = this.options.appendTo;
                t && (t = t.jquery || t.nodeType ? e(t) : this.document.find(t).eq(0));
                if (!t || !t[0]) t = this.element.closest(".ui-front");
                return t.length || (t = this.document[0].body), t
            },
            _initSource: function() {
                var t, n, r = this;
                e.isArray(this.options.source) ? (t = this.options.source, this.source = function(n, r) {
                    r(e.ui.autocomplete.filter(t, n.term))
                }) : typeof this.options.source == "string" ? (n = this.options.source, this.source = function(t, i) {
                    r.xhr && r.xhr.abort(), r.xhr = e.ajax({
                        url: n,
                        data: t,
                        dataType: "json",
                        success: function(e) {
                            i(e)
                        },
                        error: function() {
                            i([])
                        }
                    })
                }) : this.source = this.options.source
            },
            _searchTimeout: function(e) {
                clearTimeout(this.searching), this.searching = this._delay(function() {
                    var t = this.term === this._value(),
                        n = this.menu.element.is(":visible"),
                        r = e.altKey || e.ctrlKey || e.metaKey || e.shiftKey;
                    if (!t || t && !n && !r) this.selectedItem = null, this.search(null, e)
                }, this.options.delay)
            },
            search: function(e, t) {
                e = e != null ? e : this._value(), this.term = this._value();
                if (e.length < this.options.minLength) return this.close(t);
                if (this._trigger("search", t) === !1) return;
                return this._search(e)
            },
            _search: function(e) {
                this.pending++, this.element.addClass("ui-autocomplete-loading"), this.cancelSearch = !1, this.source({
                    term: e
                }, this._response())
            },
            _response: function() {
                var t = ++this.requestIndex;
                return e.proxy(function(e) {
                    t === this.requestIndex && this.__response(e), this.pending--, this.pending || this.element.removeClass("ui-autocomplete-loading")
                }, this)
            },
            __response: function(e) {
                e && (e = this._normalize(e)), this._trigger("response", null, {
                    content: e
                }), !this.options.disabled && e && e.length && !this.cancelSearch ? (this._suggest(e), this._trigger("open")) : this._close()
            },
            close: function(e) {
                this.cancelSearch = !0, this._close(e)
            },
            _close: function(e) {
                this.menu.element.is(":visible") && (this.menu.element.hide(), this.menu.blur(), this.isNewMenu = !0, this._trigger("close", e))
            },
            _change: function(e) {
                this.previous !== this._value() && this._trigger("change", e, {
                    item: this.selectedItem
                })
            },
            _normalize: function(t) {
                return t.length && t[0].label && t[0].value ? t : e.map(t, function(t) {
                    return typeof t == "string" ? {
                        label: t,
                        value: t
                    } : e.extend({}, t, {
                        label: t.label || t.value,
                        value: t.value || t.label
                    })
                })
            },
            _suggest: function(t) {
                var n = this.menu.element.empty();
                this._renderMenu(n, t), this.isNewMenu = !0, this.menu.refresh(), n.show(), this._resizeMenu(), n.position(e.extend({
                    of: this.element
                }, this.options.position)), this.options.autoFocus && this.menu.next()
            },
            _resizeMenu: function() {
                var e = this.menu.element;
                e.outerWidth(Math.max(e.width("").outerWidth() + 1, this.element.outerWidth()))
            },
            _renderMenu: function(t, n) {
                var r = this;
                e.each(n, function(e, n) {
                    r._renderItemData(t, n)
                })
            },
            _renderItemData: function(e, t) {
                return this._renderItem(e, t).data("ui-autocomplete-item", t)
            },
            _renderItem: function(t, n) {
                return e("<li>").text(n.label).appendTo(t)
            },
            _move: function(e, t) {
                if (!this.menu.element.is(":visible")) {
                    this.search(null, t);
                    return
                }
                if (this.menu.isFirstItem() && /^previous/.test(e) || this.menu.isLastItem() && /^next/.test(e)) {
                    this.isMultiLine || this._value(this.term), this.menu.blur();
                    return
                }
                this.menu[e](t)
            },
            widget: function() {
                return this.menu.element
            },
            _value: function() {
                return this.valueMethod.apply(this.element, arguments)
            },
            _keyEvent: function(e, t) {
                if (!this.isMultiLine || this.menu.element.is(":visible")) this._move(e, t), t.preventDefault()
            }
        }), e.extend(e.ui.autocomplete, {
            escapeRegex: function(e) {
                return e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")
            },
            filter: function(t, n) {
                var r = new RegExp(e.ui.autocomplete.escapeRegex(n), "i");
                return e.grep(t, function(e) {
                    return r.test(e.label || e.value || e)
                })
            }
        }), e.widget("ui.autocomplete", e.ui.autocomplete, {
            options: {
                messages: {
                    noResults: "No search results.",
                    results: function(e) {
                        return e + (e > 1 ? " results are" : " result is") + " available, use up and down arrow keys to navigate."
                    }
                }
            },
            __response: function(t) {
                var n;
                this._superApply(arguments);
                if (this.options.disabled || this.cancelSearch) return;
                t && t.length ? n = this.options.messages.results(t.length) : n = this.options.messages.noResults, this.liveRegion.children().hide(), e("<div>").text(n).appendTo(this.liveRegion)
            }
        });
        var c = e.ui.autocomplete,
            h, p = "ui-button ui-widget ui-state-default ui-corner-all",
            d = "ui-button-icons-only ui-button-icon-only ui-button-text-icons ui-button-text-icon-primary ui-button-text-icon-secondary ui-button-text-only",
            v = function() {
                var t = e(this);
                setTimeout(function() {
                    t.find(":ui-button").button("refresh")
                }, 1)
            },
            m = function(t) {
                var n = t.name,
                    r = t.form,
                    i = e([]);
                return n && (n = n.replace(/'/g, "\\'"), r ? i = e(r).find("[name='" + n + "'][type=radio]") : i = e("[name='" + n + "'][type=radio]", t.ownerDocument).filter(function() {
                    return !this.form
                })), i
            };
        e.widget("ui.button", {
            version: "1.11.2",
            defaultElement: "<button>",
            options: {
                disabled: null,
                text: !0,
                label: null,
                icons: {
                    primary: null,
                    secondary: null
                }
            },
            _create: function() {
                this.element.closest("form").unbind("reset" + this.eventNamespace).bind("reset" + this.eventNamespace, v), typeof this.options.disabled != "boolean" ? this.options.disabled = !!this.element.prop("disabled") : this.element.prop("disabled", this.options.disabled), this._determineButtonType(), this.hasTitle = !!this.buttonElement.attr("title");
                var t = this,
                    n = this.options,
                    r = this.type === "checkbox" || this.type === "radio",
                    i = r ? "" : "ui-state-active";
                n.label === null && (n.label = this.type === "input" ? this.buttonElement.val() : this.buttonElement.html()), this._hoverable(this.buttonElement), this.buttonElement.addClass(p).attr("role", "button").bind("mouseenter" + this.eventNamespace, function() {
                    if (n.disabled) return;
                    this === h && e(this).addClass("ui-state-active")
                }).bind("mouseleave" + this.eventNamespace, function() {
                    if (n.disabled) return;
                    e(this).removeClass(i)
                }).bind("click" + this.eventNamespace, function(e) {
                    n.disabled && (e.preventDefault(), e.stopImmediatePropagation())
                }), this._on({
                    focus: function() {
                        this.buttonElement.addClass("ui-state-focus")
                    },
                    blur: function() {
                        this.buttonElement.removeClass("ui-state-focus")
                    }
                }), r && this.element.bind("change" + this.eventNamespace, function() {
                    t.refresh()
                }), this.type === "checkbox" ? this.buttonElement.bind("click" + this.eventNamespace, function() {
                    if (n.disabled) return !1
                }) : this.type === "radio" ? this.buttonElement.bind("click" + this.eventNamespace, function() {
                    if (n.disabled) return !1;
                    e(this).addClass("ui-state-active"), t.buttonElement.attr("aria-pressed", "true");
                    var r = t.element[0];
                    m(r).not(r).map(function() {
                        return e(this).button("widget")[0]
                    }).removeClass("ui-state-active").attr("aria-pressed", "false")
                }) : (this.buttonElement.bind("mousedown" + this.eventNamespace, function() {
                    if (n.disabled) return !1;
                    e(this).addClass("ui-state-active"), h = this, t.document.one("mouseup", function() {
                        h = null
                    })
                }).bind("mouseup" + this.eventNamespace, function() {
                    if (n.disabled) return !1;
                    e(this).removeClass("ui-state-active")
                }).bind("keydown" + this.eventNamespace, function(t) {
                    if (n.disabled) return !1;
                    (t.keyCode === e.ui.keyCode.SPACE || t.keyCode === e.ui.keyCode.ENTER) && e(this).addClass("ui-state-active")
                }).bind("keyup" + this.eventNamespace + " blur" + this.eventNamespace, function() {
                    e(this).removeClass("ui-state-active")
                }), this.buttonElement.is("a") && this.buttonElement.keyup(function(t) {
                    t.keyCode === e.ui.keyCode.SPACE && e(this).click()
                })), this._setOption("disabled", n.disabled), this._resetButton()
            },
            _determineButtonType: function() {
                var e, t, n;
                this.element.is("[type=checkbox]") ? this.type = "checkbox" : this.element.is("[type=radio]") ? this.type = "radio" : this.element.is("input") ? this.type = "input" : this.type = "button", this.type === "checkbox" || this.type === "radio" ? (e = this.element.parents().last(), t = "label[for='" + this.element.attr("id") + "']", this.buttonElement = e.find(t), this.buttonElement.length || (e = e.length ? e.siblings() : this.element.siblings(), this.buttonElement = e.filter(t), this.buttonElement.length || (this.buttonElement = e.find(t))), this.element.addClass("ui-helper-hidden-accessible"), n = this.element.is(":checked"), n && this.buttonElement.addClass("ui-state-active"), this.buttonElement.prop("aria-pressed", n)) : this.buttonElement = this.element
            },
            widget: function() {
                return this.buttonElement
            },
            _destroy: function() {
                this.element.removeClass("ui-helper-hidden-accessible"), this.buttonElement.removeClass(p + " ui-state-active " + d).removeAttr("role").removeAttr("aria-pressed").html(this.buttonElement.find(".ui-button-text").html()), this.hasTitle || this.buttonElement.removeAttr("title")
            },
            _setOption: function(e, t) {
                this._super(e, t);
                if (e === "disabled") {
                    this.widget().toggleClass("ui-state-disabled", !!t), this.element.prop("disabled", !!t), t && (this.type === "checkbox" || this.type === "radio" ? this.buttonElement.removeClass("ui-state-focus") : this.buttonElement.removeClass("ui-state-focus ui-state-active"));
                    return
                }
                this._resetButton()
            },
            refresh: function() {
                var t = this.element.is("input, button") ? this.element.is(":disabled") : this.element.hasClass("ui-button-disabled");
                t !== this.options.disabled && this._setOption("disabled", t), this.type === "radio" ? m(this.element[0]).each(function() {
                    e(this).is(":checked") ? e(this).button("widget").addClass("ui-state-active").attr("aria-pressed", "true") : e(this).button("widget").removeClass("ui-state-active").attr("aria-pressed", "false")
                }) : this.type === "checkbox" && (this.element.is(":checked") ? this.buttonElement.addClass("ui-state-active").attr("aria-pressed", "true") : this.buttonElement.removeClass("ui-state-active").attr("aria-pressed", "false"))
            },
            _resetButton: function() {
                if (this.type === "input") {
                    this.options.label && this.element.val(this.options.label);
                    return
                }
                var t = this.buttonElement.removeClass(d),
                    n = e("<span></span>", this.document[0]).addClass("ui-button-text").html(this.options.label).appendTo(t.empty()).text(),
                    r = this.options.icons,
                    i = r.primary && r.secondary,
                    s = [];
                r.primary || r.secondary ? (this.options.text && s.push("ui-button-text-icon" + (i ? "s" : r.primary ? "-primary" : "-secondary")), r.primary && t.prepend("<span class='ui-button-icon-primary ui-icon " + r.primary + "'></span>"), r.secondary && t.append("<span class='ui-button-icon-secondary ui-icon " + r.secondary + "'></span>"), this.options.text || (s.push(i ? "ui-button-icons-only" : "ui-button-icon-only"), this.hasTitle || t.attr("title", e.trim(n)))) : s.push("ui-button-text-only"), t.addClass(s.join(" "))
            }
        }), e.widget("ui.buttonset", {
            version: "1.11.2",
            options: {
                items: "button, input[type=button], input[type=submit], input[type=reset], input[type=checkbox], input[type=radio], a, :data(ui-button)"
            },
            _create: function() {
                this.element.addClass("ui-buttonset")
            },
            _init: function() {
                this.refresh()
            },
            _setOption: function(e, t) {
                e === "disabled" && this.buttons.button("option", e, t), this._super(e, t)
            },
            refresh: function() {
                var t = this.element.css("direction") === "rtl",
                    n = this.element.find(this.options.items),
                    r = n.filter(":ui-button");
                n.not(":ui-button").button(), r.button("refresh"), this.buttons = n.map(function() {
                    return e(this).button("widget")[0]
                }).removeClass("ui-corner-all ui-corner-left ui-corner-right").filter(":first").addClass(t ? "ui-corner-right" : "ui-corner-left").end().filter(":last").addClass(t ? "ui-corner-left" : "ui-corner-right").end().end()
            },
            _destroy: function() {
                this.element.removeClass("ui-buttonset"), this.buttons.map(function() {
                    return e(this).button("widget")[0]
                }).removeClass("ui-corner-left ui-corner-right").end().button("destroy")
            }
        });
        var g = e.ui.button;
        e.extend(e.ui, {
            datepicker: {
                version: "1.11.2"
            }
        });
        var y;
        e.extend(w.prototype, {
            markerClassName: "hasDatepicker",
            maxRows: 4,
            _widgetDatepicker: function() {
                return this.dpDiv
            },
            setDefaults: function(e) {
                return x(this._defaults, e || {}), this
            },
            _attachDatepicker: function(t, n) {
                var r, i, s;
                r = t.nodeName.toLowerCase(), i = r === "div" || r === "span", t.id || (this.uuid += 1, t.id = "dp" + this.uuid), s = this._newInst(e(t), i), s.settings = e.extend({}, n || {}), r === "input" ? this._connectDatepicker(t, s) : i && this._inlineDatepicker(t, s)
            },
            _newInst: function(t, n) {
                var r = t[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1");
                return {
                    id: r,
                    input: t,
                    selectedDay: 0,
                    selectedMonth: 0,
                    selectedYear: 0,
                    drawMonth: 0,
                    drawYear: 0,
                    inline: n,
                    dpDiv: n ? E(e("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv
                }
            },
            _connectDatepicker: function(t, n) {
                var r = e(t);
                n.append = e([]), n.trigger = e([]);
                if (r.hasClass(this.markerClassName)) return;
                this._attachments(r, n), r.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress).keyup(this._doKeyUp), this._autoSize(n), e.data(t, "datepicker", n), n.settings.disabled && this._disableDatepicker(t)
            },
            _attachments: function(t, n) {
                var r, i, s, o = this._get(n, "appendText"),
                    u = this._get(n, "isRTL");
                n.append && n.append.remove(), o && (n.append = e("<span class='" + this._appendClass + "'>" + o + "</span>"), t[u ? "before" : "after"](n.append)), t.unbind("focus", this._showDatepicker), n.trigger && n.trigger.remove(), r = this._get(n, "showOn"), (r === "focus" || r === "both") && t.focus(this._showDatepicker);
                if (r === "button" || r === "both") i = this._get(n, "buttonText"), s = this._get(n, "buttonImage"), n.trigger = e(this._get(n, "buttonImageOnly") ? e("<img/>").addClass(this._triggerClass).attr({
                    src: s,
                    alt: i,
                    title: i
                }) : e("<button type='button'></button>").addClass(this._triggerClass).html(s ? e("<img/>").attr({
                    src: s,
                    alt: i,
                    title: i
                }) : i)), t[u ? "before" : "after"](n.trigger), n.trigger.click(function() {
                    return e.datepicker._datepickerShowing && e.datepicker._lastInput === t[0] ? e.datepicker._hideDatepicker() : e.datepicker._datepickerShowing && e.datepicker._lastInput !== t[0] ? (e.datepicker._hideDatepicker(), e.datepicker._showDatepicker(t[0])) : e.datepicker._showDatepicker(t[0]), !1
                })
            },
            _autoSize: function(e) {
                if (this._get(e, "autoSize") && !e.inline) {
                    var t, n, r, i, s = new Date(2009, 11, 20),
                        o = this._get(e, "dateFormat");
                    o.match(/[DM]/) && (t = function(e) {
                        n = 0, r = 0;
                        for (i = 0; i < e.length; i++) e[i].length > n && (n = e[i].length, r = i);
                        return r
                    }, s.setMonth(t(this._get(e, o.match(/MM/) ? "monthNames" : "monthNamesShort"))), s.setDate(t(this._get(e, o.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - s.getDay())), e.input.attr("size", this._formatDate(e, s).length)
                }
            },
            _inlineDatepicker: function(t, n) {
                var r = e(t);
                if (r.hasClass(this.markerClassName)) return;
                r.addClass(this.markerClassName).append(n.dpDiv), e.data(t, "datepicker", n), this._setDate(n, this._getDefaultDate(n), !0), this._updateDatepicker(n), this._updateAlternate(n), n.settings.disabled && this._disableDatepicker(t), n.dpDiv.css("display", "block")
            },
            _dialogDatepicker: function(t, n, r, i, s) {
                var o, u, a, f, l, c = this._dialogInst;
                return c || (this.uuid += 1, o = "dp" + this.uuid, this._dialogInput = e("<input type='text' id='" + o + "' style='position: absolute; top: -100px; width: 0px;'/>"), this._dialogInput.keydown(this._doKeyDown), e("body").append(this._dialogInput), c = this._dialogInst = this._newInst(this._dialogInput, !1), c.settings = {}, e.data(this._dialogInput[0], "datepicker", c)), x(c.settings, i || {}), n = n && n.constructor === Date ? this._formatDate(c, n) : n, this._dialogInput.val(n), this._pos = s ? s.length ? s : [s.pageX, s.pageY] : null, this._pos || (u = document.documentElement.clientWidth, a = document.documentElement.clientHeight, f = document.documentElement.scrollLeft || document.body.scrollLeft, l = document.documentElement.scrollTop || document.body.scrollTop, this._pos = [u / 2 - 100 + f, a / 2 - 150 + l]), this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"), c.settings.onSelect = r, this._inDialog = !0, this.dpDiv.addClass(this._dialogClass), this._showDatepicker(this._dialogInput[0]), e.blockUI && e.blockUI(this.dpDiv), e.data(this._dialogInput[0], "datepicker", c), this
            },
            _destroyDatepicker: function(t) {
                var n, r = e(t),
                    i = e.data(t, "datepicker");
                if (!r.hasClass(this.markerClassName)) return;
                n = t.nodeName.toLowerCase(), e.removeData(t, "datepicker"), n === "input" ? (i.append.remove(), i.trigger.remove(), r.removeClass(this.markerClassName).unbind("focus", this._showDatepicker).unbind("keydown", this._doKeyDown).unbind("keypress", this._doKeyPress).unbind("keyup", this._doKeyUp)) : (n === "div" || n === "span") && r.removeClass(this.markerClassName).empty()
            },
            _enableDatepicker: function(t) {
                var n, r, i = e(t),
                    s = e.data(t, "datepicker");
                if (!i.hasClass(this.markerClassName)) return;
                n = t.nodeName.toLowerCase();
                if (n === "input") t.disabled = !1, s.trigger.filter("button").each(function() {
                    this.disabled = !1
                }).end().filter("img").css({
                    opacity: "1.0",
                    cursor: ""
                });
                else if (n === "div" || n === "span") r = i.children("." + this._inlineClass), r.children().removeClass("ui-state-disabled"), r.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !1);
                this._disabledInputs = e.map(this._disabledInputs, function(e) {
                    return e === t ? null : e
                })
            },
            _disableDatepicker: function(t) {
                var n, r, i = e(t),
                    s = e.data(t, "datepicker");
                if (!i.hasClass(this.markerClassName)) return;
                n = t.nodeName.toLowerCase();
                if (n === "input") t.disabled = !0, s.trigger.filter("button").each(function() {
                    this.disabled = !0
                }).end().filter("img").css({
                    opacity: "0.5",
                    cursor: "default"
                });
                else if (n === "div" || n === "span") r = i.children("." + this._inlineClass), r.children().addClass("ui-state-disabled"), r.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !0);
                this._disabledInputs = e.map(this._disabledInputs, function(e) {
                    return e === t ? null : e
                }), this._disabledInputs[this._disabledInputs.length] = t
            },
            _isDisabledDatepicker: function(e) {
                if (!e) return !1;
                for (var t = 0; t < this._disabledInputs.length; t++)
                    if (this._disabledInputs[t] === e) return !0;
                return !1
            },
            _getInst: function(t) {
                try {
                    return e.data(t, "datepicker")
                } catch (n) {
                    throw "Missing instance data for this datepicker"
                }
            },
            _optionDatepicker: function(t, n, r) {
                var i, s, o, u, a = this._getInst(t);
                if (arguments.length === 2 && typeof n == "string") return n === "defaults" ? e.extend({}, e.datepicker._defaults) : a ? n === "all" ? e.extend({}, a.settings) : this._get(a, n) : null;
                i = n || {}, typeof n == "string" && (i = {}, i[n] = r), a && (this._curInst === a && this._hideDatepicker(), s = this._getDateDatepicker(t, !0), o = this._getMinMaxDate(a, "min"), u = this._getMinMaxDate(a, "max"), x(a.settings, i), o !== null && i.dateFormat !== undefined && i.minDate === undefined && (a.settings.minDate = this._formatDate(a, o)), u !== null && i.dateFormat !== undefined && i.maxDate === undefined && (a.settings.maxDate = this._formatDate(a, u)), "disabled" in i && (i.disabled ? this._disableDatepicker(t) : this._enableDatepicker(t)), this._attachments(e(t), a), this._autoSize(a), this._setDate(a, s), this._updateAlternate(a), this._updateDatepicker(a))
            },
            _changeDatepicker: function(e, t, n) {
                this._optionDatepicker(e, t, n)
            },
            _refreshDatepicker: function(e) {
                var t = this._getInst(e);
                t && this._updateDatepicker(t)
            },
            _setDateDatepicker: function(e, t) {
                var n = this._getInst(e);
                n && (this._setDate(n, t), this._updateDatepicker(n), this._updateAlternate(n))
            },
            _getDateDatepicker: function(e, t) {
                var n = this._getInst(e);
                return n && !n.inline && this._setDateFromField(n, t), n ? this._getDate(n) : null
            },
            _doKeyDown: function(t) {
                var n, r, i, s = e.datepicker._getInst(t.target),
                    o = !0,
                    u = s.dpDiv.is(".ui-datepicker-rtl");
                s._keyEvent = !0;
                if (e.datepicker._datepickerShowing) switch (t.keyCode) {
                    case 9:
                        e.datepicker._hideDatepicker(), o = !1;
                        break;
                    case 13:
                        return i = e("td." + e.datepicker._dayOverClass + ":not(." + e.datepicker._currentClass + ")", s.dpDiv), i[0] && e.datepicker._selectDay(t.target, s.selectedMonth, s.selectedYear, i[0]), n = e.datepicker._get(s, "onSelect"), n ? (r = e.datepicker._formatDate(s), n.apply(s.input ? s.input[0] : null, [r, s])) : e.datepicker._hideDatepicker(), !1;
                    case 27:
                        e.datepicker._hideDatepicker();
                        break;
                    case 33:
                        e.datepicker._adjustDate(t.target, t.ctrlKey ? -e.datepicker._get(s, "stepBigMonths") : -e.datepicker._get(s, "stepMonths"), "M");
                        break;
                    case 34:
                        e.datepicker._adjustDate(t.target, t.ctrlKey ? +e.datepicker._get(s, "stepBigMonths") : +e.datepicker._get(s, "stepMonths"), "M");
                        break;
                    case 35:
                        (t.ctrlKey || t.metaKey) && e.datepicker._clearDate(t.target), o = t.ctrlKey || t.metaKey;
                        break;
                    case 36:
                        (t.ctrlKey || t.metaKey) && e.datepicker._gotoToday(t.target), o = t.ctrlKey || t.metaKey;
                        break;
                    case 37:
                        (t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, u ? 1 : -1, "D"), o = t.ctrlKey || t.metaKey, t.originalEvent.altKey && e.datepicker._adjustDate(t.target, t.ctrlKey ? -e.datepicker._get(s, "stepBigMonths") : -e.datepicker._get(s, "stepMonths"), "M");
                        break;
                    case 38:
                        (t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, -7, "D"), o = t.ctrlKey || t.metaKey;
                        break;
                    case 39:
                        (t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, u ? -1 : 1, "D"), o = t.ctrlKey || t.metaKey, t.originalEvent.altKey && e.datepicker._adjustDate(t.target, t.ctrlKey ? +e.datepicker._get(s, "stepBigMonths") : +e.datepicker._get(s, "stepMonths"), "M");
                        break;
                    case 40:
                        (t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, 7, "D"), o = t.ctrlKey || t.metaKey;
                        break;
                    default:
                        o = !1
                } else t.keyCode === 36 && t.ctrlKey ? e.datepicker._showDatepicker(this) : o = !1;
                o && (t.preventDefault(), t.stopPropagation())
            },
            _doKeyPress: function(t) {
                var n, r, i = e.datepicker._getInst(t.target);
                if (e.datepicker._get(i, "constrainInput")) return n = e.datepicker._possibleChars(e.datepicker._get(i, "dateFormat")), r = String.fromCharCode(t.charCode == null ? t.keyCode : t.charCode), t.ctrlKey || t.metaKey || r < " " || !n || n.indexOf(r) > -1
            },
            _doKeyUp: function(t) {
                var n, r = e.datepicker._getInst(t.target);
                if (r.input.val() !== r.lastVal) try {
                    n = e.datepicker.parseDate(e.datepicker._get(r, "dateFormat"), r.input ? r.input.val() : null, e.datepicker._getFormatConfig(r)), n && (e.datepicker._setDateFromField(r), e.datepicker._updateAlternate(r), e.datepicker._updateDatepicker(r))
                } catch (i) {}
                return !0
            },
            _showDatepicker: function(t) {
                t = t.target || t, t.nodeName.toLowerCase() !== "input" && (t = e("input", t.parentNode)[0]);
                if (e.datepicker._isDisabledDatepicker(t) || e.datepicker._lastInput === t) return;
                var n, r, i, s, o, u, a;
                n = e.datepicker._getInst(t), e.datepicker._curInst && e.datepicker._curInst !== n && (e.datepicker._curInst.dpDiv.stop(!0, !0), n && e.datepicker._datepickerShowing && e.datepicker._hideDatepicker(e.datepicker._curInst.input[0])), r = e.datepicker._get(n, "beforeShow"), i = r ? r.apply(t, [t, n]) : {};
                if (i === !1) return;
                x(n.settings, i), n.lastVal = null, e.datepicker._lastInput = t, e.datepicker._setDateFromField(n), e.datepicker._inDialog && (t.value = ""), e.datepicker._pos || (e.datepicker._pos = e.datepicker._findPos(t), e.datepicker._pos[1] += t.offsetHeight), s = !1, e(t).parents().each(function() {
                    return s |= e(this).css("position") === "fixed", !s
                }), o = {
                    left: e.datepicker._pos[0],
                    top: e.datepicker._pos[1]
                }, e.datepicker._pos = null, n.dpDiv.empty(), n.dpDiv.css({
                    position: "absolute",
                    display: "block",
                    top: "-1000px"
                }), e.datepicker._updateDatepicker(n), o = e.datepicker._checkOffset(n, o, s), n.dpDiv.css({
                    position: e.datepicker._inDialog && e.blockUI ? "static" : s ? "fixed" : "absolute",
                    display: "none",
                    left: o.left + "px",
                    top: o.top + "px"
                }), n.inline || (u = e.datepicker._get(n, "showAnim"), a = e.datepicker._get(n, "duration"), n.dpDiv.css("z-index", b(e(t)) + 1), e.datepicker._datepickerShowing = !0, e.effects && e.effects.effect[u] ? n.dpDiv.show(u, e.datepicker._get(n, "showOptions"), a) : n.dpDiv[u || "show"](u ? a : null), e.datepicker._shouldFocusInput(n) && n.input.focus(), e.datepicker._curInst = n)
            },
            _updateDatepicker: function(t) {
                this.maxRows = 4, y = t, t.dpDiv.empty().append(this._generateHTML(t)), this._attachHandlers(t);
                var n, r = this._getNumberOfMonths(t),
                    i = r[1],
                    s = 17,
                    o = t.dpDiv.find("." + this._dayOverClass + " a");
                o.length > 0 && S.apply(o.get(0)), t.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""), i > 1 && t.dpDiv.addClass("ui-datepicker-multi-" + i).css("width", s * i + "em"), t.dpDiv[(r[0] !== 1 || r[1] !== 1 ? "add" : "remove") + "Class"]("ui-datepicker-multi"), t.dpDiv[(this._get(t, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"), t === e.datepicker._curInst && e.datepicker._datepickerShowing && e.datepicker._shouldFocusInput(t) && t.input.focus(), t.yearshtml && (n = t.yearshtml, setTimeout(function() {
                    n === t.yearshtml && t.yearshtml && t.dpDiv.find("select.ui-datepicker-year:first").replaceWith(t.yearshtml), n = t.yearshtml = null
                }, 0))
            },
            _shouldFocusInput: function(e) {
                return e.input && e.input.is(":visible") && !e.input.is(":disabled") && !e.input.is(":focus")
            },
            _checkOffset: function(t, n, r) {
                var i = t.dpDiv.outerWidth(),
                    s = t.dpDiv.outerHeight(),
                    o = t.input ? t.input.outerWidth() : 0,
                    u = t.input ? t.input.outerHeight() : 0,
                    a = document.documentElement.clientWidth + (r ? 0 : e(document).scrollLeft()),
                    f = document.documentElement.clientHeight + (r ? 0 : e(document).scrollTop());
                return n.left -= this._get(t, "isRTL") ? i - o : 0, n.left -= r && n.left === t.input.offset().left ? e(document).scrollLeft() : 0, n.top -= r && n.top === t.input.offset().top + u ? e(document).scrollTop() : 0, n.left -= Math.min(n.left, n.left + i > a && a > i ? Math.abs(n.left + i - a) : 0), n.top -= Math.min(n.top, n.top + s > f && f > s ? Math.abs(s + u) : 0), n
            },
            _findPos: function(t) {
                var n, r = this._getInst(t),
                    i = this._get(r, "isRTL");
                while (t && (t.type === "hidden" || t.nodeType !== 1 || e.expr.filters.hidden(t))) t = t[i ? "previousSibling" : "nextSibling"];
                return n = e(t).offset(), [n.left, n.top]
            },
            _hideDatepicker: function(t) {
                var n, r, i, s, o = this._curInst;
                if (!o || t && o !== e.data(t, "datepicker")) return;
                this._datepickerShowing && (n = this._get(o, "showAnim"), r = this._get(o, "duration"), i = function() {
                    e.datepicker._tidyDialog(o)
                }, e.effects && (e.effects.effect[n] || e.effects[n]) ? o.dpDiv.hide(n, e.datepicker._get(o, "showOptions"), r, i) : o.dpDiv[n === "slideDown" ? "slideUp" : n === "fadeIn" ? "fadeOut" : "hide"](n ? r : null, i), n || i(), this._datepickerShowing = !1, s = this._get(o, "onClose"), s && s.apply(o.input ? o.input[0] : null, [o.input ? o.input.val() : "", o]), this._lastInput = null, this._inDialog && (this._dialogInput.css({
                    position: "absolute",
                    left: "0",
                    top: "-100px"
                }), e.blockUI && (e.unblockUI(), e("body").append(this.dpDiv))), this._inDialog = !1)
            },
            _tidyDialog: function(e) {
                e.dpDiv.removeClass(this._dialogClass).unbind(".ui-datepicker-calendar")
            },
            _checkExternalClick: function(t) {
                if (!e.datepicker._curInst) return;
                var n = e(t.target),
                    r = e.datepicker._getInst(n[0]);
                (n[0].id !== e.datepicker._mainDivId && n.parents("#" + e.datepicker._mainDivId).length === 0 && !n.hasClass(e.datepicker.markerClassName) && !n.closest("." + e.datepicker._triggerClass).length && e.datepicker._datepickerShowing && (!e.datepicker._inDialog || !e.blockUI) || n.hasClass(e.datepicker.markerClassName) && e.datepicker._curInst !== r) && e.datepicker._hideDatepicker()
            },
            _adjustDate: function(t, n, r) {
                var i = e(t),
                    s = this._getInst(i[0]);
                if (this._isDisabledDatepicker(i[0])) return;
                this._adjustInstDate(s, n + (r === "M" ? this._get(s, "showCurrentAtPos") : 0), r), this._updateDatepicker(s)
            },
            _gotoToday: function(t) {
                var n, r = e(t),
                    i = this._getInst(r[0]);
                this._get(i, "gotoCurrent") && i.currentDay ? (i.selectedDay = i.currentDay, i.drawMonth = i.selectedMonth = i.currentMonth, i.drawYear = i.selectedYear = i.currentYear) : (n = new Date, i.selectedDay = n.getDate(), i.drawMonth = i.selectedMonth = n.getMonth(), i.drawYear = i.selectedYear = n.getFullYear()), this._notifyChange(i), this._adjustDate(r)
            },
            _selectMonthYear: function(t, n, r) {
                var i = e(t),
                    s = this._getInst(i[0]);
                s["selected" + (r === "M" ? "Month" : "Year")] = s["draw" + (r === "M" ? "Month" : "Year")] = parseInt(n.options[n.selectedIndex].value, 10), this._notifyChange(s), this._adjustDate(i)
            },
            _selectDay: function(t, n, r, i) {
                var s, o = e(t);
                if (e(i).hasClass(this._unselectableClass) || this._isDisabledDatepicker(o[0])) return;
                s = this._getInst(o[0]), s.selectedDay = s.currentDay = e("a", i).html(), s.selectedMonth = s.currentMonth = n, s.selectedYear = s.currentYear = r, this._selectDate(t, this._formatDate(s, s.currentDay, s.currentMonth, s.currentYear))
            },
            _clearDate: function(t) {
                var n = e(t);
                this._selectDate(n, "")
            },
            _selectDate: function(t, n) {
                var r, i = e(t),
                    s = this._getInst(i[0]);
                n = n != null ? n : this._formatDate(s), s.input && s.input.val(n), this._updateAlternate(s), r = this._get(s, "onSelect"), r ? r.apply(s.input ? s.input[0] : null, [n, s]) : s.input && s.input.trigger("change"), s.inline ? this._updateDatepicker(s) : (this._hideDatepicker(), this._lastInput = s.input[0], typeof s.input[0] != "object" && s.input.focus(), this._lastInput = null)
            },
            _updateAlternate: function(t) {
                var n, r, i, s = this._get(t, "altField");
                s && (n = this._get(t, "altFormat") || this._get(t, "dateFormat"), r = this._getDate(t), i = this.formatDate(n, r, this._getFormatConfig(t)), e(s).each(function() {
                    e(this).val(i)
                }))
            },
            noWeekends: function(e) {
                var t = e.getDay();
                return [t > 0 && t < 6, ""]
            },
            iso8601Week: function(e) {
                var t, n = new Date(e.getTime());
                return n.setDate(n.getDate() + 4 - (n.getDay() || 7)), t = n.getTime(), n.setMonth(0), n.setDate(1), Math.floor(Math.round((t - n) / 864e5) / 7) + 1
            },
            parseDate: function(t, n, r) {
                if (t == null || n == null) throw "Invalid arguments";
                n = typeof n == "object" ? n.toString() : n + "";
                if (n === "") return null;
                var i, s, o, u = 0,
                    a = (r ? r.shortYearCutoff : null) || this._defaults.shortYearCutoff,
                    f = typeof a != "string" ? a : (new Date).getFullYear() % 100 + parseInt(a, 10),
                    l = (r ? r.dayNamesShort : null) || this._defaults.dayNamesShort,
                    c = (r ? r.dayNames : null) || this._defaults.dayNames,
                    h = (r ? r.monthNamesShort : null) || this._defaults.monthNamesShort,
                    p = (r ? r.monthNames : null) || this._defaults.monthNames,
                    d = -1,
                    v = -1,
                    m = -1,
                    g = -1,
                    y = !1,
                    b, w = function(e) {
                        var n = i + 1 < t.length && t.charAt(i + 1) === e;
                        return n && i++, n
                    },
                    E = function(e) {
                        var t = w(e),
                            r = e === "@" ? 14 : e === "!" ? 20 : e === "y" && t ? 4 : e === "o" ? 3 : 2,
                            i = e === "y" ? r : 1,
                            s = new RegExp("^\\d{" + i + "," + r + "}"),
                            o = n.substring(u).match(s);
                        if (!o) throw "Missing number at position " + u;
                        return u += o[0].length, parseInt(o[0], 10)
                    },
                    S = function(t, r, i) {
                        var s = -1,
                            o = e.map(w(t) ? i : r, function(e, t) {
                                return [
                                    [t, e]
                                ]
                            }).sort(function(e, t) {
                                return -(e[1].length - t[1].length)
                            });
                        e.each(o, function(e, t) {
                            var r = t[1];
                            if (n.substr(u, r.length).toLowerCase() === r.toLowerCase()) return s = t[0], u += r.length, !1
                        });
                        if (s !== -1) return s + 1;
                        throw "Unknown name at position " + u
                    },
                    x = function() {
                        if (n.charAt(u) !== t.charAt(i)) throw "Unexpected literal at position " + u;
                        u++
                    };
                for (i = 0; i < t.length; i++)
                    if (y) t.charAt(i) === "'" && !w("'") ? y = !1 : x();
                    else switch (t.charAt(i)) {
                        case "d":
                            m = E("d");
                            break;
                        case "D":
                            S("D", l, c);
                            break;
                        case "o":
                            g = E("o");
                            break;
                        case "m":
                            v = E("m");
                            break;
                        case "M":
                            v = S("M", h, p);
                            break;
                        case "y":
                            d = E("y");
                            break;
                        case "@":
                            b = new Date(E("@")), d = b.getFullYear(), v = b.getMonth() + 1, m = b.getDate();
                            break;
                        case "!":
                            b = new Date((E("!") - this._ticksTo1970) / 1e4), d = b.getFullYear(), v = b.getMonth() + 1, m = b.getDate();
                            break;
                        case "'":
                            w("'") ? x() : y = !0;
                            break;
                        default:
                            x()
                    }
                if (u < n.length) {
                    o = n.substr(u);
                    if (!/^\s+/.test(o)) throw "Extra/unparsed characters found in date: " + o
                }
                d === -1 ? d = (new Date).getFullYear() : d < 100 && (d += (new Date).getFullYear() - (new Date).getFullYear() % 100 + (d <= f ? 0 : -100));
                if (g > -1) {
                    v = 1, m = g;
                    do {
                        s = this._getDaysInMonth(d, v - 1);
                        if (m <= s) break;
                        v++, m -= s
                    } while (!0)
                }
                b = this._daylightSavingAdjust(new Date(d, v - 1, m));
                if (b.getFullYear() !== d || b.getMonth() + 1 !== v || b.getDate() !== m) throw "Invalid date";
                return b
            },
            ATOM: "yy-mm-dd",
            COOKIE: "D, dd M yy",
            ISO_8601: "yy-mm-dd",
            RFC_822: "D, d M y",
            RFC_850: "DD, dd-M-y",
            RFC_1036: "D, d M y",
            RFC_1123: "D, d M yy",
            RFC_2822: "D, d M yy",
            RSS: "D, d M y",
            TICKS: "!",
            TIMESTAMP: "@",
            W3C: "yy-mm-dd",
            _ticksTo1970: (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)) * 24 * 60 * 60 * 1e7,
            formatDate: function(e, t, n) {
                if (!t) return "";
                var r, i = (n ? n.dayNamesShort : null) || this._defaults.dayNamesShort,
                    s = (n ? n.dayNames : null) || this._defaults.dayNames,
                    o = (n ? n.monthNamesShort : null) || this._defaults.monthNamesShort,
                    u = (n ? n.monthNames : null) || this._defaults.monthNames,
                    a = function(t) {
                        var n = r + 1 < e.length && e.charAt(r + 1) === t;
                        return n && r++, n
                    },
                    f = function(e, t, n) {
                        var r = "" + t;
                        if (a(e))
                            while (r.length < n) r = "0" + r;
                        return r
                    },
                    l = function(e, t, n, r) {
                        return a(e) ? r[t] : n[t]
                    },
                    c = "",
                    h = !1;
                if (t)
                    for (r = 0; r < e.length; r++)
                        if (h) e.charAt(r) === "'" && !a("'") ? h = !1 : c += e.charAt(r);
                        else switch (e.charAt(r)) {
                            case "d":
                                c += f("d", t.getDate(), 2);
                                break;
                            case "D":
                                c += l("D", t.getDay(), i, s);
                                break;
                            case "o":
                                c += f("o", Math.round(((new Date(t.getFullYear(), t.getMonth(), t.getDate())).getTime() - (new Date(t.getFullYear(), 0, 0)).getTime()) / 864e5), 3);
                                break;
                            case "m":
                                c += f("m", t.getMonth() + 1, 2);
                                break;
                            case "M":
                                c += l("M", t.getMonth(), o, u);
                                break;
                            case "y":
                                c += a("y") ? t.getFullYear() : (t.getYear() % 100 < 10 ? "0" : "") + t.getYear() % 100;
                                break;
                            case "@":
                                c += t.getTime();
                                break;
                            case "!":
                                c += t.getTime() * 1e4 + this._ticksTo1970;
                                break;
                            case "'":
                                a("'") ? c += "'" : h = !0;
                                break;
                            default:
                                c += e.charAt(r)
                        }
                return c
            },
            _possibleChars: function(e) {
                var t, n = "",
                    r = !1,
                    i = function(n) {
                        var r = t + 1 < e.length && e.charAt(t + 1) === n;
                        return r && t++, r
                    };
                for (t = 0; t < e.length; t++)
                    if (r) e.charAt(t) === "'" && !i("'") ? r = !1 : n += e.charAt(t);
                    else switch (e.charAt(t)) {
                        case "d":
                        case "m":
                        case "y":
                        case "@":
                            n += "0123456789";
                            break;
                        case "D":
                        case "M":
                            return null;
                        case "'":
                            i("'") ? n += "'" : r = !0;
                            break;
                        default:
                            n += e.charAt(t)
                    }
                return n
            },
            _get: function(e, t) {
                return e.settings[t] !== undefined ? e.settings[t] : this._defaults[t]
            },
            _setDateFromField: function(e, t) {
                if (e.input.val() === e.lastVal) return;
                var n = this._get(e, "dateFormat"),
                    r = e.lastVal = e.input ? e.input.val() : null,
                    i = this._getDefaultDate(e),
                    s = i,
                    o = this._getFormatConfig(e);
                try {
                    s = this.parseDate(n, r, o) || i
                } catch (u) {
                    r = t ? "" : r
                }
                e.selectedDay = s.getDate(), e.drawMonth = e.selectedMonth = s.getMonth(), e.drawYear = e.selectedYear = s.getFullYear(), e.currentDay = r ? s.getDate() : 0, e.currentMonth = r ? s.getMonth() : 0, e.currentYear = r ? s.getFullYear() : 0, this._adjustInstDate(e)
            },
            _getDefaultDate: function(e) {
                return this._restrictMinMax(e, this._determineDate(e, this._get(e, "defaultDate"), new Date))
            },
            _determineDate: function(t, n, r) {
                var i = function(e) {
                        var t = new Date;
                        return t.setDate(t.getDate() + e), t
                    },
                    s = function(n) {
                        try {
                            return e.datepicker.parseDate(e.datepicker._get(t, "dateFormat"), n, e.datepicker._getFormatConfig(t))
                        } catch (r) {}
                        var i = (n.toLowerCase().match(/^c/) ? e.datepicker._getDate(t) : null) || new Date,
                            s = i.getFullYear(),
                            o = i.getMonth(),
                            u = i.getDate(),
                            a = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g,
                            f = a.exec(n);
                        while (f) {
                            switch (f[2] || "d") {
                                case "d":
                                case "D":
                                    u += parseInt(f[1], 10);
                                    break;
                                case "w":
                                case "W":
                                    u += parseInt(f[1], 10) * 7;
                                    break;
                                case "m":
                                case "M":
                                    o += parseInt(f[1], 10), u = Math.min(u, e.datepicker._getDaysInMonth(s, o));
                                    break;
                                case "y":
                                case "Y":
                                    s += parseInt(f[1], 10), u = Math.min(u, e.datepicker._getDaysInMonth(s, o))
                            }
                            f = a.exec(n)
                        }
                        return new Date(s, o, u)
                    },
                    o = n == null || n === "" ? r : typeof n == "string" ? s(n) : typeof n == "number" ? isNaN(n) ? r : i(n) : new Date(n.getTime());
                return o = o && o.toString() === "Invalid Date" ? r : o, o && (o.setHours(0), o.setMinutes(0), o.setSeconds(0), o.setMilliseconds(0)), this._daylightSavingAdjust(o)
            },
            _daylightSavingAdjust: function(e) {
                return e ? (e.setHours(e.getHours() > 12 ? e.getHours() + 2 : 0), e) : null
            },
            _setDate: function(e, t, n) {
                var r = !t,
                    i = e.selectedMonth,
                    s = e.selectedYear,
                    o = this._restrictMinMax(e, this._determineDate(e, t, new Date));
                e.selectedDay = e.currentDay = o.getDate(), e.drawMonth = e.selectedMonth = e.currentMonth = o.getMonth(), e.drawYear = e.selectedYear = e.currentYear = o.getFullYear(), (i !== e.selectedMonth || s !== e.selectedYear) && !n && this._notifyChange(e), this._adjustInstDate(e), e.input && e.input.val(r ? "" : this._formatDate(e))
            },
            _getDate: function(e) {
                var t = !e.currentYear || e.input && e.input.val() === "" ? null : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
                return t
            },
            _attachHandlers: function(t) {
                var n = this._get(t, "stepMonths"),
                    r = "#" + t.id.replace(/\\\\/g, "\\");
                t.dpDiv.find("[data-handler]").map(function() {
                    var t = {
                        prev: function() {
                            e.datepicker._adjustDate(r, -n, "M")
                        },
                        next: function() {
                            e.datepicker._adjustDate(r, +n, "M")
                        },
                        hide: function() {
                            e.datepicker._hideDatepicker()
                        },
                        today: function() {
                            e.datepicker._gotoToday(r)
                        },
                        selectDay: function() {
                            return e.datepicker._selectDay(r, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), !1
                        },
                        selectMonth: function() {
                            return e.datepicker._selectMonthYear(r, this, "M"), !1
                        },
                        selectYear: function() {
                            return e.datepicker._selectMonthYear(r, this, "Y"), !1
                        }
                    };
                    e(this).bind(this.getAttribute("data-event"), t[this.getAttribute("data-handler")])
                })
            },
            _generateHTML: function(e) {
                var t, n, r, i, s, o, u, a, f, l, c, h, p, d, v, m, g, y, b, w, E, S, x, T, N, C, k, L, A, O, M, _, D, P, H, B, j, F, I, q = new Date,
                    R = this._daylightSavingAdjust(new Date(q.getFullYear(), q.getMonth(), q.getDate())),
                    U = this._get(e, "isRTL"),
                    z = this._get(e, "showButtonPanel"),
                    W = this._get(e, "hideIfNoPrevNext"),
                    X = this._get(e, "navigationAsDateFormat"),
                    V = this._getNumberOfMonths(e),
                    $ = this._get(e, "showCurrentAtPos"),
                    J = this._get(e, "stepMonths"),
                    K = V[0] !== 1 || V[1] !== 1,
                    Q = this._daylightSavingAdjust(e.currentDay ? new Date(e.currentYear, e.currentMonth, e.currentDay) : new Date(9999, 9, 9)),
                    G = this._getMinMaxDate(e, "min"),
                    Y = this._getMinMaxDate(e, "max"),
                    Z = e.drawMonth - $,
                    et = e.drawYear;
                Z < 0 && (Z += 12, et--);
                if (Y) {
                    t = this._daylightSavingAdjust(new Date(Y.getFullYear(), Y.getMonth() - V[0] * V[1] + 1, Y.getDate())), t = G && t < G ? G : t;
                    while (this._daylightSavingAdjust(new Date(et, Z, 1)) > t) Z--, Z < 0 && (Z = 11, et--)
                }
                e.drawMonth = Z, e.drawYear = et, n = this._get(e, "prevText"), n = X ? this.formatDate(n, this._daylightSavingAdjust(new Date(et, Z - J, 1)), this._getFormatConfig(e)) : n, r = this._canAdjustMonth(e, -1, et, Z) ? "<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + (U ? "e" : "w") + "'>" + n + "</span></a>" : W ? "" : "<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + (U ? "e" : "w") + "'>" + n + "</span></a>", i = this._get(e, "nextText"), i = X ? this.formatDate(i, this._daylightSavingAdjust(new Date(et, Z + J, 1)), this._getFormatConfig(e)) : i, s = this._canAdjustMonth(e, 1, et, Z) ? "<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='" + i + "'><span class='ui-icon ui-icon-circle-triangle-" + (U ? "w" : "e") + "'>" + i + "</span></a>" : W ? "" : "<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='" + i + "'><span class='ui-icon ui-icon-circle-triangle-" + (U ? "w" : "e") + "'>" + i + "</span></a>", o = this._get(e, "currentText"), u = this._get(e, "gotoCurrent") && e.currentDay ? Q : R, o = X ? this.formatDate(o, u, this._getFormatConfig(e)) : o, a = e.inline ? "" : "<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>" + this._get(e, "closeText") + "</button>", f = z ? "<div class='ui-datepicker-buttonpane ui-widget-content'>" + (U ? a : "") + (this._isInRange(e, u) ? "<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>" + o + "</button>" : "") + (U ? "" : a) + "</div>" : "", l = parseInt(this._get(e, "firstDay"), 10), l = isNaN(l) ? 0 : l, c = this._get(e, "showWeek"), h = this._get(e, "dayNames"), p = this._get(e, "dayNamesMin"), d = this._get(e, "monthNames"), v = this._get(e, "monthNamesShort"), m = this._get(e, "beforeShowDay"), g = this._get(e, "showOtherMonths"), y = this._get(e, "selectOtherMonths"), b = this._getDefaultDate(e), w = "", E;
                for (S = 0; S < V[0]; S++) {
                    x = "", this.maxRows = 4;
                    for (T = 0; T < V[1]; T++) {
                        N = this._daylightSavingAdjust(new Date(et, Z, e.selectedDay)), C = " ui-corner-all", k = "";
                        if (K) {
                            k += "<div class='ui-datepicker-group";
                            if (V[1] > 1) switch (T) {
                                case 0:
                                    k += " ui-datepicker-group-first", C = " ui-corner-" + (U ? "right" : "left");
                                    break;
                                case V[1] - 1:
                                    k += " ui-datepicker-group-last", C = " ui-corner-" + (U ? "left" : "right");
                                    break;
                                default:
                                    k += " ui-datepicker-group-middle", C = ""
                            }
                            k += "'>"
                        }
                        k += "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" + C + "'>" + (/all|left/.test(C) && S === 0 ? U ? s : r : "") + (/all|right/.test(C) && S === 0 ? U ? r : s : "") + this._generateMonthYearHeader(e, Z, et, G, Y, S > 0 || T > 0, d, v) + "</div><table class='ui-datepicker-calendar'><thead>" + "<tr>", L = c ? "<th class='ui-datepicker-week-col'>" + this._get(e, "weekHeader") + "</th>" : "";
                        for (E = 0; E < 7; E++) A = (E + l) % 7, L += "<th scope='col'" + ((E + l + 6) % 7 >= 5 ? " class='ui-datepicker-week-end'" : "") + ">" + "<span title='" + h[A] + "'>" + p[A] + "</span></th>";
                        k += L + "</tr></thead><tbody>", O = this._getDaysInMonth(et, Z), et === e.selectedYear && Z === e.selectedMonth && (e.selectedDay = Math.min(e.selectedDay, O)), M = (this._getFirstDayOfMonth(et, Z) - l + 7) % 7, _ = Math.ceil((M + O) / 7), D = K ? this.maxRows > _ ? this.maxRows : _ : _, this.maxRows = D, P = this._daylightSavingAdjust(new Date(et, Z, 1 - M));
                        for (H = 0; H < D; H++) {
                            k += "<tr>", B = c ? "<td class='ui-datepicker-week-col'>" + this._get(e, "calculateWeek")(P) + "</td>" : "";
                            for (E = 0; E < 7; E++) j = m ? m.apply(e.input ? e.input[0] : null, [P]) : [!0, ""], F = P.getMonth() !== Z, I = F && !y || !j[0] || G && P < G || Y && P > Y, B += "<td class='" + ((E + l + 6) % 7 >= 5 ? " ui-datepicker-week-end" : "") + (F ? " ui-datepicker-other-month" : "") + (P.getTime() === N.getTime() && Z === e.selectedMonth && e._keyEvent || b.getTime() === P.getTime() && b.getTime() === N.getTime() ? " " + this._dayOverClass : "") + (I ? " " + this._unselectableClass + " ui-state-disabled" : "") + (F && !g ? "" : " " + j[1] + (P.getTime() === Q.getTime() ? " " + this._currentClass : "") + (P.getTime() === R.getTime() ? " ui-datepicker-today" : "")) + "'" + ((!F || g) && j[2] ? " title='" + j[2].replace(/'/g, "&#39;") + "'" : "") + (I ? "" : " data-handler='selectDay' data-event='click' data-month='" + P.getMonth() + "' data-year='" + P.getFullYear() + "'") + ">" + (F && !g ? "&#xa0;" : I ? "<span class='ui-state-default'>" + P.getDate() + "</span>" : "<a class='ui-state-default" + (P.getTime() === R.getTime() ? " ui-state-highlight" : "") + (P.getTime() === Q.getTime() ? " ui-state-active" : "") + (F ? " ui-priority-secondary" : "") + "' href='#'>" + P.getDate() + "</a>") + "</td>", P.setDate(P.getDate() + 1), P = this._daylightSavingAdjust(P);
                            k += B + "</tr>"
                        }
                        Z++, Z > 11 && (Z = 0, et++), k += "</tbody></table>" + (K ? "</div>" + (V[0] > 0 && T === V[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : ""), x += k
                    }
                    w += x
                }
                return w += f, e._keyEvent = !1, w
            },
            _generateMonthYearHeader: function(e, t, n, r, i, s, o, u) {
                var a, f, l, c, h, p, d, v, m = this._get(e, "changeMonth"),
                    g = this._get(e, "changeYear"),
                    y = this._get(e, "showMonthAfterYear"),
                    b = "<div class='ui-datepicker-title'>",
                    w = "";
                if (s || !m) w += "<span class='ui-datepicker-month'>" + o[t] + "</span>";
                else {
                    a = r && r.getFullYear() === n, f = i && i.getFullYear() === n, w += "<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>";
                    for (l = 0; l < 12; l++)(!a || l >= r.getMonth()) && (!f || l <= i.getMonth()) && (w += "<option value='" + l + "'" + (l === t ? " selected='selected'" : "") + ">" + u[l] + "</option>");
                    w += "</select>"
                }
                y || (b += w + (s || !m || !g ? "&#xa0;" : ""));
                if (!e.yearshtml) {
                    e.yearshtml = "";
                    if (s || !g) b += "<span class='ui-datepicker-year'>" + n + "</span>";
                    else {
                        c = this._get(e, "yearRange").split(":"), h = (new Date).getFullYear(), p = function(e) {
                            var t = e.match(/c[+\-].*/) ? n + parseInt(e.substring(1), 10) : e.match(/[+\-].*/) ? h + parseInt(e, 10) : parseInt(e, 10);
                            return isNaN(t) ? h : t
                        }, d = p(c[0]), v = Math.max(d, p(c[1] || "")), d = r ? Math.max(d, r.getFullYear()) : d, v = i ? Math.min(v, i.getFullYear()) : v, e.yearshtml += "<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>";
                        for (; d <= v; d++) e.yearshtml += "<option value='" + d + "'" + (d === n ? " selected='selected'" : "") + ">" + d + "</option>";
                        e.yearshtml += "</select>", b += e.yearshtml, e.yearshtml = null
                    }
                }
                return b += this._get(e, "yearSuffix"), y && (b += (s || !m || !g ? "&#xa0;" : "") + w), b += "</div>", b
            },
            _adjustInstDate: function(e, t, n) {
                var r = e.drawYear + (n === "Y" ? t : 0),
                    i = e.drawMonth + (n === "M" ? t : 0),
                    s = Math.min(e.selectedDay, this._getDaysInMonth(r, i)) + (n === "D" ? t : 0),
                    o = this._restrictMinMax(e, this._daylightSavingAdjust(new Date(r, i, s)));
                e.selectedDay = o.getDate(), e.drawMonth = e.selectedMonth = o.getMonth(), e.drawYear = e.selectedYear = o.getFullYear(), (n === "M" || n === "Y") && this._notifyChange(e)
            },
            _restrictMinMax: function(e, t) {
                var n = this._getMinMaxDate(e, "min"),
                    r = this._getMinMaxDate(e, "max"),
                    i = n && t < n ? n : t;
                return r && i > r ? r : i
            },
            _notifyChange: function(e) {
                var t = this._get(e, "onChangeMonthYear");
                t && t.apply(e.input ? e.input[0] : null, [e.selectedYear, e.selectedMonth + 1, e])
            },
            _getNumberOfMonths: function(e) {
                var t = this._get(e, "numberOfMonths");
                return t == null ? [1, 1] : typeof t == "number" ? [1, t] : t
            },
            _getMinMaxDate: function(e, t) {
                return this._determineDate(e, this._get(e, t + "Date"), null)
            },
            _getDaysInMonth: function(e, t) {
                return 32 - this._daylightSavingAdjust(new Date(e, t, 32)).getDate()
            },
            _getFirstDayOfMonth: function(e, t) {
                return (new Date(e, t, 1)).getDay()
            },
            _canAdjustMonth: function(e, t, n, r) {
                var i = this._getNumberOfMonths(e),
                    s = this._daylightSavingAdjust(new Date(n, r + (t < 0 ? t : i[0] * i[1]), 1));
                return t < 0 && s.setDate(this._getDaysInMonth(s.getFullYear(), s.getMonth())), this._isInRange(e, s)
            },
            _isInRange: function(e, t) {
                var n, r, i = this._getMinMaxDate(e, "min"),
                    s = this._getMinMaxDate(e, "max"),
                    o = null,
                    u = null,
                    a = this._get(e, "yearRange");
                return a && (n = a.split(":"), r = (new Date).getFullYear(), o = parseInt(n[0], 10), u = parseInt(n[1], 10), n[0].match(/[+\-].*/) && (o += r), n[1].match(/[+\-].*/) && (u += r)), (!i || t.getTime() >= i.getTime()) && (!s || t.getTime() <= s.getTime()) && (!o || t.getFullYear() >= o) && (!u || t.getFullYear() <= u)
            },
            _getFormatConfig: function(e) {
                var t = this._get(e, "shortYearCutoff");
                return t = typeof t != "string" ? t : (new Date).getFullYear() % 100 + parseInt(t, 10), {
                    shortYearCutoff: t,
                    dayNamesShort: this._get(e, "dayNamesShort"),
                    dayNames: this._get(e, "dayNames"),
                    monthNamesShort: this._get(e, "monthNamesShort"),
                    monthNames: this._get(e, "monthNames")
                }
            },
            _formatDate: function(e, t, n, r) {
                t || (e.currentDay = e.selectedDay, e.currentMonth = e.selectedMonth, e.currentYear = e.selectedYear);
                var i = t ? typeof t == "object" ? t : this._daylightSavingAdjust(new Date(r, n, t)) : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
                return this.formatDate(this._get(e, "dateFormat"), i, this._getFormatConfig(e))
            }
        }), e.fn.datepicker = function(t) {
            if (!this.length) return this;
            e.datepicker.initialized || (e(document).mousedown(e.datepicker._checkExternalClick), e.datepicker.initialized = !0), e("#" + e.datepicker._mainDivId).length === 0 && e("body").append(e.datepicker.dpDiv);
            var n = Array.prototype.slice.call(arguments, 1);
            return typeof t != "string" || t !== "isDisabled" && t !== "getDate" && t !== "widget" ? t === "option" && arguments.length === 2 && typeof arguments[1] == "string" ? e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this[0]].concat(n)) : this.each(function() {
                typeof t == "string" ? e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this].concat(n)) : e.datepicker._attachDatepicker(this, t)
            }) : e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this[0]].concat(n))
        }, e.datepicker = new w, e.datepicker.initialized = !1, e.datepicker.uuid = (new Date).getTime(), e.datepicker.version = "1.11.2";
        var T = e.datepicker;
        e.widget("ui.draggable", e.ui.mouse, {
            version: "1.11.2",
            widgetEventPrefix: "drag",
            options: {
                addClasses: !0,
                appendTo: "parent",
                axis: !1,
                connectToSortable: !1,
                containment: !1,
                cursor: "auto",
                cursorAt: !1,
                grid: !1,
                handle: !1,
                helper: "original",
                iframeFix: !1,
                opacity: !1,
                refreshPositions: !1,
                revert: !1,
                revertDuration: 500,
                scope: "default",
                scroll: !0,
                scrollSensitivity: 20,
                scrollSpeed: 20,
                snap: !1,
                snapMode: "both",
                snapTolerance: 20,
                stack: !1,
                zIndex: !1,
                drag: null,
                start: null,
                stop: null
            },
            _create: function() {
                this.options.helper === "original" && this._setPositionRelative(), this.options.addClasses && this.element.addClass("ui-draggable"), this.options.disabled && this.element.addClass("ui-draggable-disabled"), this._setHandleClassName(), this._mouseInit()
            },
            _setOption: function(e, t) {
                this._super(e, t), e === "handle" && (this._removeHandleClassName(), this._setHandleClassName())
            },
            _destroy: function() {
                if ((this.helper || this.element).is(".ui-draggable-dragging")) {
                    this.destroyOnClear = !0;
                    return
                }
                this.element.removeClass("ui-draggable ui-draggable-dragging ui-draggable-disabled"), this._removeHandleClassName(), this._mouseDestroy()
            },
            _mouseCapture: function(t) {
                var n = this.options;
                return this._blurActiveElement(t), this.helper || n.disabled || e(t.target).closest(".ui-resizable-handle").length > 0 ? !1 : (this.handle = this._getHandle(t), this.handle ? (this._blockFrames(n.iframeFix === !0 ? "iframe" : n.iframeFix), !0) : !1)
            },
            _blockFrames: function(t) {
                this.iframeBlocks = this.document.find(t).map(function() {
                    var t = e(this);
                    return e("<div>").css("position", "absolute").appendTo(t.parent()).outerWidth(t.outerWidth()).outerHeight(t.outerHeight()).offset(t.offset())[0]
                })
            },
            _unblockFrames: function() {
                this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks)
            },
            _blurActiveElement: function(t) {
                var n = this.document[0];
                if (!this.handleElement.is(t.target)) return;
                try {
                    n.activeElement && n.activeElement.nodeName.toLowerCase() !== "body" && e(n.activeElement).blur()
                } catch (r) {}
            },
            _mouseStart: function(t) {
                var n = this.options;
                return this.helper = this._createHelper(t), this.helper.addClass("ui-draggable-dragging"), this._cacheHelperProportions(), e.ui.ddmanager && (e.ui.ddmanager.current = this), this._cacheMargins(), this.cssPosition = this.helper.css("position"), this.scrollParent = this.helper.scrollParent(!0), this.offsetParent = this.helper.offsetParent(), this.hasFixedAncestor = this.helper.parents().filter(function() {
                    return e(this).css("position") === "fixed"
                }).length > 0, this.positionAbs = this.element.offset(), this._refreshOffsets(t), this.originalPosition = this.position = this._generatePosition(t, !1), this.originalPageX = t.pageX, this.originalPageY = t.pageY, n.cursorAt && this._adjustOffsetFromHelper(n.cursorAt), this._setContainment(), this._trigger("start", t) === !1 ? (this._clear(), !1) : (this._cacheHelperProportions(), e.ui.ddmanager && !n.dropBehaviour && e.ui.ddmanager.prepareOffsets(this, t), this._normalizeRightBottom(), this._mouseDrag(t, !0), e.ui.ddmanager && e.ui.ddmanager.dragStart(this, t), !0)
            },
            _refreshOffsets: function(e) {
                this.offset = {
                    top: this.positionAbs.top - this.margins.top,
                    left: this.positionAbs.left - this.margins.left,
                    scroll: !1,
                    parent: this._getParentOffset(),
                    relative: this._getRelativeOffset()
                }, this.offset.click = {
                    left: e.pageX - this.offset.left,
                    top: e.pageY - this.offset.top
                }
            },
            _mouseDrag: function(t, n) {
                this.hasFixedAncestor && (this.offset.parent = this._getParentOffset()), this.position = this._generatePosition(t, !0), this.positionAbs = this._convertPositionTo("absolute");
                if (!n) {
                    var r = this._uiHash();
                    if (this._trigger("drag", t, r) === !1) return this._mouseUp({}), !1;
                    this.position = r.position
                }
                return this.helper[0].style.left = this.position.left + "px", this.helper[0].style.top = this.position.top + "px", e.ui.ddmanager && e.ui.ddmanager.drag(this, t), !1
            },
            _mouseStop: function(t) {
                var n = this,
                    r = !1;
                return e.ui.ddmanager && !this.options.dropBehaviour && (r = e.ui.ddmanager.drop(this, t)), this.dropped && (r = this.dropped, this.dropped = !1), this.options.revert === "invalid" && !r || this.options.revert === "valid" && r || this.options.revert === !0 || e.isFunction(this.options.revert) && this.options.revert.call(this.element, r) ? e(this.helper).animate(this.originalPosition, parseInt(this.options.revertDuration, 10), function() {
                    n._trigger("stop", t) !== !1 && n._clear()
                }) : this._trigger("stop", t) !== !1 && this._clear(), !1
            },
            _mouseUp: function(t) {
                return this._unblockFrames(), e.ui.ddmanager && e.ui.ddmanager.dragStop(this, t), this.handleElement.is(t.target) && this.element.focus(), e.ui.mouse.prototype._mouseUp.call(this, t)
            },
            cancel: function() {
                return this.helper.is(".ui-draggable-dragging") ? this._mouseUp({}) : this._clear(), this
            },
            _getHandle: function(t) {
                return this.options.handle ? !!e(t.target).closest(this.element.find(this.options.handle)).length : !0
            },
            _setHandleClassName: function() {
                this.handleElement = this.options.handle ? this.element.find(this.options.handle) : this.element, this.handleElement.addClass("ui-draggable-handle")
            },
            _removeHandleClassName: function() {
                this.handleElement.removeClass("ui-draggable-handle")
            },
            _createHelper: function(t) {
                var n = this.options,
                    r = e.isFunction(n.helper),
                    i = r ? e(n.helper.apply(this.element[0], [t])) : n.helper === "clone" ? this.element.clone().removeAttr("id") : this.element;
                return i.parents("body").length || i.appendTo(n.appendTo === "parent" ? this.element[0].parentNode : n.appendTo), r && i[0] === this.element[0] && this._setPositionRelative(), i[0] !== this.element[0] && !/(fixed|absolute)/.test(i.css("position")) && i.css("position", "absolute"), i
            },
            _setPositionRelative: function() {
                /^(?:r|a|f)/.test(this.element.css("position")) || (this.element[0].style.position = "relative")
            },
            _adjustOffsetFromHelper: function(t) {
                typeof t == "string" && (t = t.split(" ")), e.isArray(t) && (t = {
                    left: +t[0],
                    top: +t[1] || 0
                }), "left" in t && (this.offset.click.left = t.left + this.margins.left), "right" in t && (this.offset.click.left = this.helperProportions.width - t.right + this.margins.left), "top" in t && (this.offset.click.top = t.top + this.margins.top), "bottom" in t && (this.offset.click.top = this.helperProportions.height - t.bottom + this.margins.top)
            },
            _isRootNode: function(e) {
                return /(html|body)/i.test(e.tagName) || e === this.document[0]
            },
            _getParentOffset: function() {
                var t = this.offsetParent.offset(),
                    n = this.document[0];
                return this.cssPosition === "absolute" && this.scrollParent[0] !== n && e.contains(this.scrollParent[0], this.offsetParent[0]) && (t.left += this.scrollParent.scrollLeft(), t.top += this.scrollParent.scrollTop()), this._isRootNode(this.offsetParent[0]) && (t = {
                    top: 0,
                    left: 0
                }), {
                    top: t.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                    left: t.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
                }
            },
            _getRelativeOffset: function() {
                if (this.cssPosition !== "relative") return {
                    top: 0,
                    left: 0
                };
                var e = this.element.position(),
                    t = this._isRootNode(this.scrollParent[0]);
                return {
                    top: e.top - (parseInt(this.helper.css("top"), 10) || 0) + (t ? 0 : this.scrollParent.scrollTop()),
                    left: e.left - (parseInt(this.helper.css("left"), 10) || 0) + (t ? 0 : this.scrollParent.scrollLeft())
                }
            },
            _cacheMargins: function() {
                this.margins = {
                    left: parseInt(this.element.css("marginLeft"), 10) || 0,
                    top: parseInt(this.element.css("marginTop"), 10) || 0,
                    right: parseInt(this.element.css("marginRight"), 10) || 0,
                    bottom: parseInt(this.element.css("marginBottom"), 10) || 0
                }
            },
            _cacheHelperProportions: function() {
                this.helperProportions = {
                    width: this.helper.outerWidth(),
                    height: this.helper.outerHeight()
                }
            },
            _setContainment: function() {
                var t, n, r, i = this.options,
                    s = this.document[0];
                this.relativeContainer = null;
                if (!i.containment) {
                    this.containment = null;
                    return
                }
                if (i.containment === "window") {
                    this.containment = [e(window).scrollLeft() - this.offset.relative.left - this.offset.parent.left, e(window).scrollTop() - this.offset.relative.top - this.offset.parent.top, e(window).scrollLeft() + e(window).width() - this.helperProportions.width - this.margins.left, e(window).scrollTop() + (e(window).height() || s.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top];
                    return
                }
                if (i.containment === "document") {
                    this.containment = [0, 0, e(s).width() - this.helperProportions.width - this.margins.left, (e(s).height() || s.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top];
                    return
                }
                if (i.containment.constructor === Array) {
                    this.containment = i.containment;
                    return
                }
                i.containment === "parent" && (i.containment = this.helper[0].parentNode), n = e(i.containment), r = n[0];
                if (!r) return;
                t = /(scroll|auto)/.test(n.css("overflow")), this.containment = [(parseInt(n.css("borderLeftWidth"), 10) || 0) + (parseInt(n.css("paddingLeft"), 10) || 0), (parseInt(n.css("borderTopWidth"), 10) || 0) + (parseInt(n.css("paddingTop"), 10) || 0), (t ? Math.max(r.scrollWidth, r.offsetWidth) : r.offsetWidth) - (parseInt(n.css("borderRightWidth"), 10) || 0) - (parseInt(n.css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left - this.margins.right, (t ? Math.max(r.scrollHeight, r.offsetHeight) : r.offsetHeight) - (parseInt(n.css("borderBottomWidth"), 10) || 0) - (parseInt(n.css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top - this.margins.bottom], this.relativeContainer = n
            },
            _convertPositionTo: function(e, t) {
                t || (t = this.position);
                var n = e === "absolute" ? 1 : -1,
                    r = this._isRootNode(this.scrollParent[0]);
                return {
                    top: t.top + this.offset.relative.top * n + this.offset.parent.top * n - (this.cssPosition === "fixed" ? -this.offset.scroll.top : r ? 0 : this.offset.scroll.top) * n,
                    left: t.left + this.offset.relative.left * n + this.offset.parent.left * n - (this.cssPosition === "fixed" ? -this.offset.scroll.left : r ? 0 : this.offset.scroll.left) * n
                }
            },
            _generatePosition: function(e, t) {
                var n, r, i, s, o = this.options,
                    u = this._isRootNode(this.scrollParent[0]),
                    a = e.pageX,
                    f = e.pageY;
                if (!u || !this.offset.scroll) this.offset.scroll = {
                    top: this.scrollParent.scrollTop(),
                    left: this.scrollParent.scrollLeft()
                };
                return t && (this.containment && (this.relativeContainer ? (r = this.relativeContainer.offset(), n = [this.containment[0] + r.left, this.containment[1] + r.top, this.containment[2] + r.left, this.containment[3] + r.top]) : n = this.containment, e.pageX - this.offset.click.left < n[0] && (a = n[0] + this.offset.click.left), e.pageY - this.offset.click.top < n[1] && (f = n[1] + this.offset.click.top), e.pageX - this.offset.click.left > n[2] && (a = n[2] + this.offset.click.left), e.pageY - this.offset.click.top > n[3] && (f = n[3] + this.offset.click.top)), o.grid && (i = o.grid[1] ? this.originalPageY + Math.round((f - this.originalPageY) / o.grid[1]) * o.grid[1] : this.originalPageY, f = n ? i - this.offset.click.top >= n[1] || i - this.offset.click.top > n[3] ? i : i - this.offset.click.top >= n[1] ? i - o.grid[1] : i + o.grid[1] : i, s = o.grid[0] ? this.originalPageX + Math.round((a - this.originalPageX) / o.grid[0]) * o.grid[0] : this.originalPageX, a = n ? s - this.offset.click.left >= n[0] || s - this.offset.click.left > n[2] ? s : s - this.offset.click.left >= n[0] ? s - o.grid[0] : s + o.grid[0] : s), o.axis === "y" && (a = this.originalPageX), o.axis === "x" && (f = this.originalPageY)), {
                    top: f - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + (this.cssPosition === "fixed" ? -this.offset.scroll.top : u ? 0 : this.offset.scroll.top),
                    left: a - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + (this.cssPosition === "fixed" ? -this.offset.scroll.left : u ? 0 : this.offset.scroll.left)
                }
            },
            _clear: function() {
                this.helper.removeClass("ui-draggable-dragging"), this.helper[0] !== this.element[0] && !this.cancelHelperRemoval && this.helper.remove(), this.helper = null, this.cancelHelperRemoval = !1, this.destroyOnClear && this.destroy()
            },
            _normalizeRightBottom: function() {
                this.options.axis !== "y" && this.helper.css("right") !== "auto" && (this.helper.width(this.helper.width()), this.helper.css("right", "auto")), this.options.axis !== "x" && this.helper.css("bottom") !== "auto" && (this.helper.height(this.helper.height()), this.helper.css("bottom", "auto"))
            },
            _trigger: function(t, n, r) {
                return r = r || this._uiHash(), e.ui.plugin.call(this, t, [n, r, this], !0), /^(drag|start|stop)/.test(t) && (this.positionAbs = this._convertPositionTo("absolute"), r.offset = this.positionAbs), e.Widget.prototype._trigger.call(this, t, n, r)
            },
            plugins: {},
            _uiHash: function() {
                return {
                    helper: this.helper,
                    position: this.position,
                    originalPosition: this.originalPosition,
                    offset: this.positionAbs
                }
            }
        }), e.ui.plugin.add("draggable", "connectToSortable", {
            start: function(t, n, r) {
                var i = e.extend({}, n, {
                    item: r.element
                });
                r.sortables = [], e(r.options.connectToSortable).each(function() {
                    var n = e(this).sortable("instance");
                    n && !n.options.disabled && (r.sortables.push(n), n.refreshPositions(), n._trigger("activate", t, i))
                })
            },
            stop: function(t, n, r) {
                var i = e.extend({}, n, {
                    item: r.element
                });
                r.cancelHelperRemoval = !1, e.each(r.sortables, function() {
                    var e = this;
                    e.isOver ? (e.isOver = 0, r.cancelHelperRemoval = !0, e.cancelHelperRemoval = !1, e._storedCSS = {
                        position: e.placeholder.css("position"),
                        top: e.placeholder.css("top"),
                        left: e.placeholder.css("left")
                    }, e._mouseStop(t), e.options.helper = e.options._helper) : (e.cancelHelperRemoval = !0, e._trigger("deactivate", t, i))
                })
            },
            drag: function(t, n, r) {
                e.each(r.sortables, function() {
                    var i = !1,
                        s = this;
                    s.positionAbs = r.positionAbs, s.helperProportions = r.helperProportions, s.offset.click = r.offset.click, s._intersectsWith(s.containerCache) && (i = !0, e.each(r.sortables, function() {
                        return this.positionAbs = r.positionAbs, this.helperProportions = r.helperProportions, this.offset.click = r.offset.click, this !== s && this._intersectsWith(this.containerCache) && e.contains(s.element[0], this.element[0]) && (i = !1), i
                    })), i ? (s.isOver || (s.isOver = 1, s.currentItem = n.helper.appendTo(s.element).data("ui-sortable-item", !0), s.options._helper = s.options.helper, s.options.helper = function() {
                        return n.helper[0]
                    }, t.target = s.currentItem[0], s._mouseCapture(t, !0), s._mouseStart(t, !0, !0), s.offset.click.top = r.offset.click.top, s.offset.click.left = r.offset.click.left, s.offset.parent.left -= r.offset.parent.left - s.offset.parent.left, s.offset.parent.top -= r.offset.parent.top - s.offset.parent.top, r._trigger("toSortable", t), r.dropped = s.element, e.each(r.sortables, function() {
                        this.refreshPositions()
                    }), r.currentItem = r.element, s.fromOutside = r), s.currentItem && (s._mouseDrag(t), n.position = s.position)) : s.isOver && (s.isOver = 0, s.cancelHelperRemoval = !0, s.options._revert = s.options.revert, s.options.revert = !1, s._trigger("out", t, s._uiHash(s)), s._mouseStop(t, !0), s.options.revert = s.options._revert, s.options.helper = s.options._helper, s.placeholder && s.placeholder.remove(), r._refreshOffsets(t), n.position = r._generatePosition(t, !0), r._trigger("fromSortable", t), r.dropped = !1, e.each(r.sortables, function() {
                        this.refreshPositions()
                    }))
                })
            }
        }), e.ui.plugin.add("draggable", "cursor", {
            start: function(t, n, r) {
                var i = e("body"),
                    s = r.options;
                i.css("cursor") && (s._cursor = i.css("cursor")), i.css("cursor", s.cursor)
            },
            stop: function(t, n, r) {
                var i = r.options;
                i._cursor && e("body").css("cursor", i._cursor)
            }
        }), e.ui.plugin.add("draggable", "opacity", {
            start: function(t, n, r) {
                var i = e(n.helper),
                    s = r.options;
                i.css("opacity") && (s._opacity = i.css("opacity")), i.css("opacity", s.opacity)
            },
            stop: function(t, n, r) {
                var i = r.options;
                i._opacity && e(n.helper).css("opacity", i._opacity)
            }
        }), e.ui.plugin.add("draggable", "scroll", {
            start: function(e, t, n) {
                n.scrollParentNotHidden || (n.scrollParentNotHidden = n.helper.scrollParent(!1)), n.scrollParentNotHidden[0] !== n.document[0] && n.scrollParentNotHidden[0].tagName !== "HTML" && (n.overflowOffset = n.scrollParentNotHidden.offset())
            },
            drag: function(t, n, r) {
                var i = r.options,
                    s = !1,
                    o = r.scrollParentNotHidden[0],
                    u = r.document[0];
                if (o !== u && o.tagName !== "HTML") {
                    if (!i.axis || i.axis !== "x") r.overflowOffset.top + o.offsetHeight - t.pageY < i.scrollSensitivity ? o.scrollTop = s = o.scrollTop + i.scrollSpeed : t.pageY - r.overflowOffset.top < i.scrollSensitivity && (o.scrollTop = s = o.scrollTop - i.scrollSpeed);
                    if (!i.axis || i.axis !== "y") r.overflowOffset.left + o.offsetWidth - t.pageX < i.scrollSensitivity ? o.scrollLeft = s = o.scrollLeft + i.scrollSpeed : t.pageX - r.overflowOffset.left < i.scrollSensitivity && (o.scrollLeft = s = o.scrollLeft - i.scrollSpeed)
                } else {
                    if (!i.axis || i.axis !== "x") t.pageY - e(u).scrollTop() < i.scrollSensitivity ? s = e(u).scrollTop(e(u).scrollTop() - i.scrollSpeed) : e(window).height() - (t.pageY - e(u).scrollTop()) < i.scrollSensitivity && (s = e(u).scrollTop(e(u).scrollTop() + i.scrollSpeed));
                    if (!i.axis || i.axis !== "y") t.pageX - e(u).scrollLeft() < i.scrollSensitivity ? s = e(u).scrollLeft(e(u).scrollLeft() - i.scrollSpeed) : e(window).width() - (t.pageX - e(u).scrollLeft()) < i.scrollSensitivity && (s = e(u).scrollLeft(e(u).scrollLeft() + i.scrollSpeed))
                }
                s !== !1 && e.ui.ddmanager && !i.dropBehaviour && e.ui.ddmanager.prepareOffsets(r, t)
            }
        }), e.ui.plugin.add("draggable", "snap", {
            start: function(t, n, r) {
                var i = r.options;
                r.snapElements = [], e(i.snap.constructor !== String ? i.snap.items || ":data(ui-draggable)" : i.snap).each(function() {
                    var t = e(this),
                        n = t.offset();
                    this !== r.element[0] && r.snapElements.push({
                        item: this,
                        width: t.outerWidth(),
                        height: t.outerHeight(),
                        top: n.top,
                        left: n.left
                    })
                })
            },
            drag: function(t, n, r) {
                var i, s, o, u, a, f, l, c, h, p, d = r.options,
                    v = d.snapTolerance,
                    m = n.offset.left,
                    g = m + r.helperProportions.width,
                    y = n.offset.top,
                    b = y + r.helperProportions.height;
                for (h = r.snapElements.length - 1; h >= 0; h--) {
                    a = r.snapElements[h].left - r.margins.left, f = a + r.snapElements[h].width, l = r.snapElements[h].top - r.margins.top, c = l + r.snapElements[h].height;
                    if (g < a - v || m > f + v || b < l - v || y > c + v || !e.contains(r.snapElements[h].item.ownerDocument, r.snapElements[h].item)) {
                        r.snapElements[h].snapping && r.options.snap.release && r.options.snap.release.call(r.element, t, e.extend(r._uiHash(), {
                            snapItem: r.snapElements[h].item
                        })), r.snapElements[h].snapping = !1;
                        continue
                    }
                    d.snapMode !== "inner" && (i = Math.abs(l - b) <= v, s = Math.abs(c - y) <= v, o = Math.abs(a - g) <= v, u = Math.abs(f - m) <= v, i && (n.position.top = r._convertPositionTo("relative", {
                        top: l - r.helperProportions.height,
                        left: 0
                    }).top), s && (n.position.top = r._convertPositionTo("relative", {
                        top: c,
                        left: 0
                    }).top), o && (n.position.left = r._convertPositionTo("relative", {
                        top: 0,
                        left: a - r.helperProportions.width
                    }).left), u && (n.position.left = r._convertPositionTo("relative", {
                        top: 0,
                        left: f
                    }).left)), p = i || s || o || u, d.snapMode !== "outer" && (i = Math.abs(l - y) <= v, s = Math.abs(c - b) <= v, o = Math.abs(a - m) <= v, u = Math.abs(f - g) <= v, i && (n.position.top = r._convertPositionTo("relative", {
                        top: l,
                        left: 0
                    }).top), s && (n.position.top = r._convertPositionTo("relative", {
                        top: c - r.helperProportions.height,
                        left: 0
                    }).top), o && (n.position.left = r._convertPositionTo("relative", {
                        top: 0,
                        left: a
                    }).left), u && (n.position.left = r._convertPositionTo("relative", {
                        top: 0,
                        left: f - r.helperProportions.width
                    }).left)), !r.snapElements[h].snapping && (i || s || o || u || p) && r.options.snap.snap && r.options.snap.snap.call(r.element, t, e.extend(r._uiHash(), {
                        snapItem: r.snapElements[h].item
                    })), r.snapElements[h].snapping = i || s || o || u || p
                }
            }
        }), e.ui.plugin.add("draggable", "stack", {
            start: function(t, n, r) {
                var i, s = r.options,
                    o = e.makeArray(e(s.stack)).sort(function(t, n) {
                        return (parseInt(e(t).css("zIndex"), 10) || 0) - (parseInt(e(n).css("zIndex"), 10) || 0)
                    });
                if (!o.length) return;
                i = parseInt(e(o[0]).css("zIndex"), 10) || 0, e(o).each(function(t) {
                    e(this).css("zIndex", i + t)
                }), this.css("zIndex", i + o.length)
            }
        }), e.ui.plugin.add("draggable", "zIndex", {
            start: function(t, n, r) {
                var i = e(n.helper),
                    s = r.options;
                i.css("zIndex") && (s._zIndex = i.css("zIndex")), i.css("zIndex", s.zIndex)
            },
            stop: function(t, n, r) {
                var i = r.options;
                i._zIndex && e(n.helper).css("zIndex", i._zIndex)
            }
        });
        var N = e.ui.draggable;
        e.widget("ui.resizable", e.ui.mouse, {
            version: "1.11.2",
            widgetEventPrefix: "resize",
            options: {
                alsoResize: !1,
                animate: !1,
                animateDuration: "slow",
                animateEasing: "swing",
                aspectRatio: !1,
                autoHide: !1,
                containment: !1,
                ghost: !1,
                grid: !1,
                handles: "e,s,se",
                helper: !1,
                maxHeight: null,
                maxWidth: null,
                minHeight: 10,
                minWidth: 10,
                zIndex: 90,
                resize: null,
                start: null,
                stop: null
            },
            _num: function(e) {
                return parseInt(e, 10) || 0
            },
            _isNumber: function(e) {
                return !isNaN(parseInt(e, 10))
            },
            _hasScroll: function(t, n) {
                if (e(t).css("overflow") === "hidden") return !1;
                var r = n && n === "left" ? "scrollLeft" : "scrollTop",
                    i = !1;
                return t[r] > 0 ? !0 : (t[r] = 1, i = t[r] > 0, t[r] = 0, i)
            },
            _create: function() {
                var t, n, r, i, s, o = this,
                    u = this.options;
                this.element.addClass("ui-resizable"), e.extend(this, {
                    _aspectRatio: !!u.aspectRatio,
                    aspectRatio: u.aspectRatio,
                    originalElement: this.element,
                    _proportionallyResizeElements: [],
                    _helper: u.helper || u.ghost || u.animate ? u.helper || "ui-resizable-helper" : null
                }), this.element[0].nodeName.match(/canvas|textarea|input|select|button|img/i) && (this.element.wrap(e("<div class='ui-wrapper' style='overflow: hidden;'></div>").css({
                    position: this.element.css("position"),
                    width: this.element.outerWidth(),
                    height: this.element.outerHeight(),
                    top: this.element.css("top"),
                    left: this.element.css("left")
                })), this.element = this.element.parent().data("ui-resizable", this.element.resizable("instance")), this.elementIsWrapper = !0, this.element.css({
                    marginLeft: this.originalElement.css("marginLeft"),
                    marginTop: this.originalElement.css("marginTop"),
                    marginRight: this.originalElement.css("marginRight"),
                    marginBottom: this.originalElement.css("marginBottom")
                }), this.originalElement.css({
                    marginLeft: 0,
                    marginTop: 0,
                    marginRight: 0,
                    marginBottom: 0
                }), this.originalResizeStyle = this.originalElement.css("resize"), this.originalElement.css("resize", "none"), this._proportionallyResizeElements.push(this.originalElement.css({
                    position: "static",
                    zoom: 1,
                    display: "block"
                })), this.originalElement.css({
                    margin: this.originalElement.css("margin")
                }), this._proportionallyResize()), this.handles = u.handles || (e(".ui-resizable-handle", this.element).length ? {
                    n: ".ui-resizable-n",
                    e: ".ui-resizable-e",
                    s: ".ui-resizable-s",
                    w: ".ui-resizable-w",
                    se: ".ui-resizable-se",
                    sw: ".ui-resizable-sw",
                    ne: ".ui-resizable-ne",
                    nw: ".ui-resizable-nw"
                } : "e,s,se");
                if (this.handles.constructor === String) {
                    this.handles === "all" && (this.handles = "n,e,s,w,se,sw,ne,nw"), t = this.handles.split(","), this.handles = {};
                    for (n = 0; n < t.length; n++) r = e.trim(t[n]), s = "ui-resizable-" + r, i = e("<div class='ui-resizable-handle " + s + "'></div>"), i.css({
                        zIndex: u.zIndex
                    }), "se" === r && i.addClass("ui-icon ui-icon-gripsmall-diagonal-se"), this.handles[r] = ".ui-resizable-" + r, this.element.append(i)
                }
                this._renderAxis = function(t) {
                    var n, r, i, s;
                    t = t || this.element;
                    for (n in this.handles) {
                        this.handles[n].constructor === String && (this.handles[n] = this.element.children(this.handles[n]).first().show()), this.elementIsWrapper && this.originalElement[0].nodeName.match(/textarea|input|select|button/i) && (r = e(this.handles[n], this.element), s = /sw|ne|nw|se|n|s/.test(n) ? r.outerHeight() : r.outerWidth(), i = ["padding", /ne|nw|n/.test(n) ? "Top" : /se|sw|s/.test(n) ? "Bottom" : /^e$/.test(n) ? "Right" : "Left"].join(""), t.css(i, s), this._proportionallyResize());
                        if (!e(this.handles[n]).length) continue
                    }
                }, this._renderAxis(this.element), this._handles = e(".ui-resizable-handle", this.element).disableSelection(), this._handles.mouseover(function() {
                    o.resizing || (this.className && (i = this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)), o.axis = i && i[1] ? i[1] : "se")
                }), u.autoHide && (this._handles.hide(), e(this.element).addClass("ui-resizable-autohide").mouseenter(function() {
                    if (u.disabled) return;
                    e(this).removeClass("ui-resizable-autohide"), o._handles.show()
                }).mouseleave(function() {
                    if (u.disabled) return;
                    o.resizing || (e(this).addClass("ui-resizable-autohide"), o._handles.hide())
                })), this._mouseInit()
            },
            _destroy: function() {
                this._mouseDestroy();
                var t, n = function(t) {
                    e(t).removeClass("ui-resizable ui-resizable-disabled ui-resizable-resizing").removeData("resizable").removeData("ui-resizable").unbind(".resizable").find(".ui-resizable-handle").remove()
                };
                return this.elementIsWrapper && (n(this.element), t = this.element, this.originalElement.css({
                    position: t.css("position"),
                    width: t.outerWidth(),
                    height: t.outerHeight(),
                    top: t.css("top"),
                    left: t.css("left")
                }).insertAfter(t), t.remove()), this.originalElement.css("resize", this.originalResizeStyle), n(this.originalElement), this
            },
            _mouseCapture: function(t) {
                var n, r, i = !1;
                for (n in this.handles) {
                    r = e(this.handles[n])[0];
                    if (r === t.target || e.contains(r, t.target)) i = !0
                }
                return !this.options.disabled && i
            },
            _mouseStart: function(t) {
                var n, r, i, s = this.options,
                    o = this.element;
                return this.resizing = !0, this._renderProxy(), n = this._num(this.helper.css("left")), r = this._num(this.helper.css("top")), s.containment && (n += e(s.containment).scrollLeft() || 0, r += e(s.containment).scrollTop() || 0), this.offset = this.helper.offset(), this.position = {
                    left: n,
                    top: r
                }, this.size = this._helper ? {
                    width: this.helper.width(),
                    height: this.helper.height()
                } : {
                    width: o.width(),
                    height: o.height()
                }, this.originalSize = this._helper ? {
                    width: o.outerWidth(),
                    height: o.outerHeight()
                } : {
                    width: o.width(),
                    height: o.height()
                }, this.sizeDiff = {
                    width: o.outerWidth() - o.width(),
                    height: o.outerHeight() - o.height()
                }, this.originalPosition = {
                    left: n,
                    top: r
                }, this.originalMousePosition = {
                    left: t.pageX,
                    top: t.pageY
                }, this.aspectRatio = typeof s.aspectRatio == "number" ? s.aspectRatio : this.originalSize.width / this.originalSize.height || 1, i = e(".ui-resizable-" + this.axis).css("cursor"), e("body").css("cursor", i === "auto" ? this.axis + "-resize" : i), o.addClass("ui-resizable-resizing"), this._propagate("start", t), !0
            },
            _mouseDrag: function(t) {
                var n, r, i = this.originalMousePosition,
                    s = this.axis,
                    o = t.pageX - i.left || 0,
                    u = t.pageY - i.top || 0,
                    a = this._change[s];
                this._updatePrevProperties();
                if (!a) return !1;
                n = a.apply(this, [t, o, u]), this._updateVirtualBoundaries(t.shiftKey);
                if (this._aspectRatio || t.shiftKey) n = this._updateRatio(n, t);
                return n = this._respectSize(n, t), this._updateCache(n), this._propagate("resize", t), r = this._applyChanges(), !this._helper && this._proportionallyResizeElements.length && this._proportionallyResize(), e.isEmptyObject(r) || (this._updatePrevProperties(), this._trigger("resize", t, this.ui()), this._applyChanges()), !1
            },
            _mouseStop: function(t) {
                this.resizing = !1;
                var n, r, i, s, o, u, a, f = this.options,
                    l = this;
                return this._helper && (n = this._proportionallyResizeElements, r = n.length && /textarea/i.test(n[0].nodeName), i = r && this._hasScroll(n[0], "left") ? 0 : l.sizeDiff.height, s = r ? 0 : l.sizeDiff.width, o = {
                    width: l.helper.width() - s,
                    height: l.helper.height() - i
                }, u = parseInt(l.element.css("left"), 10) + (l.position.left - l.originalPosition.left) || null, a = parseInt(l.element.css("top"), 10) + (l.position.top - l.originalPosition.top) || null, f.animate || this.element.css(e.extend(o, {
                    top: a,
                    left: u
                })), l.helper.height(l.size.height), l.helper.width(l.size.width), this._helper && !f.animate && this._proportionallyResize()), e("body").css("cursor", "auto"), this.element.removeClass("ui-resizable-resizing"), this._propagate("stop", t), this._helper && this.helper.remove(), !1
            },
            _updatePrevProperties: function() {
                this.prevPosition = {
                    top: this.position.top,
                    left: this.position.left
                }, this.prevSize = {
                    width: this.size.width,
                    height: this.size.height
                }
            },
            _applyChanges: function() {
                var e = {};
                return this.position.top !== this.prevPosition.top && (e.top = this.position.top + "px"), this.position.left !== this.prevPosition.left && (e.left = this.position.left + "px"), this.size.width !== this.prevSize.width && (e.width = this.size.width + "px"), this.size.height !== this.prevSize.height && (e.height = this.size.height + "px"), this.helper.css(e), e
            },
            _updateVirtualBoundaries: function(e) {
                var t, n, r, i, s, o = this.options;
                s = {
                    minWidth: this._isNumber(o.minWidth) ? o.minWidth : 0,
                    maxWidth: this._isNumber(o.maxWidth) ? o.maxWidth : Infinity,
                    minHeight: this._isNumber(o.minHeight) ? o.minHeight : 0,
                    maxHeight: this._isNumber(o.maxHeight) ? o.maxHeight : Infinity
                };
                if (this._aspectRatio || e) t = s.minHeight * this.aspectRatio, r = s.minWidth / this.aspectRatio, n = s.maxHeight * this.aspectRatio, i = s.maxWidth / this.aspectRatio, t > s.minWidth && (s.minWidth = t), r > s.minHeight && (s.minHeight = r), n < s.maxWidth && (s.maxWidth = n), i < s.maxHeight && (s.maxHeight = i);
                this._vBoundaries = s
            },
            _updateCache: function(e) {
                this.offset = this.helper.offset(), this._isNumber(e.left) && (this.position.left = e.left), this._isNumber(e.top) && (this.position.top = e.top), this._isNumber(e.height) && (this.size.height = e.height), this._isNumber(e.width) && (this.size.width = e.width)
            },
            _updateRatio: function(e) {
                var t = this.position,
                    n = this.size,
                    r = this.axis;
                return this._isNumber(e.height) ? e.width = e.height * this.aspectRatio : this._isNumber(e.width) && (e.height = e.width / this.aspectRatio), r === "sw" && (e.left = t.left + (n.width - e.width), e.top = null), r === "nw" && (e.top = t.top + (n.height - e.height), e.left = t.left + (n.width - e.width)), e
            },
            _respectSize: function(e) {
                var t = this._vBoundaries,
                    n = this.axis,
                    r = this._isNumber(e.width) && t.maxWidth && t.maxWidth < e.width,
                    i = this._isNumber(e.height) && t.maxHeight && t.maxHeight < e.height,
                    s = this._isNumber(e.width) && t.minWidth && t.minWidth > e.width,
                    o = this._isNumber(e.height) && t.minHeight && t.minHeight > e.height,
                    u = this.originalPosition.left + this.originalSize.width,
                    a = this.position.top + this.size.height,
                    f = /sw|nw|w/.test(n),
                    l = /nw|ne|n/.test(n);
                return s && (e.width = t.minWidth), o && (e.height = t.minHeight), r && (e.width = t.maxWidth), i && (e.height = t.maxHeight), s && f && (e.left = u - t.minWidth), r && f && (e.left = u - t.maxWidth), o && l && (e.top = a - t.minHeight), i && l && (e.top = a - t.maxHeight), !e.width && !e.height && !e.left && e.top ? e.top = null : !e.width && !e.height && !e.top && e.left && (e.left = null), e
            },
            _getPaddingPlusBorderDimensions: function(e) {
                var t = 0,
                    n = [],
                    r = [e.css("borderTopWidth"), e.css("borderRightWidth"), e.css("borderBottomWidth"), e.css("borderLeftWidth")],
                    i = [e.css("paddingTop"), e.css("paddingRight"), e.css("paddingBottom"), e.css("paddingLeft")];
                for (; t < 4; t++) n[t] = parseInt(r[t], 10) || 0, n[t] += parseInt(i[t], 10) || 0;
                return {
                    height: n[0] + n[2],
                    width: n[1] + n[3]
                }
            },
            _proportionallyResize: function() {
                if (!this._proportionallyResizeElements.length) return;
                var e, t = 0,
                    n = this.helper || this.element;
                for (; t < this._proportionallyResizeElements.length; t++) e = this._proportionallyResizeElements[t], this.outerDimensions || (this.outerDimensions = this._getPaddingPlusBorderDimensions(e)), e.css({
                    height: n.height() - this.outerDimensions.height || 0,
                    width: n.width() - this.outerDimensions.width || 0
                })
            },
            _renderProxy: function() {
                var t = this.element,
                    n = this.options;
                this.elementOffset = t.offset(), this._helper ? (this.helper = this.helper || e("<div style='overflow:hidden;'></div>"), this.helper.addClass(this._helper).css({
                    width: this.element.outerWidth() - 1,
                    height: this.element.outerHeight() - 1,
                    position: "absolute",
                    left: this.elementOffset.left + "px",
                    top: this.elementOffset.top + "px",
                    zIndex: ++n.zIndex
                }), this.helper.appendTo("body").disableSelection()) : this.helper = this.element
            },
            _change: {
                e: function(e, t) {
                    return {
                        width: this.originalSize.width + t
                    }
                },
                w: function(e, t) {
                    var n = this.originalSize,
                        r = this.originalPosition;
                    return {
                        left: r.left + t,
                        width: n.width - t
                    }
                },
                n: function(e, t, n) {
                    var r = this.originalSize,
                        i = this.originalPosition;
                    return {
                        top: i.top + n,
                        height: r.height - n
                    }
                },
                s: function(e, t, n) {
                    return {
                        height: this.originalSize.height + n
                    }
                },
                se: function(t, n, r) {
                    return e.extend(this._change.s.apply(this, arguments), this._change.e.apply(this, [t, n, r]))
                },
                sw: function(t, n, r) {
                    return e.extend(this._change.s.apply(this, arguments), this._change.w.apply(this, [t, n, r]))
                },
                ne: function(t, n, r) {
                    return e.extend(this._change.n.apply(this, arguments), this._change.e.apply(this, [t, n, r]))
                },
                nw: function(t, n, r) {
                    return e.extend(this._change.n.apply(this, arguments), this._change.w.apply(this, [t, n, r]))
                }
            },
            _propagate: function(t, n) {
                e.ui.plugin.call(this, t, [n, this.ui()]), t !== "resize" && this._trigger(t, n, this.ui())
            },
            plugins: {},
            ui: function() {
                return {
                    originalElement: this.originalElement,
                    element: this.element,
                    helper: this.helper,
                    position: this.position,
                    size: this.size,
                    originalSize: this.originalSize,
                    originalPosition: this.originalPosition
                }
            }
        }), e.ui.plugin.add("resizable", "animate", {
            stop: function(t) {
                var n = e(this).resizable("instance"),
                    r = n.options,
                    i = n._proportionallyResizeElements,
                    s = i.length && /textarea/i.test(i[0].nodeName),
                    o = s && n._hasScroll(i[0], "left") ? 0 : n.sizeDiff.height,
                    u = s ? 0 : n.sizeDiff.width,
                    a = {
                        width: n.size.width - u,
                        height: n.size.height - o
                    },
                    f = parseInt(n.element.css("left"), 10) + (n.position.left - n.originalPosition.left) || null,
                    l = parseInt(n.element.css("top"), 10) + (n.position.top - n.originalPosition.top) || null;
                n.element.animate(e.extend(a, l && f ? {
                    top: l,
                    left: f
                } : {}), {
                    duration: r.animateDuration,
                    easing: r.animateEasing,
                    step: function() {
                        var r = {
                            width: parseInt(n.element.css("width"), 10),
                            height: parseInt(n.element.css("height"), 10),
                            top: parseInt(n.element.css("top"), 10),
                            left: parseInt(n.element.css("left"), 10)
                        };
                        i && i.length && e(i[0]).css({
                            width: r.width,
                            height: r.height
                        }), n._updateCache(r), n._propagate("resize", t)
                    }
                })
            }
        }), e.ui.plugin.add("resizable", "containment", {
            start: function() {
                var t, n, r, i, s, o, u, a = e(this).resizable("instance"),
                    f = a.options,
                    l = a.element,
                    c = f.containment,
                    h = c instanceof e ? c.get(0) : /parent/.test(c) ? l.parent().get(0) : c;
                if (!h) return;
                a.containerElement = e(h), /document/.test(c) || c === document ? (a.containerOffset = {
                    left: 0,
                    top: 0
                }, a.containerPosition = {
                    left: 0,
                    top: 0
                }, a.parentData = {
                    element: e(document),
                    left: 0,
                    top: 0,
                    width: e(document).width(),
                    height: e(document).height() || document.body.parentNode.scrollHeight
                }) : (t = e(h), n = [], e(["Top", "Right", "Left", "Bottom"]).each(function(e, r) {
                    n[e] = a._num(t.css("padding" + r))
                }), a.containerOffset = t.offset(), a.containerPosition = t.position(), a.containerSize = {
                    height: t.innerHeight() - n[3],
                    width: t.innerWidth() - n[1]
                }, r = a.containerOffset, i = a.containerSize.height, s = a.containerSize.width, o = a._hasScroll(h, "left") ? h.scrollWidth : s, u = a._hasScroll(h) ? h.scrollHeight : i, a.parentData = {
                    element: h,
                    left: r.left,
                    top: r.top,
                    width: o,
                    height: u
                })
            },
            resize: function(t) {
                var n, r, i, s, o = e(this).resizable("instance"),
                    u = o.options,
                    a = o.containerOffset,
                    f = o.position,
                    l = o._aspectRatio || t.shiftKey,
                    c = {
                        top: 0,
                        left: 0
                    },
                    h = o.containerElement,
                    p = !0;
                h[0] !== document && /static/.test(h.css("position")) && (c = a), f.left < (o._helper ? a.left : 0) && (o.size.width = o.size.width + (o._helper ? o.position.left - a.left : o.position.left - c.left), l && (o.size.height = o.size.width / o.aspectRatio, p = !1), o.position.left = u.helper ? a.left : 0), f.top < (o._helper ? a.top : 0) && (o.size.height = o.size.height + (o._helper ? o.position.top - a.top : o.position.top), l && (o.size.width = o.size.height * o.aspectRatio, p = !1), o.position.top = o._helper ? a.top : 0), i = o.containerElement.get(0) === o.element.parent().get(0), s = /relative|absolute/.test(o.containerElement.css("position")), i && s ? (o.offset.left = o.parentData.left + o.position.left, o.offset.top = o.parentData.top + o.position.top) : (o.offset.left = o.element.offset().left, o.offset.top = o.element.offset().top), n = Math.abs(o.sizeDiff.width + (o._helper ? o.offset.left - c.left : o.offset.left - a.left)), r = Math.abs(o.sizeDiff.height + (o._helper ? o.offset.top - c.top : o.offset.top - a.top)), n + o.size.width >= o.parentData.width && (o.size.width = o.parentData.width - n, l && (o.size.height = o.size.width / o.aspectRatio, p = !1)), r + o.size.height >= o.parentData.height && (o.size.height = o.parentData.height - r, l && (o.size.width = o.size.height * o.aspectRatio, p = !1)), p || (o.position.left = o.prevPosition.left, o.position.top = o.prevPosition.top, o.size.width = o.prevSize.width, o.size.height = o.prevSize.height)
            },
            stop: function() {
                var t = e(this).resizable("instance"),
                    n = t.options,
                    r = t.containerOffset,
                    i = t.containerPosition,
                    s = t.containerElement,
                    o = e(t.helper),
                    u = o.offset(),
                    a = o.outerWidth() - t.sizeDiff.width,
                    f = o.outerHeight() - t.sizeDiff.height;
                t._helper && !n.animate && /relative/.test(s.css("position")) && e(this).css({
                    left: u.left - i.left - r.left,
                    width: a,
                    height: f
                }), t._helper && !n.animate && /static/.test(s.css("position")) && e(this).css({
                    left: u.left - i.left - r.left,
                    width: a,
                    height: f
                })
            }
        }), e.ui.plugin.add("resizable", "alsoResize", {
            start: function() {
                var t = e(this).resizable("instance"),
                    n = t.options,
                    r = function(t) {
                        e(t).each(function() {
                            var t = e(this);
                            t.data("ui-resizable-alsoresize", {
                                width: parseInt(t.width(), 10),
                                height: parseInt(t.height(), 10),
                                left: parseInt(t.css("left"), 10),
                                top: parseInt(t.css("top"), 10)
                            })
                        })
                    };
                typeof n.alsoResize == "object" && !n.alsoResize.parentNode ? n.alsoResize.length ? (n.alsoResize = n.alsoResize[0], r(n.alsoResize)) : e.each(n.alsoResize, function(e) {
                    r(e)
                }) : r(n.alsoResize)
            },
            resize: function(t, n) {
                var r = e(this).resizable("instance"),
                    i = r.options,
                    s = r.originalSize,
                    o = r.originalPosition,
                    u = {
                        height: r.size.height - s.height || 0,
                        width: r.size.width - s.width || 0,
                        top: r.position.top - o.top || 0,
                        left: r.position.left - o.left || 0
                    },
                    a = function(t, r) {
                        e(t).each(function() {
                            var t = e(this),
                                i = e(this).data("ui-resizable-alsoresize"),
                                s = {},
                                o = r && r.length ? r : t.parents(n.originalElement[0]).length ? ["width", "height"] : ["width", "height", "top", "left"];
                            e.each(o, function(e, t) {
                                var n = (i[t] || 0) + (u[t] || 0);
                                n && n >= 0 && (s[t] = n || null)
                            }), t.css(s)
                        })
                    };
                typeof i.alsoResize == "object" && !i.alsoResize.nodeType ? e.each(i.alsoResize, function(e, t) {
                    a(e, t)
                }) : a(i.alsoResize)
            },
            stop: function() {
                e(this).removeData("resizable-alsoresize")
            }
        }), e.ui.plugin.add("resizable", "ghost", {
            start: function() {
                var t = e(this).resizable("instance"),
                    n = t.options,
                    r = t.size;
                t.ghost = t.originalElement.clone(), t.ghost.css({
                    opacity: .25,
                    display: "block",
                    position: "relative",
                    height: r.height,
                    width: r.width,
                    margin: 0,
                    left: 0,
                    top: 0
                }).addClass("ui-resizable-ghost").addClass(typeof n.ghost == "string" ? n.ghost : ""), t.ghost.appendTo(t.helper)
            },
            resize: function() {
                var t = e(this).resizable("instance");
                t.ghost && t.ghost.css({
                    position: "relative",
                    height: t.size.height,
                    width: t.size.width
                })
            },
            stop: function() {
                var t = e(this).resizable("instance");
                t.ghost && t.helper && t.helper.get(0).removeChild(t.ghost.get(0))
            }
        }), e.ui.plugin.add("resizable", "grid", {
            resize: function() {
                var t, n = e(this).resizable("instance"),
                    r = n.options,
                    i = n.size,
                    s = n.originalSize,
                    o = n.originalPosition,
                    u = n.axis,
                    a = typeof r.grid == "number" ? [r.grid, r.grid] : r.grid,
                    f = a[0] || 1,
                    l = a[1] || 1,
                    c = Math.round((i.width - s.width) / f) * f,
                    h = Math.round((i.height - s.height) / l) * l,
                    p = s.width + c,
                    d = s.height + h,
                    v = r.maxWidth && r.maxWidth < p,
                    m = r.maxHeight && r.maxHeight < d,
                    g = r.minWidth && r.minWidth > p,
                    y = r.minHeight && r.minHeight > d;
                r.grid = a, g && (p += f), y && (d += l), v && (p -= f), m && (d -= l);
                if (/^(se|s|e)$/.test(u)) n.size.width = p, n.size.height = d;
                else if (/^(ne)$/.test(u)) n.size.width = p, n.size.height = d, n.position.top = o.top - h;
                else if (/^(sw)$/.test(u)) n.size.width = p, n.size.height = d, n.position.left = o.left - c;
                else {
                    if (d - l <= 0 || p - f <= 0) t = n._getPaddingPlusBorderDimensions(this);
                    d - l > 0 ? (n.size.height = d, n.position.top = o.top - h) : (d = l - t.height, n.size.height = d, n.position.top = o.top + s.height - d), p - f > 0 ? (n.size.width = p, n.position.left = o.left - c) : (p = l - t.height, n.size.width = p, n.position.left = o.left + s.width - p)
                }
            }
        });
        var C = e.ui.resizable,
            k = e.widget("ui.dialog", {
                version: "1.11.2",
                options: {
                    appendTo: "body",
                    autoOpen: !0,
                    buttons: [],
                    closeOnEscape: !0,
                    closeText: "Close",
                    dialogClass: "",
                    draggable: !0,
                    hide: null,
                    height: "auto",
                    maxHeight: null,
                    maxWidth: null,
                    minHeight: 150,
                    minWidth: 150,
                    modal: !1,
                    position: {
                        my: "center",
                        at: "center",
                        of: window,
                        collision: "fit",
                        using: function(t) {
                            var n = e(this).css(t).offset().top;
                            n < 0 && e(this).css("top", t.top - n)
                        }
                    },
                    resizable: !0,
                    show: null,
                    title: null,
                    width: 300,
                    beforeClose: null,
                    close: null,
                    drag: null,
                    dragStart: null,
                    dragStop: null,
                    focus: null,
                    open: null,
                    resize: null,
                    resizeStart: null,
                    resizeStop: null
                },
                sizeRelatedOptions: {
                    buttons: !0,
                    height: !0,
                    maxHeight: !0,
                    maxWidth: !0,
                    minHeight: !0,
                    minWidth: !0,
                    width: !0
                },
                resizableRelatedOptions: {
                    maxHeight: !0,
                    maxWidth: !0,
                    minHeight: !0,
                    minWidth: !0
                },
                _create: function() {
                    this.originalCss = {
                        display: this.element[0].style.display,
                        width: this.element[0].style.width,
                        minHeight: this.element[0].style.minHeight,
                        maxHeight: this.element[0].style.maxHeight,
                        height: this.element[0].style.height
                    }, this.originalPosition = {
                        parent: this.element.parent(),
                        index: this.element.parent().children().index(this.element)
                    }, this.originalTitle = this.element.attr("title"), this.options.title = this.options.title || this.originalTitle, this._createWrapper(), this.element.show().removeAttr("title").addClass("ui-dialog-content ui-widget-content").appendTo(this.uiDialog), this._createTitlebar(), this._createButtonPane(), this.options.draggable && e.fn.draggable && this._makeDraggable(), this.options.resizable && e.fn.resizable && this._makeResizable(), this._isOpen = !1, this._trackFocus()
                },
                _init: function() {
                    this.options.autoOpen && this.open()
                },
                _appendTo: function() {
                    var t = this.options.appendTo;
                    return t && (t.jquery || t.nodeType) ? e(t) : this.document.find(t || "body").eq(0)
                },
                _destroy: function() {
                    var e, t = this.originalPosition;
                    this._destroyOverlay(), this.element.removeUniqueId().removeClass("ui-dialog-content ui-widget-content").css(this.originalCss).detach(), this.uiDialog.stop(!0, !0).remove(), this.originalTitle && this.element.attr("title", this.originalTitle), e = t.parent.children().eq(t.index), e.length && e[0] !== this.element[0] ? e.before(this.element) : t.parent.append(this.element)
                },
                widget: function() {
                    return this.uiDialog
                },
                disable: e.noop,
                enable: e.noop,
                close: function(t) {
                    var n, r = this;
                    if (!this._isOpen || this._trigger("beforeClose", t) === !1) return;
                    this._isOpen = !1, this._focusedElement = null, this._destroyOverlay(), this._untrackInstance();
                    if (!this.opener.filter(":focusable").focus().length) try {
                        n = this.document[0].activeElement, n && n.nodeName.toLowerCase() !== "body" && e(n).blur()
                    } catch (i) {}
                    this._hide(this.uiDialog, this.options.hide, function() {
                        r._trigger("close", t)
                    })
                },
                isOpen: function() {
                    return this._isOpen
                },
                moveToTop: function() {
                    this._moveToTop()
                },
                _moveToTop: function(t, n) {
                    var r = !1,
                        i = this.uiDialog.siblings(".ui-front:visible").map(function() {
                            return +e(this).css("z-index")
                        }).get(),
                        s = Math.max.apply(null, i);
                    return s >= +this.uiDialog.css("z-index") && (this.uiDialog.css("z-index", s + 1), r = !0), r && !n && this._trigger("focus", t), r
                },
                open: function() {
                    var t = this;
                    if (this._isOpen) {
                        this._moveToTop() && this._focusTabbable();
                        return
                    }
                    this._isOpen = !0, this.opener = e(this.document[0].activeElement), this._size(), this._position(), this._createOverlay(), this._moveToTop(null, !0), this.overlay && this.overlay.css("z-index", this.uiDialog.css("z-index") - 1), this._show(this.uiDialog, this.options.show, function() {
                        t._focusTabbable(), t._trigger("focus")
                    }), this._makeFocusTarget(), this._trigger("open")
                },
                _focusTabbable: function() {
                    var e = this._focusedElement;
                    e || (e = this.element.find("[autofocus]")), e.length || (e = this.element.find(":tabbable")), e.length || (e = this.uiDialogButtonPane.find(":tabbable")), e.length || (e = this.uiDialogTitlebarClose.filter(":tabbable")), e.length || (e = this.uiDialog), e.eq(0).focus()
                },
                _keepFocus: function(t) {
                    function n() {
                        var t = this.document[0].activeElement,
                            n = this.uiDialog[0] === t || e.contains(this.uiDialog[0], t);
                        n || this._focusTabbable()
                    }
                    t.preventDefault(), n.call(this), this._delay(n)
                },
                _createWrapper: function() {
                    this.uiDialog = e("<div>").addClass("ui-dialog ui-widget ui-widget-content ui-corner-all ui-front " + this.options.dialogClass).hide().attr({
                        tabIndex: -1,
                        role: "dialog"
                    }).appendTo(this._appendTo()), this._on(this.uiDialog, {
                        keydown: function(t) {
                            if (this.options.closeOnEscape && !t.isDefaultPrevented() && t.keyCode && t.keyCode === e.ui.keyCode.ESCAPE) {
                                t.preventDefault(), this.close(t);
                                return
                            }
                            if (t.keyCode !== e.ui.keyCode.TAB || t.isDefaultPrevented()) return;
                            var n = this.uiDialog.find(":tabbable"),
                                r = n.filter(":first"),
                                i = n.filter(":last");
                            t.target !== i[0] && t.target !== this.uiDialog[0] || !!t.shiftKey ? (t.target === r[0] || t.target === this.uiDialog[0]) && t.shiftKey && (this._delay(function() {
                                i.focus()
                            }), t.preventDefault()) : (this._delay(function() {
                                r.focus()
                            }), t.preventDefault())
                        },
                        mousedown: function(e) {
                            this._moveToTop(e) && this._focusTabbable()
                        }
                    }), this.element.find("[aria-describedby]").length || this.uiDialog.attr({
                        "aria-describedby": this.element.uniqueId().attr("id")
                    })
                },
                _createTitlebar: function() {
                    var t;
                    this.uiDialogTitlebar = e("<div>").addClass("ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix").prependTo(this.uiDialog), this._on(this.uiDialogTitlebar, {
                        mousedown: function(t) {
                            e(t.target).closest(".ui-dialog-titlebar-close") || this.uiDialog.focus()
                        }
                    }), this.uiDialogTitlebarClose = e("<button type='button'></button>").button({
                        label: this.options.closeText,
                        icons: {
                            primary: "ui-icon-closethick"
                        },
                        text: !1
                    }).addClass("ui-dialog-titlebar-close").appendTo(this.uiDialogTitlebar), this._on(this.uiDialogTitlebarClose, {
                        click: function(e) {
                            e.preventDefault(), this.close(e)
                        }
                    }), t = e("<span>").uniqueId().addClass("ui-dialog-title").prependTo(this.uiDialogTitlebar), this._title(t), this.uiDialog.attr({
                        "aria-labelledby": t.attr("id")
                    })
                },
                _title: function(e) {
                    this.options.title || e.html("&#160;"), e.text(this.options.title)
                },
                _createButtonPane: function() {
                    this.uiDialogButtonPane = e("<div>").addClass("ui-dialog-buttonpane ui-widget-content ui-helper-clearfix"), this.uiButtonSet = e("<div>").addClass("ui-dialog-buttonset").appendTo(this.uiDialogButtonPane), this._createButtons()
                },
                _createButtons: function() {
                    var t = this,
                        n = this.options.buttons;
                    this.uiDialogButtonPane.remove(), this.uiButtonSet.empty();
                    if (e.isEmptyObject(n) || e.isArray(n) && !n.length) {
                        this.uiDialog.removeClass("ui-dialog-buttons");
                        return
                    }
                    e.each(n, function(n, r) {
                        var i, s;
                        r = e.isFunction(r) ? {
                            click: r,
                            text: n
                        } : r, r = e.extend({
                            type: "button"
                        }, r), i = r.click, r.click = function() {
                            i.apply(t.element[0], arguments)
                        }, s = {
                            icons: r.icons,
                            text: r.showText
                        }, delete r.icons, delete r.showText, e("<button></button>", r).button(s).appendTo(t.uiButtonSet)
                    }), this.uiDialog.addClass("ui-dialog-buttons"), this.uiDialogButtonPane.appendTo(this.uiDialog)
                },
                _makeDraggable: function() {
                    function r(e) {
                        return {
                            position: e.position,
                            offset: e.offset
                        }
                    }
                    var t = this,
                        n = this.options;
                    this.uiDialog.draggable({
                        cancel: ".ui-dialog-content, .ui-dialog-titlebar-close",
                        handle: ".ui-dialog-titlebar",
                        containment: "document",
                        start: function(n, i) {
                            e(this).addClass("ui-dialog-dragging"), t._blockFrames(), t._trigger("dragStart", n, r(i))
                        },
                        drag: function(e, n) {
                            t._trigger("drag", e, r(n))
                        },
                        stop: function(i, s) {
                            var o = s.offset.left - t.document.scrollLeft(),
                                u = s.offset.top - t.document.scrollTop();
                            n.position = {
                                my: "left top",
                                at: "left" + (o >= 0 ? "+" : "") + o + " " + "top" + (u >= 0 ? "+" : "") + u,
                                of: t.window
                            }, e(this).removeClass("ui-dialog-dragging"), t._unblockFrames(), t._trigger("dragStop", i, r(s))
                        }
                    })
                },
                _makeResizable: function() {
                    function o(e) {
                        return {
                            originalPosition: e.originalPosition,
                            originalSize: e.originalSize,
                            position: e.position,
                            size: e.size
                        }
                    }
                    var t = this,
                        n = this.options,
                        r = n.resizable,
                        i = this.uiDialog.css("position"),
                        s = typeof r == "string" ? r : "n,e,s,w,se,sw,ne,nw";
                    this.uiDialog.resizable({
                        cancel: ".ui-dialog-content",
                        containment: "document",
                        alsoResize: this.element,
                        maxWidth: n.maxWidth,
                        maxHeight: n.maxHeight,
                        minWidth: n.minWidth,
                        minHeight: this._minHeight(),
                        handles: s,
                        start: function(n, r) {
                            e(this).addClass("ui-dialog-resizing"), t._blockFrames(), t._trigger("resizeStart", n, o(r))
                        },
                        resize: function(e, n) {
                            t._trigger("resize", e, o(n))
                        },
                        stop: function(r, i) {
                            var s = t.uiDialog.offset(),
                                u = s.left - t.document.scrollLeft(),
                                a = s.top - t.document.scrollTop();
                            n.height = t.uiDialog.height(), n.width = t.uiDialog.width(), n.position = {
                                my: "left top",
                                at: "left" + (u >= 0 ? "+" : "") + u + " " + "top" + (a >= 0 ? "+" : "") + a,
                                of: t.window
                            }, e(this).removeClass("ui-dialog-resizing"), t._unblockFrames(), t._trigger("resizeStop", r, o(i))
                        }
                    }).css("position", i)
                },
                _trackFocus: function() {
                    this._on(this.widget(), {
                        focusin: function(t) {
                            this._makeFocusTarget(), this._focusedElement = e(t.target)
                        }
                    })
                },
                _makeFocusTarget: function() {
                    this._untrackInstance(), this._trackingInstances().unshift(this)
                },
                _untrackInstance: function() {
                    var t = this._trackingInstances(),
                        n = e.inArray(this, t);
                    n !== -1 && t.splice(n, 1)
                },
                _trackingInstances: function() {
                    var e = this.document.data("ui-dialog-instances");
                    return e || (e = [], this.document.data("ui-dialog-instances", e)), e
                },
                _minHeight: function() {
                    var e = this.options;
                    return e.height === "auto" ? e.minHeight : Math.min(e.minHeight, e.height)
                },
                _position: function() {
                    var e = this.uiDialog.is(":visible");
                    e || this.uiDialog.show(), this.uiDialog.position(this.options.position), e || this.uiDialog.hide()
                },
                _setOptions: function(t) {
                    var n = this,
                        r = !1,
                        i = {};
                    e.each(t, function(e, t) {
                        n._setOption(e, t), e in n.sizeRelatedOptions && (r = !0), e in n.resizableRelatedOptions && (i[e] = t)
                    }), r && (this._size(), this._position()), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", i)
                },
                _setOption: function(e, t) {
                    var n, r, i = this.uiDialog;
                    e === "dialogClass" && i.removeClass(this.options.dialogClass).addClass(t);
                    if (e === "disabled") return;
                    this._super(e, t), e === "appendTo" && this.uiDialog.appendTo(this._appendTo()), e === "buttons" && this._createButtons(), e === "closeText" && this.uiDialogTitlebarClose.button({
                        label: "" + t
                    }), e === "draggable" && (n = i.is(":data(ui-draggable)"), n && !t && i.draggable("destroy"), !n && t && this._makeDraggable()), e === "position" && this._position(), e === "resizable" && (r = i.is(":data(ui-resizable)"), r && !t && i.resizable("destroy"), r && typeof t == "string" && i.resizable("option", "handles", t), !r && t !== !1 && this._makeResizable()), e === "title" && this._title(this.uiDialogTitlebar.find(".ui-dialog-title"))
                },
                _size: function() {
                    var e, t, n, r = this.options;
                    this.element.show().css({
                        width: "auto",
                        minHeight: 0,
                        maxHeight: "none",
                        height: 0
                    }), r.minWidth > r.width && (r.width = r.minWidth), e = this.uiDialog.css({
                        height: "auto",
                        width: r.width
                    }).outerHeight(), t = Math.max(0, r.minHeight - e), n = typeof r.maxHeight == "number" ? Math.max(0, r.maxHeight - e) : "none", r.height === "auto" ? this.element.css({
                        minHeight: t,
                        maxHeight: n,
                        height: "auto"
                    }) : this.element.height(Math.max(0, r.height - e)), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", "minHeight", this._minHeight())
                },
                _blockFrames: function() {
                    this.iframeBlocks = this.document.find("iframe").map(function() {
                        var t = e(this);
                        return e("<div>").css({
                            position: "absolute",
                            width: t.outerWidth(),
                            height: t.outerHeight()
                        }).appendTo(t.parent()).offset(t.offset())[0]
                    })
                },
                _unblockFrames: function() {
                    this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks)
                },
                _allowInteraction: function(t) {
                    return e(t.target).closest(".ui-dialog").length ? !0 : !!e(t.target).closest(".ui-datepicker").length
                },
                _createOverlay: function() {
                    if (!this.options.modal) return;
                    var t = !0;
                    this._delay(function() {
                        t = !1
                    }), this.document.data("ui-dialog-overlays") || this._on(this.document, {
                        focusin: function(e) {
                            if (t) return;
                            this._allowInteraction(e) || (e.preventDefault(), this._trackingInstances()[0]._focusTabbable())
                        }
                    }), this.overlay = e("<div>").addClass("ui-widget-overlay ui-front").appendTo(this._appendTo()), this._on(this.overlay, {
                        mousedown: "_keepFocus"
                    }), this.document.data("ui-dialog-overlays", (this.document.data("ui-dialog-overlays") || 0) + 1)
                },
                _destroyOverlay: function() {
                    if (!this.options.modal) return;
                    if (this.overlay) {
                        var e = this.document.data("ui-dialog-overlays") - 1;
                        e ? this.document.data("ui-dialog-overlays", e) : this.document.unbind("focusin").removeData("ui-dialog-overlays"), this.overlay.remove(), this.overlay = null
                    }
                }
            });
        e.widget("ui.droppable", {
            version: "1.11.2",
            widgetEventPrefix: "drop",
            options: {
                accept: "*",
                activeClass: !1,
                addClasses: !0,
                greedy: !1,
                hoverClass: !1,
                scope: "default",
                tolerance: "intersect",
                activate: null,
                deactivate: null,
                drop: null,
                out: null,
                over: null
            },
            _create: function() {
                var t, n = this.options,
                    r = n.accept;
                this.isover = !1, this.isout = !0, this.accept = e.isFunction(r) ? r : function(e) {
                    return e.is(r)
                }, this.proportions = function() {
                    if (!arguments.length) return t ? t : t = {
                        width: this.element[0].offsetWidth,
                        height: this.element[0].offsetHeight
                    };
                    t = arguments[0]
                }, this._addToManager(n.scope), n.addClasses && this.element.addClass("ui-droppable")
            },
            _addToManager: function(t) {
                e.ui.ddmanager.droppables[t] = e.ui.ddmanager.droppables[t] || [], e.ui.ddmanager.droppables[t].push(this)
            },
            _splice: function(e) {
                var t = 0;
                for (; t < e.length; t++) e[t] === this && e.splice(t, 1)
            },
            _destroy: function() {
                var t = e.ui.ddmanager.droppables[this.options.scope];
                this._splice(t), this.element.removeClass("ui-droppable ui-droppable-disabled")
            },
            _setOption: function(t, n) {
                if (t === "accept") this.accept = e.isFunction(n) ? n : function(e) {
                    return e.is(n)
                };
                else if (t === "scope") {
                    var r = e.ui.ddmanager.droppables[this.options.scope];
                    this._splice(r), this._addToManager(n)
                }
                this._super(t, n)
            },
            _activate: function(t) {
                var n = e.ui.ddmanager.current;
                this.options.activeClass && this.element.addClass(this.options.activeClass), n && this._trigger("activate", t, this.ui(n))
            },
            _deactivate: function(t) {
                var n = e.ui.ddmanager.current;
                this.options.activeClass && this.element.removeClass(this.options.activeClass), n && this._trigger("deactivate", t, this.ui(n))
            },
            _over: function(t) {
                var n = e.ui.ddmanager.current;
                if (!n || (n.currentItem || n.element)[0] === this.element[0]) return;
                this.accept.call(this.element[0], n.currentItem || n.element) && (this.options.hoverClass && this.element.addClass(this.options.hoverClass), this._trigger("over", t, this.ui(n)))
            },
            _out: function(t) {
                var n = e.ui.ddmanager.current;
                if (!n || (n.currentItem || n.element)[0] === this.element[0]) return;
                this.accept.call(this.element[0], n.currentItem || n.element) && (this.options.hoverClass && this.element.removeClass(this.options.hoverClass), this._trigger("out", t, this.ui(n)))
            },
            _drop: function(t, n) {
                var r = n || e.ui.ddmanager.current,
                    i = !1;
                return !r || (r.currentItem || r.element)[0] === this.element[0] ? !1 : (this.element.find(":data(ui-droppable)").not(".ui-draggable-dragging").each(function() {
                    var n = e(this).droppable("instance");
                    if (n.options.greedy && !n.options.disabled && n.options.scope === r.options.scope && n.accept.call(n.element[0], r.currentItem || r.element) && e.ui.intersect(r, e.extend(n, {
                            offset: n.element.offset()
                        }), n.options.tolerance, t)) return i = !0, !1
                }), i ? !1 : this.accept.call(this.element[0], r.currentItem || r.element) ? (this.options.activeClass && this.element.removeClass(this.options.activeClass), this.options.hoverClass && this.element.removeClass(this.options.hoverClass), this._trigger("drop", t, this.ui(r)), this.element) : !1)
            },
            ui: function(e) {
                return {
                    draggable: e.currentItem || e.element,
                    helper: e.helper,
                    position: e.position,
                    offset: e.positionAbs
                }
            }
        }), e.ui.intersect = function() {
            function e(e, t, n) {
                return e >= t && e < t + n
            }
            return function(t, n, r, i) {
                if (!n.offset) return !1;
                var s = (t.positionAbs || t.position.absolute).left + t.margins.left,
                    o = (t.positionAbs || t.position.absolute).top + t.margins.top,
                    u = s + t.helperProportions.width,
                    a = o + t.helperProportions.height,
                    f = n.offset.left,
                    l = n.offset.top,
                    c = f + n.proportions().width,
                    h = l + n.proportions().height;
                switch (r) {
                    case "fit":
                        return f <= s && u <= c && l <= o && a <= h;
                    case "intersect":
                        return f < s + t.helperProportions.width / 2 && u - t.helperProportions.width / 2 < c && l < o + t.helperProportions.height / 2 && a - t.helperProportions.height / 2 < h;
                    case "pointer":
                        return e(i.pageY, l, n.proportions().height) && e(i.pageX, f, n.proportions().width);
                    case "touch":
                        return (o >= l && o <= h || a >= l && a <= h || o < l && a > h) && (s >= f && s <= c || u >= f && u <= c || s < f && u > c);
                    default:
                        return !1
                }
            }
        }(), e.ui.ddmanager = {
            current: null,
            droppables: {
                "default": []
            },
            prepareOffsets: function(t, n) {
                var r, i, s = e.ui.ddmanager.droppables[t.options.scope] || [],
                    o = n ? n.type : null,
                    u = (t.currentItem || t.element).find(":data(ui-droppable)").addBack();
                e: for (r = 0; r < s.length; r++) {
                    if (s[r].options.disabled || t && !s[r].accept.call(s[r].element[0], t.currentItem || t.element)) continue;
                    for (i = 0; i < u.length; i++)
                        if (u[i] === s[r].element[0]) {
                            s[r].proportions().height = 0;
                            continue e
                        } s[r].visible = s[r].element.css("display") !== "none";
                    if (!s[r].visible) continue;
                    o === "mousedown" && s[r]._activate.call(s[r], n), s[r].offset = s[r].element.offset(), s[r].proportions({
                        width: s[r].element[0].offsetWidth,
                        height: s[r].element[0].offsetHeight
                    })
                }
            },
            drop: function(t, n) {
                var r = !1;
                return e.each((e.ui.ddmanager.droppables[t.options.scope] || []).slice(), function() {
                    if (!this.options) return;
                    !this.options.disabled && this.visible && e.ui.intersect(t, this, this.options.tolerance, n) && (r = this._drop.call(this, n) || r), !this.options.disabled && this.visible && this.accept.call(this.element[0], t.currentItem || t.element) && (this.isout = !0, this.isover = !1, this._deactivate.call(this, n))
                }), r
            },
            dragStart: function(t, n) {
                t.element.parentsUntil("body").bind("scroll.droppable", function() {
                    t.options.refreshPositions || e.ui.ddmanager.prepareOffsets(t, n)
                })
            },
            drag: function(t, n) {
                t.options.refreshPositions && e.ui.ddmanager.prepareOffsets(t, n), e.each(e.ui.ddmanager.droppables[t.options.scope] || [], function() {
                    if (this.options.disabled || this.greedyChild || !this.visible) return;
                    var r, i, s, o = e.ui.intersect(t, this, this.options.tolerance, n),
                        u = !o && this.isover ? "isout" : o && !this.isover ? "isover" : null;
                    if (!u) return;
                    this.options.greedy && (i = this.options.scope, s = this.element.parents(":data(ui-droppable)").filter(function() {
                        return e(this).droppable("instance").options.scope === i
                    }), s.length && (r = e(s[0]).droppable("instance"), r.greedyChild = u === "isover")), r && u === "isover" && (r.isover = !1, r.isout = !0, r._out.call(r, n)), this[u] = !0, this[u === "isout" ? "isover" : "isout"] = !1, this[u === "isover" ? "_over" : "_out"].call(this, n), r && u === "isout" && (r.isout = !1, r.isover = !0, r._over.call(r, n))
                })
            },
            dragStop: function(t, n) {
                t.element.parentsUntil("body").unbind("scroll.droppable"), t.options.refreshPositions || e.ui.ddmanager.prepareOffsets(t, n)
            }
        };
        var L = e.ui.droppable,
            A = "ui-effects-",
            O = e;
        e.effects = {
                effect: {}
            },
            function(e, t) {
                function h(e, t, n) {
                    var r = u[t.type] || {};
                    return e == null ? n || !t.def ? null : t.def : (e = r.floor ? ~~e : parseFloat(e), isNaN(e) ? t.def : r.mod ? (e + r.mod) % r.mod : 0 > e ? 0 : r.max < e ? r.max : e)
                }

                function p(t) {
                    var n = s(),
                        r = n._rgba = [];
                    return t = t.toLowerCase(), c(i, function(e, i) {
                        var s, u = i.re.exec(t),
                            a = u && i.parse(u),
                            f = i.space || "rgba";
                        if (a) return s = n[f](a), n[o[f].cache] = s[o[f].cache], r = n._rgba = s._rgba, !1
                    }), r.length ? (r.join() === "0,0,0,0" && e.extend(r, l.transparent), n) : l[t]
                }

                function d(e, t, n) {
                    return n = (n + 1) % 1, n * 6 < 1 ? e + (t - e) * n * 6 : n * 2 < 1 ? t : n * 3 < 2 ? e + (t - e) * (2 / 3 - n) * 6 : e
                }
                var n = "backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor",
                    r = /^([\-+])=\s*(\d+\.?\d*)/,
                    i = [{
                        re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        parse: function(e) {
                            return [e[1], e[2], e[3], e[4]]
                        }
                    }, {
                        re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        parse: function(e) {
                            return [e[1] * 2.55, e[2] * 2.55, e[3] * 2.55, e[4]]
                        }
                    }, {
                        re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,
                        parse: function(e) {
                            return [parseInt(e[1], 16), parseInt(e[2], 16), parseInt(e[3], 16)]
                        }
                    }, {
                        re: /#([a-f0-9])([a-f0-9])([a-f0-9])/,
                        parse: function(e) {
                            return [parseInt(e[1] + e[1], 16), parseInt(e[2] + e[2], 16), parseInt(e[3] + e[3], 16)]
                        }
                    }, {
                        re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        space: "hsla",
                        parse: function(e) {
                            return [e[1], e[2] / 100, e[3] / 100, e[4]]
                        }
                    }],
                    s = e.Color = function(t, n, r, i) {
                        return new e.Color.fn.parse(t, n, r, i)
                    },
                    o = {
                        rgba: {
                            props: {
                                red: {
                                    idx: 0,
                                    type: "byte"
                                },
                                green: {
                                    idx: 1,
                                    type: "byte"
                                },
                                blue: {
                                    idx: 2,
                                    type: "byte"
                                }
                            }
                        },
                        hsla: {
                            props: {
                                hue: {
                                    idx: 0,
                                    type: "degrees"
                                },
                                saturation: {
                                    idx: 1,
                                    type: "percent"
                                },
                                lightness: {
                                    idx: 2,
                                    type: "percent"
                                }
                            }
                        }
                    },
                    u = {
                        "byte": {
                            floor: !0,
                            max: 255
                        },
                        percent: {
                            max: 1
                        },
                        degrees: {
                            mod: 360,
                            floor: !0
                        }
                    },
                    a = s.support = {},
                    f = e("<p>")[0],
                    l, c = e.each;
                f.style.cssText = "background-color:rgba(1,1,1,.5)", a.rgba = f.style.backgroundColor.indexOf("rgba") > -1, c(o, function(e, t) {
                    t.cache = "_" + e, t.props.alpha = {
                        idx: 3,
                        type: "percent",
                        def: 1
                    }
                }), s.fn = e.extend(s.prototype, {
                    parse: function(n, r, i, u) {
                        if (n === t) return this._rgba = [null, null, null, null], this;
                        if (n.jquery || n.nodeType) n = e(n).css(r), r = t;
                        var a = this,
                            f = e.type(n),
                            d = this._rgba = [];
                        r !== t && (n = [n, r, i, u], f = "array");
                        if (f === "string") return this.parse(p(n) || l._default);
                        if (f === "array") return c(o.rgba.props, function(e, t) {
                            d[t.idx] = h(n[t.idx], t)
                        }), this;
                        if (f === "object") return n instanceof s ? c(o, function(e, t) {
                            n[t.cache] && (a[t.cache] = n[t.cache].slice())
                        }) : c(o, function(t, r) {
                            var i = r.cache;
                            c(r.props, function(e, t) {
                                if (!a[i] && r.to) {
                                    if (e === "alpha" || n[e] == null) return;
                                    a[i] = r.to(a._rgba)
                                }
                                a[i][t.idx] = h(n[e], t, !0)
                            }), a[i] && e.inArray(null, a[i].slice(0, 3)) < 0 && (a[i][3] = 1, r.from && (a._rgba = r.from(a[i])))
                        }), this
                    },
                    is: function(e) {
                        var t = s(e),
                            n = !0,
                            r = this;
                        return c(o, function(e, i) {
                            var s, o = t[i.cache];
                            return o && (s = r[i.cache] || i.to && i.to(r._rgba) || [], c(i.props, function(e, t) {
                                if (o[t.idx] != null) return n = o[t.idx] === s[t.idx], n
                            })), n
                        }), n
                    },
                    _space: function() {
                        var e = [],
                            t = this;
                        return c(o, function(n, r) {
                            t[r.cache] && e.push(n)
                        }), e.pop()
                    },
                    transition: function(e, t) {
                        var n = s(e),
                            r = n._space(),
                            i = o[r],
                            a = this.alpha() === 0 ? s("transparent") : this,
                            f = a[i.cache] || i.to(a._rgba),
                            l = f.slice();
                        return n = n[i.cache], c(i.props, function(e, r) {
                            var i = r.idx,
                                s = f[i],
                                o = n[i],
                                a = u[r.type] || {};
                            if (o === null) return;
                            s === null ? l[i] = o : (a.mod && (o - s > a.mod / 2 ? s += a.mod : s - o > a.mod / 2 && (s -= a.mod)), l[i] = h((o - s) * t + s, r))
                        }), this[r](l)
                    },
                    blend: function(t) {
                        if (this._rgba[3] === 1) return this;
                        var n = this._rgba.slice(),
                            r = n.pop(),
                            i = s(t)._rgba;
                        return s(e.map(n, function(e, t) {
                            return (1 - r) * i[t] + r * e
                        }))
                    },
                    toRgbaString: function() {
                        var t = "rgba(",
                            n = e.map(this._rgba, function(e, t) {
                                return e == null ? t > 2 ? 1 : 0 : e
                            });
                        return n[3] === 1 && (n.pop(), t = "rgb("), t + n.join() + ")"
                    },
                    toHslaString: function() {
                        var t = "hsla(",
                            n = e.map(this.hsla(), function(e, t) {
                                return e == null && (e = t > 2 ? 1 : 0), t && t < 3 && (e = Math.round(e * 100) + "%"), e
                            });
                        return n[3] === 1 && (n.pop(), t = "hsl("), t + n.join() + ")"
                    },
                    toHexString: function(t) {
                        var n = this._rgba.slice(),
                            r = n.pop();
                        return t && n.push(~~(r * 255)), "#" + e.map(n, function(e) {
                            return e = (e || 0).toString(16), e.length === 1 ? "0" + e : e
                        }).join("")
                    },
                    toString: function() {
                        return this._rgba[3] === 0 ? "transparent" : this.toRgbaString()
                    }
                }), s.fn.parse.prototype = s.fn, o.hsla.to = function(e) {
                    if (e[0] == null || e[1] == null || e[2] == null) return [null, null, null, e[3]];
                    var t = e[0] / 255,
                        n = e[1] / 255,
                        r = e[2] / 255,
                        i = e[3],
                        s = Math.max(t, n, r),
                        o = Math.min(t, n, r),
                        u = s - o,
                        a = s + o,
                        f = a * .5,
                        l, c;
                    return o === s ? l = 0 : t === s ? l = 60 * (n - r) / u + 360 : n === s ? l = 60 * (r - t) / u + 120 : l = 60 * (t - n) / u + 240, u === 0 ? c = 0 : f <= .5 ? c = u / a : c = u / (2 - a), [Math.round(l) % 360, c, f, i == null ? 1 : i]
                }, o.hsla.from = function(e) {
                    if (e[0] == null || e[1] == null || e[2] == null) return [null, null, null, e[3]];
                    var t = e[0] / 360,
                        n = e[1],
                        r = e[2],
                        i = e[3],
                        s = r <= .5 ? r * (1 + n) : r + n - r * n,
                        o = 2 * r - s;
                    return [Math.round(d(o, s, t + 1 / 3) * 255), Math.round(d(o, s, t) * 255), Math.round(d(o, s, t - 1 / 3) * 255), i]
                }, c(o, function(n, i) {
                    var o = i.props,
                        u = i.cache,
                        a = i.to,
                        f = i.from;
                    s.fn[n] = function(n) {
                        a && !this[u] && (this[u] = a(this._rgba));
                        if (n === t) return this[u].slice();
                        var r, i = e.type(n),
                            l = i === "array" || i === "object" ? n : arguments,
                            p = this[u].slice();
                        return c(o, function(e, t) {
                            var n = l[i === "object" ? e : t.idx];
                            n == null && (n = p[t.idx]), p[t.idx] = h(n, t)
                        }), f ? (r = s(f(p)), r[u] = p, r) : s(p)
                    }, c(o, function(t, i) {
                        if (s.fn[t]) return;
                        s.fn[t] = function(s) {
                            var o = e.type(s),
                                u = t === "alpha" ? this._hsla ? "hsla" : "rgba" : n,
                                a = this[u](),
                                f = a[i.idx],
                                l;
                            return o === "undefined" ? f : (o === "function" && (s = s.call(this, f), o = e.type(s)), s == null && i.empty ? this : (o === "string" && (l = r.exec(s), l && (s = f + parseFloat(l[2]) * (l[1] === "+" ? 1 : -1))), a[i.idx] = s, this[u](a)))
                        }
                    })
                }), s.hook = function(t) {
                    var n = t.split(" ");
                    c(n, function(t, n) {
                        e.cssHooks[n] = {
                            set: function(t, r) {
                                var i, o, u = "";
                                if (r !== "transparent" && (e.type(r) !== "string" || (i = p(r)))) {
                                    r = s(i || r);
                                    if (!a.rgba && r._rgba[3] !== 1) {
                                        o = n === "backgroundColor" ? t.parentNode : t;
                                        while ((u === "" || u === "transparent") && o && o.style) try {
                                            u = e.css(o, "backgroundColor"), o = o.parentNode
                                        } catch (f) {}
                                        r = r.blend(u && u !== "transparent" ? u : "_default")
                                    }
                                    r = r.toRgbaString()
                                }
                                try {
                                    t.style[n] = r
                                } catch (f) {}
                            }
                        }, e.fx.step[n] = function(t) {
                            t.colorInit || (t.start = s(t.elem, n), t.end = s(t.end), t.colorInit = !0), e.cssHooks[n].set(t.elem, t.start.transition(t.end, t.pos))
                        }
                    })
                }, s.hook(n), e.cssHooks.borderColor = {
                    expand: function(e) {
                        var t = {};
                        return c(["Top", "Right", "Bottom", "Left"], function(n, r) {
                            t["border" + r + "Color"] = e
                        }), t
                    }
                }, l = e.Color.names = {
                    aqua: "#00ffff",
                    black: "#000000",
                    blue: "#0000ff",
                    fuchsia: "#ff00ff",
                    gray: "#808080",
                    green: "#008000",
                    lime: "#00ff00",
                    maroon: "#800000",
                    navy: "#000080",
                    olive: "#808000",
                    purple: "#800080",
                    red: "#ff0000",
                    silver: "#c0c0c0",
                    teal: "#008080",
                    white: "#ffffff",
                    yellow: "#ffff00",
                    transparent: [null, null, null, 0],
                    _default: "#ffffff"
                }
            }(O),
            function() {
                function r(t) {
                    var n, r, i = t.ownerDocument.defaultView ? t.ownerDocument.defaultView.getComputedStyle(t, null) : t.currentStyle,
                        s = {};
                    if (i && i.length && i[0] && i[i[0]]) {
                        r = i.length;
                        while (r--) n = i[r], typeof i[n] == "string" && (s[e.camelCase(n)] = i[n])
                    } else
                        for (n in i) typeof i[n] == "string" && (s[n] = i[n]);
                    return s
                }

                function i(t, r) {
                    var i = {},
                        s, o;
                    for (s in r) o = r[s], t[s] !== o && !n[s] && (e.fx.step[s] || !isNaN(parseFloat(o))) && (i[s] = o);
                    return i
                }
                var t = ["add", "remove", "toggle"],
                    n = {
                        border: 1,
                        borderBottom: 1,
                        borderColor: 1,
                        borderLeft: 1,
                        borderRight: 1,
                        borderTop: 1,
                        borderWidth: 1,
                        margin: 1,
                        padding: 1
                    };
                e.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function(t, n) {
                    e.fx.step[n] = function(e) {
                        if (e.end !== "none" && !e.setAttr || e.pos === 1 && !e.setAttr) O.style(e.elem, n, e.end), e.setAttr = !0
                    }
                }), e.fn.addBack || (e.fn.addBack = function(e) {
                    return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
                }), e.effects.animateClass = function(n, s, o, u) {
                    var a = e.speed(s, o, u);
                    return this.queue(function() {
                        var s = e(this),
                            o = s.attr("class") || "",
                            u, f = a.children ? s.find("*").addBack() : s;
                        f = f.map(function() {
                            var t = e(this);
                            return {
                                el: t,
                                start: r(this)
                            }
                        }), u = function() {
                            e.each(t, function(e, t) {
                                n[t] && s[t + "Class"](n[t])
                            })
                        }, u(), f = f.map(function() {
                            return this.end = r(this.el[0]), this.diff = i(this.start, this.end), this
                        }), s.attr("class", o), f = f.map(function() {
                            var t = this,
                                n = e.Deferred(),
                                r = e.extend({}, a, {
                                    queue: !1,
                                    complete: function() {
                                        n.resolve(t)
                                    }
                                });
                            return this.el.animate(this.diff, r), n.promise()
                        }), e.when.apply(e, f.get()).done(function() {
                            u(), e.each(arguments, function() {
                                var t = this.el;
                                e.each(this.diff, function(e) {
                                    t.css(e, "")
                                })
                            }), a.complete.call(s[0])
                        })
                    })
                }, e.fn.extend({
                    addClass: function(t) {
                        return function(n, r, i, s) {
                            return r ? e.effects.animateClass.call(this, {
                                add: n
                            }, r, i, s) : t.apply(this, arguments)
                        }
                    }(e.fn.addClass),
                    removeClass: function(t) {
                        return function(n, r, i, s) {
                            return arguments.length > 1 ? e.effects.animateClass.call(this, {
                                remove: n
                            }, r, i, s) : t.apply(this, arguments)
                        }
                    }(e.fn.removeClass),
                    toggleClass: function(t) {
                        return function(n, r, i, s, o) {
                            return typeof r == "boolean" || r === undefined ? i ? e.effects.animateClass.call(this, r ? {
                                add: n
                            } : {
                                remove: n
                            }, i, s, o) : t.apply(this, arguments) : e.effects.animateClass.call(this, {
                                toggle: n
                            }, r, i, s)
                        }
                    }(e.fn.toggleClass),
                    switchClass: function(t, n, r, i, s) {
                        return e.effects.animateClass.call(this, {
                            add: n,
                            remove: t
                        }, r, i, s)
                    }
                })
            }(),
            function() {
                function t(t, n, r, i) {
                    e.isPlainObject(t) && (n = t, t = t.effect), t = {
                        effect: t
                    }, n == null && (n = {}), e.isFunction(n) && (i = n, r = null, n = {});
                    if (typeof n == "number" || e.fx.speeds[n]) i = r, r = n, n = {};
                    return e.isFunction(r) && (i = r, r = null), n && e.extend(t, n), r = r || n.duration, t.duration = e.fx.off ? 0 : typeof r == "number" ? r : r in e.fx.speeds ? e.fx.speeds[r] : e.fx.speeds._default, t.complete = i || n.complete, t
                }

                function n(t) {
                    return !t || typeof t == "number" || e.fx.speeds[t] ? !0 : typeof t == "string" && !e.effects.effect[t] ? !0 : e.isFunction(t) ? !0 : typeof t == "object" && !t.effect ? !0 : !1
                }
                e.extend(e.effects, {
                    version: "1.11.2",
                    save: function(e, t) {
                        for (var n = 0; n < t.length; n++) t[n] !== null && e.data(A + t[n], e[0].style[t[n]])
                    },
                    restore: function(e, t) {
                        var n, r;
                        for (r = 0; r < t.length; r++) t[r] !== null && (n = e.data(A + t[r]), n === undefined && (n = ""), e.css(t[r], n))
                    },
                    setMode: function(e, t) {
                        return t === "toggle" && (t = e.is(":hidden") ? "show" : "hide"), t
                    },
                    getBaseline: function(e, t) {
                        var n, r;
                        switch (e[0]) {
                            case "top":
                                n = 0;
                                break;
                            case "middle":
                                n = .5;
                                break;
                            case "bottom":
                                n = 1;
                                break;
                            default:
                                n = e[0] / t.height
                        }
                        switch (e[1]) {
                            case "left":
                                r = 0;
                                break;
                            case "center":
                                r = .5;
                                break;
                            case "right":
                                r = 1;
                                break;
                            default:
                                r = e[1] / t.width
                        }
                        return {
                            x: r,
                            y: n
                        }
                    },
                    createWrapper: function(t) {
                        if (t.parent().is(".ui-effects-wrapper")) return t.parent();
                        var n = {
                                width: t.outerWidth(!0),
                                height: t.outerHeight(!0),
                                "float": t.css("float")
                            },
                            r = e("<div></div>").addClass("ui-effects-wrapper").css({
                                fontSize: "100%",
                                background: "transparent",
                                border: "none",
                                margin: 0,
                                padding: 0
                            }),
                            i = {
                                width: t.width(),
                                height: t.height()
                            },
                            s = document.activeElement;
                        try {
                            s.id
                        } catch (o) {
                            s = document.body
                        }
                        return t.wrap(r), (t[0] === s || e.contains(t[0], s)) && e(s).focus(), r = t.parent(), t.css("position") === "static" ? (r.css({
                            position: "relative"
                        }), t.css({
                            position: "relative"
                        })) : (e.extend(n, {
                            position: t.css("position"),
                            zIndex: t.css("z-index")
                        }), e.each(["top", "left", "bottom", "right"], function(e, r) {
                            n[r] = t.css(r), isNaN(parseInt(n[r], 10)) && (n[r] = "auto")
                        }), t.css({
                            position: "relative",
                            top: 0,
                            left: 0,
                            right: "auto",
                            bottom: "auto"
                        })), t.css(i), r.css(n).show()
                    },
                    removeWrapper: function(t) {
                        var n = document.activeElement;
                        return t.parent().is(".ui-effects-wrapper") && (t.parent().replaceWith(t), (t[0] === n || e.contains(t[0], n)) && e(n).focus()), t
                    },
                    setTransition: function(t, n, r, i) {
                        return i = i || {}, e.each(n, function(e, n) {
                            var s = t.cssUnit(n);
                            s[0] > 0 && (i[n] = s[0] * r + s[1])
                        }), i
                    }
                }), e.fn.extend({
                    effect: function() {
                        function o(t) {
                            function u() {
                                e.isFunction(i) && i.call(r[0]), e.isFunction(t) && t()
                            }
                            var r = e(this),
                                i = n.complete,
                                o = n.mode;
                            (r.is(":hidden") ? o === "hide" : o === "show") ? (r[o](), u()) : s.call(r[0], n, u)
                        }
                        var n = t.apply(this, arguments),
                            r = n.mode,
                            i = n.queue,
                            s = e.effects.effect[n.effect];
                        return e.fx.off || !s ? r ? this[r](n.duration, n.complete) : this.each(function() {
                            n.complete && n.complete.call(this)
                        }) : i === !1 ? this.each(o) : this.queue(i || "fx", o)
                    },
                    show: function(e) {
                        return function(r) {
                            if (n(r)) return e.apply(this, arguments);
                            var i = t.apply(this, arguments);
                            return i.mode = "show", this.effect.call(this, i)
                        }
                    }(e.fn.show),
                    hide: function(e) {
                        return function(r) {
                            if (n(r)) return e.apply(this, arguments);
                            var i = t.apply(this, arguments);
                            return i.mode = "hide", this.effect.call(this, i)
                        }
                    }(e.fn.hide),
                    toggle: function(e) {
                        return function(r) {
                            if (n(r) || typeof r == "boolean") return e.apply(this, arguments);
                            var i = t.apply(this, arguments);
                            return i.mode = "toggle", this.effect.call(this, i)
                        }
                    }(e.fn.toggle),
                    cssUnit: function(t) {
                        var n = this.css(t),
                            r = [];
                        return e.each(["em", "px", "%", "pt"], function(e, t) {
                            n.indexOf(t) > 0 && (r = [parseFloat(n), t])
                        }), r
                    }
                })
            }(),
            function() {
                var t = {};
                e.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function(e, n) {
                    t[n] = function(t) {
                        return Math.pow(t, e + 2)
                    }
                }), e.extend(t, {
                    Sine: function(e) {
                        return 1 - Math.cos(e * Math.PI / 2)
                    },
                    Circ: function(e) {
                        return 1 - Math.sqrt(1 - e * e)
                    },
                    Elastic: function(e) {
                        return e === 0 || e === 1 ? e : -Math.pow(2, 8 * (e - 1)) * Math.sin(((e - 1) * 80 - 7.5) * Math.PI / 15)
                    },
                    Back: function(e) {
                        return e * e * (3 * e - 2)
                    },
                    Bounce: function(e) {
                        var t, n = 4;
                        while (e < ((t = Math.pow(2, --n)) - 1) / 11);
                        return 1 / Math.pow(4, 3 - n) - 7.5625 * Math.pow((t * 3 - 2) / 22 - e, 2)
                    }
                }), e.each(t, function(t, n) {
                    e.easing["easeIn" + t] = n, e.easing["easeOut" + t] = function(e) {
                        return 1 - n(1 - e)
                    }, e.easing["easeInOut" + t] = function(e) {
                        return e < .5 ? n(e * 2) / 2 : 1 - n(e * -2 + 2) / 2
                    }
                })
            }();
        var M = e.effects,
            _ = e.effects.effect.blind = function(t, n) {
                var r = e(this),
                    i = /up|down|vertical/,
                    s = /up|left|vertical|horizontal/,
                    o = ["position", "top", "bottom", "left", "right", "height", "width"],
                    u = e.effects.setMode(r, t.mode || "hide"),
                    a = t.direction || "up",
                    f = i.test(a),
                    l = f ? "height" : "width",
                    c = f ? "top" : "left",
                    h = s.test(a),
                    p = {},
                    d = u === "show",
                    v, m, g;
                r.parent().is(".ui-effects-wrapper") ? e.effects.save(r.parent(), o) : e.effects.save(r, o), r.show(), v = e.effects.createWrapper(r).css({
                    overflow: "hidden"
                }), m = v[l](), g = parseFloat(v.css(c)) || 0, p[l] = d ? m : 0, h || (r.css(f ? "bottom" : "right", 0).css(f ? "top" : "left", "auto").css({
                    position: "absolute"
                }), p[c] = d ? g : m + g), d && (v.css(l, 0), h || v.css(c, g + m)), v.animate(p, {
                    duration: t.duration,
                    easing: t.easing,
                    queue: !1,
                    complete: function() {
                        u === "hide" && r.hide(), e.effects.restore(r, o), e.effects.removeWrapper(r), n()
                    }
                })
            },
            D = e.effects.effect.bounce = function(t, n) {
                var r = e(this),
                    i = ["position", "top", "bottom", "left", "right", "height", "width"],
                    s = e.effects.setMode(r, t.mode || "effect"),
                    o = s === "hide",
                    u = s === "show",
                    a = t.direction || "up",
                    f = t.distance,
                    l = t.times || 5,
                    c = l * 2 + (u || o ? 1 : 0),
                    h = t.duration / c,
                    p = t.easing,
                    d = a === "up" || a === "down" ? "top" : "left",
                    v = a === "up" || a === "left",
                    m, g, y, b = r.queue(),
                    w = b.length;
                (u || o) && i.push("opacity"), e.effects.save(r, i), r.show(), e.effects.createWrapper(r), f || (f = r[d === "top" ? "outerHeight" : "outerWidth"]() / 3), u && (y = {
                    opacity: 1
                }, y[d] = 0, r.css("opacity", 0).css(d, v ? -f * 2 : f * 2).animate(y, h, p)), o && (f /= Math.pow(2, l - 1)), y = {}, y[d] = 0;
                for (m = 0; m < l; m++) g = {}, g[d] = (v ? "-=" : "+=") + f, r.animate(g, h, p).animate(y, h, p), f = o ? f * 2 : f / 2;
                o && (g = {
                    opacity: 0
                }, g[d] = (v ? "-=" : "+=") + f, r.animate(g, h, p)), r.queue(function() {
                    o && r.hide(), e.effects.restore(r, i), e.effects.removeWrapper(r), n()
                }), w > 1 && b.splice.apply(b, [1, 0].concat(b.splice(w, c + 1))), r.dequeue()
            },
            P = e.effects.effect.clip = function(t, n) {
                var r = e(this),
                    i = ["position", "top", "bottom", "left", "right", "height", "width"],
                    s = e.effects.setMode(r, t.mode || "hide"),
                    o = s === "show",
                    u = t.direction || "vertical",
                    a = u === "vertical",
                    f = a ? "height" : "width",
                    l = a ? "top" : "left",
                    c = {},
                    h, p, d;
                e.effects.save(r, i), r.show(), h = e.effects.createWrapper(r).css({
                    overflow: "hidden"
                }), p = r[0].tagName === "IMG" ? h : r, d = p[f](), o && (p.css(f, 0), p.css(l, d / 2)), c[f] = o ? d : 0, c[l] = o ? 0 : d / 2, p.animate(c, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: function() {
                        o || r.hide(), e.effects.restore(r, i), e.effects.removeWrapper(r), n()
                    }
                })
            },
            H = e.effects.effect.drop = function(t, n) {
                var r = e(this),
                    i = ["position", "top", "bottom", "left", "right", "opacity", "height", "width"],
                    s = e.effects.setMode(r, t.mode || "hide"),
                    o = s === "show",
                    u = t.direction || "left",
                    a = u === "up" || u === "down" ? "top" : "left",
                    f = u === "up" || u === "left" ? "pos" : "neg",
                    l = {
                        opacity: o ? 1 : 0
                    },
                    c;
                e.effects.save(r, i), r.show(), e.effects.createWrapper(r), c = t.distance || r[a === "top" ? "outerHeight" : "outerWidth"](!0) / 2, o && r.css("opacity", 0).css(a, f === "pos" ? -c : c), l[a] = (o ? f === "pos" ? "+=" : "-=" : f === "pos" ? "-=" : "+=") + c, r.animate(l, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: function() {
                        s === "hide" && r.hide(), e.effects.restore(r, i), e.effects.removeWrapper(r), n()
                    }
                })
            },
            B = e.effects.effect.explode = function(t, n) {
                function y() {
                    c.push(this), c.length === r * i && b()
                }

                function b() {
                    s.css({
                        visibility: "visible"
                    }), e(c).remove(), u || s.hide(), n()
                }
                var r = t.pieces ? Math.round(Math.sqrt(t.pieces)) : 3,
                    i = r,
                    s = e(this),
                    o = e.effects.setMode(s, t.mode || "hide"),
                    u = o === "show",
                    a = s.show().css("visibility", "hidden").offset(),
                    f = Math.ceil(s.outerWidth() / i),
                    l = Math.ceil(s.outerHeight() / r),
                    c = [],
                    h, p, d, v, m, g;
                for (h = 0; h < r; h++) {
                    v = a.top + h * l, g = h - (r - 1) / 2;
                    for (p = 0; p < i; p++) d = a.left + p * f, m = p - (i - 1) / 2, s.clone().appendTo("body").wrap("<div></div>").css({
                        position: "absolute",
                        visibility: "visible",
                        left: -p * f,
                        top: -h * l
                    }).parent().addClass("ui-effects-explode").css({
                        position: "absolute",
                        overflow: "hidden",
                        width: f,
                        height: l,
                        left: d + (u ? m * f : 0),
                        top: v + (u ? g * l : 0),
                        opacity: u ? 0 : 1
                    }).animate({
                        left: d + (u ? 0 : m * f),
                        top: v + (u ? 0 : g * l),
                        opacity: u ? 1 : 0
                    }, t.duration || 500, t.easing, y)
                }
            },
            j = e.effects.effect.fade = function(t, n) {
                var r = e(this),
                    i = e.effects.setMode(r, t.mode || "toggle");
                r.animate({
                    opacity: i
                }, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: n
                })
            },
            F = e.effects.effect.fold = function(t, n) {
                var r = e(this),
                    i = ["position", "top", "bottom", "left", "right", "height", "width"],
                    s = e.effects.setMode(r, t.mode || "hide"),
                    o = s === "show",
                    u = s === "hide",
                    a = t.size || 15,
                    f = /([0-9]+)%/.exec(a),
                    l = !!t.horizFirst,
                    c = o !== l,
                    h = c ? ["width", "height"] : ["height", "width"],
                    p = t.duration / 2,
                    d, v, m = {},
                    g = {};
                e.effects.save(r, i), r.show(), d = e.effects.createWrapper(r).css({
                    overflow: "hidden"
                }), v = c ? [d.width(), d.height()] : [d.height(), d.width()], f && (a = parseInt(f[1], 10) / 100 * v[u ? 0 : 1]), o && d.css(l ? {
                    height: 0,
                    width: a
                } : {
                    height: a,
                    width: 0
                }), m[h[0]] = o ? v[0] : a, g[h[1]] = o ? v[1] : 0, d.animate(m, p, t.easing).animate(g, p, t.easing, function() {
                    u && r.hide(), e.effects.restore(r, i), e.effects.removeWrapper(r), n()
                })
            },
            I = e.effects.effect.highlight = function(t, n) {
                var r = e(this),
                    i = ["backgroundImage", "backgroundColor", "opacity"],
                    s = e.effects.setMode(r, t.mode || "show"),
                    o = {
                        backgroundColor: r.css("backgroundColor")
                    };
                s === "hide" && (o.opacity = 0), e.effects.save(r, i), r.show().css({
                    backgroundImage: "none",
                    backgroundColor: t.color || "#ffff99"
                }).animate(o, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: function() {
                        s === "hide" && r.hide(), e.effects.restore(r, i), n()
                    }
                })
            },
            q = e.effects.effect.size = function(t, n) {
                var r, i, s, o = e(this),
                    u = ["position", "top", "bottom", "left", "right", "width", "height", "overflow", "opacity"],
                    a = ["position", "top", "bottom", "left", "right", "overflow", "opacity"],
                    f = ["width", "height", "overflow"],
                    l = ["fontSize"],
                    c = ["borderTopWidth", "borderBottomWidth", "paddingTop", "paddingBottom"],
                    h = ["borderLeftWidth", "borderRightWidth", "paddingLeft", "paddingRight"],
                    p = e.effects.setMode(o, t.mode || "effect"),
                    d = t.restore || p !== "effect",
                    v = t.scale || "both",
                    m = t.origin || ["middle", "center"],
                    g = o.css("position"),
                    y = d ? u : a,
                    b = {
                        height: 0,
                        width: 0,
                        outerHeight: 0,
                        outerWidth: 0
                    };
                p === "show" && o.show(), r = {
                    height: o.height(),
                    width: o.width(),
                    outerHeight: o.outerHeight(),
                    outerWidth: o.outerWidth()
                }, t.mode === "toggle" && p === "show" ? (o.from = t.to || b, o.to = t.from || r) : (o.from = t.from || (p === "show" ? b : r), o.to = t.to || (p === "hide" ? b : r)), s = {
                    from: {
                        y: o.from.height / r.height,
                        x: o.from.width / r.width
                    },
                    to: {
                        y: o.to.height / r.height,
                        x: o.to.width / r.width
                    }
                };
                if (v === "box" || v === "both") s.from.y !== s.to.y && (y = y.concat(c), o.from = e.effects.setTransition(o, c, s.from.y, o.from), o.to = e.effects.setTransition(o, c, s.to.y, o.to)), s.from.x !== s.to.x && (y = y.concat(h), o.from = e.effects.setTransition(o, h, s.from.x, o.from), o.to = e.effects.setTransition(o, h, s.to.x, o.to));
                (v === "content" || v === "both") && s.from.y !== s.to.y && (y = y.concat(l).concat(f), o.from = e.effects.setTransition(o, l, s.from.y, o.from), o.to = e.effects.setTransition(o, l, s.to.y, o.to)), e.effects.save(o, y), o.show(), e.effects.createWrapper(o), o.css("overflow", "hidden").css(o.from), m && (i = e.effects.getBaseline(m, r), o.from.top = (r.outerHeight - o.outerHeight()) * i.y, o.from.left = (r.outerWidth - o.outerWidth()) * i.x, o.to.top = (r.outerHeight - o.to.outerHeight) * i.y, o.to.left = (r.outerWidth - o.to.outerWidth) * i.x), o.css(o.from);
                if (v === "content" || v === "both") c = c.concat(["marginTop", "marginBottom"]).concat(l), h = h.concat(["marginLeft", "marginRight"]), f = u.concat(c).concat(h), o.find("*[width]").each(function() {
                    var n = e(this),
                        r = {
                            height: n.height(),
                            width: n.width(),
                            outerHeight: n.outerHeight(),
                            outerWidth: n.outerWidth()
                        };
                    d && e.effects.save(n, f), n.from = {
                        height: r.height * s.from.y,
                        width: r.width * s.from.x,
                        outerHeight: r.outerHeight * s.from.y,
                        outerWidth: r.outerWidth * s.from.x
                    }, n.to = {
                        height: r.height * s.to.y,
                        width: r.width * s.to.x,
                        outerHeight: r.height * s.to.y,
                        outerWidth: r.width * s.to.x
                    }, s.from.y !== s.to.y && (n.from = e.effects.setTransition(n, c, s.from.y, n.from), n.to = e.effects.setTransition(n, c, s.to.y, n.to)), s.from.x !== s.to.x && (n.from = e.effects.setTransition(n, h, s.from.x, n.from), n.to = e.effects.setTransition(n, h, s.to.x, n.to)), n.css(n.from), n.animate(n.to, t.duration, t.easing, function() {
                        d && e.effects.restore(n, f)
                    })
                });
                o.animate(o.to, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: function() {
                        o.to.opacity === 0 && o.css("opacity", o.from.opacity), p === "hide" && o.hide(), e.effects.restore(o, y), d || (g === "static" ? o.css({
                            position: "relative",
                            top: o.to.top,
                            left: o.to.left
                        }) : e.each(["top", "left"], function(e, t) {
                            o.css(t, function(t, n) {
                                var r = parseInt(n, 10),
                                    i = e ? o.to.left : o.to.top;
                                return n === "auto" ? i + "px" : r + i + "px"
                            })
                        })), e.effects.removeWrapper(o), n()
                    }
                })
            },
            R = e.effects.effect.scale = function(t, n) {
                var r = e(this),
                    i = e.extend(!0, {}, t),
                    s = e.effects.setMode(r, t.mode || "effect"),
                    o = parseInt(t.percent, 10) || (parseInt(t.percent, 10) === 0 ? 0 : s === "hide" ? 0 : 100),
                    u = t.direction || "both",
                    a = t.origin,
                    f = {
                        height: r.height(),
                        width: r.width(),
                        outerHeight: r.outerHeight(),
                        outerWidth: r.outerWidth()
                    },
                    l = {
                        y: u !== "horizontal" ? o / 100 : 1,
                        x: u !== "vertical" ? o / 100 : 1
                    };
                i.effect = "size", i.queue = !1, i.complete = n, s !== "effect" && (i.origin = a || ["middle", "center"], i.restore = !0), i.from = t.from || (s === "show" ? {
                    height: 0,
                    width: 0,
                    outerHeight: 0,
                    outerWidth: 0
                } : f), i.to = {
                    height: f.height * l.y,
                    width: f.width * l.x,
                    outerHeight: f.outerHeight * l.y,
                    outerWidth: f.outerWidth * l.x
                }, i.fade && (s === "show" && (i.from.opacity = 0, i.to.opacity = 1), s === "hide" && (i.from.opacity = 1, i.to.opacity = 0)), r.effect(i)
            },
            U = e.effects.effect.puff = function(t, n) {
                var r = e(this),
                    i = e.effects.setMode(r, t.mode || "hide"),
                    s = i === "hide",
                    o = parseInt(t.percent, 10) || 150,
                    u = o / 100,
                    a = {
                        height: r.height(),
                        width: r.width(),
                        outerHeight: r.outerHeight(),
                        outerWidth: r.outerWidth()
                    };
                e.extend(t, {
                    effect: "scale",
                    queue: !1,
                    fade: !0,
                    mode: i,
                    complete: n,
                    percent: s ? o : 100,
                    from: s ? a : {
                        height: a.height * u,
                        width: a.width * u,
                        outerHeight: a.outerHeight * u,
                        outerWidth: a.outerWidth * u
                    }
                }), r.effect(t)
            },
            z = e.effects.effect.pulsate = function(t, n) {
                var r = e(this),
                    i = e.effects.setMode(r, t.mode || "show"),
                    s = i === "show",
                    o = i === "hide",
                    u = s || i === "hide",
                    a = (t.times || 5) * 2 + (u ? 1 : 0),
                    f = t.duration / a,
                    l = 0,
                    c = r.queue(),
                    h = c.length,
                    p;
                if (s || !r.is(":visible")) r.css("opacity", 0).show(), l = 1;
                for (p = 1; p < a; p++) r.animate({
                    opacity: l
                }, f, t.easing), l = 1 - l;
                r.animate({
                    opacity: l
                }, f, t.easing), r.queue(function() {
                    o && r.hide(), n()
                }), h > 1 && c.splice.apply(c, [1, 0].concat(c.splice(h, a + 1))), r.dequeue()
            },
            W = e.effects.effect.shake = function(t, n) {
                var r = e(this),
                    i = ["position", "top", "bottom", "left", "right", "height", "width"],
                    s = e.effects.setMode(r, t.mode || "effect"),
                    o = t.direction || "left",
                    u = t.distance || 20,
                    a = t.times || 3,
                    f = a * 2 + 1,
                    l = Math.round(t.duration / f),
                    c = o === "up" || o === "down" ? "top" : "left",
                    h = o === "up" || o === "left",
                    p = {},
                    d = {},
                    v = {},
                    m, g = r.queue(),
                    y = g.length;
                e.effects.save(r, i), r.show(), e.effects.createWrapper(r), p[c] = (h ? "-=" : "+=") + u, d[c] = (h ? "+=" : "-=") + u * 2, v[c] = (h ? "-=" : "+=") + u * 2, r.animate(p, l, t.easing);
                for (m = 1; m < a; m++) r.animate(d, l, t.easing).animate(v, l, t.easing);
                r.animate(d, l, t.easing).animate(p, l / 2, t.easing).queue(function() {
                    s === "hide" && r.hide(), e.effects.restore(r, i), e.effects.removeWrapper(r), n()
                }), y > 1 && g.splice.apply(g, [1, 0].concat(g.splice(y, f + 1))), r.dequeue()
            },
            X = e.effects.effect.slide = function(t, n) {
                var r = e(this),
                    i = ["position", "top", "bottom", "left", "right", "width", "height"],
                    s = e.effects.setMode(r, t.mode || "show"),
                    o = s === "show",
                    u = t.direction || "left",
                    a = u === "up" || u === "down" ? "top" : "left",
                    f = u === "up" || u === "left",
                    l, c = {};
                e.effects.save(r, i), r.show(), l = t.distance || r[a === "top" ? "outerHeight" : "outerWidth"](!0), e.effects.createWrapper(r).css({
                    overflow: "hidden"
                }), o && r.css(a, f ? isNaN(l) ? "-" + l : -l : l), c[a] = (o ? f ? "+=" : "-=" : f ? "-=" : "+=") + l, r.animate(c, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: function() {
                        s === "hide" && r.hide(), e.effects.restore(r, i), e.effects.removeWrapper(r), n()
                    }
                })
            },
            V = e.effects.effect.transfer = function(t, n) {
                var r = e(this),
                    i = e(t.to),
                    s = i.css("position") === "fixed",
                    o = e("body"),
                    u = s ? o.scrollTop() : 0,
                    a = s ? o.scrollLeft() : 0,
                    f = i.offset(),
                    l = {
                        top: f.top - u,
                        left: f.left - a,
                        height: i.innerHeight(),
                        width: i.innerWidth()
                    },
                    c = r.offset(),
                    h = e("<div class='ui-effects-transfer'></div>").appendTo(document.body).addClass(t.className).css({
                        top: c.top - u,
                        left: c.left - a,
                        height: r.innerHeight(),
                        width: r.innerWidth(),
                        position: s ? "fixed" : "absolute"
                    }).animate(l, t.duration, t.easing, function() {
                        h.remove(), n()
                    })
            },
            $ = e.widget("ui.progressbar", {
                version: "1.11.2",
                options: {
                    max: 100,
                    value: 0,
                    change: null,
                    complete: null
                },
                min: 0,
                _create: function() {
                    this.oldValue = this.options.value = this._constrainedValue(), this.element.addClass("ui-progressbar ui-widget ui-widget-content ui-corner-all").attr({
                        role: "progressbar",
                        "aria-valuemin": this.min
                    }), this.valueDiv = e("<div class='ui-progressbar-value ui-widget-header ui-corner-left'></div>").appendTo(this.element), this._refreshValue()
                },
                _destroy: function() {
                    this.element.removeClass("ui-progressbar ui-widget ui-widget-content ui-corner-all").removeAttr("role").removeAttr("aria-valuemin").removeAttr("aria-valuemax").removeAttr("aria-valuenow"), this.valueDiv.remove()
                },
                value: function(e) {
                    if (e === undefined) return this.options.value;
                    this.options.value = this._constrainedValue(e), this._refreshValue()
                },
                _constrainedValue: function(e) {
                    return e === undefined && (e = this.options.value), this.indeterminate = e === !1, typeof e != "number" && (e = 0), this.indeterminate ? !1 : Math.min(this.options.max, Math.max(this.min, e))
                },
                _setOptions: function(e) {
                    var t = e.value;
                    delete e.value, this._super(e), this.options.value = this._constrainedValue(t), this._refreshValue()
                },
                _setOption: function(e, t) {
                    e === "max" && (t = Math.max(this.min, t)), e === "disabled" && this.element.toggleClass("ui-state-disabled", !!t).attr("aria-disabled", t), this._super(e, t)
                },
                _percentage: function() {
                    return this.indeterminate ? 100 : 100 * (this.options.value - this.min) / (this.options.max - this.min)
                },
                _refreshValue: function() {
                    var t = this.options.value,
                        n = this._percentage();
                    this.valueDiv.toggle(this.indeterminate || t > this.min).toggleClass("ui-corner-right", t === this.options.max).width(n.toFixed(0) + "%"), this.element.toggleClass("ui-progressbar-indeterminate", this.indeterminate), this.indeterminate ? (this.element.removeAttr("aria-valuenow"), this.overlayDiv || (this.overlayDiv = e("<div class='ui-progressbar-overlay'></div>").appendTo(this.valueDiv))) : (this.element.attr({
                        "aria-valuemax": this.options.max,
                        "aria-valuenow": t
                    }), this.overlayDiv && (this.overlayDiv.remove(), this.overlayDiv = null)), this.oldValue !== t && (this.oldValue = t, this._trigger("change")), t === this.options.max && this._trigger("complete")
                }
            }),
            J = e.widget("ui.selectable", e.ui.mouse, {
                version: "1.11.2",
                options: {
                    appendTo: "body",
                    autoRefresh: !0,
                    distance: 0,
                    filter: "*",
                    tolerance: "touch",
                    selected: null,
                    selecting: null,
                    start: null,
                    stop: null,
                    unselected: null,
                    unselecting: null
                },
                _create: function() {
                    var t, n = this;
                    this.element.addClass("ui-selectable"), this.dragged = !1, this.refresh = function() {
                        t = e(n.options.filter, n.element[0]), t.addClass("ui-selectee"), t.each(function() {
                            var t = e(this),
                                n = t.offset();
                            e.data(this, "selectable-item", {
                                element: this,
                                $element: t,
                                left: n.left,
                                top: n.top,
                                right: n.left + t.outerWidth(),
                                bottom: n.top + t.outerHeight(),
                                startselected: !1,
                                selected: t.hasClass("ui-selected"),
                                selecting: t.hasClass("ui-selecting"),
                                unselecting: t.hasClass("ui-unselecting")
                            })
                        })
                    }, this.refresh(), this.selectees = t.addClass("ui-selectee"), this._mouseInit(), this.helper = e("<div class='ui-selectable-helper'></div>")
                },
                _destroy: function() {
                    this.selectees.removeClass("ui-selectee").removeData("selectable-item"), this.element.removeClass("ui-selectable ui-selectable-disabled"), this._mouseDestroy()
                },
                _mouseStart: function(t) {
                    var n = this,
                        r = this.options;
                    this.opos = [t.pageX, t.pageY];
                    if (this.options.disabled) return;
                    this.selectees = e(r.filter, this.element[0]), this._trigger("start", t), e(r.appendTo).append(this.helper), this.helper.css({
                        left: t.pageX,
                        top: t.pageY,
                        width: 0,
                        height: 0
                    }), r.autoRefresh && this.refresh(), this.selectees.filter(".ui-selected").each(function() {
                        var r = e.data(this, "selectable-item");
                        r.startselected = !0, !t.metaKey && !t.ctrlKey && (r.$element.removeClass("ui-selected"), r.selected = !1, r.$element.addClass("ui-unselecting"), r.unselecting = !0, n._trigger("unselecting", t, {
                            unselecting: r.element
                        }))
                    }), e(t.target).parents().addBack().each(function() {
                        var r, i = e.data(this, "selectable-item");
                        if (i) return r = !t.metaKey && !t.ctrlKey || !i.$element.hasClass("ui-selected"), i.$element.removeClass(r ? "ui-unselecting" : "ui-selected").addClass(r ? "ui-selecting" : "ui-unselecting"), i.unselecting = !r, i.selecting = r, i.selected = r, r ? n._trigger("selecting", t, {
                            selecting: i.element
                        }) : n._trigger("unselecting", t, {
                            unselecting: i.element
                        }), !1
                    })
                },
                _mouseDrag: function(t) {
                    this.dragged = !0;
                    if (this.options.disabled) return;
                    var n, r = this,
                        i = this.options,
                        s = this.opos[0],
                        o = this.opos[1],
                        u = t.pageX,
                        a = t.pageY;
                    return s > u && (n = u, u = s, s = n), o > a && (n = a, a = o, o = n), this.helper.css({
                        left: s,
                        top: o,
                        width: u - s,
                        height: a - o
                    }), this.selectees.each(function() {
                        var n = e.data(this, "selectable-item"),
                            f = !1;
                        if (!n || n.element === r.element[0]) return;
                        i.tolerance === "touch" ? f = !(n.left > u || n.right < s || n.top > a || n.bottom < o) : i.tolerance === "fit" && (f = n.left > s && n.right < u && n.top > o && n.bottom < a), f ? (n.selected && (n.$element.removeClass("ui-selected"), n.selected = !1), n.unselecting && (n.$element.removeClass("ui-unselecting"), n.unselecting = !1), n.selecting || (n.$element.addClass("ui-selecting"), n.selecting = !0, r._trigger("selecting", t, {
                            selecting: n.element
                        }))) : (n.selecting && ((t.metaKey || t.ctrlKey) && n.startselected ? (n.$element.removeClass("ui-selecting"), n.selecting = !1, n.$element.addClass("ui-selected"), n.selected = !0) : (n.$element.removeClass("ui-selecting"), n.selecting = !1, n.startselected && (n.$element.addClass("ui-unselecting"), n.unselecting = !0), r._trigger("unselecting", t, {
                            unselecting: n.element
                        }))), n.selected && !t.metaKey && !t.ctrlKey && !n.startselected && (n.$element.removeClass("ui-selected"), n.selected = !1, n.$element.addClass("ui-unselecting"), n.unselecting = !0, r._trigger("unselecting", t, {
                            unselecting: n.element
                        })))
                    }), !1
                },
                _mouseStop: function(t) {
                    var n = this;
                    return this.dragged = !1, e(".ui-unselecting", this.element[0]).each(function() {
                        var r = e.data(this, "selectable-item");
                        r.$element.removeClass("ui-unselecting"), r.unselecting = !1, r.startselected = !1, n._trigger("unselected", t, {
                            unselected: r.element
                        })
                    }), e(".ui-selecting", this.element[0]).each(function() {
                        var r = e.data(this, "selectable-item");
                        r.$element.removeClass("ui-selecting").addClass("ui-selected"), r.selecting = !1, r.selected = !0, r.startselected = !0, n._trigger("selected", t, {
                            selected: r.element
                        })
                    }), this._trigger("stop", t), this.helper.remove(), !1
                }
            }),
            K = e.widget("ui.selectmenu", {
                version: "1.11.2",
                defaultElement: "<select>",
                options: {
                    appendTo: null,
                    disabled: null,
                    icons: {
                        button: "ui-icon-triangle-1-s"
                    },
                    position: {
                        my: "left top",
                        at: "left bottom",
                        collision: "none"
                    },
                    width: null,
                    change: null,
                    close: null,
                    focus: null,
                    open: null,
                    select: null
                },
                _create: function() {
                    var e = this.element.uniqueId().attr("id");
                    this.ids = {
                        element: e,
                        button: e + "-button",
                        menu: e + "-menu"
                    }, this._drawButton(), this._drawMenu(), this.options.disabled && this.disable()
                },
                _drawButton: function() {
                    var t = this,
                        n = this.element.attr("tabindex");
                    this.label = e("label[for='" + this.ids.element + "']").attr("for", this.ids.button), this._on(this.label, {
                        click: function(e) {
                            this.button.focus(), e.preventDefault()
                        }
                    }), this.element.hide(), this.button = e("<span>", {
                        "class": "ui-selectmenu-button ui-widget ui-state-default ui-corner-all",
                        tabindex: n || this.options.disabled ? -1 : 0,
                        id: this.ids.button,
                        role: "combobox",
                        "aria-expanded": "false",
                        "aria-autocomplete": "list",
                        "aria-owns": this.ids.menu,
                        "aria-haspopup": "true"
                    }).insertAfter(this.element), e("<span>", {
                        "class": "ui-icon " + this.options.icons.button
                    }).prependTo(this.button), this.buttonText = e("<span>", {
                        "class": "ui-selectmenu-text"
                    }).appendTo(this.button), this._setText(this.buttonText, this.element.find("option:selected").text()), this._resizeButton(), this._on(this.button, this._buttonEvents), this.button.one("focusin", function() {
                        t.menuItems || t._refreshMenu()
                    }), this._hoverable(this.button), this._focusable(this.button)
                },
                _drawMenu: function() {
                    var t = this;
                    this.menu = e("<ul>", {
                        "aria-hidden": "true",
                        "aria-labelledby": this.ids.button,
                        id: this.ids.menu
                    }), this.menuWrap = e("<div>", {
                        "class": "ui-selectmenu-menu ui-front"
                    }).append(this.menu).appendTo(this._appendTo()), this.menuInstance = this.menu.menu({
                        role: "listbox",
                        select: function(e, n) {
                            e.preventDefault(), t._setSelection(), t._select(n.item.data("ui-selectmenu-item"), e)
                        },
                        focus: function(e, n) {
                            var r = n.item.data("ui-selectmenu-item");
                            t.focusIndex != null && r.index !== t.focusIndex && (t._trigger("focus", e, {
                                item: r
                            }), t.isOpen || t._select(r, e)), t.focusIndex = r.index, t.button.attr("aria-activedescendant", t.menuItems.eq(r.index).attr("id"))
                        }
                    }).menu("instance"), this.menu.addClass("ui-corner-bottom").removeClass("ui-corner-all"), this.menuInstance._off(this.menu, "mouseleave"), this.menuInstance._closeOnDocumentClick = function() {
                        return !1
                    }, this.menuInstance._isDivider = function() {
                        return !1
                    }
                },
                refresh: function() {
                    this._refreshMenu(), this._setText(this.buttonText, this._getSelectedItem().text()), this.options.width || this._resizeButton()
                },
                _refreshMenu: function() {
                    this.menu.empty();
                    var e, t = this.element.find("option");
                    if (!t.length) return;
                    this._parseOptions(t), this._renderMenu(this.menu, this.items), this.menuInstance.refresh(), this.menuItems = this.menu.find("li").not(".ui-selectmenu-optgroup"), e = this._getSelectedItem(), this.menuInstance.focus(null, e), this._setAria(e.data("ui-selectmenu-item")), this._setOption("disabled", this.element.prop("disabled"))
                },
                open: function(e) {
                    if (this.options.disabled) return;
                    this.menuItems ? (this.menu.find(".ui-state-focus").removeClass("ui-state-focus"), this.menuInstance.focus(null, this._getSelectedItem())) : this._refreshMenu(), this.isOpen = !0, this._toggleAttr(), this._resizeMenu(), this._position(), this._on(this.document, this._documentClick), this._trigger("open", e)
                },
                _position: function() {
                    this.menuWrap.position(e.extend({
                        of: this.button
                    }, this.options.position))
                },
                close: function(e) {
                    if (!this.isOpen) return;
                    this.isOpen = !1, this._toggleAttr(), this.range = null, this._off(this.document), this._trigger("close", e)
                },
                widget: function() {
                    return this.button
                },
                menuWidget: function() {
                    return this.menu
                },
                _renderMenu: function(t, n) {
                    var r = this,
                        i = "";
                    e.each(n, function(n, s) {
                        s.optgroup !== i && (e("<li>", {
                            "class": "ui-selectmenu-optgroup ui-menu-divider" + (s.element.parent("optgroup").prop("disabled") ? " ui-state-disabled" : ""),
                            text: s.optgroup
                        }).appendTo(t), i = s.optgroup), r._renderItemData(t, s)
                    })
                },
                _renderItemData: function(e, t) {
                    return this._renderItem(e, t).data("ui-selectmenu-item", t)
                },
                _renderItem: function(t, n) {
                    var r = e("<li>");
                    return n.disabled && r.addClass("ui-state-disabled"), this._setText(r, n.label), r.appendTo(t)
                },
                _setText: function(e, t) {
                    t ? e.text(t) : e.html("&#160;")
                },
                _move: function(e, t) {
                    var n, r, i = ".ui-menu-item";
                    this.isOpen ? n = this.menuItems.eq(this.focusIndex) : (n = this.menuItems.eq(this.element[0].selectedIndex), i += ":not(.ui-state-disabled)"), e === "first" || e === "last" ? r = n[e === "first" ? "prevAll" : "nextAll"](i).eq(-1) : r = n[e + "All"](i).eq(0), r.length && this.menuInstance.focus(t, r)
                },
                _getSelectedItem: function() {
                    return this.menuItems.eq(this.element[0].selectedIndex)
                },
                _toggle: function(e) {
                    this[this.isOpen ? "close" : "open"](e)
                },
                _setSelection: function() {
                    var e;
                    if (!this.range) return;
                    window.getSelection ? (e = window.getSelection(), e.removeAllRanges(), e.addRange(this.range)) : this.range.select(), this.button.focus()
                },
                _documentClick: {
                    mousedown: function(t) {
                        if (!this.isOpen) return;
                        e(t.target).closest(".ui-selectmenu-menu, #" + this.ids.button).length || this.close(t)
                    }
                },
                _buttonEvents: {
                    mousedown: function() {
                        var e;
                        window.getSelection ? (e = window.getSelection(), e.rangeCount && (this.range = e.getRangeAt(0))) : this.range = document.selection.createRange()
                    },
                    click: function(e) {
                        this._setSelection(), this._toggle(e)
                    },
                    keydown: function(t) {
                        var n = !0;
                        switch (t.keyCode) {
                            case e.ui.keyCode.TAB:
                            case e.ui.keyCode.ESCAPE:
                                this.close(t), n = !1;
                                break;
                            case e.ui.keyCode.ENTER:
                                this.isOpen && this._selectFocusedItem(t);
                                break;
                            case e.ui.keyCode.UP:
                                t.altKey ? this._toggle(t) : this._move("prev", t);
                                break;
                            case e.ui.keyCode.DOWN:
                                t.altKey ? this._toggle(t) : this._move("next", t);
                                break;
                            case e.ui.keyCode.SPACE:
                                this.isOpen ? this._selectFocusedItem(t) : this._toggle(t);
                                break;
                            case e.ui.keyCode.LEFT:
                                this._move("prev", t);
                                break;
                            case e.ui.keyCode.RIGHT:
                                this._move("next", t);
                                break;
                            case e.ui.keyCode.HOME:
                            case e.ui.keyCode.PAGE_UP:
                                this._move("first", t);
                                break;
                            case e.ui.keyCode.END:
                            case e.ui.keyCode.PAGE_DOWN:
                                this._move("last", t);
                                break;
                            default:
                                this.menu.trigger(t), n = !1
                        }
                        n && t.preventDefault()
                    }
                },
                _selectFocusedItem: function(e) {
                    var t = this.menuItems.eq(this.focusIndex);
                    t.hasClass("ui-state-disabled") || this._select(t.data("ui-selectmenu-item"), e)
                },
                _select: function(e, t) {
                    var n = this.element[0].selectedIndex;
                    this.element[0].selectedIndex = e.index, this._setText(this.buttonText, e.label), this._setAria(e), this._trigger("select", t, {
                        item: e
                    }), e.index !== n && this._trigger("change", t, {
                        item: e
                    }), this.close(t)
                },
                _setAria: function(e) {
                    var t = this.menuItems.eq(e.index).attr("id");
                    this.button.attr({
                        "aria-labelledby": t,
                        "aria-activedescendant": t
                    }), this.menu.attr("aria-activedescendant", t)
                },
                _setOption: function(e, t) {
                    e === "icons" && this.button.find("span.ui-icon").removeClass(this.options.icons.button).addClass(t.button), this._super(e, t), e === "appendTo" && this.menuWrap.appendTo(this._appendTo()), e === "disabled" && (this.menuInstance.option("disabled", t), this.button.toggleClass("ui-state-disabled", t).attr("aria-disabled", t), this.element.prop("disabled", t), t ? (this.button.attr("tabindex", -1), this.close()) : this.button.attr("tabindex", 0)), e === "width" && this._resizeButton()
                },
                _appendTo: function() {
                    var t = this.options.appendTo;
                    t && (t = t.jquery || t.nodeType ? e(t) : this.document.find(t).eq(0));
                    if (!t || !t[0]) t = this.element.closest(".ui-front");
                    return t.length || (t = this.document[0].body), t
                },
                _toggleAttr: function() {
                    this.button.toggleClass("ui-corner-top", this.isOpen).toggleClass("ui-corner-all", !this.isOpen).attr("aria-expanded", this.isOpen), this.menuWrap.toggleClass("ui-selectmenu-open", this.isOpen), this.menu.attr("aria-hidden", !this.isOpen)
                },
                _resizeButton: function() {
                    var e = this.options.width;
                    e || (e = this.element.show().outerWidth(), this.element.hide()), this.button.outerWidth(e)
                },
                _resizeMenu: function() {
                    this.menu.outerWidth(Math.max(this.button.outerWidth(), this.menu.width("").outerWidth() + 1))
                },
                _getCreateOptions: function() {
                    return {
                        disabled: this.element.prop("disabled")
                    }
                },
                _parseOptions: function(t) {
                    var n = [];
                    t.each(function(t, r) {
                        var i = e(r),
                            s = i.parent("optgroup");
                        n.push({
                            element: i,
                            index: t,
                            value: i.attr("value"),
                            label: i.text(),
                            optgroup: s.attr("label") || "",
                            disabled: s.prop("disabled") || i.prop("disabled")
                        })
                    }), this.items = n
                },
                _destroy: function() {
                    this.menuWrap.remove(), this.button.remove(), this.element.show(), this.element.removeUniqueId(), this.label.attr("for", this.ids.element)
                }
            }),
            Q = e.widget("ui.slider", e.ui.mouse, {
                version: "1.11.2",
                widgetEventPrefix: "slide",
                options: {
                    animate: !1,
                    distance: 0,
                    max: 100,
                    min: 0,
                    orientation: "horizontal",
                    range: !1,
                    step: 1,
                    value: 0,
                    values: null,
                    change: null,
                    slide: null,
                    start: null,
                    stop: null
                },
                numPages: 5,
                _create: function() {
                    this._keySliding = !1, this._mouseSliding = !1, this._animateOff = !0, this._handleIndex = null, this._detectOrientation(), this._mouseInit(), this._calculateNewMax(), this.element.addClass("ui-slider ui-slider-" + this.orientation + " ui-widget" + " ui-widget-content" + " ui-corner-all"), this._refresh(), this._setOption("disabled", this.options.disabled), this._animateOff = !1
                },
                _refresh: function() {
                    this._createRange(), this._createHandles(), this._setupEvents(), this._refreshValue()
                },
                _createHandles: function() {
                    var t, n, r = this.options,
                        i = this.element.find(".ui-slider-handle").addClass("ui-state-default ui-corner-all"),
                        s = "<span class='ui-slider-handle ui-state-default ui-corner-all' tabindex='0'></span>",
                        o = [];
                    n = r.values && r.values.length || 1, i.length > n && (i.slice(n).remove(), i = i.slice(0, n));
                    for (t = i.length; t < n; t++) o.push(s);
                    this.handles = i.add(e(o.join("")).appendTo(this.element)), this.handle = this.handles.eq(0), this.handles.each(function(t) {
                        e(this).data("ui-slider-handle-index", t)
                    })
                },
                _createRange: function() {
                    var t = this.options,
                        n = "";
                    t.range ? (t.range === !0 && (t.values ? t.values.length && t.values.length !== 2 ? t.values = [t.values[0], t.values[0]] : e.isArray(t.values) && (t.values = t.values.slice(0)) : t.values = [this._valueMin(), this._valueMin()]), !this.range || !this.range.length ? (this.range = e("<div></div>").appendTo(this.element), n = "ui-slider-range ui-widget-header ui-corner-all") : this.range.removeClass("ui-slider-range-min ui-slider-range-max").css({
                        left: "",
                        bottom: ""
                    }), this.range.addClass(n + (t.range === "min" || t.range === "max" ? " ui-slider-range-" + t.range : ""))) : (this.range && this.range.remove(), this.range = null)
                },
                _setupEvents: function() {
                    this._off(this.handles), this._on(this.handles, this._handleEvents), this._hoverable(this.handles), this._focusable(this.handles)
                },
                _destroy: function() {
                    this.handles.remove(), this.range && this.range.remove(), this.element.removeClass("ui-slider ui-slider-horizontal ui-slider-vertical ui-widget ui-widget-content ui-corner-all"), this._mouseDestroy()
                },
                _mouseCapture: function(t) {
                    var n, r, i, s, o, u, a, f, l = this,
                        c = this.options;
                    return c.disabled ? !1 : (this.elementSize = {
                        width: this.element.outerWidth(),
                        height: this.element.outerHeight()
                    }, this.elementOffset = this.element.offset(), n = {
                        x: t.pageX,
                        y: t.pageY
                    }, r = this._normValueFromMouse(n), i = this._valueMax() - this._valueMin() + 1, this.handles.each(function(t) {
                        var n = Math.abs(r - l.values(t));
                        if (i > n || i === n && (t === l._lastChangedValue || l.values(t) === c.min)) i = n, s = e(this), o = t
                    }), u = this._start(t, o), u === !1 ? !1 : (this._mouseSliding = !0, this._handleIndex = o, s.addClass("ui-state-active").focus(), a = s.offset(), f = !e(t.target).parents().addBack().is(".ui-slider-handle"), this._clickOffset = f ? {
                        left: 0,
                        top: 0
                    } : {
                        left: t.pageX - a.left - s.width() / 2,
                        top: t.pageY - a.top - s.height() / 2 - (parseInt(s.css("borderTopWidth"), 10) || 0) - (parseInt(s.css("borderBottomWidth"), 10) || 0) + (parseInt(s.css("marginTop"), 10) || 0)
                    }, this.handles.hasClass("ui-state-hover") || this._slide(t, o, r), this._animateOff = !0, !0))
                },
                _mouseStart: function() {
                    return !0
                },
                _mouseDrag: function(e) {
                    var t = {
                            x: e.pageX,
                            y: e.pageY
                        },
                        n = this._normValueFromMouse(t);
                    return this._slide(e, this._handleIndex, n), !1
                },
                _mouseStop: function(e) {
                    return this.handles.removeClass("ui-state-active"), this._mouseSliding = !1, this._stop(e, this._handleIndex), this._change(e, this._handleIndex), this._handleIndex = null, this._clickOffset = null, this._animateOff = !1, !1
                },
                _detectOrientation: function() {
                    this.orientation = this.options.orientation === "vertical" ? "vertical" : "horizontal"
                },
                _normValueFromMouse: function(e) {
                    var t, n, r, i, s;
                    return this.orientation === "horizontal" ? (t = this.elementSize.width, n = e.x - this.elementOffset.left - (this._clickOffset ? this._clickOffset.left : 0)) : (t = this.elementSize.height, n = e.y - this.elementOffset.top - (this._clickOffset ? this._clickOffset.top : 0)), r = n / t, r > 1 && (r = 1), r < 0 && (r = 0), this.orientation === "vertical" && (r = 1 - r), i = this._valueMax() - this._valueMin(), s = this._valueMin() + r * i, this._trimAlignValue(s)
                },
                _start: function(e, t) {
                    var n = {
                        handle: this.handles[t],
                        value: this.value()
                    };
                    return this.options.values && this.options.values.length && (n.value = this.values(t), n.values = this.values()), this._trigger("start", e, n)
                },
                _slide: function(e, t, n) {
                    var r, i, s;
                    this.options.values && this.options.values.length ? (r = this.values(t ? 0 : 1), this.options.values.length === 2 && this.options.range === !0 && (t === 0 && n > r || t === 1 && n < r) && (n = r), n !== this.values(t) && (i = this.values(), i[t] = n, s = this._trigger("slide", e, {
                        handle: this.handles[t],
                        value: n,
                        values: i
                    }), r = this.values(t ? 0 : 1), s !== !1 && this.values(t, n))) : n !== this.value() && (s = this._trigger("slide", e, {
                        handle: this.handles[t],
                        value: n
                    }), s !== !1 && this.value(n))
                },
                _stop: function(e, t) {
                    var n = {
                        handle: this.handles[t],
                        value: this.value()
                    };
                    this.options.values && this.options.values.length && (n.value = this.values(t), n.values = this.values()), this._trigger("stop", e, n)
                },
                _change: function(e, t) {
                    if (!this._keySliding && !this._mouseSliding) {
                        var n = {
                            handle: this.handles[t],
                            value: this.value()
                        };
                        this.options.values && this.options.values.length && (n.value = this.values(t), n.values = this.values()), this._lastChangedValue = t, this._trigger("change", e, n)
                    }
                },
                value: function(e) {
                    if (arguments.length) {
                        this.options.value = this._trimAlignValue(e), this._refreshValue(), this._change(null, 0);
                        return
                    }
                    return this._value()
                },
                values: function(t, n) {
                    var r, i, s;
                    if (arguments.length > 1) {
                        this.options.values[t] = this._trimAlignValue(n), this._refreshValue(), this._change(null, t);
                        return
                    }
                    if (!arguments.length) return this._values();
                    if (!e.isArray(arguments[0])) return this.options.values && this.options.values.length ? this._values(t) : this.value();
                    r = this.options.values, i = arguments[0];
                    for (s = 0; s < r.length; s += 1) r[s] = this._trimAlignValue(i[s]), this._change(null, s);
                    this._refreshValue()
                },
                _setOption: function(t, n) {
                    var r, i = 0;
                    t === "range" && this.options.range === !0 && (n === "min" ? (this.options.value = this._values(0), this.options.values = null) : n === "max" && (this.options.value = this._values(this.options.values.length - 1), this.options.values = null)), e.isArray(this.options.values) && (i = this.options.values.length), t === "disabled" && this.element.toggleClass("ui-state-disabled", !!n), this._super(t, n);
                    switch (t) {
                        case "orientation":
                            this._detectOrientation(), this.element.removeClass("ui-slider-horizontal ui-slider-vertical").addClass("ui-slider-" + this.orientation), this._refreshValue(), this.handles.css(n === "horizontal" ? "bottom" : "left", "");
                            break;
                        case "value":
                            this._animateOff = !0, this._refreshValue(), this._change(null, 0), this._animateOff = !1;
                            break;
                        case "values":
                            this._animateOff = !0, this._refreshValue();
                            for (r = 0; r < i; r += 1) this._change(null, r);
                            this._animateOff = !1;
                            break;
                        case "step":
                        case "min":
                        case "max":
                            this._animateOff = !0, this._calculateNewMax(), this._refreshValue(), this._animateOff = !1;
                            break;
                        case "range":
                            this._animateOff = !0, this._refresh(), this._animateOff = !1
                    }
                },
                _value: function() {
                    var e = this.options.value;
                    return e = this._trimAlignValue(e), e
                },
                _values: function(e) {
                    var t, n, r;
                    if (arguments.length) return t = this.options.values[e], t = this._trimAlignValue(t), t;
                    if (this.options.values && this.options.values.length) {
                        n = this.options.values.slice();
                        for (r = 0; r < n.length; r += 1) n[r] = this._trimAlignValue(n[r]);
                        return n
                    }
                    return []
                },
                _trimAlignValue: function(e) {
                    if (e <= this._valueMin()) return this._valueMin();
                    if (e >= this._valueMax()) return this._valueMax();
                    var t = this.options.step > 0 ? this.options.step : 1,
                        n = (e - this._valueMin()) % t,
                        r = e - n;
                    return Math.abs(n) * 2 >= t && (r += n > 0 ? t : -t), parseFloat(r.toFixed(5))
                },
                _calculateNewMax: function() {
                    var e = (this.options.max - this._valueMin()) % this.options.step;
                    this.max = this.options.max - e
                },
                _valueMin: function() {
                    return this.options.min
                },
                _valueMax: function() {
                    return this.max
                },
                _refreshValue: function() {
                    var t, n, r, i, s, o = this.options.range,
                        u = this.options,
                        a = this,
                        f = this._animateOff ? !1 : u.animate,
                        l = {};
                    this.options.values && this.options.values.length ? this.handles.each(function(r) {
                        n = (a.values(r) - a._valueMin()) / (a._valueMax() - a._valueMin()) * 100, l[a.orientation === "horizontal" ? "left" : "bottom"] = n + "%", e(this).stop(1, 1)[f ? "animate" : "css"](l, u.animate), a.options.range === !0 && (a.orientation === "horizontal" ? (r === 0 && a.range.stop(1, 1)[f ? "animate" : "css"]({
                            left: n + "%"
                        }, u.animate), r === 1 && a.range[f ? "animate" : "css"]({
                            width: n - t + "%"
                        }, {
                            queue: !1,
                            duration: u.animate
                        })) : (r === 0 && a.range.stop(1, 1)[f ? "animate" : "css"]({
                            bottom: n + "%"
                        }, u.animate), r === 1 && a.range[f ? "animate" : "css"]({
                            height: n - t + "%"
                        }, {
                            queue: !1,
                            duration: u.animate
                        }))), t = n
                    }) : (r = this.value(), i = this._valueMin(), s = this._valueMax(), n = s !== i ? (r - i) / (s - i) * 100 : 0, l[this.orientation === "horizontal" ? "left" : "bottom"] = n + "%", this.handle.stop(1, 1)[f ? "animate" : "css"](l, u.animate), o === "min" && this.orientation === "horizontal" && this.range.stop(1, 1)[f ? "animate" : "css"]({
                        width: n + "%"
                    }, u.animate), o === "max" && this.orientation === "horizontal" && this.range[f ? "animate" : "css"]({
                        width: 100 - n + "%"
                    }, {
                        queue: !1,
                        duration: u.animate
                    }), o === "min" && this.orientation === "vertical" && this.range.stop(1, 1)[f ? "animate" : "css"]({
                        height: n + "%"
                    }, u.animate), o === "max" && this.orientation === "vertical" && this.range[f ? "animate" : "css"]({
                        height: 100 - n + "%"
                    }, {
                        queue: !1,
                        duration: u.animate
                    }))
                },
                _handleEvents: {
                    keydown: function(t) {
                        var n, r, i, s, o = e(t.target).data("ui-slider-handle-index");
                        switch (t.keyCode) {
                            case e.ui.keyCode.HOME:
                            case e.ui.keyCode.END:
                            case e.ui.keyCode.PAGE_UP:
                            case e.ui.keyCode.PAGE_DOWN:
                            case e.ui.keyCode.UP:
                            case e.ui.keyCode.RIGHT:
                            case e.ui.keyCode.DOWN:
                            case e.ui.keyCode.LEFT:
                                t.preventDefault();
                                if (!this._keySliding) {
                                    this._keySliding = !0, e(t.target).addClass("ui-state-active"), n = this._start(t, o);
                                    if (n === !1) return
                                }
                        }
                        s = this.options.step, this.options.values && this.options.values.length ? r = i = this.values(o) : r = i = this.value();
                        switch (t.keyCode) {
                            case e.ui.keyCode.HOME:
                                i = this._valueMin();
                                break;
                            case e.ui.keyCode.END:
                                i = this._valueMax();
                                break;
                            case e.ui.keyCode.PAGE_UP:
                                i = this._trimAlignValue(r + (this._valueMax() - this._valueMin()) / this.numPages);
                                break;
                            case e.ui.keyCode.PAGE_DOWN:
                                i = this._trimAlignValue(r - (this._valueMax() - this._valueMin()) / this.numPages);
                                break;
                            case e.ui.keyCode.UP:
                            case e.ui.keyCode.RIGHT:
                                if (r === this._valueMax()) return;
                                i = this._trimAlignValue(r + s);
                                break;
                            case e.ui.keyCode.DOWN:
                            case e.ui.keyCode.LEFT:
                                if (r === this._valueMin()) return;
                                i = this._trimAlignValue(r - s)
                        }
                        this._slide(t, o, i)
                    },
                    keyup: function(t) {
                        var n = e(t.target).data("ui-slider-handle-index");
                        this._keySliding && (this._keySliding = !1, this._stop(t, n), this._change(t, n), e(t.target).removeClass("ui-state-active"))
                    }
                }
            }),
            G = e.widget("ui.sortable", e.ui.mouse, {
                version: "1.11.2",
                widgetEventPrefix: "sort",
                ready: !1,
                options: {
                    appendTo: "parent",
                    axis: !1,
                    connectWith: !1,
                    containment: !1,
                    cursor: "auto",
                    cursorAt: !1,
                    dropOnEmpty: !0,
                    forcePlaceholderSize: !1,
                    forceHelperSize: !1,
                    grid: !1,
                    handle: !1,
                    helper: "original",
                    items: "> *",
                    opacity: !1,
                    placeholder: !1,
                    revert: !1,
                    scroll: !0,
                    scrollSensitivity: 20,
                    scrollSpeed: 20,
                    scope: "default",
                    tolerance: "intersect",
                    zIndex: 1e3,
                    activate: null,
                    beforeStop: null,
                    change: null,
                    deactivate: null,
                    out: null,
                    over: null,
                    receive: null,
                    remove: null,
                    sort: null,
                    start: null,
                    stop: null,
                    update: null
                },
                _isOverAxis: function(e, t, n) {
                    return e >= t && e < t + n
                },
                _isFloating: function(e) {
                    return /left|right/.test(e.css("float")) || /inline|table-cell/.test(e.css("display"))
                },
                _create: function() {
                    var e = this.options;
                    this.containerCache = {}, this.element.addClass("ui-sortable"), this.refresh(), this.floating = this.items.length ? e.axis === "x" || this._isFloating(this.items[0].item) : !1, this.offset = this.element.offset(), this._mouseInit(), this._setHandleClassName(), this.ready = !0
                },
                _setOption: function(e, t) {
                    this._super(e, t), e === "handle" && this._setHandleClassName()
                },
                _setHandleClassName: function() {
                    this.element.find(".ui-sortable-handle").removeClass("ui-sortable-handle"), e.each(this.items, function() {
                        (this.instance.options.handle ? this.item.find(this.instance.options.handle) : this.item).addClass("ui-sortable-handle")
                    })
                },
                _destroy: function() {
                    this.element.removeClass("ui-sortable ui-sortable-disabled").find(".ui-sortable-handle").removeClass("ui-sortable-handle"), this._mouseDestroy();
                    for (var e = this.items.length - 1; e >= 0; e--) this.items[e].item.removeData(this.widgetName + "-item");
                    return this
                },
                _mouseCapture: function(t, n) {
                    var r = null,
                        i = !1,
                        s = this;
                    if (this.reverting) return !1;
                    if (this.options.disabled || this.options.type === "static") return !1;
                    this._refreshItems(t), e(t.target).parents().each(function() {
                        if (e.data(this, s.widgetName + "-item") === s) return r = e(this), !1
                    }), e.data(t.target, s.widgetName + "-item") === s && (r = e(t.target));
                    if (!r) return !1;
                    if (this.options.handle && !n) {
                        e(this.options.handle, r).find("*").addBack().each(function() {
                            this === t.target && (i = !0)
                        });
                        if (!i) return !1
                    }
                    return this.currentItem = r, this._removeCurrentsFromItems(), !0
                },
                _mouseStart: function(t, n, r) {
                    var i, s, o = this.options;
                    this.currentContainer = this, this.refreshPositions(), this.helper = this._createHelper(t), this._cacheHelperProportions(), this._cacheMargins(), this.scrollParent = this.helper.scrollParent(), this.offset = this.currentItem.offset(), this.offset = {
                        top: this.offset.top - this.margins.top,
                        left: this.offset.left - this.margins.left
                    }, e.extend(this.offset, {
                        click: {
                            left: t.pageX - this.offset.left,
                            top: t.pageY - this.offset.top
                        },
                        parent: this._getParentOffset(),
                        relative: this._getRelativeOffset()
                    }), this.helper.css("position", "absolute"), this.cssPosition = this.helper.css("position"), this.originalPosition = this._generatePosition(t), this.originalPageX = t.pageX, this.originalPageY = t.pageY, o.cursorAt && this._adjustOffsetFromHelper(o.cursorAt), this.domPosition = {
                        prev: this.currentItem.prev()[0],
                        parent: this.currentItem.parent()[0]
                    }, this.helper[0] !== this.currentItem[0] && this.currentItem.hide(), this._createPlaceholder(), o.containment && this._setContainment(), o.cursor && o.cursor !== "auto" && (s = this.document.find("body"), this.storedCursor = s.css("cursor"), s.css("cursor", o.cursor), this.storedStylesheet = e("<style>*{ cursor: " + o.cursor + " !important; }</style>").appendTo(s)), o.opacity && (this.helper.css("opacity") && (this._storedOpacity = this.helper.css("opacity")), this.helper.css("opacity", o.opacity)), o.zIndex && (this.helper.css("zIndex") && (this._storedZIndex = this.helper.css("zIndex")), this.helper.css("zIndex", o.zIndex)), this.scrollParent[0] !== document && this.scrollParent[0].tagName !== "HTML" && (this.overflowOffset = this.scrollParent.offset()), this._trigger("start", t, this._uiHash()), this._preserveHelperProportions || this._cacheHelperProportions();
                    if (!r)
                        for (i = this.containers.length - 1; i >= 0; i--) this.containers[i]._trigger("activate", t, this._uiHash(this));
                    return e.ui.ddmanager && (e.ui.ddmanager.current = this), e.ui.ddmanager && !o.dropBehaviour && e.ui.ddmanager.prepareOffsets(this, t), this.dragging = !0, this.helper.addClass("ui-sortable-helper"), this._mouseDrag(t), !0
                },
                _mouseDrag: function(t) {
                    var n, r, i, s, o = this.options,
                        u = !1;
                    this.position = this._generatePosition(t), this.positionAbs = this._convertPositionTo("absolute"), this.lastPositionAbs || (this.lastPositionAbs = this.positionAbs), this.options.scroll && (this.scrollParent[0] !== document && this.scrollParent[0].tagName !== "HTML" ? (this.overflowOffset.top + this.scrollParent[0].offsetHeight - t.pageY < o.scrollSensitivity ? this.scrollParent[0].scrollTop = u = this.scrollParent[0].scrollTop + o.scrollSpeed : t.pageY - this.overflowOffset.top < o.scrollSensitivity && (this.scrollParent[0].scrollTop = u = this.scrollParent[0].scrollTop - o.scrollSpeed), this.overflowOffset.left + this.scrollParent[0].offsetWidth - t.pageX < o.scrollSensitivity ? this.scrollParent[0].scrollLeft = u = this.scrollParent[0].scrollLeft + o.scrollSpeed : t.pageX - this.overflowOffset.left < o.scrollSensitivity && (this.scrollParent[0].scrollLeft = u = this.scrollParent[0].scrollLeft - o.scrollSpeed)) : (t.pageY - e(document).scrollTop() < o.scrollSensitivity ? u = e(document).scrollTop(e(document).scrollTop() - o.scrollSpeed) : e(window).height() - (t.pageY - e(document).scrollTop()) < o.scrollSensitivity && (u = e(document).scrollTop(e(document).scrollTop() + o.scrollSpeed)), t.pageX - e(document).scrollLeft() < o.scrollSensitivity ? u = e(document).scrollLeft(e(document).scrollLeft() - o.scrollSpeed) : e(window).width() - (t.pageX - e(document).scrollLeft()) < o.scrollSensitivity && (u = e(document).scrollLeft(e(document).scrollLeft() + o.scrollSpeed))), u !== !1 && e.ui.ddmanager && !o.dropBehaviour && e.ui.ddmanager.prepareOffsets(this, t)), this.positionAbs = this._convertPositionTo("absolute");
                    if (!this.options.axis || this.options.axis !== "y") this.helper[0].style.left = this.position.left + "px";
                    if (!this.options.axis || this.options.axis !== "x") this.helper[0].style.top = this.position.top + "px";
                    for (n = this.items.length - 1; n >= 0; n--) {
                        r = this.items[n], i = r.item[0], s = this._intersectsWithPointer(r);
                        if (!s) continue;
                        if (r.instance !== this.currentContainer) continue;
                        if (i !== this.currentItem[0] && this.placeholder[s === 1 ? "next" : "prev"]()[0] !== i && !e.contains(this.placeholder[0], i) && (this.options.type === "semi-dynamic" ? !e.contains(this.element[0], i) : !0)) {
                            this.direction = s === 1 ? "down" : "up";
                            if (this.options.tolerance !== "pointer" && !this._intersectsWithSides(r)) break;
                            this._rearrange(t, r), this._trigger("change", t, this._uiHash());
                            break
                        }
                    }
                    return this._contactContainers(t), e.ui.ddmanager && e.ui.ddmanager.drag(this, t), this._trigger("sort", t, this._uiHash()), this.lastPositionAbs = this.positionAbs, !1
                },
                _mouseStop: function(t, n) {
                    if (!t) return;
                    e.ui.ddmanager && !this.options.dropBehaviour && e.ui.ddmanager.drop(this, t);
                    if (this.options.revert) {
                        var r = this,
                            i = this.placeholder.offset(),
                            s = this.options.axis,
                            o = {};
                        if (!s || s === "x") o.left = i.left - this.offset.parent.left - this.margins.left + (this.offsetParent[0] === document.body ? 0 : this.offsetParent[0].scrollLeft);
                        if (!s || s === "y") o.top = i.top - this.offset.parent.top - this.margins.top + (this.offsetParent[0] === document.body ? 0 : this.offsetParent[0].scrollTop);
                        this.reverting = !0, e(this.helper).animate(o, parseInt(this.options.revert, 10) || 500, function() {
                            r._clear(t)
                        })
                    } else this._clear(t, n);
                    return !1
                },
                cancel: function() {
                    if (this.dragging) {
                        this._mouseUp({
                            target: null
                        }), this.options.helper === "original" ? this.currentItem.css(this._storedCSS).removeClass("ui-sortable-helper") : this.currentItem.show();
                        for (var t = this.containers.length - 1; t >= 0; t--) this.containers[t]._trigger("deactivate", null, this._uiHash(this)), this.containers[t].containerCache.over && (this.containers[t]._trigger("out", null, this._uiHash(this)), this.containers[t].containerCache.over = 0)
                    }
                    return this.placeholder && (this.placeholder[0].parentNode && this.placeholder[0].parentNode.removeChild(this.placeholder[0]), this.options.helper !== "original" && this.helper && this.helper[0].parentNode && this.helper.remove(), e.extend(this, {
                        helper: null,
                        dragging: !1,
                        reverting: !1,
                        _noFinalSort: null
                    }), this.domPosition.prev ? e(this.domPosition.prev).after(this.currentItem) : e(this.domPosition.parent).prepend(this.currentItem)), this
                },
                serialize: function(t) {
                    var n = this._getItemsAsjQuery(t && t.connected),
                        r = [];
                    return t = t || {}, e(n).each(function() {
                        var n = (e(t.item || this).attr(t.attribute || "id") || "").match(t.expression || /(.+)[\-=_](.+)/);
                        n && r.push((t.key || n[1] + "[]") + "=" + (t.key && t.expression ? n[1] : n[2]))
                    }), !r.length && t.key && r.push(t.key + "="), r.join("&")
                },
                toArray: function(t) {
                    var n = this._getItemsAsjQuery(t && t.connected),
                        r = [];
                    return t = t || {}, n.each(function() {
                        r.push(e(t.item || this).attr(t.attribute || "id") || "")
                    }), r
                },
                _intersectsWith: function(e) {
                    var t = this.positionAbs.left,
                        n = t + this.helperProportions.width,
                        r = this.positionAbs.top,
                        i = r + this.helperProportions.height,
                        s = e.left,
                        o = s + e.width,
                        u = e.top,
                        a = u + e.height,
                        f = this.offset.click.top,
                        l = this.offset.click.left,
                        c = this.options.axis === "x" || r + f > u && r + f < a,
                        h = this.options.axis === "y" || t + l > s && t + l < o,
                        p = c && h;
                    return this.options.tolerance === "pointer" || this.options.forcePointerForContainers || this.options.tolerance !== "pointer" && this.helperProportions[this.floating ? "width" : "height"] > e[this.floating ? "width" : "height"] ? p : s < t + this.helperProportions.width / 2 && n - this.helperProportions.width / 2 < o && u < r + this.helperProportions.height / 2 && i - this.helperProportions.height / 2 < a
                },
                _intersectsWithPointer: function(e) {
                    var t = this.options.axis === "x" || this._isOverAxis(this.positionAbs.top + this.offset.click.top, e.top, e.height),
                        n = this.options.axis === "y" || this._isOverAxis(this.positionAbs.left + this.offset.click.left, e.left, e.width),
                        r = t && n,
                        i = this._getDragVerticalDirection(),
                        s = this._getDragHorizontalDirection();
                    return r ? this.floating ? s && s === "right" || i === "down" ? 2 : 1 : i && (i === "down" ? 2 : 1) : !1
                },
                _intersectsWithSides: function(e) {
                    var t = this._isOverAxis(this.positionAbs.top + this.offset.click.top, e.top + e.height / 2, e.height),
                        n = this._isOverAxis(this.positionAbs.left + this.offset.click.left, e.left + e.width / 2, e.width),
                        r = this._getDragVerticalDirection(),
                        i = this._getDragHorizontalDirection();
                    return this.floating && i ? i === "right" && n || i === "left" && !n : r && (r === "down" && t || r === "up" && !t)
                },
                _getDragVerticalDirection: function() {
                    var e = this.positionAbs.top - this.lastPositionAbs.top;
                    return e !== 0 && (e > 0 ? "down" : "up")
                },
                _getDragHorizontalDirection: function() {
                    var e = this.positionAbs.left - this.lastPositionAbs.left;
                    return e !== 0 && (e > 0 ? "right" : "left")
                },
                refresh: function(e) {
                    return this._refreshItems(e), this._setHandleClassName(), this.refreshPositions(), this
                },
                _connectWith: function() {
                    var e = this.options;
                    return e.connectWith.constructor === String ? [e.connectWith] : e.connectWith
                },
                _getItemsAsjQuery: function(t) {
                    function f() {
                        o.push(this)
                    }
                    var n, r, i, s, o = [],
                        u = [],
                        a = this._connectWith();
                    if (a && t)
                        for (n = a.length - 1; n >= 0; n--) {
                            i = e(a[n]);
                            for (r = i.length - 1; r >= 0; r--) s = e.data(i[r], this.widgetFullName), s && s !== this && !s.options.disabled && u.push([e.isFunction(s.options.items) ? s.options.items.call(s.element) : e(s.options.items, s.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), s])
                        }
                    u.push([e.isFunction(this.options.items) ? this.options.items.call(this.element, null, {
                        options: this.options,
                        item: this.currentItem
                    }) : e(this.options.items, this.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), this]);
                    for (n = u.length - 1; n >= 0; n--) u[n][0].each(f);
                    return e(o)
                },
                _removeCurrentsFromItems: function() {
                    var t = this.currentItem.find(":data(" + this.widgetName + "-item)");
                    this.items = e.grep(this.items, function(e) {
                        for (var n = 0; n < t.length; n++)
                            if (t[n] === e.item[0]) return !1;
                        return !0
                    })
                },
                _refreshItems: function(t) {
                    this.items = [], this.containers = [this];
                    var n, r, i, s, o, u, a, f, l = this.items,
                        c = [
                            [e.isFunction(this.options.items) ? this.options.items.call(this.element[0], t, {
                                item: this.currentItem
                            }) : e(this.options.items, this.element), this]
                        ],
                        h = this._connectWith();
                    if (h && this.ready)
                        for (n = h.length - 1; n >= 0; n--) {
                            i = e(h[n]);
                            for (r = i.length - 1; r >= 0; r--) s = e.data(i[r], this.widgetFullName), s && s !== this && !s.options.disabled && (c.push([e.isFunction(s.options.items) ? s.options.items.call(s.element[0], t, {
                                item: this.currentItem
                            }) : e(s.options.items, s.element), s]), this.containers.push(s))
                        }
                    for (n = c.length - 1; n >= 0; n--) {
                        o = c[n][1], u = c[n][0];
                        for (r = 0, f = u.length; r < f; r++) a = e(u[r]), a.data(this.widgetName + "-item", o), l.push({
                            item: a,
                            instance: o,
                            width: 0,
                            height: 0,
                            left: 0,
                            top: 0
                        })
                    }
                },
                refreshPositions: function(t) {
                    this.offsetParent && this.helper && (this.offset.parent = this._getParentOffset());
                    var n, r, i, s;
                    for (n = this.items.length - 1; n >= 0; n--) {
                        r = this.items[n];
                        if (r.instance !== this.currentContainer && this.currentContainer && r.item[0] !== this.currentItem[0]) continue;
                        i = this.options.toleranceElement ? e(this.options.toleranceElement, r.item) : r.item, t || (r.width = i.outerWidth(), r.height = i.outerHeight()), s = i.offset(), r.left = s.left, r.top = s.top
                    }
                    if (this.options.custom && this.options.custom.refreshContainers) this.options.custom.refreshContainers.call(this);
                    else
                        for (n = this.containers.length - 1; n >= 0; n--) s = this.containers[n].element.offset(), this.containers[n].containerCache.left = s.left, this.containers[n].containerCache.top = s.top, this.containers[n].containerCache.width = this.containers[n].element.outerWidth(), this.containers[n].containerCache.height = this.containers[n].element.outerHeight();
                    return this
                },
                _createPlaceholder: function(t) {
                    t = t || this;
                    var n, r = t.options;
                    if (!r.placeholder || r.placeholder.constructor === String) n = r.placeholder, r.placeholder = {
                        element: function() {
                            var r = t.currentItem[0].nodeName.toLowerCase(),
                                i = e("<" + r + ">", t.document[0]).addClass(n || t.currentItem[0].className + " ui-sortable-placeholder").removeClass("ui-sortable-helper");
                            return r === "tr" ? t.currentItem.children().each(function() {
                                e("<td>&#160;</td>", t.document[0]).attr("colspan", e(this).attr("colspan") || 1).appendTo(i)
                            }) : r === "img" && i.attr("src", t.currentItem.attr("src")), n || i.css("visibility", "hidden"), i
                        },
                        update: function(e, i) {
                            if (n && !r.forcePlaceholderSize) return;
                            i.height() || i.height(t.currentItem.innerHeight() - parseInt(t.currentItem.css("paddingTop") || 0, 10) - parseInt(t.currentItem.css("paddingBottom") || 0, 10)), i.width() || i.width(t.currentItem.innerWidth() - parseInt(t.currentItem.css("paddingLeft") || 0, 10) - parseInt(t.currentItem.css("paddingRight") || 0, 10))
                        }
                    };
                    t.placeholder = e(r.placeholder.element.call(t.element, t.currentItem)), t.currentItem.after(t.placeholder), r.placeholder.update(t, t.placeholder)
                },
                _contactContainers: function(t) {
                    var n, r, i, s, o, u, a, f, l, c, h = null,
                        p = null;
                    for (n = this.containers.length - 1; n >= 0; n--) {
                        if (e.contains(this.currentItem[0], this.containers[n].element[0])) continue;
                        if (this._intersectsWith(this.containers[n].containerCache)) {
                            if (h && e.contains(this.containers[n].element[0], h.element[0])) continue;
                            h = this.containers[n], p = n
                        } else this.containers[n].containerCache.over && (this.containers[n]._trigger("out", t, this._uiHash(this)), this.containers[n].containerCache.over = 0)
                    }
                    if (!h) return;
                    if (this.containers.length === 1) this.containers[p].containerCache.over || (this.containers[p]._trigger("over", t, this._uiHash(this)), this.containers[p].containerCache.over = 1);
                    else {
                        i = 1e4, s = null, l = h.floating || this._isFloating(this.currentItem), o = l ? "left" : "top", u = l ? "width" : "height", c = l ? "clientX" : "clientY";
                        for (r = this.items.length - 1; r >= 0; r--) {
                            if (!e.contains(this.containers[p].element[0], this.items[r].item[0])) continue;
                            if (this.items[r].item[0] === this.currentItem[0]) continue;
                            a = this.items[r].item.offset()[o], f = !1, t[c] - a > this.items[r][u] / 2 && (f = !0), Math.abs(t[c] - a) < i && (i = Math.abs(t[c] - a), s = this.items[r], this.direction = f ? "up" : "down")
                        }
                        if (!s && !this.options.dropOnEmpty) return;
                        if (this.currentContainer === this.containers[p]) {
                            this.currentContainer.containerCache.over || (this.containers[p]._trigger("over", t, this._uiHash()), this.currentContainer.containerCache.over = 1);
                            return
                        }
                        s ? this._rearrange(t, s, null, !0) : this._rearrange(t, null, this.containers[p].element, !0), this._trigger("change", t, this._uiHash()), this.containers[p]._trigger("change", t, this._uiHash(this)), this.currentContainer = this.containers[p], this.options.placeholder.update(this.currentContainer, this.placeholder), this.containers[p]._trigger("over", t, this._uiHash(this)), this.containers[p].containerCache.over = 1
                    }
                },
                _createHelper: function(t) {
                    var n = this.options,
                        r = e.isFunction(n.helper) ? e(n.helper.apply(this.element[0], [t, this.currentItem])) : n.helper === "clone" ? this.currentItem.clone() : this.currentItem;
                    return r.parents("body").length || e(n.appendTo !== "parent" ? n.appendTo : this.currentItem[0].parentNode)[0].appendChild(r[0]), r[0] === this.currentItem[0] && (this._storedCSS = {
                        width: this.currentItem[0].style.width,
                        height: this.currentItem[0].style.height,
                        position: this.currentItem.css("position"),
                        top: this.currentItem.css("top"),
                        left: this.currentItem.css("left")
                    }), (!r[0].style.width || n.forceHelperSize) && r.width(this.currentItem.width()), (!r[0].style.height || n.forceHelperSize) && r.height(this.currentItem.height()), r
                },
                _adjustOffsetFromHelper: function(t) {
                    typeof t == "string" && (t = t.split(" ")), e.isArray(t) && (t = {
                        left: +t[0],
                        top: +t[1] || 0
                    }), "left" in t && (this.offset.click.left = t.left + this.margins.left), "right" in t && (this.offset.click.left = this.helperProportions.width - t.right + this.margins.left), "top" in t && (this.offset.click.top = t.top + this.margins.top), "bottom" in t && (this.offset.click.top = this.helperProportions.height - t.bottom + this.margins.top)
                },
                _getParentOffset: function() {
                    this.offsetParent = this.helper.offsetParent();
                    var t = this.offsetParent.offset();
                    this.cssPosition === "absolute" && this.scrollParent[0] !== document && e.contains(this.scrollParent[0], this.offsetParent[0]) && (t.left += this.scrollParent.scrollLeft(), t.top += this.scrollParent.scrollTop());
                    if (this.offsetParent[0] === document.body || this.offsetParent[0].tagName && this.offsetParent[0].tagName.toLowerCase() === "html" && e.ui.ie) t = {
                        top: 0,
                        left: 0
                    };
                    return {
                        top: t.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                        left: t.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
                    }
                },
                _getRelativeOffset: function() {
                    if (this.cssPosition === "relative") {
                        var e = this.currentItem.position();
                        return {
                            top: e.top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),
                            left: e.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()
                        }
                    }
                    return {
                        top: 0,
                        left: 0
                    }
                },
                _cacheMargins: function() {
                    this.margins = {
                        left: parseInt(this.currentItem.css("marginLeft"), 10) || 0,
                        top: parseInt(this.currentItem.css("marginTop"), 10) || 0
                    }
                },
                _cacheHelperProportions: function() {
                    this.helperProportions = {
                        width: this.helper.outerWidth(),
                        height: this.helper.outerHeight()
                    }
                },
                _setContainment: function() {
                    var t, n, r, i = this.options;
                    i.containment === "parent" && (i.containment = this.helper[0].parentNode);
                    if (i.containment === "document" || i.containment === "window") this.containment = [0 - this.offset.relative.left - this.offset.parent.left, 0 - this.offset.relative.top - this.offset.parent.top, e(i.containment === "document" ? document : window).width() - this.helperProportions.width - this.margins.left, (e(i.containment === "document" ? document : window).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top];
                    /^(document|window|parent)$/.test(i.containment) || (t = e(i.containment)[0], n = e(i.containment).offset(), r = e(t).css("overflow") !== "hidden", this.containment = [n.left + (parseInt(e(t).css("borderLeftWidth"), 10) || 0) + (parseInt(e(t).css("paddingLeft"), 10) || 0) - this.margins.left, n.top + (parseInt(e(t).css("borderTopWidth"), 10) || 0) + (parseInt(e(t).css("paddingTop"), 10) || 0) - this.margins.top, n.left + (r ? Math.max(t.scrollWidth, t.offsetWidth) : t.offsetWidth) - (parseInt(e(t).css("borderLeftWidth"), 10) || 0) - (parseInt(e(t).css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left, n.top + (r ? Math.max(t.scrollHeight, t.offsetHeight) : t.offsetHeight) - (parseInt(e(t).css("borderTopWidth"), 10) || 0) - (parseInt(e(t).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top])
                },
                _convertPositionTo: function(t, n) {
                    n || (n = this.position);
                    var r = t === "absolute" ? 1 : -1,
                        i = this.cssPosition !== "absolute" || this.scrollParent[0] !== document && !!e.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                        s = /(html|body)/i.test(i[0].tagName);
                    return {
                        top: n.top + this.offset.relative.top * r + this.offset.parent.top * r - (this.cssPosition === "fixed" ? -this.scrollParent.scrollTop() : s ? 0 : i.scrollTop()) * r,
                        left: n.left + this.offset.relative.left * r + this.offset.parent.left * r - (this.cssPosition === "fixed" ? -this.scrollParent.scrollLeft() : s ? 0 : i.scrollLeft()) * r
                    }
                },
                _generatePosition: function(t) {
                    var n, r, i = this.options,
                        s = t.pageX,
                        o = t.pageY,
                        u = this.cssPosition !== "absolute" || this.scrollParent[0] !== document && !!e.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                        a = /(html|body)/i.test(u[0].tagName);
                    return this.cssPosition === "relative" && (this.scrollParent[0] === document || this.scrollParent[0] === this.offsetParent[0]) && (this.offset.relative = this._getRelativeOffset()), this.originalPosition && (this.containment && (t.pageX - this.offset.click.left < this.containment[0] && (s = this.containment[0] + this.offset.click.left), t.pageY - this.offset.click.top < this.containment[1] && (o = this.containment[1] + this.offset.click.top), t.pageX - this.offset.click.left > this.containment[2] && (s = this.containment[2] + this.offset.click.left), t.pageY - this.offset.click.top > this.containment[3] && (o = this.containment[3] + this.offset.click.top)), i.grid && (n = this.originalPageY + Math.round((o - this.originalPageY) / i.grid[1]) * i.grid[1], o = this.containment ? n - this.offset.click.top >= this.containment[1] && n - this.offset.click.top <= this.containment[3] ? n : n - this.offset.click.top >= this.containment[1] ? n - i.grid[1] : n + i.grid[1] : n, r = this.originalPageX + Math.round((s - this.originalPageX) / i.grid[0]) * i.grid[0], s = this.containment ? r - this.offset.click.left >= this.containment[0] && r - this.offset.click.left <= this.containment[2] ? r : r - this.offset.click.left >= this.containment[0] ? r - i.grid[0] : r + i.grid[0] : r)), {
                        top: o - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + (this.cssPosition === "fixed" ? -this.scrollParent.scrollTop() : a ? 0 : u.scrollTop()),
                        left: s - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + (this.cssPosition === "fixed" ? -this.scrollParent.scrollLeft() : a ? 0 : u.scrollLeft())
                    }
                },
                _rearrange: function(e, t, n, r) {
                    n ? n[0].appendChild(this.placeholder[0]) : t.item[0].parentNode.insertBefore(this.placeholder[0], this.direction === "down" ? t.item[0] : t.item[0].nextSibling), this.counter = this.counter ? ++this.counter : 1;
                    var i = this.counter;
                    this._delay(function() {
                        i === this.counter && this.refreshPositions(!r)
                    })
                },
                _clear: function(e, t) {
                    function i(e, t, n) {
                        return function(r) {
                            n._trigger(e, r, t._uiHash(t))
                        }
                    }
                    this.reverting = !1;
                    var n, r = [];
                    !this._noFinalSort && this.currentItem.parent().length && this.placeholder.before(this.currentItem), this._noFinalSort = null;
                    if (this.helper[0] === this.currentItem[0]) {
                        for (n in this._storedCSS)
                            if (this._storedCSS[n] === "auto" || this._storedCSS[n] === "static") this._storedCSS[n] = "";
                        this.currentItem.css(this._storedCSS).removeClass("ui-sortable-helper")
                    } else this.currentItem.show();
                    this.fromOutside && !t && r.push(function(e) {
                        this._trigger("receive", e, this._uiHash(this.fromOutside))
                    }), (this.fromOutside || this.domPosition.prev !== this.currentItem.prev().not(".ui-sortable-helper")[0] || this.domPosition.parent !== this.currentItem.parent()[0]) && !t && r.push(function(e) {
                        this._trigger("update", e, this._uiHash())
                    }), this !== this.currentContainer && (t || (r.push(function(e) {
                        this._trigger("remove", e, this._uiHash())
                    }), r.push(function(e) {
                        return function(t) {
                            e._trigger("receive", t, this._uiHash(this))
                        }
                    }.call(this, this.currentContainer)), r.push(function(e) {
                        return function(t) {
                            e._trigger("update", t, this._uiHash(this))
                        }
                    }.call(this, this.currentContainer))));
                    for (n = this.containers.length - 1; n >= 0; n--) t || r.push(i("deactivate", this, this.containers[n])), this.containers[n].containerCache.over && (r.push(i("out", this, this.containers[n])), this.containers[n].containerCache.over = 0);
                    this.storedCursor && (this.document.find("body").css("cursor", this.storedCursor), this.storedStylesheet.remove()), this._storedOpacity && this.helper.css("opacity", this._storedOpacity), this._storedZIndex && this.helper.css("zIndex", this._storedZIndex === "auto" ? "" : this._storedZIndex), this.dragging = !1, t || this._trigger("beforeStop", e, this._uiHash()), this.placeholder[0].parentNode.removeChild(this.placeholder[0]), this.cancelHelperRemoval || (this.helper[0] !== this.currentItem[0] && this.helper.remove(), this.helper = null);
                    if (!t) {
                        for (n = 0; n < r.length; n++) r[n].call(this, e);
                        this._trigger("stop", e, this._uiHash())
                    }
                    return this.fromOutside = !1, !this.cancelHelperRemoval
                },
                _trigger: function() {
                    e.Widget.prototype._trigger.apply(this, arguments) === !1 && this.cancel()
                },
                _uiHash: function(t) {
                    var n = t || this;
                    return {
                        helper: n.helper,
                        placeholder: n.placeholder || e([]),
                        position: n.position,
                        originalPosition: n.originalPosition,
                        offset: n.positionAbs,
                        item: n.currentItem,
                        sender: t ? t.element : null
                    }
                }
            }),
            Z = e.widget("ui.spinner", {
                version: "1.11.2",
                defaultElement: "<input>",
                widgetEventPrefix: "spin",
                options: {
                    culture: null,
                    icons: {
                        down: "ui-icon-triangle-1-s",
                        up: "ui-icon-triangle-1-n"
                    },
                    incremental: !0,
                    max: null,
                    min: null,
                    numberFormat: null,
                    page: 10,
                    step: 1,
                    change: null,
                    spin: null,
                    start: null,
                    stop: null
                },
                _create: function() {
                    this._setOption("max", this.options.max), this._setOption("min", this.options.min), this._setOption("step", this.options.step), this.value() !== "" && this._value(this.element.val(), !0), this._draw(), this._on(this._events), this._refresh(), this._on(this.window, {
                        beforeunload: function() {
                            this.element.removeAttr("autocomplete")
                        }
                    })
                },
                _getCreateOptions: function() {
                    var t = {},
                        n = this.element;
                    return e.each(["min", "max", "step"], function(e, r) {
                        var i = n.attr(r);
                        i !== undefined && i.length && (t[r] = i)
                    }), t
                },
                _events: {
                    keydown: function(e) {
                        this._start(e) && this._keydown(e) && e.preventDefault()
                    },
                    keyup: "_stop",
                    focus: function() {
                        this.previous = this.element.val()
                    },
                    blur: function(e) {
                        if (this.cancelBlur) {
                            delete this.cancelBlur;
                            return
                        }
                        this._stop(), this._refresh(), this.previous !== this.element.val() && this._trigger("change", e)
                    },
                    mousewheel: function(e, t) {
                        if (!t) return;
                        if (!this.spinning && !this._start(e)) return !1;
                        this._spin((t > 0 ? 1 : -1) * this.options.step, e), clearTimeout(this.mousewheelTimer), this.mousewheelTimer = this._delay(function() {
                            this.spinning && this._stop(e)
                        }, 100), e.preventDefault()
                    },
                    "mousedown .ui-spinner-button": function(t) {
                        function r() {
                            var e = this.element[0] === this.document[0].activeElement;
                            e || (this.element.focus(), this.previous = n, this._delay(function() {
                                this.previous = n
                            }))
                        }
                        var n;
                        n = this.element[0] === this.document[0].activeElement ? this.previous : this.element.val(), t.preventDefault(), r.call(this), this.cancelBlur = !0, this._delay(function() {
                            delete this.cancelBlur, r.call(this)
                        });
                        if (this._start(t) === !1) return;
                        this._repeat(null, e(t.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, t)
                    },
                    "mouseup .ui-spinner-button": "_stop",
                    "mouseenter .ui-spinner-button": function(t) {
                        if (!e(t.currentTarget).hasClass("ui-state-active")) return;
                        if (this._start(t) === !1) return !1;
                        this._repeat(null, e(t.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, t)
                    },
                    "mouseleave .ui-spinner-button": "_stop"
                },
                _draw: function() {
                    var e = this.uiSpinner = this.element.addClass("ui-spinner-input").attr("autocomplete", "off").wrap(this._uiSpinnerHtml()).parent().append(this._buttonHtml());
                    this.element.attr("role", "spinbutton"), this.buttons = e.find(".ui-spinner-button").attr("tabIndex", -1).button().removeClass("ui-corner-all"), this.buttons.height() > Math.ceil(e.height() * .5) && e.height() > 0 && e.height(e.height()), this.options.disabled && this.disable()
                },
                _keydown: function(t) {
                    var n = this.options,
                        r = e.ui.keyCode;
                    switch (t.keyCode) {
                        case r.UP:
                            return this._repeat(null, 1, t), !0;
                        case r.DOWN:
                            return this._repeat(null, -1, t), !0;
                        case r.PAGE_UP:
                            return this._repeat(null, n.page, t), !0;
                        case r.PAGE_DOWN:
                            return this._repeat(null, -n.page, t), !0
                    }
                    return !1
                },
                _uiSpinnerHtml: function() {
                    return "<span class='ui-spinner ui-widget ui-widget-content ui-corner-all'></span>"
                },
                _buttonHtml: function() {
                    return "<a class='ui-spinner-button ui-spinner-up ui-corner-tr'><span class='ui-icon " + this.options.icons.up + "'>&#9650;</span>" + "</a>" + "<a class='ui-spinner-button ui-spinner-down ui-corner-br'>" + "<span class='ui-icon " + this.options.icons.down + "'>&#9660;</span>" + "</a>"
                },
                _start: function(e) {
                    return !this.spinning && this._trigger("start", e) === !1 ? !1 : (this.counter || (this.counter = 1), this.spinning = !0, !0)
                },
                _repeat: function(e, t, n) {
                    e = e || 500, clearTimeout(this.timer), this.timer = this._delay(function() {
                        this._repeat(40, t, n)
                    }, e), this._spin(t * this.options.step, n)
                },
                _spin: function(e, t) {
                    var n = this.value() || 0;
                    this.counter || (this.counter = 1), n = this._adjustValue(n + e * this._increment(this.counter));
                    if (!this.spinning || this._trigger("spin", t, {
                            value: n
                        }) !== !1) this._value(n), this.counter++
                },
                _increment: function(t) {
                    var n = this.options.incremental;
                    return n ? e.isFunction(n) ? n(t) : Math.floor(t * t * t / 5e4 - t * t / 500 + 17 * t / 200 + 1) : 1
                },
                _precision: function() {
                    var e = this._precisionOf(this.options.step);
                    return this.options.min !== null && (e = Math.max(e, this._precisionOf(this.options.min))), e
                },
                _precisionOf: function(e) {
                    var t = e.toString(),
                        n = t.indexOf(".");
                    return n === -1 ? 0 : t.length - n - 1
                },
                _adjustValue: function(e) {
                    var t, n, r = this.options;
                    return t = r.min !== null ? r.min : 0, n = e - t, n = Math.round(n / r.step) * r.step, e = t + n, e = parseFloat(e.toFixed(this._precision())), r.max !== null && e > r.max ? r.max : r.min !== null && e < r.min ? r.min : e
                },
                _stop: function(e) {
                    if (!this.spinning) return;
                    clearTimeout(this.timer), clearTimeout(this.mousewheelTimer), this.counter = 0, this.spinning = !1, this._trigger("stop", e)
                },
                _setOption: function(e, t) {
                    if (e === "culture" || e === "numberFormat") {
                        var n = this._parse(this.element.val());
                        this.options[e] = t, this.element.val(this._format(n));
                        return
                    }(e === "max" || e === "min" || e === "step") && typeof t == "string" && (t = this._parse(t)), e === "icons" && (this.buttons.first().find(".ui-icon").removeClass(this.options.icons.up).addClass(t.up), this.buttons.last().find(".ui-icon").removeClass(this.options.icons.down).addClass(t.down)), this._super(e, t), e === "disabled" && (this.widget().toggleClass("ui-state-disabled", !!t), this.element.prop("disabled", !!t), this.buttons.button(t ? "disable" : "enable"))
                },
                _setOptions: Y(function(e) {
                    this._super(e)
                }),
                _parse: function(e) {
                    return typeof e == "string" && e !== "" && (e = window.Globalize && this.options.numberFormat ? Globalize.parseFloat(e, 10, this.options.culture) : +e), e === "" || isNaN(e) ? null : e
                },
                _format: function(e) {
                    return e === "" ? "" : window.Globalize && this.options.numberFormat ? Globalize.format(e, this.options.numberFormat, this.options.culture) : e
                },
                _refresh: function() {
                    this.element.attr({
                        "aria-valuemin": this.options.min,
                        "aria-valuemax": this.options.max,
                        "aria-valuenow": this._parse(this.element.val())
                    })
                },
                isValid: function() {
                    var e = this.value();
                    return e === null ? !1 : e === this._adjustValue(e)
                },
                _value: function(e, t) {
                    var n;
                    e !== "" && (n = this._parse(e), n !== null && (t || (n = this._adjustValue(n)), e = this._format(n))), this.element.val(e), this._refresh()
                },
                _destroy: function() {
                    this.element.removeClass("ui-spinner-input").prop("disabled", !1).removeAttr("autocomplete").removeAttr("role").removeAttr("aria-valuemin").removeAttr("aria-valuemax").removeAttr("aria-valuenow"), this.uiSpinner.replaceWith(this.element)
                },
                stepUp: Y(function(e) {
                    this._stepUp(e)
                }),
                _stepUp: function(e) {
                    this._start() && (this._spin((e || 1) * this.options.step), this._stop())
                },
                stepDown: Y(function(e) {
                    this._stepDown(e)
                }),
                _stepDown: function(e) {
                    this._start() && (this._spin((e || 1) * -this.options.step), this._stop())
                },
                pageUp: Y(function(e) {
                    this._stepUp((e || 1) * this.options.page)
                }),
                pageDown: Y(function(e) {
                    this._stepDown((e || 1) * this.options.page)
                }),
                value: function(e) {
                    if (!arguments.length) return this._parse(this.element.val());
                    Y(this._value).call(this, e)
                },
                widget: function() {
                    return this.uiSpinner
                }
            }),
            et = e.widget("ui.tabs", {
                version: "1.11.2",
                delay: 300,
                options: {
                    active: null,
                    collapsible: !1,
                    event: "click",
                    heightStyle: "content",
                    hide: null,
                    show: null,
                    activate: null,
                    beforeActivate: null,
                    beforeLoad: null,
                    load: null
                },
                _isLocal: function() {
                    var e = /#.*$/;
                    return function(t) {
                        var n, r;
                        t = t.cloneNode(!1), n = t.href.replace(e, ""), r = location.href.replace(e, "");
                        try {
                            n = decodeURIComponent(n)
                        } catch (i) {}
                        try {
                            r = decodeURIComponent(r)
                        } catch (i) {}
                        return t.hash.length > 1 && n === r
                    }
                }(),
                _create: function() {
                    var t = this,
                        n = this.options;
                    this.running = !1, this.element.addClass("ui-tabs ui-widget ui-widget-content ui-corner-all").toggleClass("ui-tabs-collapsible", n.collapsible), this._processTabs(), n.active = this._initialActive(), e.isArray(n.disabled) && (n.disabled = e.unique(n.disabled.concat(e.map(this.tabs.filter(".ui-state-disabled"), function(e) {
                        return t.tabs.index(e)
                    }))).sort()), this.options.active !== !1 && this.anchors.length ? this.active = this._findActive(n.active) : this.active = e(), this._refresh(), this.active.length && this.load(n.active)
                },
                _initialActive: function() {
                    var t = this.options.active,
                        n = this.options.collapsible,
                        r = location.hash.substring(1);
                    if (t === null) {
                        r && this.tabs.each(function(n, i) {
                            if (e(i).attr("aria-controls") === r) return t = n, !1
                        }), t === null && (t = this.tabs.index(this.tabs.filter(".ui-tabs-active")));
                        if (t === null || t === -1) t = this.tabs.length ? 0 : !1
                    }
                    return t !== !1 && (t = this.tabs.index(this.tabs.eq(t)), t === -1 && (t = n ? !1 : 0)), !n && t === !1 && this.anchors.length && (t = 0), t
                },
                _getCreateEventData: function() {
                    return {
                        tab: this.active,
                        panel: this.active.length ? this._getPanelForTab(this.active) : e()
                    }
                },
                _tabKeydown: function(t) {
                    var n = e(this.document[0].activeElement).closest("li"),
                        r = this.tabs.index(n),
                        i = !0;
                    if (this._handlePageNav(t)) return;
                    switch (t.keyCode) {
                        case e.ui.keyCode.RIGHT:
                        case e.ui.keyCode.DOWN:
                            r++;
                            break;
                        case e.ui.keyCode.UP:
                        case e.ui.keyCode.LEFT:
                            i = !1, r--;
                            break;
                        case e.ui.keyCode.END:
                            r = this.anchors.length - 1;
                            break;
                        case e.ui.keyCode.HOME:
                            r = 0;
                            break;
                        case e.ui.keyCode.SPACE:
                            t.preventDefault(), clearTimeout(this.activating), this._activate(r);
                            return;
                        case e.ui.keyCode.ENTER:
                            t.preventDefault(), clearTimeout(this.activating), this._activate(r === this.options.active ? !1 : r);
                            return;
                        default:
                            return
                    }
                    t.preventDefault(), clearTimeout(this.activating), r = this._focusNextTab(r, i), t.ctrlKey || (n.attr("aria-selected", "false"), this.tabs.eq(r).attr("aria-selected", "true"), this.activating = this._delay(function() {
                        this.option("active", r)
                    }, this.delay))
                },
                _panelKeydown: function(t) {
                    if (this._handlePageNav(t)) return;
                    t.ctrlKey && t.keyCode === e.ui.keyCode.UP && (t.preventDefault(), this.active.focus())
                },
                _handlePageNav: function(t) {
                    if (t.altKey && t.keyCode === e.ui.keyCode.PAGE_UP) return this._activate(this._focusNextTab(this.options.active - 1, !1)), !0;
                    if (t.altKey && t.keyCode === e.ui.keyCode.PAGE_DOWN) return this._activate(this._focusNextTab(this.options.active + 1, !0)), !0
                },
                _findNextTab: function(t, n) {
                    function i() {
                        return t > r && (t = 0), t < 0 && (t = r), t
                    }
                    var r = this.tabs.length - 1;
                    while (e.inArray(i(), this.options.disabled) !== -1) t = n ? t + 1 : t - 1;
                    return t
                },
                _focusNextTab: function(e, t) {
                    return e = this._findNextTab(e, t), this.tabs.eq(e).focus(), e
                },
                _setOption: function(e, t) {
                    if (e === "active") {
                        this._activate(t);
                        return
                    }
                    if (e === "disabled") {
                        this._setupDisabled(t);
                        return
                    }
                    this._super(e, t), e === "collapsible" && (this.element.toggleClass("ui-tabs-collapsible", t), !t && this.options.active === !1 && this._activate(0)), e === "event" && this._setupEvents(t), e === "heightStyle" && this._setupHeightStyle(t)
                },
                _sanitizeSelector: function(e) {
                    return e ? e.replace(/[!"$%&'()*+,.\/:;<=>?@\[\]\^`{|}~]/g, "\\$&") : ""
                },
                refresh: function() {
                    var t = this.options,
                        n = this.tablist.children(":has(a[href])");
                    t.disabled = e.map(n.filter(".ui-state-disabled"), function(e) {
                        return n.index(e)
                    }), this._processTabs(), t.active === !1 || !this.anchors.length ? (t.active = !1, this.active = e()) : this.active.length && !e.contains(this.tablist[0], this.active[0]) ? this.tabs.length === t.disabled.length ? (t.active = !1, this.active = e()) : this._activate(this._findNextTab(Math.max(0, t.active - 1), !1)) : t.active = this.tabs.index(this.active), this._refresh()
                },
                _refresh: function() {
                    this._setupDisabled(this.options.disabled), this._setupEvents(this.options.event), this._setupHeightStyle(this.options.heightStyle), this.tabs.not(this.active).attr({
                        "aria-selected": "false",
                        "aria-expanded": "false",
                        tabIndex: -1
                    }), this.panels.not(this._getPanelForTab(this.active)).hide().attr({
                        "aria-hidden": "true"
                    }), this.active.length ? (this.active.addClass("ui-tabs-active ui-state-active").attr({
                        "aria-selected": "true",
                        "aria-expanded": "true",
                        tabIndex: 0
                    }), this._getPanelForTab(this.active).show().attr({
                        "aria-hidden": "false"
                    })) : this.tabs.eq(0).attr("tabIndex", 0)
                },
                _processTabs: function() {
                    var t = this,
                        n = this.tabs,
                        r = this.anchors,
                        i = this.panels;
                    this.tablist = this._getList().addClass("ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all").attr("role", "tablist").delegate("> li", "mousedown" + this.eventNamespace, function(t) {
                        e(this).is(".ui-state-disabled") && t.preventDefault()
                    }).delegate(".ui-tabs-anchor", "focus" + this.eventNamespace, function() {
                        e(this).closest("li").is(".ui-state-disabled") && this.blur()
                    }), this.tabs = this.tablist.find("> li:has(a[href])").addClass("ui-state-default ui-corner-top").attr({
                        role: "tab",
                        tabIndex: -1
                    }), this.anchors = this.tabs.map(function() {
                        return e("a", this)[0]
                    }).addClass("ui-tabs-anchor").attr({
                        role: "presentation",
                        tabIndex: -1
                    }), this.panels = e(), this.anchors.each(function(n, r) {
                        var i, s, o, u = e(r).uniqueId().attr("id"),
                            a = e(r).closest("li"),
                            f = a.attr("aria-controls");
                        t._isLocal(r) ? (i = r.hash, o = i.substring(1), s = t.element.find(t._sanitizeSelector(i))) : (o = a.attr("aria-controls") || e({}).uniqueId()[0].id, i = "#" + o, s = t.element.find(i), s.length || (s = t._createPanel(o), s.insertAfter(t.panels[n - 1] || t.tablist)), s.attr("aria-live", "polite")), s.length && (t.panels = t.panels.add(s)), f && a.data("ui-tabs-aria-controls", f), a.attr({
                            "aria-controls": o,
                            "aria-labelledby": u
                        }), s.attr("aria-labelledby", u)
                    }), this.panels.addClass("ui-tabs-panel ui-widget-content ui-corner-bottom").attr("role", "tabpanel"), n && (this._off(n.not(this.tabs)), this._off(r.not(this.anchors)), this._off(i.not(this.panels)))
                },
                _getList: function() {
                    return this.tablist || this.element.find("ol,ul").eq(0)
                },
                _createPanel: function(t) {
                    return e("<div>").attr("id", t).addClass("ui-tabs-panel ui-widget-content ui-corner-bottom").data("ui-tabs-destroy", !0)
                },
                _setupDisabled: function(t) {
                    e.isArray(t) && (t.length ? t.length === this.anchors.length && (t = !0) : t = !1);
                    for (var n = 0, r; r = this.tabs[n]; n++) t === !0 || e.inArray(n, t) !== -1 ? e(r).addClass("ui-state-disabled").attr("aria-disabled", "true") : e(r).removeClass("ui-state-disabled").removeAttr("aria-disabled");
                    this.options.disabled = t
                },
                _setupEvents: function(t) {
                    var n = {};
                    t && e.each(t.split(" "), function(e, t) {
                        n[t] = "_eventHandler"
                    }), this._off(this.anchors.add(this.tabs).add(this.panels)), this._on(!0, this.anchors, {
                        click: function(e) {
                            e.preventDefault()
                        }
                    }), this._on(this.anchors, n), this._on(this.tabs, {
                        keydown: "_tabKeydown"
                    }), this._on(this.panels, {
                        keydown: "_panelKeydown"
                    }), this._focusable(this.tabs), this._hoverable(this.tabs)
                },
                _setupHeightStyle: function(t) {
                    var n, r = this.element.parent();
                    t === "fill" ? (n = r.height(), n -= this.element.outerHeight() - this.element.height(), this.element.siblings(":visible").each(function() {
                        var t = e(this),
                            r = t.css("position");
                        if (r === "absolute" || r === "fixed") return;
                        n -= t.outerHeight(!0)
                    }), this.element.children().not(this.panels).each(function() {
                        n -= e(this).outerHeight(!0)
                    }), this.panels.each(function() {
                        e(this).height(Math.max(0, n - e(this).innerHeight() + e(this).height()))
                    }).css("overflow", "auto")) : t === "auto" && (n = 0, this.panels.each(function() {
                        n = Math.max(n, e(this).height("").height())
                    }).height(n))
                },
                _eventHandler: function(t) {
                    var n = this.options,
                        r = this.active,
                        i = e(t.currentTarget),
                        s = i.closest("li"),
                        o = s[0] === r[0],
                        u = o && n.collapsible,
                        a = u ? e() : this._getPanelForTab(s),
                        f = r.length ? this._getPanelForTab(r) : e(),
                        l = {
                            oldTab: r,
                            oldPanel: f,
                            newTab: u ? e() : s,
                            newPanel: a
                        };
                    t.preventDefault();
                    if (s.hasClass("ui-state-disabled") || s.hasClass("ui-tabs-loading") || this.running || o && !n.collapsible || this._trigger("beforeActivate", t, l) === !1) return;
                    n.active = u ? !1 : this.tabs.index(s), this.active = o ? e() : s, this.xhr && this.xhr.abort(), !f.length && !a.length && e.error("jQuery UI Tabs: Mismatching fragment identifier."), a.length && this.load(this.tabs.index(s), t), this._toggle(t, l)
                },
                _toggle: function(t, n) {
                    function o() {
                        r.running = !1, r._trigger("activate", t, n)
                    }

                    function u() {
                        n.newTab.closest("li").addClass("ui-tabs-active ui-state-active"), i.length && r.options.show ? r._show(i, r.options.show, o) : (i.show(), o())
                    }
                    var r = this,
                        i = n.newPanel,
                        s = n.oldPanel;
                    this.running = !0, s.length && this.options.hide ? this._hide(s, this.options.hide, function() {
                        n.oldTab.closest("li").removeClass("ui-tabs-active ui-state-active"), u()
                    }) : (n.oldTab.closest("li").removeClass("ui-tabs-active ui-state-active"), s.hide(), u()), s.attr("aria-hidden", "true"), n.oldTab.attr({
                        "aria-selected": "false",
                        "aria-expanded": "false"
                    }), i.length && s.length ? n.oldTab.attr("tabIndex", -1) : i.length && this.tabs.filter(function() {
                        return e(this).attr("tabIndex") === 0
                    }).attr("tabIndex", -1), i.attr("aria-hidden", "false"), n.newTab.attr({
                        "aria-selected": "true",
                        "aria-expanded": "true",
                        tabIndex: 0
                    })
                },
                _activate: function(t) {
                    var n, r = this._findActive(t);
                    if (r[0] === this.active[0]) return;
                    r.length || (r = this.active), n = r.find(".ui-tabs-anchor")[0], this._eventHandler({
                        target: n,
                        currentTarget: n,
                        preventDefault: e.noop
                    })
                },
                _findActive: function(t) {
                    return t === !1 ? e() : this.tabs.eq(t)
                },
                _getIndex: function(e) {
                    return typeof e == "string" && (e = this.anchors.index(this.anchors.filter("[href$='" + e + "']"))), e
                },
                _destroy: function() {
                    this.xhr && this.xhr.abort(), this.element.removeClass("ui-tabs ui-widget ui-widget-content ui-corner-all ui-tabs-collapsible"), this.tablist.removeClass("ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all").removeAttr("role"), this.anchors.removeClass("ui-tabs-anchor").removeAttr("role").removeAttr("tabIndex").removeUniqueId(), this.tablist.unbind(this.eventNamespace), this.tabs.add(this.panels).each(function() {
                        e.data(this, "ui-tabs-destroy") ? e(this).remove() : e(this).removeClass("ui-state-default ui-state-active ui-state-disabled ui-corner-top ui-corner-bottom ui-widget-content ui-tabs-active ui-tabs-panel").removeAttr("tabIndex").removeAttr("aria-live").removeAttr("aria-busy").removeAttr("aria-selected").removeAttr("aria-labelledby").removeAttr("aria-hidden").removeAttr("aria-expanded").removeAttr("role")
                    }), this.tabs.each(function() {
                        var t = e(this),
                            n = t.data("ui-tabs-aria-controls");
                        n ? t.attr("aria-controls", n).removeData("ui-tabs-aria-controls") : t.removeAttr("aria-controls")
                    }), this.panels.show(), this.options.heightStyle !== "content" && this.panels.css("height", "")
                },
                enable: function(t) {
                    var n = this.options.disabled;
                    if (n === !1) return;
                    t === undefined ? n = !1 : (t = this._getIndex(t), e.isArray(n) ? n = e.map(n, function(e) {
                        return e !== t ? e : null
                    }) : n = e.map(this.tabs, function(e, n) {
                        return n !== t ? n : null
                    })), this._setupDisabled(n)
                },
                disable: function(t) {
                    var n = this.options.disabled;
                    if (n === !0) return;
                    if (t === undefined) n = !0;
                    else {
                        t = this._getIndex(t);
                        if (e.inArray(t, n) !== -1) return;
                        e.isArray(n) ? n = e.merge([t], n).sort() : n = [t]
                    }
                    this._setupDisabled(n)
                },
                load: function(t, n) {
                    t = this._getIndex(t);
                    var r = this,
                        i = this.tabs.eq(t),
                        s = i.find(".ui-tabs-anchor"),
                        o = this._getPanelForTab(i),
                        u = {
                            tab: i,
                            panel: o
                        };
                    if (this._isLocal(s[0])) return;
                    this.xhr = e.ajax(this._ajaxSettings(s, n, u)), this.xhr && this.xhr.statusText !== "canceled" && (i.addClass("ui-tabs-loading"), o.attr("aria-busy", "true"), this.xhr.success(function(e) {
                        setTimeout(function() {
                            o.html(e), r._trigger("load", n, u)
                        }, 1)
                    }).complete(function(e, t) {
                        setTimeout(function() {
                            t === "abort" && r.panels.stop(!1, !0), i.removeClass("ui-tabs-loading"), o.removeAttr("aria-busy"), e === r.xhr && delete r.xhr
                        }, 1)
                    }))
                },
                _ajaxSettings: function(t, n, r) {
                    var i = this;
                    return {
                        url: t.attr("href"),
                        beforeSend: function(t, s) {
                            return i._trigger("beforeLoad", n, e.extend({
                                jqXHR: t,
                                ajaxSettings: s
                            }, r))
                        }
                    }
                },
                _getPanelForTab: function(t) {
                    var n = e(t).attr("aria-controls");
                    return this.element.find(this._sanitizeSelector("#" + n))
                }
            }),
            tt = e.widget("ui.tooltip", {
                version: "1.11.2",
                options: {
                    content: function() {
                        var t = e(this).attr("title") || "";
                        return e("<a>").text(t).html()
                    },
                    hide: !0,
                    items: "[title]:not([disabled])",
                    position: {
                        my: "left top+15",
                        at: "left bottom",
                        collision: "flipfit flip"
                    },
                    show: !0,
                    tooltipClass: null,
                    track: !1,
                    close: null,
                    open: null
                },
                _addDescribedBy: function(t, n) {
                    var r = (t.attr("aria-describedby") || "").split(/\s+/);
                    r.push(n), t.data("ui-tooltip-id", n).attr("aria-describedby", e.trim(r.join(" ")))
                },
                _removeDescribedBy: function(t) {
                    var n = t.data("ui-tooltip-id"),
                        r = (t.attr("aria-describedby") || "").split(/\s+/),
                        i = e.inArray(n, r);
                    i !== -1 && r.splice(i, 1), t.removeData("ui-tooltip-id"), r = e.trim(r.join(" ")), r ? t.attr("aria-describedby", r) : t.removeAttr("aria-describedby")
                },
                _create: function() {
                    this._on({
                        mouseover: "open",
                        focusin: "open"
                    }), this.tooltips = {}, this.parents = {}, this.options.disabled && this._disable(), this.liveRegion = e("<div>").attr({
                        role: "log",
                        "aria-live": "assertive",
                        "aria-relevant": "additions"
                    }).addClass("ui-helper-hidden-accessible").appendTo(this.document[0].body)
                },
                _setOption: function(t, n) {
                    var r = this;
                    if (t === "disabled") {
                        this[n ? "_disable" : "_enable"](), this.options[t] = n;
                        return
                    }
                    this._super(t, n), t === "content" && e.each(this.tooltips, function(e, t) {
                        r._updateContent(t.element)
                    })
                },
                _disable: function() {
                    var t = this;
                    e.each(this.tooltips, function(n, r) {
                        var i = e.Event("blur");
                        i.target = i.currentTarget = r.element[0], t.close(i, !0)
                    }), this.element.find(this.options.items).addBack().each(function() {
                        var t = e(this);
                        t.is("[title]") && t.data("ui-tooltip-title", t.attr("title")).removeAttr("title")
                    })
                },
                _enable: function() {
                    this.element.find(this.options.items).addBack().each(function() {
                        var t = e(this);
                        t.data("ui-tooltip-title") && t.attr("title", t.data("ui-tooltip-title"))
                    })
                },
                open: function(t) {
                    var n = this,
                        r = e(t ? t.target : this.element).closest(this.options.items);
                    if (!r.length || r.data("ui-tooltip-id")) return;
                    r.attr("title") && r.data("ui-tooltip-title", r.attr("title")), r.data("ui-tooltip-open", !0), t && t.type === "mouseover" && r.parents().each(function() {
                        var t = e(this),
                            r;
                        t.data("ui-tooltip-open") && (r = e.Event("blur"), r.target = r.currentTarget = this, n.close(r, !0)), t.attr("title") && (t.uniqueId(), n.parents[this.id] = {
                            element: this,
                            title: t.attr("title")
                        }, t.attr("title", ""))
                    }), this._updateContent(r, t)
                },
                _updateContent: function(e, t) {
                    var n, r = this.options.content,
                        i = this,
                        s = t ? t.type : null;
                    if (typeof r == "string") return this._open(t, e, r);
                    n = r.call(e[0], function(n) {
                        if (!e.data("ui-tooltip-open")) return;
                        i._delay(function() {
                            t && (t.type = s), this._open(t, e, n)
                        })
                    }), n && this._open(t, e, n)
                },
                _open: function(t, n, r) {
                    function l(e) {
                        f.of = e;
                        if (s.is(":hidden")) return;
                        s.position(f)
                    }
                    var i, s, o, u, a, f = e.extend({}, this.options.position);
                    if (!r) return;
                    i = this._find(n);
                    if (i) {
                        i.tooltip.find(".ui-tooltip-content").html(r);
                        return
                    }
                    n.is("[title]") && (t && t.type === "mouseover" ? n.attr("title", "") : n.removeAttr("title")), i = this._tooltip(n), s = i.tooltip, this._addDescribedBy(n, s.attr("id")), s.find(".ui-tooltip-content").html(r), this.liveRegion.children().hide(), r.clone ? (a = r.clone(), a.removeAttr("id").find("[id]").removeAttr("id")) : a = r, e("<div>").html(a).appendTo(this.liveRegion), this.options.track && t && /^mouse/.test(t.type) ? (this._on(this.document, {
                        mousemove: l
                    }), l(t)) : s.position(e.extend({
                        of: n
                    }, this.options.position)), s.hide(), this._show(s, this.options.show), this.options.show && this.options.show.delay && (u = this.delayedShow = setInterval(function() {
                        s.is(":visible") && (l(f.of), clearInterval(u))
                    }, e.fx.interval)), this._trigger("open", t, {
                        tooltip: s
                    }), o = {
                        keyup: function(t) {
                            if (t.keyCode === e.ui.keyCode.ESCAPE) {
                                var r = e.Event(t);
                                r.currentTarget = n[0], this.close(r, !0)
                            }
                        }
                    }, n[0] !== this.element[0] && (o.remove = function() {
                        this._removeTooltip(s)
                    });
                    if (!t || t.type === "mouseover") o.mouseleave = "close";
                    if (!t || t.type === "focusin") o.focusout = "close";
                    this._on(!0, n, o)
                },
                close: function(t) {
                    var n, r = this,
                        i = e(t ? t.currentTarget : this.element),
                        s = this._find(i);
                    if (!s) return;
                    n = s.tooltip;
                    if (s.closing) return;
                    clearInterval(this.delayedShow), i.data("ui-tooltip-title") && !i.attr("title") && i.attr("title", i.data("ui-tooltip-title")), this._removeDescribedBy(i), s.hiding = !0, n.stop(!0), this._hide(n, this.options.hide, function() {
                        r._removeTooltip(e(this))
                    }), i.removeData("ui-tooltip-open"), this._off(i, "mouseleave focusout keyup"), i[0] !== this.element[0] && this._off(i, "remove"), this._off(this.document, "mousemove"), t && t.type === "mouseleave" && e.each(this.parents, function(t, n) {
                        e(n.element).attr("title", n.title), delete r.parents[t]
                    }), s.closing = !0, this._trigger("close", t, {
                        tooltip: n
                    }), s.hiding || (s.closing = !1)
                },
                _tooltip: function(t) {
                    var n = e("<div>").attr("role", "tooltip").addClass("ui-tooltip ui-widget ui-corner-all ui-widget-content " + (this.options.tooltipClass || "")),
                        r = n.uniqueId().attr("id");
                    return e("<div>").addClass("ui-tooltip-content").appendTo(n), n.appendTo(this.document[0].body), this.tooltips[r] = {
                        element: t,
                        tooltip: n
                    }
                },
                _find: function(e) {
                    var t = e.data("ui-tooltip-id");
                    return t ? this.tooltips[t] : null
                },
                _removeTooltip: function(e) {
                    e.remove(), delete this.tooltips[e.attr("id")]
                },
                _destroy: function() {
                    var t = this;
                    e.each(this.tooltips, function(n, r) {
                        var i = e.Event("blur"),
                            s = r.element;
                        i.target = i.currentTarget = s[0], t.close(i, !0), e("#" + n).remove(), s.data("ui-tooltip-title") && (s.attr("title") || s.attr("title", s.data("ui-tooltip-title")), s.removeData("ui-tooltip-title"))
                    }), this.liveRegion.remove()
                }
            })
    });
var JSEncryptExports = {};
(function(e) {
    function i(e, t, n) {
        e != null && ("number" == typeof e ? this.fromNumber(e, t, n) : t == null && "string" != typeof e ? this.fromString(e, 256) : this.fromString(e, t))
    }

    function s() {
        return new i(null)
    }

    function o(e, t, n, r, i, s) {
        while (--s >= 0) {
            var o = t * this[e++] + n[r] + i;
            i = Math.floor(o / 67108864), n[r++] = o & 67108863
        }
        return i
    }

    function u(e, t, n, r, i, s) {
        var o = t & 32767,
            u = t >> 15;
        while (--s >= 0) {
            var a = this[e] & 32767,
                f = this[e++] >> 15,
                l = u * a + f * o;
            a = o * a + ((l & 32767) << 15) + n[r] + (i & 1073741823), i = (a >>> 30) + (l >>> 15) + u * f + (i >>> 30), n[r++] = a & 1073741823
        }
        return i
    }

    function a(e, t, n, r, i, s) {
        var o = t & 16383,
            u = t >> 14;
        while (--s >= 0) {
            var a = this[e] & 16383,
                f = this[e++] >> 14,
                l = u * a + f * o;
            a = o * a + ((l & 16383) << 14) + n[r] + i, i = (a >> 28) + (l >> 14) + u * f, n[r++] = a & 268435455
        }
        return i
    }

    function d(e) {
        return l.charAt(e)
    }

    function m(e, t) {
        var n = c[e.charCodeAt(t)];
        return n == null ? -1 : n
    }

    function g(e) {
        for (var t = this.t - 1; t >= 0; --t) e[t] = this[t];
        e.t = this.t, e.s = this.s
    }

    function y(e) {
        this.t = 1, this.s = e < 0 ? -1 : 0, e > 0 ? this[0] = e : e < -1 ? this[0] = e + DV : this.t = 0
    }

    function b(e) {
        var t = s();
        return t.fromInt(e), t
    }

    function w(e, t) {
        var n;
        if (t == 16) n = 4;
        else if (t == 8) n = 3;
        else if (t == 256) n = 8;
        else if (t == 2) n = 1;
        else if (t == 32) n = 5;
        else {
            if (t != 4) {
                this.fromRadix(e, t);
                return
            }
            n = 2
        }
        this.t = 0, this.s = 0;
        var r = e.length,
            s = !1,
            o = 0;
        while (--r >= 0) {
            var u = n == 8 ? e[r] & 255 : m(e, r);
            if (u < 0) {
                e.charAt(r) == "-" && (s = !0);
                continue
            }
            s = !1, o == 0 ? this[this.t++] = u : o + n > this.DB ? (this[this.t - 1] |= (u & (1 << this.DB - o) - 1) << o, this[this.t++] = u >> this.DB - o) : this[this.t - 1] |= u << o, o += n, o >= this.DB && (o -= this.DB)
        }
        n == 8 && (e[0] & 128) != 0 && (this.s = -1, o > 0 && (this[this.t - 1] |= (1 << this.DB - o) - 1 << o)), this.clamp(), s && i.ZERO.subTo(this, this)
    }

    function E() {
        var e = this.s & this.DM;
        while (this.t > 0 && this[this.t - 1] == e) --this.t
    }

    function S(e) {
        if (this.s < 0) return "-" + this.negate().toString(e);
        var t;
        if (e == 16) t = 4;
        else if (e == 8) t = 3;
        else if (e == 2) t = 1;
        else if (e == 32) t = 5;
        else {
            if (e != 4) return this.toRadix(e);
            t = 2
        }
        var n = (1 << t) - 1,
            r, i = !1,
            s = "",
            o = this.t,
            u = this.DB - o * this.DB % t;
        if (o-- > 0) {
            u < this.DB && (r = this[o] >> u) > 0 && (i = !0, s = d(r));
            while (o >= 0) u < t ? (r = (this[o] & (1 << u) - 1) << t - u, r |= this[--o] >> (u += this.DB - t)) : (r = this[o] >> (u -= t) & n, u <= 0 && (u += this.DB, --o)), r > 0 && (i = !0), i && (s += d(r))
        }
        return i ? s : "0"
    }

    function x() {
        var e = s();
        return i.ZERO.subTo(this, e), e
    }

    function T() {
        return this.s < 0 ? this.negate() : this
    }

    function N(e) {
        var t = this.s - e.s;
        if (t != 0) return t;
        var n = this.t;
        t = n - e.t;
        if (t != 0) return this.s < 0 ? -t : t;
        while (--n >= 0)
            if ((t = this[n] - e[n]) != 0) return t;
        return 0
    }

    function C(e) {
        var t = 1,
            n;
        return (n = e >>> 16) != 0 && (e = n, t += 16), (n = e >> 8) != 0 && (e = n, t += 8), (n = e >> 4) != 0 && (e = n, t += 4), (n = e >> 2) != 0 && (e = n, t += 2), (n = e >> 1) != 0 && (e = n, t += 1), t
    }

    function k() {
        return this.t <= 0 ? 0 : this.DB * (this.t - 1) + C(this[this.t - 1] ^ this.s & this.DM)
    }

    function L(e, t) {
        var n;
        for (n = this.t - 1; n >= 0; --n) t[n + e] = this[n];
        for (n = e - 1; n >= 0; --n) t[n] = 0;
        t.t = this.t + e, t.s = this.s
    }

    function A(e, t) {
        for (var n = e; n < this.t; ++n) t[n - e] = this[n];
        t.t = Math.max(this.t - e, 0), t.s = this.s
    }

    function O(e, t) {
        var n = e % this.DB,
            r = this.DB - n,
            i = (1 << r) - 1,
            s = Math.floor(e / this.DB),
            o = this.s << n & this.DM,
            u;
        for (u = this.t - 1; u >= 0; --u) t[u + s + 1] = this[u] >> r | o, o = (this[u] & i) << n;
        for (u = s - 1; u >= 0; --u) t[u] = 0;
        t[s] = o, t.t = this.t + s + 1, t.s = this.s, t.clamp()
    }

    function M(e, t) {
        t.s = this.s;
        var n = Math.floor(e / this.DB);
        if (n >= this.t) {
            t.t = 0;
            return
        }
        var r = e % this.DB,
            i = this.DB - r,
            s = (1 << r) - 1;
        t[0] = this[n] >> r;
        for (var o = n + 1; o < this.t; ++o) t[o - n - 1] |= (this[o] & s) << i, t[o - n] = this[o] >> r;
        r > 0 && (t[this.t - n - 1] |= (this.s & s) << i), t.t = this.t - n, t.clamp()
    }

    function _(e, t) {
        var n = 0,
            r = 0,
            i = Math.min(e.t, this.t);
        while (n < i) r += this[n] - e[n], t[n++] = r & this.DM, r >>= this.DB;
        if (e.t < this.t) {
            r -= e.s;
            while (n < this.t) r += this[n], t[n++] = r & this.DM, r >>= this.DB;
            r += this.s
        } else {
            r += this.s;
            while (n < e.t) r -= e[n], t[n++] = r & this.DM, r >>= this.DB;
            r -= e.s
        }
        t.s = r < 0 ? -1 : 0, r < -1 ? t[n++] = this.DV + r : r > 0 && (t[n++] = r), t.t = n, t.clamp()
    }

    function D(e, t) {
        var n = this.abs(),
            r = e.abs(),
            s = n.t;
        t.t = s + r.t;
        while (--s >= 0) t[s] = 0;
        for (s = 0; s < r.t; ++s) t[s + n.t] = n.am(0, r[s], t, s, 0, n.t);
        t.s = 0, t.clamp(), this.s != e.s && i.ZERO.subTo(t, t)
    }

    function P(e) {
        var t = this.abs(),
            n = e.t = 2 * t.t;
        while (--n >= 0) e[n] = 0;
        for (n = 0; n < t.t - 1; ++n) {
            var r = t.am(n, t[n], e, 2 * n, 0, 1);
            (e[n + t.t] += t.am(n + 1, 2 * t[n], e, 2 * n + 1, r, t.t - n - 1)) >= t.DV && (e[n + t.t] -= t.DV, e[n + t.t + 1] = 1)
        }
        e.t > 0 && (e[e.t - 1] += t.am(n, t[n], e, 2 * n, 0, 1)), e.s = 0, e.clamp()
    }

    function H(e, t, n) {
        var r = e.abs();
        if (r.t <= 0) return;
        var o = this.abs();
        if (o.t < r.t) {
            t != null && t.fromInt(0), n != null && this.copyTo(n);
            return
        }
        n == null && (n = s());
        var u = s(),
            a = this.s,
            f = e.s,
            l = this.DB - C(r[r.t - 1]);
        l > 0 ? (r.lShiftTo(l, u), o.lShiftTo(l, n)) : (r.copyTo(u), o.copyTo(n));
        var c = u.t,
            h = u[c - 1];
        if (h == 0) return;
        var p = h * (1 << this.F1) + (c > 1 ? u[c - 2] >> this.F2 : 0),
            d = this.FV / p,
            v = (1 << this.F1) / p,
            m = 1 << this.F2,
            g = n.t,
            y = g - c,
            b = t == null ? s() : t;
        u.dlShiftTo(y, b), n.compareTo(b) >= 0 && (n[n.t++] = 1, n.subTo(b, n)), i.ONE.dlShiftTo(c, b), b.subTo(u, u);
        while (u.t < c) u[u.t++] = 0;
        while (--y >= 0) {
            var w = n[--g] == h ? this.DM : Math.floor(n[g] * d + (n[g - 1] + m) * v);
            if ((n[g] += u.am(0, w, n, y, 0, c)) < w) {
                u.dlShiftTo(y, b), n.subTo(b, n);
                while (n[g] < --w) n.subTo(b, n)
            }
        }
        t != null && (n.drShiftTo(c, t), a != f && i.ZERO.subTo(t, t)), n.t = c, n.clamp(), l > 0 && n.rShiftTo(l, n), a < 0 && i.ZERO.subTo(n, n)
    }

    function B(e) {
        var t = s();
        return this.abs().divRemTo(e, null, t), this.s < 0 && t.compareTo(i.ZERO) > 0 && e.subTo(t, t), t
    }

    function j(e) {
        this.m = e
    }

    function F(e) {
        return e.s < 0 || e.compareTo(this.m) >= 0 ? e.mod(this.m) : e
    }

    function I(e) {
        return e
    }

    function q(e) {
        e.divRemTo(this.m, null, e)
    }

    function R(e, t, n) {
        e.multiplyTo(t, n), this.reduce(n)
    }

    function U(e, t) {
        e.squareTo(t), this.reduce(t)
    }

    function z() {
        if (this.t < 1) return 0;
        var e = this[0];
        if ((e & 1) == 0) return 0;
        var t = e & 3;
        return t = t * (2 - (e & 15) * t) & 15, t = t * (2 - (e & 255) * t) & 255, t = t * (2 - ((e & 65535) * t & 65535)) & 65535, t = t * (2 - e * t % this.DV) % this.DV, t > 0 ? this.DV - t : -t
    }

    function W(e) {
        this.m = e, this.mp = e.invDigit(), this.mpl = this.mp & 32767, this.mph = this.mp >> 15, this.um = (1 << e.DB - 15) - 1, this.mt2 = 2 * e.t
    }

    function X(e) {
        var t = s();
        return e.abs().dlShiftTo(this.m.t, t), t.divRemTo(this.m, null, t), e.s < 0 && t.compareTo(i.ZERO) > 0 && this.m.subTo(t, t), t
    }

    function V(e) {
        var t = s();
        return e.copyTo(t), this.reduce(t), t
    }

    function $(e) {
        while (e.t <= this.mt2) e[e.t++] = 0;
        for (var t = 0; t < this.m.t; ++t) {
            var n = e[t] & 32767,
                r = n * this.mpl + ((n * this.mph + (e[t] >> 15) * this.mpl & this.um) << 15) & e.DM;
            n = t + this.m.t, e[n] += this.m.am(0, r, e, t, 0, this.m.t);
            while (e[n] >= e.DV) e[n] -= e.DV, e[++n]++
        }
        e.clamp(), e.drShiftTo(this.m.t, e), e.compareTo(this.m) >= 0 && e.subTo(this.m, e)
    }

    function J(e, t) {
        e.squareTo(t), this.reduce(t)
    }

    function K(e, t, n) {
        e.multiplyTo(t, n), this.reduce(n)
    }

    function Q() {
        return (this.t > 0 ? this[0] & 1 : this.s) == 0
    }

    function G(e, t) {
        if (e > 4294967295 || e < 1) return i.ONE;
        var n = s(),
            r = s(),
            o = t.convert(this),
            u = C(e) - 1;
        o.copyTo(n);
        while (--u >= 0) {
            t.sqrTo(n, r);
            if ((e & 1 << u) > 0) t.mulTo(r, o, n);
            else {
                var a = n;
                n = r, r = a
            }
        }
        return t.revert(n)
    }

    function Y(e, t) {
        var n;
        return e < 256 || t.isEven() ? n = new j(t) : n = new W(t), this.exp(e, n)
    }

    function Z() {
        var e = s();
        return this.copyTo(e), e
    }

    function et() {
        if (this.s < 0) {
            if (this.t == 1) return this[0] - this.DV;
            if (this.t == 0) return -1
        } else {
            if (this.t == 1) return this[0];
            if (this.t == 0) return 0
        }
        return (this[1] & (1 << 32 - this.DB) - 1) << this.DB | this[0]
    }

    function tt() {
        return this.t == 0 ? this.s : this[0] << 24 >> 24
    }

    function nt() {
        return this.t == 0 ? this.s : this[0] << 16 >> 16
    }

    function rt(e) {
        return Math.floor(Math.LN2 * this.DB / Math.log(e))
    }

    function it() {
        return this.s < 0 ? -1 : this.t <= 0 || this.t == 1 && this[0] <= 0 ? 0 : 1
    }

    function st(e) {
        e == null && (e = 10);
        if (this.signum() == 0 || e < 2 || e > 36) return "0";
        var t = this.chunkSize(e),
            n = Math.pow(e, t),
            r = b(n),
            i = s(),
            o = s(),
            u = "";
        this.divRemTo(r, i, o);
        while (i.signum() > 0) u = (n + o.intValue()).toString(e).substr(1) + u, i.divRemTo(r, i, o);
        return o.intValue().toString(e) + u
    }

    function ot(e, t) {
        this.fromInt(0), t == null && (t = 10);
        var n = this.chunkSize(t),
            r = Math.pow(t, n),
            s = !1,
            o = 0,
            u = 0;
        for (var a = 0; a < e.length; ++a) {
            var f = m(e, a);
            if (f < 0) {
                e.charAt(a) == "-" && this.signum() == 0 && (s = !0);
                continue
            }
            u = t * u + f, ++o >= n && (this.dMultiply(r), this.dAddOffset(u, 0), o = 0, u = 0)
        }
        o > 0 && (this.dMultiply(Math.pow(t, o)), this.dAddOffset(u, 0)), s && i.ZERO.subTo(this, this)
    }

    function ut(e, t, n) {
        if ("number" == typeof t)
            if (e < 2) this.fromInt(1);
            else {
                this.fromNumber(e, n), this.testBit(e - 1) || this.bitwiseTo(i.ONE.shiftLeft(e - 1), vt, this), this.isEven() && this.dAddOffset(1, 0);
                while (!this.isProbablePrime(t)) this.dAddOffset(2, 0), this.bitLength() > e && this.subTo(i.ONE.shiftLeft(e - 1), this)
            }
        else {
            var r = new Array,
                s = e & 7;
            r.length = (e >> 3) + 1, t.nextBytes(r), s > 0 ? r[0] &= (1 << s) - 1 : r[0] = 0, this.fromString(r, 256)
        }
    }

    function at() {
        var e = this.t,
            t = new Array;
        t[0] = this.s;
        var n = this.DB - e * this.DB % 8,
            r, i = 0;
        if (e-- > 0) {
            n < this.DB && (r = this[e] >> n) != (this.s & this.DM) >> n && (t[i++] = r | this.s << this.DB - n);
            while (e >= 0) {
                n < 8 ? (r = (this[e] & (1 << n) - 1) << 8 - n, r |= this[--e] >> (n += this.DB - 8)) : (r = this[e] >> (n -= 8) & 255, n <= 0 && (n += this.DB, --e)), (r & 128) != 0 && (r |= -256), i == 0 && (this.s & 128) != (r & 128) && ++i;
                if (i > 0 || r != this.s) t[i++] = r
            }
        }
        return t
    }

    function ft(e) {
        return this.compareTo(e) == 0
    }

    function lt(e) {
        return this.compareTo(e) < 0 ? this : e
    }

    function ct(e) {
        return this.compareTo(e) > 0 ? this : e
    }

    function ht(e, t, n) {
        var r, i, s = Math.min(e.t, this.t);
        for (r = 0; r < s; ++r) n[r] = t(this[r], e[r]);
        if (e.t < this.t) {
            i = e.s & this.DM;
            for (r = s; r < this.t; ++r) n[r] = t(this[r], i);
            n.t = this.t
        } else {
            i = this.s & this.DM;
            for (r = s; r < e.t; ++r) n[r] = t(i, e[r]);
            n.t = e.t
        }
        n.s = t(this.s, e.s), n.clamp()
    }

    function pt(e, t) {
        return e & t
    }

    function dt(e) {
        var t = s();
        return this.bitwiseTo(e, pt, t), t
    }

    function vt(e, t) {
        return e | t
    }

    function mt(e) {
        var t = s();
        return this.bitwiseTo(e, vt, t), t
    }

    function gt(e, t) {
        return e ^ t
    }

    function yt(e) {
        var t = s();
        return this.bitwiseTo(e, gt, t), t
    }

    function bt(e, t) {
        return e & ~t
    }

    function wt(e) {
        var t = s();
        return this.bitwiseTo(e, bt, t), t
    }

    function Et() {
        var e = s();
        for (var t = 0; t < this.t; ++t) e[t] = this.DM & ~this[t];
        return e.t = this.t, e.s = ~this.s, e
    }

    function St(e) {
        var t = s();
        return e < 0 ? this.rShiftTo(-e, t) : this.lShiftTo(e, t), t
    }

    function xt(e) {
        var t = s();
        return e < 0 ? this.lShiftTo(-e, t) : this.rShiftTo(e, t), t
    }

    function Tt(e) {
        if (e == 0) return -1;
        var t = 0;
        return (e & 65535) == 0 && (e >>= 16, t += 16), (e & 255) == 0 && (e >>= 8, t += 8), (e & 15) == 0 && (e >>= 4, t += 4), (e & 3) == 0 && (e >>= 2, t += 2), (e & 1) == 0 && ++t, t
    }

    function Nt() {
        for (var e = 0; e < this.t; ++e)
            if (this[e] != 0) return e * this.DB + Tt(this[e]);
        return this.s < 0 ? this.t * this.DB : -1
    }

    function Ct(e) {
        var t = 0;
        while (e != 0) e &= e - 1, ++t;
        return t
    }

    function kt() {
        var e = 0,
            t = this.s & this.DM;
        for (var n = 0; n < this.t; ++n) e += Ct(this[n] ^ t);
        return e
    }

    function Lt(e) {
        var t = Math.floor(e / this.DB);
        return t >= this.t ? this.s != 0 : (this[t] & 1 << e % this.DB) != 0
    }

    function At(e, t) {
        var n = i.ONE.shiftLeft(e);
        return this.bitwiseTo(n, t, n), n
    }

    function Ot(e) {
        return this.changeBit(e, vt)
    }

    function Mt(e) {
        return this.changeBit(e, bt)
    }

    function _t(e) {
        return this.changeBit(e, gt)
    }

    function Dt(e, t) {
        var n = 0,
            r = 0,
            i = Math.min(e.t, this.t);
        while (n < i) r += this[n] + e[n], t[n++] = r & this.DM, r >>= this.DB;
        if (e.t < this.t) {
            r += e.s;
            while (n < this.t) r += this[n], t[n++] = r & this.DM, r >>= this.DB;
            r += this.s
        } else {
            r += this.s;
            while (n < e.t) r += e[n], t[n++] = r & this.DM, r >>= this.DB;
            r += e.s
        }
        t.s = r < 0 ? -1 : 0, r > 0 ? t[n++] = r : r < -1 && (t[n++] = this.DV + r), t.t = n, t.clamp()
    }

    function Pt(e) {
        var t = s();
        return this.addTo(e, t), t
    }

    function Ht(e) {
        var t = s();
        return this.subTo(e, t), t
    }

    function Bt(e) {
        var t = s();
        return this.multiplyTo(e, t), t
    }

    function jt() {
        var e = s();
        return this.squareTo(e), e
    }

    function Ft(e) {
        var t = s();
        return this.divRemTo(e, t, null), t
    }

    function It(e) {
        var t = s();
        return this.divRemTo(e, null, t), t
    }

    function qt(e) {
        var t = s(),
            n = s();
        return this.divRemTo(e, t, n), new Array(t, n)
    }

    function Rt(e) {
        this[this.t] = this.am(0, e - 1, this, 0, 0, this.t), ++this.t, this.clamp()
    }

    function Ut(e, t) {
        if (e == 0) return;
        while (this.t <= t) this[this.t++] = 0;
        this[t] += e;
        while (this[t] >= this.DV) this[t] -= this.DV, ++t >= this.t && (this[this.t++] = 0), ++this[t]
    }

    function zt() {}

    function Wt(e) {
        return e
    }

    function Xt(e, t, n) {
        e.multiplyTo(t, n)
    }

    function Vt(e, t) {
        e.squareTo(t)
    }

    function $t(e) {
        return this.exp(e, new zt)
    }

    function Jt(e, t, n) {
        var r = Math.min(this.t + e.t, t);
        n.s = 0, n.t = r;
        while (r > 0) n[--r] = 0;
        var i;
        for (i = n.t - this.t; r < i; ++r) n[r + this.t] = this.am(0, e[r], n, r, 0, this.t);
        for (i = Math.min(e.t, t); r < i; ++r) this.am(0, e[r], n, r, 0, t - r);
        n.clamp()
    }

    function Kt(e, t, n) {
        --t;
        var r = n.t = this.t + e.t - t;
        n.s = 0;
        while (--r >= 0) n[r] = 0;
        for (r = Math.max(t - this.t, 0); r < e.t; ++r) n[this.t + r - t] = this.am(t - r, e[r], n, 0, 0, this.t + r - t);
        n.clamp(), n.drShiftTo(1, n)
    }

    function Qt(e) {
        this.r2 = s(), this.q3 = s(), i.ONE.dlShiftTo(2 * e.t, this.r2), this.mu = this.r2.divide(e), this.m = e
    }

    function Gt(e) {
        if (e.s < 0 || e.t > 2 * this.m.t) return e.mod(this.m);
        if (e.compareTo(this.m) < 0) return e;
        var t = s();
        return e.copyTo(t), this.reduce(t), t
    }

    function Yt(e) {
        return e
    }

    function Zt(e) {
        e.drShiftTo(this.m.t - 1, this.r2), e.t > this.m.t + 1 && (e.t = this.m.t + 1, e.clamp()), this.mu.multiplyUpperTo(this.r2, this.m.t + 1, this.q3), this.m.multiplyLowerTo(this.q3, this.m.t + 1, this.r2);
        while (e.compareTo(this.r2) < 0) e.dAddOffset(1, this.m.t + 1);
        e.subTo(this.r2, e);
        while (e.compareTo(this.m) >= 0) e.subTo(this.m, e)
    }

    function en(e, t) {
        e.squareTo(t), this.reduce(t)
    }

    function tn(e, t, n) {
        e.multiplyTo(t, n), this.reduce(n)
    }

    function nn(e, t) {
        var n = e.bitLength(),
            r, i = b(1),
            o;
        if (n <= 0) return i;
        n < 18 ? r = 1 : n < 48 ? r = 3 : n < 144 ? r = 4 : n < 768 ? r = 5 : r = 6, n < 8 ? o = new j(t) : t.isEven() ? o = new Qt(t) : o = new W(t);
        var u = new Array,
            a = 3,
            f = r - 1,
            l = (1 << r) - 1;
        u[1] = o.convert(this);
        if (r > 1) {
            var c = s();
            o.sqrTo(u[1], c);
            while (a <= l) u[a] = s(), o.mulTo(c, u[a - 2], u[a]), a += 2
        }
        var h = e.t - 1,
            p, d = !0,
            v = s(),
            m;
        n = C(e[h]) - 1;
        while (h >= 0) {
            n >= f ? p = e[h] >> n - f & l : (p = (e[h] & (1 << n + 1) - 1) << f - n, h > 0 && (p |= e[h - 1] >> this.DB + n - f)), a = r;
            while ((p & 1) == 0) p >>= 1, --a;
            (n -= a) < 0 && (n += this.DB, --h);
            if (d) u[p].copyTo(i), d = !1;
            else {
                while (a > 1) o.sqrTo(i, v), o.sqrTo(v, i), a -= 2;
                a > 0 ? o.sqrTo(i, v) : (m = i, i = v, v = m), o.mulTo(v, u[p], i)
            }
            while (h >= 0 && (e[h] & 1 << n) == 0) o.sqrTo(i, v), m = i, i = v, v = m, --n < 0 && (n = this.DB - 1, --h)
        }
        return o.revert(i)
    }

    function rn(e) {
        var t = this.s < 0 ? this.negate() : this.clone(),
            n = e.s < 0 ? e.negate() : e.clone();
        if (t.compareTo(n) < 0) {
            var r = t;
            t = n, n = r
        }
        var i = t.getLowestSetBit(),
            s = n.getLowestSetBit();
        if (s < 0) return t;
        i < s && (s = i), s > 0 && (t.rShiftTo(s, t), n.rShiftTo(s, n));
        while (t.signum() > 0)(i = t.getLowestSetBit()) > 0 && t.rShiftTo(i, t), (i = n.getLowestSetBit()) > 0 && n.rShiftTo(i, n), t.compareTo(n) >= 0 ? (t.subTo(n, t), t.rShiftTo(1, t)) : (n.subTo(t, n), n.rShiftTo(1, n));
        return s > 0 && n.lShiftTo(s, n), n
    }

    function sn(e) {
        if (e <= 0) return 0;
        var t = this.DV % e,
            n = this.s < 0 ? e - 1 : 0;
        if (this.t > 0)
            if (t == 0) n = this[0] % e;
            else
                for (var r = this.t - 1; r >= 0; --r) n = (t * n + this[r]) % e;
        return n
    }

    function on(e) {
        var t = e.isEven();
        if (this.isEven() && t || e.signum() == 0) return i.ZERO;
        var n = e.clone(),
            r = this.clone(),
            s = b(1),
            o = b(0),
            u = b(0),
            a = b(1);
        while (n.signum() != 0) {
            while (n.isEven()) {
                n.rShiftTo(1, n);
                if (t) {
                    if (!s.isEven() || !o.isEven()) s.addTo(this, s), o.subTo(e, o);
                    s.rShiftTo(1, s)
                } else o.isEven() || o.subTo(e, o);
                o.rShiftTo(1, o)
            }
            while (r.isEven()) {
                r.rShiftTo(1, r);
                if (t) {
                    if (!u.isEven() || !a.isEven()) u.addTo(this, u), a.subTo(e, a);
                    u.rShiftTo(1, u)
                } else a.isEven() || a.subTo(e, a);
                a.rShiftTo(1, a)
            }
            n.compareTo(r) >= 0 ? (n.subTo(r, n), t && s.subTo(u, s), o.subTo(a, o)) : (r.subTo(n, r), t && u.subTo(s, u), a.subTo(o, a))
        }
        return r.compareTo(i.ONE) != 0 ? i.ZERO : a.compareTo(e) >= 0 ? a.subtract(e) : a.signum() < 0 ? (a.addTo(e, a), a.signum() < 0 ? a.add(e) : a) : a
    }

    function fn(e) {
        var t, n = this.abs();
        if (n.t == 1 && n[0] <= un[un.length - 1]) {
            for (t = 0; t < un.length; ++t)
                if (n[0] == un[t]) return !0;
            return !1
        }
        if (n.isEven()) return !1;
        t = 1;
        while (t < un.length) {
            var r = un[t],
                i = t + 1;
            while (i < un.length && r < an) r *= un[i++];
            r = n.modInt(r);
            while (t < i)
                if (r % un[t++] == 0) return !1
        }
        return n.millerRabin(e)
    }

    function ln(e) {
        var t = this.subtract(i.ONE),
            n = t.getLowestSetBit();
        if (n <= 0) return !1;
        var r = t.shiftRight(n);
        e = e + 1 >> 1, e > un.length && (e = un.length);
        var o = s();
        for (var u = 0; u < e; ++u) {
            o.fromInt(un[Math.floor(Math.random() * un.length)]);
            var a = o.modPow(r, this);
            if (a.compareTo(i.ONE) != 0 && a.compareTo(t) != 0) {
                var f = 1;
                while (f++ < n && a.compareTo(t) != 0) {
                    a = a.modPowInt(2, this);
                    if (a.compareTo(i.ONE) == 0) return !1
                }
                if (a.compareTo(t) != 0) return !1
            }
        }
        return !0
    }

    function cn() {
        this.i = 0, this.j = 0, this.S = new Array
    }

    function hn(e) {
        var t, n, r;
        for (t = 0; t < 256; ++t) this.S[t] = t;
        n = 0;
        for (t = 0; t < 256; ++t) n = n + this.S[t] + e[t % e.length] & 255, r = this.S[t], this.S[t] = this.S[n], this.S[n] = r;
        this.i = 0, this.j = 0
    }

    function pn() {
        var e;
        return this.i = this.i + 1 & 255, this.j = this.j + this.S[this.i] & 255, e = this.S[this.i], this.S[this.i] = this.S[this.j], this.S[this.j] = e, this.S[e + this.S[this.i] & 255]
    }

    function dn() {
        return new cn
    }

    function Sn() {
        if (mn == null) {
            mn = dn();
            while (yn < vn) {
                var e = Math.floor(65536 * Math.random());
                gn[yn++] = e & 255
            }
            mn.init(gn);
            for (yn = 0; yn < gn.length; ++yn) gn[yn] = 0;
            yn = 0
        }
        return mn.next()
    }

    function xn(e) {
        var t;
        for (t = 0; t < e.length; ++t) e[t] = Sn()
    }

    function Tn() {}

    function Nn(e, t) {
        return new i(e, t)
    }

    function Cn(e, t) {
        var n = "",
            r = 0;
        while (r + t < e.length) n += e.substring(r, r + t) + "\n", r += t;
        return n + e.substring(r, e.length)
    }

    function kn(e) {
        return e < 16 ? "0" + e.toString(16) : e.toString(16)
    }

    function Ln(e, t) {
        if (t < e.length + 11) return console.error("Message too long for RSA"), null;
        var n = new Array,
            r = e.length - 1;
        while (r >= 0 && t > 0) {
            var s = e.charCodeAt(r--);
            s < 128 ? n[--t] = s : s > 127 && s < 2048 ? (n[--t] = s & 63 | 128, n[--t] = s >> 6 | 192) : (n[--t] = s & 63 | 128, n[--t] = s >> 6 & 63 | 128, n[--t] = s >> 12 | 224)
        }
        n[--t] = 0;
        var o = new Tn,
            u = new Array;
        while (t > 2) {
            u[0] = 0;
            while (u[0] == 0) o.nextBytes(u);
            n[--t] = u[0]
        }
        return n[--t] = 2, n[--t] = 0, new i(n)
    }

    function An() {
        this.n = null, this.e = 0, this.d = null, this.p = null, this.q = null, this.dmp1 = null, this.dmq1 = null, this.coeff = null
    }

    function On(e, t) {
        e != null && t != null && e.length > 0 && t.length > 0 ? (this.n = Nn(e, 16), this.e = parseInt(t, 16)) : console.error("Invalid RSA public key")
    }

    function Mn(e) {
        return e.modPowInt(this.e, this.n)
    }

    function _n(e) {
        var t = Ln(e, this.n.bitLength() + 7 >> 3);
        if (t == null) return null;
        var n = this.doPublic(t);
        if (n == null) return null;
        var r = n.toString(16);
        return (r.length & 1) == 0 ? r : "0" + r
    }

    function Dn(e, t) {
        var n = e.toByteArray(),
            r = 0;
        while (r < n.length && n[r] == 0) ++r;
        if (n.length - r != t - 1 || n[r] != 2) return null;
        ++r;
        while (n[r] != 0)
            if (++r >= n.length) return null;
        var i = "";
        while (++r < n.length) {
            var s = n[r] & 255;
            s < 128 ? i += String.fromCharCode(s) : s > 191 && s < 224 ? (i += String.fromCharCode((s & 31) << 6 | n[r + 1] & 63), ++r) : (i += String.fromCharCode((s & 15) << 12 | (n[r + 1] & 63) << 6 | n[r + 2] & 63), r += 2)
        }
        return i
    }

    function Pn(e, t, n) {
        e != null && t != null && e.length > 0 && t.length > 0 ? (this.n = Nn(e, 16), this.e = parseInt(t, 16), this.d = Nn(n, 16)) : console.error("Invalid RSA private key")
    }

    function Hn(e, t, n, r, i, s, o, u) {
        e != null && t != null && e.length > 0 && t.length > 0 ? (this.n = Nn(e, 16), this.e = parseInt(t, 16), this.d = Nn(n, 16), this.p = Nn(r, 16), this.q = Nn(i, 16), this.dmp1 = Nn(s, 16), this.dmq1 = Nn(o, 16), this.coeff = Nn(u, 16)) : console.error("Invalid RSA private key")
    }

    function Bn(e, t) {
        var n = new Tn,
            r = e >> 1;
        this.e = parseInt(t, 16);
        var s = new i(t, 16);
        for (;;) {
            for (;;) {
                this.p = new i(e - r, 1, n);
                if (this.p.subtract(i.ONE).gcd(s).compareTo(i.ONE) == 0 && this.p.isProbablePrime(10)) break
            }
            for (;;) {
                this.q = new i(r, 1, n);
                if (this.q.subtract(i.ONE).gcd(s).compareTo(i.ONE) == 0 && this.q.isProbablePrime(10)) break
            }
            if (this.p.compareTo(this.q) <= 0) {
                var o = this.p;
                this.p = this.q, this.q = o
            }
            var u = this.p.subtract(i.ONE),
                a = this.q.subtract(i.ONE),
                f = u.multiply(a);
            if (f.gcd(s).compareTo(i.ONE) == 0) {
                this.n = this.p.multiply(this.q), this.d = s.modInverse(f), this.dmp1 = this.d.mod(u), this.dmq1 = this.d.mod(a), this.coeff = this.q.modInverse(this.p);
                break
            }
        }
    }

    function jn(e) {
        if (this.p == null || this.q == null) return e.modPow(this.d, this.n);
        var t = e.mod(this.p).modPow(this.dmp1, this.p),
            n = e.mod(this.q).modPow(this.dmq1, this.q);
        while (t.compareTo(n) < 0) t = t.add(this.p);
        return t.subtract(n).multiply(this.coeff).mod(this.p).multiply(this.q).add(n)
    }

    function Fn(e) {
        var t = Nn(e, 16),
            n = this.doPrivate(t);
        return n == null ? null : Dn(n, this.n.bitLength() + 7 >> 3)
    }

    function Rn(e) {
        var t, n, r = "";
        for (t = 0; t + 3 <= e.length; t += 3) n = parseInt(e.substring(t, t + 3), 16), r += In.charAt(n >> 6) + In.charAt(n & 63);
        t + 1 == e.length ? (n = parseInt(e.substring(t, t + 1), 16), r += In.charAt(n << 2)) : t + 2 == e.length && (n = parseInt(e.substring(t, t + 2), 16), r += In.charAt(n >> 2) + In.charAt((n & 3) << 4));
        while ((r.length & 3) > 0) r += qn;
        return r
    }

    function Un(e) {
        var t = "",
            n, r = 0,
            i;
        for (n = 0; n < e.length; ++n) {
            if (e.charAt(n) == qn) break;
            v = In.indexOf(e.charAt(n));
            if (v < 0) continue;
            r == 0 ? (t += d(v >> 2), i = v & 3, r = 1) : r == 1 ? (t += d(i << 2 | v >> 4), i = v & 15, r = 2) : r == 2 ? (t += d(i), t += d(v >> 2), i = v & 3, r = 3) : (t += d(i << 2 | v >> 4), t += d(v & 15), r = 0)
        }
        return r == 1 && (t += d(i << 2)), t
    }

    function zn(e) {
        var t = Un(e),
            n, r = new Array;
        for (n = 0; 2 * n < t.length; ++n) r[n] = parseInt(t.substring(2 * n, 2 * n + 2), 16);
        return r
    }
    var t, n = 0xdeadbeefcafe,
        r = (n & 16777215) == 15715070;
    r && navigator.appName == "Microsoft Internet Explorer" ? (i.prototype.am = u, t = 30) : r && navigator.appName != "Netscape" ? (i.prototype.am = o, t = 26) : (i.prototype.am = a, t = 28), i.prototype.DB = t, i.prototype.DM = (1 << t) - 1, i.prototype.DV = 1 << t;
    var f = 52;
    i.prototype.FV = Math.pow(2, f), i.prototype.F1 = f - t, i.prototype.F2 = 2 * t - f;
    var l = "0123456789abcdefghijklmnopqrstuvwxyz",
        c = new Array,
        h, p;
    h = "0".charCodeAt(0);
    for (p = 0; p <= 9; ++p) c[h++] = p;
    h = "a".charCodeAt(0);
    for (p = 10; p < 36; ++p) c[h++] = p;
    h = "A".charCodeAt(0);
    for (p = 10; p < 36; ++p) c[h++] = p;
    j.prototype.convert = F, j.prototype.revert = I, j.prototype.reduce = q, j.prototype.mulTo = R, j.prototype.sqrTo = U, W.prototype.convert = X, W.prototype.revert = V, W.prototype.reduce = $, W.prototype.mulTo = K, W.prototype.sqrTo = J, i.prototype.copyTo = g, i.prototype.fromInt = y, i.prototype.fromString = w, i.prototype.clamp = E, i.prototype.dlShiftTo = L, i.prototype.drShiftTo = A, i.prototype.lShiftTo = O, i.prototype.rShiftTo = M, i.prototype.subTo = _, i.prototype.multiplyTo = D, i.prototype.squareTo = P, i.prototype.divRemTo = H, i.prototype.invDigit = z, i.prototype.isEven = Q, i.prototype.exp = G, i.prototype.toString = S, i.prototype.negate = x, i.prototype.abs = T, i.prototype.compareTo = N, i.prototype.bitLength = k, i.prototype.mod = B, i.prototype.modPowInt = Y, i.ZERO = b(0), i.ONE = b(1), zt.prototype.convert = Wt, zt.prototype.revert = Wt, zt.prototype.mulTo = Xt, zt.prototype.sqrTo = Vt, Qt.prototype.convert = Gt, Qt.prototype.revert = Yt, Qt.prototype.reduce = Zt, Qt.prototype.mulTo = tn, Qt.prototype.sqrTo = en;
    var un = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997],
        an = (1 << 26) / un[un.length - 1];
    i.prototype.chunkSize = rt, i.prototype.toRadix = st, i.prototype.fromRadix = ot, i.prototype.fromNumber = ut, i.prototype.bitwiseTo = ht, i.prototype.changeBit = At, i.prototype.addTo = Dt, i.prototype.dMultiply = Rt, i.prototype.dAddOffset = Ut, i.prototype.multiplyLowerTo = Jt, i.prototype.multiplyUpperTo = Kt, i.prototype.modInt = sn, i.prototype.millerRabin = ln, i.prototype.clone = Z, i.prototype.intValue = et, i.prototype.byteValue = tt, i.prototype.shortValue = nt, i.prototype.signum = it, i.prototype.toByteArray = at, i.prototype.equals = ft, i.prototype.min = lt, i.prototype.max = ct, i.prototype.and = dt, i.prototype.or = mt, i.prototype.xor = yt, i.prototype.andNot = wt, i.prototype.not = Et, i.prototype.shiftLeft = St, i.prototype.shiftRight = xt, i.prototype.getLowestSetBit = Nt, i.prototype.bitCount = kt, i.prototype.testBit = Lt, i.prototype.setBit = Ot, i.prototype.clearBit = Mt, i.prototype.flipBit = _t, i.prototype.add = Pt, i.prototype.subtract = Ht, i.prototype.multiply = Bt, i.prototype.divide = Ft, i.prototype.remainder = It, i.prototype.divideAndRemainder = qt, i.prototype.modPow = nn, i.prototype.modInverse = on, i.prototype.pow = $t, i.prototype.gcd = rn, i.prototype.isProbablePrime = fn, i.prototype.square = jt, cn.prototype.init = hn, cn.prototype.next = pn;
    var vn = 256,
        mn, gn, yn;
    if (gn == null) {
        gn = new Array, yn = 0;
        var bn;
        if (window.crypto && window.crypto.getRandomValues) {
            var wn = new Uint32Array(256);
            window.crypto.getRandomValues(wn);
            for (bn = 0; bn < wn.length; ++bn) gn[yn++] = wn[bn] & 255
        }
        var En = function(e) {
            this.count = this.count || 0;
            if (this.count >= 256 || yn >= vn) {
                window.removeEventListener ? window.removeEventListener("mousemove", En) : window.detachEvent && window.detachEvent("onmousemove", En);
                return
            }
            this.count += 1;
            var t = e.x + e.y;
            gn[yn++] = t & 255
        };
        window.addEventListener ? window.addEventListener("mousemove", En) : window.attachEvent && window.attachEvent("onmousemove", En)
    }
    Tn.prototype.nextBytes = xn, An.prototype.doPublic = Mn, An.prototype.setPublic = On, An.prototype.encrypt = _n, An.prototype.doPrivate = jn, An.prototype.setPrivate = Pn, An.prototype.setPrivateEx = Hn, An.prototype.generate = Bn, An.prototype.decrypt = Fn,
        function() {
            var e = function(e, t, n) {
                var r = new Tn,
                    o = e >> 1;
                this.e = parseInt(t, 16);
                var u = new i(t, 16),
                    a = this,
                    f = function() {
                        var t = function() {
                                if (a.p.compareTo(a.q) <= 0) {
                                    var e = a.p;
                                    a.p = a.q, a.q = e
                                }
                                var t = a.p.subtract(i.ONE),
                                    r = a.q.subtract(i.ONE),
                                    s = t.multiply(r);
                                s.gcd(u).compareTo(i.ONE) == 0 ? (a.n = a.p.multiply(a.q), a.d = u.modInverse(s), a.dmp1 = a.d.mod(t), a.dmq1 = a.d.mod(r), a.coeff = a.q.modInverse(a.p), setTimeout(function() {
                                    n()
                                }, 0)) : setTimeout(f, 0)
                            },
                            l = function() {
                                a.q = s(), a.q.fromNumberAsync(o, 1, r, function() {
                                    a.q.subtract(i.ONE).gcda(u, function(e) {
                                        e.compareTo(i.ONE) == 0 && a.q.isProbablePrime(10) ? setTimeout(t, 0) : setTimeout(l, 0)
                                    })
                                })
                            },
                            c = function() {
                                a.p = s(), a.p.fromNumberAsync(e - o, 1, r, function() {
                                    a.p.subtract(i.ONE).gcda(u, function(e) {
                                        e.compareTo(i.ONE) == 0 && a.p.isProbablePrime(10) ? setTimeout(l, 0) : setTimeout(c, 0)
                                    })
                                })
                            };
                        setTimeout(c, 0)
                    };
                setTimeout(f, 0)
            };
            An.prototype.generateAsync = e;
            var t = function(e, t) {
                var n = this.s < 0 ? this.negate() : this.clone(),
                    r = e.s < 0 ? e.negate() : e.clone();
                if (n.compareTo(r) < 0) {
                    var i = n;
                    n = r, r = i
                }
                var s = n.getLowestSetBit(),
                    o = r.getLowestSetBit();
                if (o < 0) {
                    t(n);
                    return
                }
                s < o && (o = s), o > 0 && (n.rShiftTo(o, n), r.rShiftTo(o, r));
                var u = function() {
                    (s = n.getLowestSetBit()) > 0 && n.rShiftTo(s, n), (s = r.getLowestSetBit()) > 0 && r.rShiftTo(s, r), n.compareTo(r) >= 0 ? (n.subTo(r, n), n.rShiftTo(1, n)) : (r.subTo(n, r), r.rShiftTo(1, r)), n.signum() > 0 ? setTimeout(u, 0) : (o > 0 && r.lShiftTo(o, r), setTimeout(function() {
                        t(r)
                    }, 0))
                };
                setTimeout(u, 10)
            };
            i.prototype.gcda = t;
            var n = function(e, t, n, r) {
                if ("number" == typeof t)
                    if (e < 2) this.fromInt(1);
                    else {
                        this.fromNumber(e, n), this.testBit(e - 1) || this.bitwiseTo(i.ONE.shiftLeft(e - 1), vt, this), this.isEven() && this.dAddOffset(1, 0);
                        var s = this,
                            o = function() {
                                s.dAddOffset(2, 0), s.bitLength() > e && s.subTo(i.ONE.shiftLeft(e - 1), s), s.isProbablePrime(t) ? setTimeout(function() {
                                    r()
                                }, 0) : setTimeout(o, 0)
                            };
                        setTimeout(o, 0)
                    }
                else {
                    var u = new Array,
                        a = e & 7;
                    u.length = (e >> 3) + 1, t.nextBytes(u), a > 0 ? u[0] &= (1 << a) - 1 : u[0] = 0, this.fromString(u, 256)
                }
            };
            i.prototype.fromNumberAsync = n
        }();
    var In = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        qn = "=",
        Wn = Wn || {};
    Wn.env = Wn.env || {};
    var Xn = Wn,
        Vn = Object.prototype,
        $n = "[object Function]",
        Jn = ["toString", "valueOf"];
    Wn.env.parseUA = function(e) {
        var t = function(e) {
                var t = 0;
                return parseFloat(e.replace(/\./g, function() {
                    return t++ == 1 ? "" : "."
                }))
            },
            n = navigator,
            r = {
                ie: 0,
                opera: 0,
                gecko: 0,
                webkit: 0,
                chrome: 0,
                mobile: null,
                air: 0,
                ipad: 0,
                iphone: 0,
                ipod: 0,
                ios: null,
                android: 0,
                webos: 0,
                caja: n && n.cajaVersion,
                secure: !1,
                os: null
            },
            i = e || navigator && navigator.userAgent,
            s = window && window.location,
            o = s && s.href,
            u;
        return r.secure = o && o.toLowerCase().indexOf("https") === 0, i && (/windows|win32/i.test(i) ? r.os = "windows" : /macintosh/i.test(i) ? r.os = "macintosh" : /rhino/i.test(i) && (r.os = "rhino"), /KHTML/.test(i) && (r.webkit = 1), u = i.match(/AppleWebKit\/([^\s]*)/), u && u[1] && (r.webkit = t(u[1]), / Mobile\//.test(i) ? (r.mobile = "Apple", u = i.match(/OS ([^\s]*)/), u && u[1] && (u = t(u[1].replace("_", "."))), r.ios = u, r.ipad = r.ipod = r.iphone = 0, u = i.match(/iPad|iPod|iPhone/), u && u[0] && (r[u[0].toLowerCase()] = r.ios)) : (u = i.match(/NokiaN[^\/]*|Android \d\.\d|webOS\/\d\.\d/), u && (r.mobile = u[0]), /webOS/.test(i) && (r.mobile = "WebOS", u = i.match(/webOS\/([^\s]*);/), u && u[1] && (r.webos = t(u[1]))), / Android/.test(i) && (r.mobile = "Android", u = i.match(/Android ([^\s]*);/), u && u[1] && (r.android = t(u[1])))), u = i.match(/Chrome\/([^\s]*)/), u && u[1] ? r.chrome = t(u[1]) : (u = i.match(/AdobeAIR\/([^\s]*)/), u && (r.air = u[0]))), r.webkit || (u = i.match(/Opera[\s\/]([^\s]*)/), u && u[1] ? (r.opera = t(u[1]), u = i.match(/Version\/([^\s]*)/), u && u[1] && (r.opera = t(u[1])), u = i.match(/Opera Mini[^;]*/), u && (r.mobile = u[0])) : (u = i.match(/MSIE\s([^;]*)/), u && u[1] ? r.ie = t(u[1]) : (u = i.match(/Gecko\/([^\s]*)/), u && (r.gecko = 1, u = i.match(/rv:([^\s\)]*)/), u && u[1] && (r.gecko = t(u[1]))))))), r
    }, Wn.env.ua = Wn.env.parseUA(), Wn.isFunction = function(e) {
        return typeof e == "function" || Vn.toString.apply(e) === $n
    }, Wn._IEEnumFix = Wn.env.ua.ie ? function(e, t) {
        var n, r, i;
        for (n = 0; n < Jn.length; n += 1) r = Jn[n], i = t[r], Xn.isFunction(i) && i != Vn[r] && (e[r] = i)
    } : function() {}, Wn.extend = function(e, t, n) {
        if (!t || !e) throw new Error("extend failed, please check that all dependencies are included.");
        var r = function() {},
            i;
        r.prototype = t.prototype, e.prototype = new r, e.prototype.constructor = e, e.superclass = t.prototype, t.prototype.constructor == Vn.constructor && (t.prototype.constructor = t);
        if (n) {
            for (i in n) Xn.hasOwnProperty(n, i) && (e.prototype[i] = n[i]);
            Xn._IEEnumFix(e.prototype, n)
        }
    };
    if (typeof KJUR == "undefined" || !KJUR) KJUR = {};
    if (typeof KJUR.asn1 == "undefined" || !KJUR.asn1) KJUR.asn1 = {};
    KJUR.asn1.ASN1Util = new function() {
            this.integerToByteHex = function(e) {
                var t = e.toString(16);
                return t.length % 2 == 1 && (t = "0" + t), t
            }, this.bigIntToMinTwosComplementsHex = function(e) {
                var t = e.toString(16);
                if (t.substr(0, 1) != "-") t.length % 2 == 1 ? t = "0" + t : t.match(/^[0-7]/) || (t = "00" + t);
                else {
                    var n = t.substr(1),
                        r = n.length;
                    r % 2 == 1 ? r += 1 : t.match(/^[0-7]/) || (r += 2);
                    var s = "";
                    for (var o = 0; o < r; o++) s += "f";
                    var u = new i(s, 16),
                        a = u.xor(e).add(i.ONE);
                    t = a.toString(16).replace(/^-/, "")
                }
                return t
            }, this.getPEMStringFromHex = function(e, t) {
                var n = CryptoJS.enc.Hex.parse(e),
                    r = CryptoJS.enc.Base64.stringify(n),
                    i = r.replace(/(.{64})/g, "$1\r\n");
                return i = i.replace(/\r\n$/, ""), "-----BEGIN " + t + "-----\r\n" + i + "\r\n-----END " + t + "-----\r\n"
            }
        }, KJUR.asn1.ASN1Object = function() {
            var e = !0,
                t = null,
                n = "00",
                r = "00",
                i = "";
            this.getLengthHexFromValue = function() {
                if (typeof this.hV == "undefined" || this.hV == null) throw "this.hV is null or undefined.";
                if (this.hV.length % 2 == 1) throw "value hex must be even length: n=" + i.length + ",v=" + this.hV;
                var e = this.hV.length / 2,
                    t = e.toString(16);
                t.length % 2 == 1 && (t = "0" + t);
                if (e < 128) return t;
                var n = t.length / 2;
                if (n > 15) throw "ASN.1 length too long to represent by 8x: n = " + e.toString(16);
                var r = 128 + n;
                return r.toString(16) + t
            }, this.getEncodedHex = function() {
                if (this.hTLV == null || this.isModified) this.hV = this.getFreshValueHex(), this.hL = this.getLengthHexFromValue(), this.hTLV = this.hT + this.hL + this.hV, this.isModified = !1;
                return this.hTLV
            }, this.getValueHex = function() {
                return this.getEncodedHex(), this.hV
            }, this.getFreshValueHex = function() {
                return ""
            }
        }, KJUR.asn1.DERAbstractString = function(e) {
            KJUR.asn1.DERAbstractString.superclass.constructor.call(this);
            var t = null,
                n = null;
            this.getString = function() {
                return this.s
            }, this.setString = function(e) {
                this.hTLV = null, this.isModified = !0, this.s = e, this.hV = stohex(this.s)
            }, this.setStringHex = function(e) {
                this.hTLV = null, this.isModified = !0, this.s = null, this.hV = e
            }, this.getFreshValueHex = function() {
                return this.hV
            }, typeof e != "undefined" && (typeof e["str"] != "undefined" ? this.setString(e.str) : typeof e["hex"] != "undefined" && this.setStringHex(e.hex))
        }, Wn.extend(KJUR.asn1.DERAbstractString, KJUR.asn1.ASN1Object), KJUR.asn1.DERAbstractTime = function(e) {
            KJUR.asn1.DERAbstractTime.superclass.constructor.call(this);
            var t = null,
                n = null;
            this.localDateToUTC = function(e) {
                utc = e.getTime() + e.getTimezoneOffset() * 6e4;
                var t = new Date(utc);
                return t
            }, this.formatDate = function(e, t) {
                var n = this.zeroPadding,
                    r = this.localDateToUTC(e),
                    i = String(r.getFullYear());
                t == "utc" && (i = i.substr(2, 2));
                var s = n(String(r.getMonth() + 1), 2),
                    o = n(String(r.getDate()), 2),
                    u = n(String(r.getHours()), 2),
                    a = n(String(r.getMinutes()), 2),
                    f = n(String(r.getSeconds()), 2);
                return i + s + o + u + a + f + "Z"
            }, this.zeroPadding = function(e, t) {
                return e.length >= t ? e : (new Array(t - e.length + 1)).join("0") + e
            }, this.getString = function() {
                return this.s
            }, this.setString = function(e) {
                this.hTLV = null, this.isModified = !0, this.s = e, this.hV = stohex(this.s)
            }, this.setByDateValue = function(e, t, n, r, i, s) {
                var o = new Date(Date.UTC(e, t - 1, n, r, i, s, 0));
                this.setByDate(o)
            }, this.getFreshValueHex = function() {
                return this.hV
            }
        }, Wn.extend(KJUR.asn1.DERAbstractTime, KJUR.asn1.ASN1Object), KJUR.asn1.DERAbstractStructured = function(e) {
            KJUR.asn1.DERAbstractString.superclass.constructor.call(this);
            var t = null;
            this.setByASN1ObjectArray = function(e) {
                this.hTLV = null, this.isModified = !0, this.asn1Array = e
            }, this.appendASN1Object = function(e) {
                this.hTLV = null, this.isModified = !0, this.asn1Array.push(e)
            }, this.asn1Array = new Array, typeof e != "undefined" && typeof e["array"] != "undefined" && (this.asn1Array = e.array)
        }, Wn.extend(KJUR.asn1.DERAbstractStructured, KJUR.asn1.ASN1Object), KJUR.asn1.DERBoolean = function() {
            KJUR.asn1.DERBoolean.superclass.constructor.call(this), this.hT = "01", this.hTLV = "0101ff"
        }, Wn.extend(KJUR.asn1.DERBoolean, KJUR.asn1.ASN1Object), KJUR.asn1.DERInteger = function(e) {
            KJUR.asn1.DERInteger.superclass.constructor.call(this), this.hT = "02", this.setByBigInteger = function(e) {
                this.hTLV = null, this.isModified = !0, this.hV = KJUR.asn1.ASN1Util.bigIntToMinTwosComplementsHex(e)
            }, this.setByInteger = function(e) {
                var t = new i(String(e), 10);
                this.setByBigInteger(t)
            }, this.setValueHex = function(e) {
                this.hV = e
            }, this.getFreshValueHex = function() {
                return this.hV
            }, typeof e != "undefined" && (typeof e["bigint"] != "undefined" ? this.setByBigInteger(e.bigint) : typeof e["int"] != "undefined" ? this.setByInteger(e["int"]) : typeof e["hex"] != "undefined" && this.setValueHex(e.hex))
        }, Wn.extend(KJUR.asn1.DERInteger, KJUR.asn1.ASN1Object), KJUR.asn1.DERBitString = function(e) {
            KJUR.asn1.DERBitString.superclass.constructor.call(this), this.hT = "03", this.setHexValueIncludingUnusedBits = function(e) {
                this.hTLV = null, this.isModified = !0, this.hV = e
            }, this.setUnusedBitsAndHexValue = function(e, t) {
                if (e < 0 || 7 < e) throw "unused bits shall be from 0 to 7: u = " + e;
                var n = "0" + e;
                this.hTLV = null, this.isModified = !0, this.hV = n + t
            }, this.setByBinaryString = function(e) {
                e = e.replace(/0+$/, "");
                var t = 8 - e.length % 8;
                t == 8 && (t = 0);
                for (var n = 0; n <= t; n++) e += "0";
                var r = "";
                for (var n = 0; n < e.length - 1; n += 8) {
                    var i = e.substr(n, 8),
                        s = parseInt(i, 2).toString(16);
                    s.length == 1 && (s = "0" + s), r += s
                }
                this.hTLV = null, this.isModified = !0, this.hV = "0" + t + r
            }, this.setByBooleanArray = function(e) {
                var t = "";
                for (var n = 0; n < e.length; n++) e[n] == 1 ? t += "1" : t += "0";
                this.setByBinaryString(t)
            }, this.newFalseArray = function(e) {
                var t = new Array(e);
                for (var n = 0; n < e; n++) t[n] = !1;
                return t
            }, this.getFreshValueHex = function() {
                return this.hV
            }, typeof e != "undefined" && (typeof e["hex"] != "undefined" ? this.setHexValueIncludingUnusedBits(e.hex) : typeof e["bin"] != "undefined" ? this.setByBinaryString(e.bin) : typeof e["array"] != "undefined" && this.setByBooleanArray(e.array))
        }, Wn.extend(KJUR.asn1.DERBitString, KJUR.asn1.ASN1Object), KJUR.asn1.DEROctetString = function(e) {
            KJUR.asn1.DEROctetString.superclass.constructor.call(this, e), this.hT = "04"
        }, Wn.extend(KJUR.asn1.DEROctetString, KJUR.asn1.DERAbstractString), KJUR.asn1.DERNull = function() {
            KJUR.asn1.DERNull.superclass.constructor.call(this), this.hT = "05", this.hTLV = "0500"
        }, Wn.extend(KJUR.asn1.DERNull, KJUR.asn1.ASN1Object), KJUR.asn1.DERObjectIdentifier = function(e) {
            var t = function(e) {
                    var t = e.toString(16);
                    return t.length == 1 && (t = "0" + t), t
                },
                n = function(e) {
                    var n = "",
                        r = new i(e, 10),
                        s = r.toString(2),
                        o = 7 - s.length % 7;
                    o == 7 && (o = 0);
                    var u = "";
                    for (var a = 0; a < o; a++) u += "0";
                    s = u + s;
                    for (var a = 0; a < s.length - 1; a += 7) {
                        var f = s.substr(a, 7);
                        a != s.length - 7 && (f = "1" + f), n += t(parseInt(f, 2))
                    }
                    return n
                };
            KJUR.asn1.DERObjectIdentifier.superclass.constructor.call(this), this.hT = "06", this.setValueHex = function(e) {
                this.hTLV = null, this.isModified = !0, this.s = null, this.hV = e
            }, this.setValueOidString = function(e) {
                if (!e.match(/^[0-9.]+$/)) throw "malformed oid string: " + e;
                var r = "",
                    i = e.split("."),
                    s = parseInt(i[0]) * 40 + parseInt(i[1]);
                r += t(s), i.splice(0, 2);
                for (var o = 0; o < i.length; o++) r += n(i[o]);
                this.hTLV = null, this.isModified = !0, this.s = null, this.hV = r
            }, this.setValueName = function(e) {
                if (typeof KJUR.asn1.x509.OID.name2oidList[e] == "undefined") throw "DERObjectIdentifier oidName undefined: " + e;
                var t = KJUR.asn1.x509.OID.name2oidList[e];
                this.setValueOidString(t)
            }, this.getFreshValueHex = function() {
                return this.hV
            }, typeof e != "undefined" && (typeof e["oid"] != "undefined" ? this.setValueOidString(e.oid) : typeof e["hex"] != "undefined" ? this.setValueHex(e.hex) : typeof e["name"] != "undefined" && this.setValueName(e.name))
        }, Wn.extend(KJUR.asn1.DERObjectIdentifier, KJUR.asn1.ASN1Object), KJUR.asn1.DERUTF8String = function(e) {
            KJUR.asn1.DERUTF8String.superclass.constructor.call(this, e), this.hT = "0c"
        }, Wn.extend(KJUR.asn1.DERUTF8String, KJUR.asn1.DERAbstractString), KJUR.asn1.DERNumericString = function(e) {
            KJUR.asn1.DERNumericString.superclass.constructor.call(this, e), this.hT = "12"
        }, Wn.extend(KJUR.asn1.DERNumericString, KJUR.asn1.DERAbstractString), KJUR.asn1.DERPrintableString = function(e) {
            KJUR.asn1.DERPrintableString.superclass.constructor.call(this, e), this.hT = "13"
        }, Wn.extend(KJUR.asn1.DERPrintableString, KJUR.asn1.DERAbstractString), KJUR.asn1.DERTeletexString = function(e) {
            KJUR.asn1.DERTeletexString.superclass.constructor.call(this, e), this.hT = "14"
        }, Wn.extend(KJUR.asn1.DERTeletexString, KJUR.asn1.DERAbstractString), KJUR.asn1.DERIA5String = function(e) {
            KJUR.asn1.DERIA5String.superclass.constructor.call(this, e), this.hT = "16"
        }, Wn.extend(KJUR.asn1.DERIA5String, KJUR.asn1.DERAbstractString), KJUR.asn1.DERUTCTime = function(e) {
            KJUR.asn1.DERUTCTime.superclass.constructor.call(this, e), this.hT = "17", this.setByDate = function(e) {
                this.hTLV = null, this.isModified = !0, this.date = e, this.s = this.formatDate(this.date, "utc"), this.hV = stohex(this.s)
            }, typeof e != "undefined" && (typeof e["str"] != "undefined" ? this.setString(e.str) : typeof e["hex"] != "undefined" ? this.setStringHex(e.hex) : typeof e["date"] != "undefined" && this.setByDate(e.date))
        }, Wn.extend(KJUR.asn1.DERUTCTime, KJUR.asn1.DERAbstractTime), KJUR.asn1.DERGeneralizedTime = function(e) {
            KJUR.asn1.DERGeneralizedTime.superclass.constructor.call(this, e), this.hT = "18", this.setByDate = function(e) {
                this.hTLV = null, this.isModified = !0, this.date = e, this.s = this.formatDate(this.date, "gen"), this.hV = stohex(this.s)
            }, typeof e != "undefined" && (typeof e["str"] != "undefined" ? this.setString(e.str) : typeof e["hex"] != "undefined" ? this.setStringHex(e.hex) : typeof e["date"] != "undefined" && this.setByDate(e.date))
        }, Wn.extend(KJUR.asn1.DERGeneralizedTime, KJUR.asn1.DERAbstractTime), KJUR.asn1.DERSequence = function(e) {
            KJUR.asn1.DERSequence.superclass.constructor.call(this, e), this.hT = "30", this.getFreshValueHex = function() {
                var e = "";
                for (var t = 0; t < this.asn1Array.length; t++) {
                    var n = this.asn1Array[t];
                    e += n.getEncodedHex()
                }
                return this.hV = e, this.hV
            }
        }, Wn.extend(KJUR.asn1.DERSequence, KJUR.asn1.DERAbstractStructured), KJUR.asn1.DERSet = function(e) {
            KJUR.asn1.DERSet.superclass.constructor.call(this, e), this.hT = "31", this.getFreshValueHex = function() {
                var e = new Array;
                for (var t = 0; t < this.asn1Array.length; t++) {
                    var n = this.asn1Array[t];
                    e.push(n.getEncodedHex())
                }
                return e.sort(), this.hV = e.join(""), this.hV
            }
        }, Wn.extend(KJUR.asn1.DERSet, KJUR.asn1.DERAbstractStructured), KJUR.asn1.DERTaggedObject = function(e) {
            KJUR.asn1.DERTaggedObject.superclass.constructor.call(this), this.hT = "a0", this.hV = "", this.isExplicit = !0, this.asn1Object = null, this.setASN1Object = function(e, t, n) {
                this.hT = t, this.isExplicit = e, this.asn1Object = n, this.isExplicit ? (this.hV = this.asn1Object.getEncodedHex(), this.hTLV = null, this.isModified = !0) : (this.hV = null, this.hTLV = n.getEncodedHex(), this.hTLV = this.hTLV.replace(/^../, t), this.isModified = !1)
            }, this.getFreshValueHex = function() {
                return this.hV
            }, typeof e != "undefined" && (typeof e["tag"] != "undefined" && (this.hT = e.tag), typeof e["explicit"] != "undefined" && (this.isExplicit = e.explicit), typeof e["obj"] != "undefined" && (this.asn1Object = e.obj, this.setASN1Object(this.isExplicit, this.hT, this.asn1Object)))
        }, Wn.extend(KJUR.asn1.DERTaggedObject, KJUR.asn1.ASN1Object),
        function(e) {
            "use strict";
            var t = {},
                n;
            t.decode = function(t) {
                var r;
                if (n === e) {
                    var i = "0123456789ABCDEF",
                        s = " \f\n\r	 \u2028\u2029";
                    n = [];
                    for (r = 0; r < 16; ++r) n[i.charAt(r)] = r;
                    i = i.toLowerCase();
                    for (r = 10; r < 16; ++r) n[i.charAt(r)] = r;
                    for (r = 0; r < s.length; ++r) n[s.charAt(r)] = -1
                }
                var o = [],
                    u = 0,
                    a = 0;
                for (r = 0; r < t.length; ++r) {
                    var f = t.charAt(r);
                    if (f == "=") break;
                    f = n[f];
                    if (f == -1) continue;
                    if (f === e) throw "Illegal character at offset " + r;
                    u |= f, ++a >= 2 ? (o[o.length] = u, u = 0, a = 0) : u <<= 4
                }
                if (a) throw "Hex encoding incomplete: 4 bits missing";
                return o
            }, window.Hex = t
        }(),
        function(e) {
            "use strict";
            var t = {},
                n;
            t.decode = function(t) {
                var r;
                if (n === e) {
                    var i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                        s = "= \f\n\r	 \u2028\u2029";
                    n = [];
                    for (r = 0; r < 64; ++r) n[i.charAt(r)] = r;
                    for (r = 0; r < s.length; ++r) n[s.charAt(r)] = -1
                }
                var o = [],
                    u = 0,
                    a = 0;
                for (r = 0; r < t.length; ++r) {
                    var f = t.charAt(r);
                    if (f == "=") break;
                    f = n[f];
                    if (f == -1) continue;
                    if (f === e) throw "Illegal character at offset " + r;
                    u |= f, ++a >= 4 ? (o[o.length] = u >> 16, o[o.length] = u >> 8 & 255, o[o.length] = u & 255, u = 0, a = 0) : u <<= 6
                }
                switch (a) {
                    case 1:
                        throw "Base64 encoding incomplete: at least 2 bits missing";
                    case 2:
                        o[o.length] = u >> 10;
                        break;
                    case 3:
                        o[o.length] = u >> 16, o[o.length] = u >> 8 & 255
                }
                return o
            }, t.re = /-----BEGIN [^-]+-----([A-Za-z0-9+\/=\s]+)-----END [^-]+-----|begin-base64[^\n]+\n([A-Za-z0-9+\/=\s]+)====/, t.unarmor = function(e) {
                var n = t.re.exec(e);
                if (n)
                    if (n[1]) e = n[1];
                    else {
                        if (!n[2]) throw "RegExp out of sync";
                        e = n[2]
                    } return t.decode(e)
            }, window.Base64 = t
        }(),
        function(e) {
            "use strict";

            function i(e, t) {
                e instanceof i ? (this.enc = e.enc, this.pos = e.pos) : (this.enc = e, this.pos = t)
            }

            function s(e, t, n, r, i) {
                this.stream = e, this.header = t, this.length = n, this.tag = r, this.sub = i
            }
            var t = 100,
                n = "…",
                r = {
                    tag: function(e, t) {
                        var n = document.createElement(e);
                        return n.className = t, n
                    },
                    text: function(e) {
                        return document.createTextNode(e)
                    }
                };
            i.prototype.get = function(t) {
                t === e && (t = this.pos++);
                if (t >= this.enc.length) throw "Requesting byte offset " + t + " on a stream of length " + this.enc.length;
                return this.enc[t]
            }, i.prototype.hexDigits = "0123456789ABCDEF", i.prototype.hexByte = function(e) {
                return this.hexDigits.charAt(e >> 4 & 15) + this.hexDigits.charAt(e & 15)
            }, i.prototype.hexDump = function(e, t, n) {
                var r = "";
                for (var i = e; i < t; ++i) {
                    r += this.hexByte(this.get(i));
                    if (n !== !0) switch (i & 15) {
                        case 7:
                            r += "  ";
                            break;
                        case 15:
                            r += "\n";
                            break;
                        default:
                            r += " "
                    }
                }
                return r
            }, i.prototype.parseStringISO = function(e, t) {
                var n = "";
                for (var r = e; r < t; ++r) n += String.fromCharCode(this.get(r));
                return n
            }, i.prototype.parseStringUTF = function(e, t) {
                var n = "";
                for (var r = e; r < t;) {
                    var i = this.get(r++);
                    i < 128 ? n += String.fromCharCode(i) : i > 191 && i < 224 ? n += String.fromCharCode((i & 31) << 6 | this.get(r++) & 63) : n += String.fromCharCode((i & 15) << 12 | (this.get(r++) & 63) << 6 | this.get(r++) & 63)
                }
                return n
            }, i.prototype.parseStringBMP = function(e, t) {
                var n = "";
                for (var r = e; r < t; r += 2) {
                    var i = this.get(r),
                        s = this.get(r + 1);
                    n += String.fromCharCode((i << 8) + s)
                }
                return n
            }, i.prototype.reTime = /^((?:1[89]|2\d)?\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])(?:([0-5]\d)(?:([0-5]\d)(?:[.,](\d{1,3}))?)?)?(Z|[-+](?:[0]\d|1[0-2])([0-5]\d)?)?$/, i.prototype.parseTime = function(e, t) {
                var n = this.parseStringISO(e, t),
                    r = this.reTime.exec(n);
                return r ? (n = r[1] + "-" + r[2] + "-" + r[3] + " " + r[4], r[5] && (n += ":" + r[5], r[6] && (n += ":" + r[6], r[7] && (n += "." + r[7]))), r[8] && (n += " UTC", r[8] != "Z" && (n += r[8], r[9] && (n += ":" + r[9]))), n) : "Unrecognized time: " + n
            }, i.prototype.parseInteger = function(e, t) {
                var n = t - e;
                if (n > 4) {
                    n <<= 3;
                    var r = this.get(e);
                    if (r === 0) n -= 8;
                    else
                        while (r < 128) r <<= 1, --n;
                    return "(" + n + " bit)"
                }
                var i = 0;
                for (var s = e; s < t; ++s) i = i << 8 | this.get(s);
                return i
            }, i.prototype.parseBitString = function(e, t) {
                var n = this.get(e),
                    r = (t - e - 1 << 3) - n,
                    i = "(" + r + " bit)";
                if (r <= 20) {
                    var s = n;
                    i += " ";
                    for (var o = t - 1; o > e; --o) {
                        var u = this.get(o);
                        for (var a = s; a < 8; ++a) i += u >> a & 1 ? "1" : "0";
                        s = 0
                    }
                }
                return i
            }, i.prototype.parseOctetString = function(e, r) {
                var i = r - e,
                    s = "(" + i + " byte) ";
                i > t && (r = e + t);
                for (var o = e; o < r; ++o) s += this.hexByte(this.get(o));
                return i > t && (s += n), s
            }, i.prototype.parseOID = function(e, t) {
                var n = "",
                    r = 0,
                    i = 0;
                for (var s = e; s < t; ++s) {
                    var o = this.get(s);
                    r = r << 7 | o & 127, i += 7;
                    if (!(o & 128)) {
                        if (n === "") {
                            var u = r < 80 ? r < 40 ? 0 : 1 : 2;
                            n = u + "." + (r - u * 40)
                        } else n += "." + (i >= 31 ? "bigint" : r);
                        r = i = 0
                    }
                }
                return n
            }, s.prototype.typeName = function() {
                if (this.tag === e) return "unknown";
                var t = this.tag >> 6,
                    n = this.tag >> 5 & 1,
                    r = this.tag & 31;
                switch (t) {
                    case 0:
                        switch (r) {
                            case 0:
                                return "EOC";
                            case 1:
                                return "BOOLEAN";
                            case 2:
                                return "INTEGER";
                            case 3:
                                return "BIT_STRING";
                            case 4:
                                return "OCTET_STRING";
                            case 5:
                                return "NULL";
                            case 6:
                                return "OBJECT_IDENTIFIER";
                            case 7:
                                return "ObjectDescriptor";
                            case 8:
                                return "EXTERNAL";
                            case 9:
                                return "REAL";
                            case 10:
                                return "ENUMERATED";
                            case 11:
                                return "EMBEDDED_PDV";
                            case 12:
                                return "UTF8String";
                            case 16:
                                return "SEQUENCE";
                            case 17:
                                return "SET";
                            case 18:
                                return "NumericString";
                            case 19:
                                return "PrintableString";
                            case 20:
                                return "TeletexString";
                            case 21:
                                return "VideotexString";
                            case 22:
                                return "IA5String";
                            case 23:
                                return "UTCTime";
                            case 24:
                                return "GeneralizedTime";
                            case 25:
                                return "GraphicString";
                            case 26:
                                return "VisibleString";
                            case 27:
                                return "GeneralString";
                            case 28:
                                return "UniversalString";
                            case 30:
                                return "BMPString";
                            default:
                                return "Universal_" + r.toString(16)
                        };
                    case 1:
                        return "Application_" + r.toString(16);
                    case 2:
                        return "[" + r + "]";
                    case 3:
                        return "Private_" + r.toString(16)
                }
            }, s.prototype.reSeemsASCII = /^[ -~]+$/, s.prototype.content = function() {
                if (this.tag === e) return null;
                var r = this.tag >> 6,
                    i = this.tag & 31,
                    s = this.posContent(),
                    o = Math.abs(this.length);
                if (r !== 0) {
                    if (this.sub !== null) return "(" + this.sub.length + " elem)";
                    var u = this.stream.parseStringISO(s, s + Math.min(o, t));
                    return this.reSeemsASCII.test(u) ? u.substring(0, 2 * t) + (u.length > 2 * t ? n : "") : this.stream.parseOctetString(s, s + o)
                }
                switch (i) {
                    case 1:
                        return this.stream.get(s) === 0 ? "false" : "true";
                    case 2:
                        return this.stream.parseInteger(s, s + o);
                    case 3:
                        return this.sub ? "(" + this.sub.length + " elem)" : this.stream.parseBitString(s, s + o);
                    case 4:
                        return this.sub ? "(" + this.sub.length + " elem)" : this.stream.parseOctetString(s, s + o);
                    case 6:
                        return this.stream.parseOID(s, s + o);
                    case 16:
                    case 17:
                        return "(" + this.sub.length + " elem)";
                    case 12:
                        return this.stream.parseStringUTF(s, s + o);
                    case 18:
                    case 19:
                    case 20:
                    case 21:
                    case 22:
                    case 26:
                        return this.stream.parseStringISO(s, s + o);
                    case 30:
                        return this.stream.parseStringBMP(s, s + o);
                    case 23:
                    case 24:
                        return this.stream.parseTime(s, s + o)
                }
                return null
            }, s.prototype.toString = function() {
                return this.typeName() + "@" + this.stream.pos + "[header:" + this.header + ",length:" + this.length + ",sub:" + (this.sub === null ? "null" : this.sub.length) + "]"
            }, s.prototype.print = function(t) {
                t === e && (t = ""), document.writeln(t + this);
                if (this.sub !== null) {
                    t += "  ";
                    for (var n = 0, r = this.sub.length; n < r; ++n) this.sub[n].print(t)
                }
            }, s.prototype.toPrettyString = function(t) {
                t === e && (t = "");
                var n = t + this.typeName() + " @" + this.stream.pos;
                this.length >= 0 && (n += "+"), n += this.length, this.tag & 32 ? n += " (constructed)" : (this.tag == 3 || this.tag == 4) && this.sub !== null && (n += " (encapsulates)"), n += "\n";
                if (this.sub !== null) {
                    t += "  ";
                    for (var r = 0, i = this.sub.length; r < i; ++r) n += this.sub[r].toPrettyString(t)
                }
                return n
            }, s.prototype.toDOM = function() {
                var e = r.tag("div", "node");
                e.asn1 = this;
                var t = r.tag("div", "head"),
                    n = this.typeName().replace(/_/g, " ");
                t.innerHTML = n;
                var i = this.content();
                if (i !== null) {
                    i = String(i).replace(/</g, "&lt;");
                    var s = r.tag("span", "preview");
                    s.appendChild(r.text(i)), t.appendChild(s)
                }
                e.appendChild(t), this.node = e, this.head = t;
                var o = r.tag("div", "value");
                n = "Offset: " + this.stream.pos + "<br/>", n += "Length: " + this.header + "+", this.length >= 0 ? n += this.length : n += -this.length + " (undefined)", this.tag & 32 ? n += "<br/>(constructed)" : (this.tag == 3 || this.tag == 4) && this.sub !== null && (n += "<br/>(encapsulates)");
                if (i !== null) {
                    n += "<br/>Value:<br/><b>" + i + "</b>";
                    if (typeof oids == "object" && this.tag == 6) {
                        var u = oids[i];
                        u && (u.d && (n += "<br/>" + u.d), u.c && (n += "<br/>" + u.c), u.w && (n += "<br/>(warning!)"))
                    }
                }
                o.innerHTML = n, e.appendChild(o);
                var a = r.tag("div", "sub");
                if (this.sub !== null)
                    for (var f = 0, l = this.sub.length; f < l; ++f) a.appendChild(this.sub[f].toDOM());
                return e.appendChild(a), t.onclick = function() {
                    e.className = e.className == "node collapsed" ? "node" : "node collapsed"
                }, e
            }, s.prototype.posStart = function() {
                return this.stream.pos
            }, s.prototype.posContent = function() {
                return this.stream.pos + this.header
            }, s.prototype.posEnd = function() {
                return this.stream.pos + this.header + Math.abs(this.length)
            }, s.prototype.fakeHover = function(e) {
                this.node.className += " hover", e && (this.head.className += " hover")
            }, s.prototype.fakeOut = function(e) {
                var t = / ?hover/;
                this.node.className = this.node.className.replace(t, ""), e && (this.head.className = this.head.className.replace(t, ""))
            }, s.prototype.toHexDOM_sub = function(e, t, n, i, s) {
                if (i >= s) return;
                var o = r.tag("span", t);
                o.appendChild(r.text(n.hexDump(i, s))), e.appendChild(o)
            }, s.prototype.toHexDOM = function(t) {
                var n = r.tag("span", "hex");
                t === e && (t = n), this.head.hexNode = n, this.head.onmouseover = function() {
                    this.hexNode.className = "hexCurrent"
                }, this.head.onmouseout = function() {
                    this.hexNode.className = "hex"
                }, n.asn1 = this, n.onmouseover = function() {
                    var e = !t.selected;
                    e && (t.selected = this.asn1, this.className = "hexCurrent"), this.asn1.fakeHover(e)
                }, n.onmouseout = function() {
                    var e = t.selected == this.asn1;
                    this.asn1.fakeOut(e), e && (t.selected = null, this.className = "hex")
                }, this.toHexDOM_sub(n, "tag", this.stream, this.posStart(), this.posStart() + 1), this.toHexDOM_sub(n, this.length >= 0 ? "dlen" : "ulen", this.stream, this.posStart() + 1, this.posContent());
                if (this.sub === null) n.appendChild(r.text(this.stream.hexDump(this.posContent(), this.posEnd())));
                else if (this.sub.length > 0) {
                    var i = this.sub[0],
                        s = this.sub[this.sub.length - 1];
                    this.toHexDOM_sub(n, "intro", this.stream, this.posContent(), i.posStart());
                    for (var o = 0, u = this.sub.length; o < u; ++o) n.appendChild(this.sub[o].toHexDOM(t));
                    this.toHexDOM_sub(n, "outro", this.stream, s.posEnd(), this.posEnd())
                }
                return n
            }, s.prototype.toHexString = function(e) {
                return this.stream.hexDump(this.posStart(), this.posEnd(), !0)
            }, s.decodeLength = function(e) {
                var t = e.get(),
                    n = t & 127;
                if (n == t) return n;
                if (n > 3) throw "Length over 24 bits not supported at position " + (e.pos - 1);
                if (n === 0) return -1;
                t = 0;
                for (var r = 0; r < n; ++r) t = t << 8 | e.get();
                return t
            }, s.hasContent = function(e, t, n) {
                if (e & 32) return !0;
                if (e < 3 || e > 4) return !1;
                var r = new i(n);
                e == 3 && r.get();
                var o = r.get();
                if (o >> 6 & 1) return !1;
                try {
                    var u = s.decodeLength(r);
                    return r.pos - n.pos + u == t
                } catch (a) {
                    return !1
                }
            }, s.decode = function(e) {
                e instanceof i || (e = new i(e, 0));
                var t = new i(e),
                    n = e.get(),
                    r = s.decodeLength(e),
                    o = e.pos - t.pos,
                    u = null;
                if (s.hasContent(n, r, e)) {
                    var a = e.pos;
                    n == 3 && e.get(), u = [];
                    if (r >= 0) {
                        var f = a + r;
                        while (e.pos < f) u[u.length] = s.decode(e);
                        if (e.pos != f) throw "Content size is not correct for container starting at offset " + a
                    } else try {
                        for (;;) {
                            var l = s.decode(e);
                            if (l.tag === 0) break;
                            u[u.length] = l
                        }
                        r = a - e.pos
                    } catch (c) {
                        throw "Exception while decoding undefined length content: " + c
                    }
                } else e.pos += r;
                return new s(t, o, r, n, u)
            }, s.test = function() {
                var e = [{
                    value: [39],
                    expected: 39
                }, {
                    value: [129, 201],
                    expected: 201
                }, {
                    value: [131, 254, 220, 186],
                    expected: 16702650
                }];
                for (var t = 0, n = e.length; t < n; ++t) {
                    var r = 0,
                        o = new i(e[t].value, 0),
                        u = s.decodeLength(o);
                    u != e[t].expected && document.write("In test[" + t + "] expected " + e[t].expected + " got " + u + "\n")
                }
            }, window.ASN1 = s
        }(), ASN1.prototype.getHexStringValue = function() {
            var e = this.toHexString(),
                t = this.header * 2,
                n = this.length * 2;
            return e.substr(t, n)
        }, An.prototype.parseKey = function(e) {
            try {
                var t = 0,
                    n = 0,
                    r = /^\s*(?:[0-9A-Fa-f][0-9A-Fa-f]\s*)+$/,
                    i = r.test(e) ? Hex.decode(e) : Base64.unarmor(e),
                    s = ASN1.decode(i);
                if (s.sub.length === 9) {
                    t = s.sub[1].getHexStringValue(), this.n = Nn(t, 16), n = s.sub[2].getHexStringValue(), this.e = parseInt(n, 16);
                    var o = s.sub[3].getHexStringValue();
                    this.d = Nn(o, 16);
                    var u = s.sub[4].getHexStringValue();
                    this.p = Nn(u, 16);
                    var a = s.sub[5].getHexStringValue();
                    this.q = Nn(a, 16);
                    var f = s.sub[6].getHexStringValue();
                    this.dmp1 = Nn(f, 16);
                    var l = s.sub[7].getHexStringValue();
                    this.dmq1 = Nn(l, 16);
                    var c = s.sub[8].getHexStringValue();
                    this.coeff = Nn(c, 16)
                } else {
                    if (s.sub.length !== 2) return !1;
                    var h = s.sub[1],
                        p = h.sub[0];
                    t = p.sub[0].getHexStringValue(), this.n = Nn(t, 16), n = p.sub[1].getHexStringValue(), this.e = parseInt(n, 16)
                }
                return !0
            } catch (d) {
                return !1
            }
        }, An.prototype.getPrivateBaseKey = function() {
            var e = {
                    array: [new KJUR.asn1.DERInteger({
                        "int": 0
                    }), new KJUR.asn1.DERInteger({
                        bigint: this.n
                    }), new KJUR.asn1.DERInteger({
                        "int": this.e
                    }), new KJUR.asn1.DERInteger({
                        bigint: this.d
                    }), new KJUR.asn1.DERInteger({
                        bigint: this.p
                    }), new KJUR.asn1.DERInteger({
                        bigint: this.q
                    }), new KJUR.asn1.DERInteger({
                        bigint: this.dmp1
                    }), new KJUR.asn1.DERInteger({
                        bigint: this.dmq1
                    }), new KJUR.asn1.DERInteger({
                        bigint: this.coeff
                    })]
                },
                t = new KJUR.asn1.DERSequence(e);
            return t.getEncodedHex()
        }, An.prototype.getPrivateBaseKeyB64 = function() {
            return Rn(this.getPrivateBaseKey())
        }, An.prototype.getPublicBaseKey = function() {
            var e = {
                    array: [new KJUR.asn1.DERObjectIdentifier({
                        oid: "1.2.840.113549.1.1.1"
                    }), new KJUR.asn1.DERNull]
                },
                t = new KJUR.asn1.DERSequence(e);
            e = {
                array: [new KJUR.asn1.DERInteger({
                    bigint: this.n
                }), new KJUR.asn1.DERInteger({
                    "int": this.e
                })]
            };
            var n = new KJUR.asn1.DERSequence(e);
            e = {
                hex: "00" + n.getEncodedHex()
            };
            var r = new KJUR.asn1.DERBitString(e);
            e = {
                array: [t, r]
            };
            var i = new KJUR.asn1.DERSequence(e);
            return i.getEncodedHex()
        }, An.prototype.getPublicBaseKeyB64 = function() {
            return Rn(this.getPublicBaseKey())
        }, An.prototype.wordwrap = function(e, t) {
            t = t || 64;
            if (!e) return e;
            var n = "(.{1," + t + "})( +|$\n?)|(.{1," + t + "})";
            return e.match(RegExp(n, "g")).join("\n")
        }, An.prototype.getPrivateKey = function() {
            var e = "-----BEGIN RSA PRIVATE KEY-----\n";
            return e += this.wordwrap(this.getPrivateBaseKeyB64()) + "\n", e += "-----END RSA PRIVATE KEY-----", e
        }, An.prototype.getPublicKey = function() {
            var e = "-----BEGIN PUBLIC KEY-----\n";
            return e += this.wordwrap(this.getPublicBaseKeyB64()) + "\n", e += "-----END PUBLIC KEY-----", e
        }, An.prototype.hasPublicKeyProperty = function(e) {
            return e = e || {}, e.hasOwnProperty("n") && e.hasOwnProperty("e")
        }, An.prototype.hasPrivateKeyProperty = function(e) {
            return e = e || {}, e.hasOwnProperty("n") && e.hasOwnProperty("e") && e.hasOwnProperty("d") && e.hasOwnProperty("p") && e.hasOwnProperty("q") && e.hasOwnProperty("dmp1") && e.hasOwnProperty("dmq1") && e.hasOwnProperty("coeff")
        }, An.prototype.parsePropertiesFrom = function(e) {
            this.n = e.n, this.e = e.e, e.hasOwnProperty("d") && (this.d = e.d, this.p = e.p, this.q = e.q, this.dmp1 = e.dmp1, this.dmq1 = e.dmq1, this.coeff = e.coeff)
        };
    var Kn = function(e) {
        An.call(this), e && (typeof e == "string" ? this.parseKey(e) : (this.hasPrivateKeyProperty(e) || this.hasPublicKeyProperty(e)) && this.parsePropertiesFrom(e))
    };
    Kn.prototype = new An, Kn.prototype.constructor = Kn;
    var Qn = function(e) {
        e = e || {}, this.default_key_size = parseInt(e.default_key_size) || 1024, this.default_public_exponent = e.default_public_exponent || "010001", this.log = e.log || !1, this.key = null
    };
    Qn.prototype.setKey = function(e) {
        this.log && this.key && console.warn("A key was already set, overriding existing."), this.key = new Kn(e)
    }, Qn.prototype.setPrivateKey = function(e) {
        this.setKey(e)
    }, Qn.prototype.setPublicKey = function(e) {
        this.setKey(e)
    }, Qn.prototype.decrypt = function(e) {
        try {
            return this.getKey().decrypt(Un(e))
        } catch (t) {
            return !1
        }
    }, Qn.prototype.encrypt = function(e) {
        try {
            return Rn(this.getKey().encrypt(e))
        } catch (t) {
            return !1
        }
    }, Qn.prototype.getKey = function(e) {
        if (!this.key) {
            this.key = new Kn;
            if (e && {}.toString.call(e) === "[object Function]") {
                this.key.generateAsync(this.default_key_size, this.default_public_exponent, e);
                return
            }
            this.key.generate(this.default_key_size, this.default_public_exponent)
        }
        return this.key
    }, Qn.prototype.getPrivateKey = function() {
        return this.getKey().getPrivateKey()
    }, Qn.prototype.getPrivateKeyB64 = function() {
        return this.getKey().getPrivateBaseKeyB64()
    }, Qn.prototype.getPublicKey = function() {
        return this.getKey().getPublicKey()
    }, Qn.prototype.getPublicKeyB64 = function() {
        return this.getKey().getPublicBaseKeyB64()
    }, e.JSEncrypt = Qn
})(JSEncryptExports);
var JSEncrypt = JSEncryptExports.JSEncrypt;
define("jsencrypt", function() {}), define("app", ["jquery", "natureface", "dbhandler", "global", "mq", "cycle", "jqueryui", "iscroll", "jsencrypt"], function(e, t, n, r, i) {
    function s() {
        try {
            throw Error("")
        } catch (e) {
            return e
        }
    }
    return String.prototype.format = String.prototype.f = function() {
        var e = this,
            t = arguments.length;
        while (t--) e = e.replace(new RegExp("\\{" + t + "\\}", "gm"), arguments[t]);
        return e
    }, e.app = e.extend({
        gapikey: "AIzaSyCfHrdY2w8KMGL1rCFhtBPEwvp9wyXhO5c",
        serverip: "192.168.1.254",
        serverport: "2010",
        serverpath: "/WebBrowser/Command",
        searchisbusy: !1,
        serverrest: function() {
            return e.app.serverRestByIp(e.app.serverip)
        },
        isHttp: function() {
            return "https:" === document.location.protocol || "http:" === document.location.protocol
        },
        isDevel: !1,
        serverRestByIp: function(t) {
            return e.app.isHttp() || e.app.isDevel ? e.app.serverpath : "http://" + t + (e.app.serverport == "80" ? "" : ":" + e.app.serverport) + e.app.serverpath
        },
        debug: !0,
        natureface: !1,
        initdb: function() {
            try {
                var t = n.connect("ksonglover.net", 20971520, "KSonglover WebDB");
                if (!t) return;
                n.migration(1, function(e) {
                    e.executeSql("CREATE TABLE IF NOT EXISTS tbl_setting (key unique, value)")
                }), n.migration(2, function(e) {
                    e.executeSql("INSERT INTO tbl_setting (key, value) values(?,?)", ["ipaddress", "192.168.1.2"])
                }), n.migration(3, function(e) {
                    e.executeSql("INSERT INTO tbl_setting (key, value) values(?,?)", ["port", "2010"])
                }), n.migration(4, function(e) {
                    e.executeSql("CREATE TABLE IF NOT EXISTS tbl_history (q unique, updatetime)")
                }), n.migration(5, function(e) {
                    e.executeSql("CREATE TABLE IF NOT EXISTS tbl_youtube (key unique, clicked, loved, prop)")
                }), n.doMigration(), console.info("get ip address(db) ...."), n.query("SELECT * FROM tbl_setting WHERE key='ipaddress'", function(t) {
                    for (var n = 0, r = null; n < t.rows.length; n++) r = t.rows.item(n), console.info("ip address(db):" + r.value), e.app.serverip = r.value
                })
            } catch (r) {
                console.info(r)
            }
        },
        addhistory: function(e) {
            n.query("insert or replace into tbl_history (q, updatetime) values ('{0}', '{1}')".f(q, (new Date).getTime())), n.query("delete from tbl_history where q not in (select q from tbl_history order by updatetime desc limit 10)")
        },
        gethistory: function(e) {
            n.query("SELECT * FROM tbl_history", function(t) {
                var n = [];
                for (var r = 0, i = null; r < t.rows.length; r++) i = t.rows.item(r), n.push(i.q);
                e(n)
            })
        },
        setinfo: function(e, t) {
            var r = JSON.stringify(t);
            r = r.replace(/'/g, "''"), n.query("insert or replace into tbl_youtube (key, clicked, loved, prop) values ('{0}', '{1}', '{2}', '{3}')".f(e, t.clicked, t.loved, r))
        },
        getinfo: function(e, t) {
            n.query("SELECT prop FROM tbl_youtube WHERE key='{0}'".f(e), function(e) {
                if (e.rows.length > 0) {
                    var n = e.rows.item(0);
                    t(JSON.parse(n.prop))
                } else t({
                    position: 0,
                    clicked: !1,
                    loved: !1
                })
            })
        },
        getLoved: function(e) {
            n.query("SELECT prop FROM tbl_youtube where loved='true'", function(t) {
                var n = {
                    items: []
                };
                for (var r = 0, i = null; r < t.rows.length; r++) i = t.rows.item(r), n.items.push(JSON.parse(i.prop).item);
                e(n)
            })
        },
        mask: function(e) {
            var t = new JSEncrypt;
            return t.setKey("-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCq+7MLbanmniGeAOAKQKo19RhG9cC5QjLnfbvzTm3W3ZqO4Fy86gmEnMpIN/sMzOJSsgyqbKAoXBJrw6iQLO7TkzzqSpe3sDDVWe3VO7+OluUx7KEZinfgG9DK/WqDOKv4fUnGhBrRT59FXmwe2F/7Ls007ptVT7D/wSu8p7XuBQIDAQAB-----END PUBLIC KEY-----"), t.encrypt(e)
        },
        saveip: function(e) {
            this.serverip = e, n.query("UPDATE tbl_setting SET value='" + e + "' WHERE key='ipaddress'")
        },
        init: function(n) {
            this.initdb(), e.app.natureface && e(e.app.natureface.settings.div).remove(), e.app.natureface = new t({
                fullscreen: !0,
                theme: "setting",
                prefix: e.app.isDevel ? "www/resource/" + e.app.theme + "/" : "./resource/" + e.app.theme + "/",
                firsttarget: e.app.firsttarget,
                transparent: !0
            })
        },
        options: function(t) {
            return e.extend({}, t.defaults, t.options)
        },
        profile: !1,
        ajax: function(t) {
            if (i.connected && !t.url) return i.ajax(JSON.parse(t.data));
            var n = {
                url: e.app.serverrest(),
                dataType: "json",
                type: "POST",
                timeout: 1e4,
                cache: !1,
                async: !0
            };
            return e.ajax(e.extend(n, t))
        },
        endwith: function(e, t) {
            return e.indexOf(t, e.length - t.length) !== -1
        },
        lastlog: !1,
        maxrecord: 500,
        lastcmd: "",
        listing: function(t, n, r, i, s, o) {
            if (o) {
                if (e.app.lastcmd != n.orig) {
                    console.info("scroll cancel!");
                    return
                }
            } else e.app.lastcmd = JSON.stringify(n), n.orig = JSON.stringify(n);
            return console.info("request data:", n), e.app.ajax({
                data: JSON.stringify(n),
                async: !0
            }).done(function(u) {
                var a = "[group=" + t + "]",
                    f = e("#group_" + t + "_div_container");
                f.css({
                    "overflow-y": "scroll",
                    "overflow-x": "hidden",
                    "-webkit-overflow-scrolling": "touch"
                }), o || e(a).first().empty().nextAll().remove();
                var l = e("#group_" + t + "_div"),
                    c, h = e(a).last();
                console.info("response data:", u);
                for (var p = 0; p < u.items.length; p++) {
                    !o && p == 0 ? c = e(a).first() : (c = h.clone().empty(), c.css({
                        top: parseInt(h.css("top")) + h.height() + "px",
                        height: parseInt(c.css("line-height")) + 2 + "px"
                    }).appendTo(l));
                    if (e(a).length > e.app.maxrecord) {
                        c.html("<center>資料過多，請縮小尋找範圍,最多 " + e.app.maxrecord + " 筆...</center>");
                        break
                    }
                    typeof r == "function" && r(c, u.items[p]), h = c
                }
                u.absolutepage < u.page && u.absolutepage > 0 && e(a).length < e.app.maxrecord && (u.items.length != u.pagesize ? (n.page = u.absolutepage + 1, e.app.listing(t, n, r, i, s, !0), f.unbind()) : f.unbind().one("onTouchEnd", function() {
                    n.page = u.absolutepage + 1, e.app.listing(t, n, r, i, s, !0)
                })), u.items.length > 0 && (l.css("height", parseInt(c.css("top")) + c.height() + 1 + "px"), l.parent().css("height", l.height() + 1)), isbusy = !1, f.off("scroll touchmove").on("scroll touchmove", function() {
                    var t = parseInt(e("#group_songList_div_container").css("height")),
                        n = Math.round(e(this).scrollTop() / t) + 1,
                        r = parseInt(parseInt(e(a).length / i)) + 1,
                        o = n + " / " + r;
                    e(s).show().html(o), r - n <= 3 && (isbusy = !0, f.trigger("onTouchEnd")), clearTimeout(e(this).data("scrollTimeout")), e(this).data("scrollTimeout", setTimeout(function() {
                        e(s).fadeOut("slow")
                    }, 1e3))
                })
            })
        },
        cordova: !1,
        fullscreen: function(e) {
            this.cordova && (e ? (screen.orientation.unlock(), StatusBar.hide()) : (screen.orientation.lock("portrait"), StatusBar.show()))
        },
        qrcode: function(e) {
            console.info("MQ連線...");
            try {
                i.login(e, function() {
                    i.ajax({
                        command: "connect"
                    }).done(function(e) {
                        console.info("登入包廂[成功]!"), navigator.notification.alert("登入播放台成功！", function(e) {}, "已連線", ["確定"])
                    }).fail(function(e) {
                        console.error("登入包廂[失敗]！", e)
                    })
                })
            } catch (t) {
                console.info(t)
            }
        },
        inputip: function() {
            var e = this,
                t = "請輸入IP或掃碼(播放台按ESC)";
            this.cordova ? navigator.notification.prompt(t, function(t) {
                switch (t.buttonIndex) {
                    case 1:
                        e.saveip(t.input1);
                        break;
                    case 2:
                        cordova.plugins.diagnostic.requestCameraAuthorization(function(t) {
                            t == cordova.plugins.diagnostic.permissionStatus.GRANTED ? cordova.plugins.barcodeScanner.scan(function(t) {
                                try {
                                    if (!t.cancelled) {
                                        var n = JSON.parse(t.text);
                                        if (n.channel) {
                                            var r = ["mq2.ksonglover.com", "mq1.ksonglover.com", "mq.ksonglover.com"];
                                            r.indexOf(n.server) > -1 ? (console.info("採用MQ連接", n), e.qrcode(n)) : console.info("Server不是限制的主機", n)
                                        } else n.ip && e.saveip(n.ip)
                                    }
                                } catch (i) {}
                            }) : console.info("Camera Deny!")
                        }, function(e) {
                            console.info("Camera Error" + e)
                        }, !1)
                }
            }, "取得連線", ["確定", "掃碼", "取消"], e.serverip) : doit(prompt(t, app.serverip))
        }
    }, r), e.app
}), define("cordovahandler", ["jquery", "app"], function(e, t) {
    t.cordova = !0, setTimeout(e("#applogo").fadeOut("slow"), 1e3);
    if (!document.addEventListener) return {};
    var n = function(e) {
        var n = new jQuery.Deferred,
            r = 0,
            i = 255,
            s = e.split(".").slice(0, 3).join("."),
            o = "";
        for (var u = 1; u <= i; u++) {
            var a = s + "." + u;
            t.ajax({
                ping: a,
                url: t.serverRestByIp(a),
                data: JSON.stringify({
                    command: "status"
                }),
                timeout: 3e3,
                async: !0
            }).done(function(e) {
                t.saveip(this.ping), console.info("Found Player : " + this.ping)
            }).fail(function(e) {}).always(function(e) {
                r += 1, n.notify(parseInt(r / i * 100)), r == i && (console.info("Player(maybe) : " + t.serverip), n.resolve(t.serverip))
            })
        }
        return n.promise()
    };
    return document.addEventListener("deviceready", function() {
        e("#applogo").fadeOut("slow"), t.init();
        try {
            var r = navigator.connection.type,
                i = {};
            i[Connection.UNKNOWN] = "Unknown connection", i[Connection.ETHERNET] = "Ethernet connection", i[Connection.WIFI] = "WiFi connection", i[Connection.CELL_2G] = "Cell 2G connection", i[Connection.CELL_3G] = "Cell 3G connection", i[Connection.CELL_4G] = "Cell 4G connection", i[Connection.CELL] = "Cell generic connection", i[Connection.NONE] = "No network connection", r == Connection.ETHERNET || r == Connection.WIFI ? networkinterface.getIPAddress(function(t) {
                console.info("Device ip address:" + t), e.when(n(t)).then(function(e) {
                    console.info("discovery [Finished]")
                }, function(e) {}, function(e) {})
            }, function(e) {}) : console.info("network state error[skip]")
        } catch (s) {}
        document.addEventListener("backbutton", function() {
            var e = t.natureface.layer();
            switch (e) {
                case "book":
                case "youtubeplayer":
                    t.natureface.target("youtube");
                    break;
                case "default":
                    confirm("請是否要離開系統?", "離開") && navigator.app.exitApp();
                    break;
                case "bookadvplayer":
                    t.natureface.target("bookadv");
                    break;
                case "bookplayer":
                    t.natureface.target("book");
                    break;
                case "bookadv":
                case "options":
                    t.natureface.target("search");
                    break;
                case "search":
                case "youtube":
                default:
                    t.natureface.target("default")
            }
        }, !1), document.addEventListener("menubutton", function() {
            t.natureface.target("default")
        }, !1), document.addEventListener("searchbutton", function() {
            t.natureface.target("youtube")
        }, !1)
    }, !1), {}
}), define("_book", ["jquery", "app"], function(e, t) {
    var n = ["SingerSong", "Source", "TypeChildren", "TypeFestival", "TypeGroup", "TypeHighSong", "TypeMovie", "TypeOneByOne"];
    e(".bookhr,.bookadvhr").css("height", "1px"), e("#bookback").on("click", function() {
        t.natureface.layer() == "book" ? t.natureface.target("youtube") : t.natureface.target("search")
    }), e("#bookfinished").on("click", function() {
        var n = e("#bookvideoinfo").data("song");
        n.command = "saveyoutubeinfo";
        if (n.SongName.trim() == "" || n.Singer1.trim() == "") {
            alert("歌名及歌手皆不能為空白資料，請重新輸入。");
            return
        }
        console.info(n), t.ajax({
            data: JSON.stringify(n)
        }).done(function() {
            e("#bookback").trigger("click"), console.info("OK")
        })
    }), e("[id^=booksinger1sex]").on("click", function() {
        var t = e("#bookvideoinfo").data("song");
        t.Singer1Sex = e(this).text() == "女" ? 0 : e(this).text() == "男" ? 1 : 2, i(t)
    }), e("[id^=booksinger2sex]").on("click", function() {
        var t = e("#bookvideoinfo").data("song");
        t.Singer2Sex = e(this).text() == "女" ? 0 : e(this).text() == "男" ? 1 : 2, i(t)
    }), e("#bookSongName, #bookSinger1, #bookSinger2").on("blur", function() {
        var t = e("#bookvideoinfo").data("song"),
            n = e(this).attr("id").replace("book", "");
        t[n] = e(this).val(), i(t)
    }), e("#bookSinger1, #bookSinger2").on("input", function() {
        if (e(this).val().trim() != "") {
            var n = e(this).val().trim();
            t.ajax({
                data: JSON.stringify({
                    command: "getSingersByKeyword",
                    keyword: n
                })
            }).done(function(e) {
                console.info(e.items)
            })
        }
    }), e.each(n, function(t, n) {
        e("#book" + n).on("click", function() {
            var t = e("#bookvideoinfo").data("song");
            t[n] = !e(this).data("value"), i(t)
        })
    });
    var r = function() {
        var t = e("#bookvideoinfo").data("song"),
            n = e(this).attr("id").replace("book", "").replace("plus", "").replace("del", ""),
            r = e(this).data("value");
        console.info(n, r);
        switch (n) {
            case "SongLanguage":
                for (var s = 0; s < t.LanguageNames.length - 1; s++)
                    if (t.LanguageNames[s] == e("#bookSongLanguage").text()) {
                        var o = s + r;
                        t.LanguageNames[o] == "YOUTUBE" && (o = s + r * 2), o >= 0 && o <= t.LanguageNames.length - 1 && (t.SongLanguage = t.LanguageNames[o], console.info(t.SongLanguage, o))
                    } break;
            case "Volume":
                r == 1 && t.Volume < 100 ? t.Volume = t.Volume + 5 : r == -1 && t.Volume > 0 && (t.Volume = t.Volume - 5);
                break;
            case "Channel":
                r == 1 && t.Channel < t.ChannelNames.length - 2 ? t.Channel = t.Channel + 1 : r == -1 && t.Channel > -1 && (t.Channel = t.Channel - 1)
        }
        i(t)
    };
    e("#bookSongLanguageplus,#bookChannelplus,#bookVolumeplus").data("value", 1).on("click", r), e("#bookSongLanguagedel,#bookChanneldel,#bookVolumedel").data("value", -1).on("click", r);
    var i = function(t) {
        e("#bookSinger1").val(t.Singer1), e("[id^=booksinger1sex]").removeClass("bookchecked").addClass("bookunchecked"), e("#booksinger1sex" + t.Singer1Sex).removeClass("bookunchecked").addClass("bookchecked"), e("#bookSinger2").val(t.Singer2), e("[id^=booksinger2sex]").removeClass("bookchecked").addClass("bookunchecked"), e("#booksinger2sex" + t.Singer2Sex).removeClass("bookunchecked").addClass("bookchecked"), e.each(n, function(n, r) {
            e("#book" + r).removeClass("bookchecked bookunchecked").addClass(t[r] ? "bookchecked" : "bookunchecked").data("value", t[r])
        }), e("#bookSongName").val(t.SongName), e("#bookSongLanguage").text(t.SongLanguage), e("#bookChannel").text(t.ChannelNames[t.Channel + 1]), e("#bookVolume").text(t.Volume + "%")
    };
    return {
        init: function(n, r, s) {
            console.info("maintian song:", n), $box = e("#bookvideoinfo").data("song", n).empty();
            var o = function() {
                $box.find(".youtubeleft").css("width", "44%"), $box.find(".glyphicon-book").remove()
            };
            if (r) {
                t.natureface.target("bookadv");
                var u = {
                    part: "id,snippet",
                    q: n.Vid,
                    maxResults: 1,
                    type: "video",
                    key: t.gapikey
                };
                e.get("https://www.googleapis.com/youtube/v3/search", u, function(t) {
                    console.info("render:", t.items[0]), s($box, t.items[0]), e("#bookvideoinfo"), o()
                })
            } else t.natureface.target("book"), $box.append(e("#" + n.Vid).clone(!0)), o();
            i(n)
        }
    }
}), define("_youtube", ["jquery", "app", "_book"], function(e, t, n) {
    function f(e) {
        var t = e.split(":"),
            n = 0,
            r = 1;
        while (t.length > 0) n += r * parseInt(t.pop(), 10), r *= 60;
        return n
    }

    function l(t, n) {
        n.position > 30 && e("[id=looked_" + t + "]").addClass("youtubelooked youtubelabel").html("看過"), n.clicked && (e("[id=clicked_" + t + "]").addClass("youtubeclicked youtubelabel").html("點過"), e("[id=thumb_" + t + "]").css({
            opacity: .4
        })), n.loved ? (e("[id=loved_" + t + "]").css("color", "red"), e("#youtubeplayer").data("videoid") == t && e("#youtubePlayerHeart").css("color", "red")) : (e("[id=loved_" + t + "]").css("color", "white"), e("#youtubeplayer").data("videoid") == t && e("#youtubePlayerHeart").css("color", "white"))
    }

    function c(r, i) {
        var s = i.id.videoId,
            o = i.snippet.title,
            u = i.snippet.description,
            c = i.snippet.thumbnails.high.url,
            h = i.snippet.channelTitle,
            p = i.snippet.publishedAt;
        r.unbind().append(e("<div>").attr("id", s).addClass("youtubebox").append(e("<div>").addClass("youtubeleft").append(e("<img>").attr("src", c).attr("id", "thumb_" + s).addClass("youtubeimg").on("click", function() {
            a(s)
        })).append(e("<span>").addClass("youtubeduration youtubelabel").attr("id", "duration_" + s).html("")).append(e("<div>").attr("id", "looked_" + s)).append(e("<div>").attr("id", "clicked_" + s))).append(e("<div>").addClass("youtubeblock").append(e("<div>").html(o).addClass("youtubetitle")).append(e("<div>").html(u).addClass("youtubedesc"))).append(e("<div>").addClass("youtubeactionblock").append(e("<div>").addClass("btn-group-vertical").append(e("<label>").addClass("youtubeaction glyphicon glyphicon-pencil").on("click", function() {
            console.info(e("#duration_" + s).data("duration"));
            if (e("#duration_" + s).data("duration") > 480 && !confirm("大於一般的ktv大小, 是否還是要點播?\n注意，太大的媒體將影响相關功能操作\n(如快轉、倒轉、載入等等。)")) return;
            if (e("#duration_" + s).data("duration") > 0) {
                console.info("add youtube start...");
                var n = function(n) {
                    t.ajax({
                        data: JSON.stringify({
                            command: n,
                            videoid: s,
                            title: o,
                            level: e("#youtubePlayerHD").data("level"),
                            duration: e("#duration_" + s).data("duration")
                        })
                    }).done(function(n) {
                        console.info("add youtube:" + s), e("#btnosdshow").trigger("click"), t.getinfo(s, function(n) {
                            n.clicked || (n.clicked = !0, n.duration = e("#duration_" + s).data("duration"), t.setinfo(s, n), l(s, n))
                        })
                    })
                };
                if (t.cordova) {
                    var r = function(e) {
                        switch (e) {
                            case 1:
                                n("addyoutube");
                                break;
                            case 2:
                                n("insertyoutube")
                        }
                    };
                    navigator.notification.confirm("請確認歌曲 : " + o, r, "點播", ["確認", "插播", "取消"])
                } else {
                    var i = window.confirm("是否插播歌曲：" + o + "\n\n [確定] 插播" + "\n\n [取消] 標準點播");
                    i == 1 ? n("insertyoutube") : n("addyoutube")
                }
            }
        })).append(e("<label>").addClass("youtubeaction glyphicon glyphicon-heart").attr("id", "loved_" + s).on("click", function() {
            t.getinfo(s, function(e) {
                console.info(s, e), e.loved = !e.loved, e.item = i, t.setinfo(s, e), l(s, e)
            })
        })).append(e("<label>").addClass("youtubeaction glyphicon glyphicon-book").attr("id", "book_" + s).on("click", function() {
            t.ajax({
                data: JSON.stringify({
                    command: "getyoutubeinfo",
                    videoid: s,
                    title: o,
                    level: e("#youtubePlayerHD").data("level"),
                    duration: e("#duration_" + s).data("duration")
                })
            }).done(function(e) {
                console.info(e), n.init(e, !1)
            })
        })))).append(e("<hr>").addClass("youtubehr").css({
            width: r.width() - 20
        }))), t.getinfo(s, function(e) {
            l(s, e)
        }), e.get("https://www.googleapis.com/youtube/v3/videos?id=" + s + "&part=contentDetails&key=" + t.gapikey, function(t) {
            if (!t.items[0].contentDetails) return null;
            var n = t.items[0].contentDetails.duration;
            try {
                n.indexOf("S") < 0 && (n += "0S"), n.indexOf("M") < 0 && n.indexOf("H") >= 0 && (n = n.replace("H", "H0M"), console.info(n)), n = n.substring(2).replace(/[HM]/g, ":").replace("S", "").replace(/(\:|-|\s)(\d)(?=\D|$)/g, "$10$2"), e("[id=duration_" + s + "]").data("duration", f(n)).html(n)
            } catch (r) {
                console.info(r)
            }
        })
    }
    var r = ":loved:",
        i = function(n) {
            e("#youtubesearch").val(n.keyword), v(), n.clear && e("#youtubesearch").val(""), n.save && t.addhistory(n.keyword)
        },
        s = function() {
            e("#youtubeplayer").css("top", "").empty().load().get(0).pause()
        };
    e("#youtubePlayerReturn").on("click", function() {
        var e = t.natureface.layer();
        t.natureface.target(e.replace("player", ""))
    }), e("#youtubePlayerOrder, #youtubePlayerHeart, #youtubePlayerBook").on("click", function() {
        var t = e("#youtubeplayer").data("videoid");
        console.info(e(this).attr("id"), t), e(this).hasClass("glyphicon-pencil") ? e("#" + t).find(".glyphicon-pencil").trigger("click") : e(this).hasClass("glyphicon-heart") ? e("#" + t).find(".glyphicon-heart").trigger("click") : e("#" + t).find(".glyphicon-book").trigger("click")
    }), e("#youtubePlayerHD").data("level", 3).on("click", function() {
        var t = e(this).data("level");
        t += 1, t > 3 && (t = 1), e(this).css({
            color: t == 3 ? "#ffff00" : "#ffffff"
        }).text(t == 3 ? "HD" : t == 2 ? "MD" : "SD"), e(this).data("level", t), o = e("#youtubeplayer").get(0).currentTime, a(e("#youtubeplayer").data("videoid"))
    }), e("#youtubeKTV, #youtubeMV").on("click", function() {
        var t = new RegExp(e(this).text(), "i"),
            n = e("#youtubesearch").val();
        n.search(t) < 0 && i({
            keyword: n + " " + e(this).text(),
            clear: !1,
            save: !0
        })
    }), e("#youtubeLoved").on("click", function() {
        i({
            keyword: r,
            clear: !0,
            save: !1
        })
    });
    var o = 0,
        u = e("#youtubeplayer").get(0);
    u.addEventListener("seeking", function() {
        console.info("seeking"), e("#youtubeplayerloading").show()
    }), u.addEventListener("seeked", function() {
        console.info("seeked:", u.currentTime, u.duration), e("#youtubeplayerloading").hide()
    }), u.addEventListener("loadedmetadata", function() {
        console.info("loadedmetadata"), u.currentTime = o, o = 0
    }, !1), u.addEventListener("timeupdate", function() {
        var n = e("#youtubeplayer").data("videoid");
        if (u.currentTime >= u.duration - 2) t.getinfo(n, function(e) {
            e.position = 0, t.setinfo(n, e)
        }), t.natureface.layer().match("^book") || e("#youtubePlayerNext").trigger("click");
        else {
            var r = parseInt(u.currentTime);
            t.getinfo(n, function(e) {
                e.position != r && (e.position = r, t.setinfo(n, e), l(n, e))
            })
        }
    }), e("#youtubeplayer").bind("webkitfullscreenchange mozfullscreenchange fullscreenchange", function(e) {
        t.fullscreen(document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen)
    });
    var a = function(n, r) {
        if (!n) return;
        s();
        var i = t.natureface.layer();
        t.endwith(i, "player") || t.natureface.target(t.natureface.layer() + "player"), e("#youtubePlayerHeart").css("color", "white"), t.ajax({
            data: JSON.stringify({
                limit: "mp4",
                id: t.mask(n)
            }),
            url: "http://www.lijifun.com/youtube/videoinfo.php"
        }).done(function(i) {
            console.info(i);
            var s = e("#youtubePlayerHD").data("level") > i.videos.length ? i.videos.length : e("#youtubePlayerHD").data("level");
            console.info(i.videos[s - 1].format, i.videos[s - 1].url);
            if (e("#youtubeplayer").is(":hidden")) return;
            e("#youtubeplayer").empty().data("videoid", n).attr("controls", "controls").append(e("<source>").attr("src", i.videos[s - 1].url).attr("type", "video/mp4")).load(), e("#youtubeplayer").get(0).play(), e("#youtubePlayerHeart").css("color", e("#loved_" + n).css("color")), t.getinfo(n, function(i) {
                console.info("duration:" + e("#duration_" + n).data("duration")), i.duration = e("#duration_" + n).data("duration"), t.setinfo(n, i), console.info("load info:", i), e("#youtubeplayer").data("info", i), r ? o = r : i.duration - i.position > 60 ? (console.info("播放上次位置:" + i.position), o = i.position) : o = 0
            })
        })
    };
    e(document).bind("target", function(e, t, n) {
        n != "youtubeplayer" && s()
    }), s(), e("#youtubecleardata").on("click", function() {
        e("#youtubesearch").val(""), e("[group=videoList]").empty(), e("#youtubekeywordbg,#group_youtubekeywords_div_container").hide()
    }), e("#youtubePlayerPrev").on("click", function() {
        var t = e("#youtubeplayer").data("videoid"),
            n = e("#" + t).parent().prev().children().attr("id");
        n ? (console.info("prev:" + n), a(n, 0)) : a(e(".youtubebox").attr("id"), 0)
    }), e("#youtubePlayerNext").on("click", function() {
        var t = e("#youtubeplayer").data("videoid"),
            n = e("#" + t).parent().next().children().attr("id");
        n ? (console.info("next:" + n), a(n, 0)) : a(e(".youtubebox").attr("id"), 0)
    }), e("#youtubeplayerloading").empty().css({
        height: "",
        width: "",
        "line-height": ""
    });
    var h = e("#group_youtubeList_div_container");
    h.css({
        "overflow-y": "scroll",
        "overflow-x": "hidden",
        "-webkit-overflow-scrolling": "touch"
    });
    var p = "",
        d = 4,
        v = function() {
            q = e("#youtubesearch").val(), e("#youtubekeywordbg,#group_youtubekeywords_div_container").hide();
            var n = !1,
                i = function(s, o) {
                    var u = e.extend({
                            part: "id,snippet",
                            q: s,
                            maxResults: d * 5,
                            type: "video",
                            key: t.gapikey
                        }, o ? o : {}),
                        a;
                    s == r ? a = function(e, n) {
                        t.getLoved(n)
                    } : a = function(t, n) {
                        e.get("https://www.googleapis.com/youtube/v3/search", t, n)
                    }, a(u, function(t) {
                        var u = "[group=youtubeList]";
                        o || e(u).first().empty().nextAll().remove(), p = t.nextPageToken;
                        var a = e("#group_youtubeList_div"),
                            f, l = e(u).last();
                        e.each(t.items, function(t, n) {
                            !o && t == 0 ? f = e(u).first() : (f = l.clone().empty(), f.css({
                                top: parseInt(l.css("top")) + l.height() + "px",
                                height: parseInt(f.css("line-height")) + 2 + "px"
                            }).appendTo(a)), c(f, n), l = f
                        }), t.items.length > 0 && (a.css("height", parseInt(f.css("top")) + f.height() + 1 + "px"), a.parent().css("height", a.height() + 1)), n = !1, h.off("scroll touchmove").on("scroll touchmove", function() {
                            var t = parseInt((parseInt(e(this).scrollTop() / f.height()) + 1) / d + 1),
                                o = parseInt(parseInt(e(u).length / d)) + 1,
                                a = t + " / " + o;
                            e("#youtubePos").show().html(a), !n && s != r && o - t <= 5 && (n = !0, i(s, {
                                pageToken: p
                            })), clearTimeout(e(this).data("scrollTimeout")), e(this).data("scrollTimeout", setTimeout(function() {
                                e("#youtubePos").fadeOut("slow")
                            }, 1e3))
                        })
                    })
                };
            i(q, !1)
        },
        m = function(t) {
            var n = "[group=youtubekeywords]";
            e(n).removeClass("completefirst completelast").first().empty().nextAll().remove();
            var r = e("#group_youtubekeywords_div"),
                s, o = e(n).last();
            e.each(t, function(t, u) {
                t == 0 ? s = e(n).first() : (s = o.clone().empty(), s.css({
                    top: parseInt(o.css("top")) + o.height() + "px",
                    height: parseInt(s.css("line-height")) + 2 + "px"
                }).appendTo(r)), s.off("click").on("click", function() {
                    i({
                        keyword: u,
                        clear: !1,
                        save: !0
                    })
                }).append(e("<div>").addClass("completeitemtext").html(u)).append(e("<hr>").addClass("youtubehr").css({
                    width: "100%",
                    left: "0px"
                })), t < r.attr("rows") && (o = s)
            }), e(n).first().addClass("completefirst"), o.addClass("completelast"), t.length > 0 ? e("#youtubekeywordbg,#group_youtubekeywords_div_container").show() : e("#youtubekeywordbg,#group_youtubekeywords_div_container").hide()
        };
    return e("#youtubesearch").autocomplete({
        source: function(n) {
            var r = n.term;
            e.get("https://suggestqueries.google.com/complete/search?ds=yt&client=android&hjson=t&cp=1&q=" + r + "&key=" + t.gapikey + "&format=5&alt=json&callback=?", function(e) {
                m(JSON.parse(e)[1])
            }).fail(function(e, t, n) {
                console.info(e.responseText + t)
            })
        }
    }).on("focus input", function() {
        e(this).val() == "" && t.gethistory(m)
    }).on("keypress", function() {
        e(this).val() == "" && t.gethistory(m);
        if (event.which != 13) return;
        e(this).blur(), v()
    }), i({
        keyword: "熱門 最新 新歌 KTV",
        clear: !0,
        save: !1
    }), {
        renderBox: function(e, t) {
            c(e, t)
        }
    }
}), define("_default", ["jquery", "app", "_book", "_youtube", "mq"], function(e, t, n, r, i) {
    var s = {
            firstcolor: {
                "ㄅ": "#FF530D",
                "ㄆ": "#E80C7A",
                "ㄇ": "#FF0DFF",
                "ㄈ": "#0971B2",
                "ㄉ": "#1485CC",
                "ㄊ": "#669900",
                "ㄋ": "#FF0000",
                "ㄌ": "#00FF48",
                "ㄍ": "#00B233",
                "ㄎ": "#FF1919",
                "ㄏ": "#9FAC9F",
                "ㄐ": "#8D8DB2",
                "ㄑ": "#FF6E6E",
                "ㄒ": "#FF7C7C",
                "ㄓ": "#85ADFF",
                "ㄔ": "#425680",
                "ㄕ": "#99C2FF",
                "ㄖ": "#717785",
                "ㄗ": "#99993D",
                "ㄘ": "#FF9933",
                "ㄙ": "#009933",
                "ㄚ": "#33AD5C",
                "ㄛ": "#FFA319",
                "ㄜ": "#00FFFF",
                "ㄝ": "#3ECCCC",
                "ㄞ": "#2B8F8F",
                "ㄟ": "#8CAAAA",
                "ㄠ": "#B2A8C8",
                "ㄡ": "#6B6578",
                "ㄢ": "#0099FF",
                "ㄣ": "#006BB2",
                "ㄤ": "#5C5C33",
                "ㄥ": "#7D7D5C",
                "ㄦ": "#64644A",
                "ㄧ": "#A64D4D",
                "ㄨ": "#CA9494",
                "ㄩ": "#B26B5A",
                "default": "#66A666"
            },
            attrcolor: {
                "男": "#8AAFE6",
                "女": "#FF9999",
                "團體": "#C1A32E",
                "國語": "#9898E6",
                "台語": "#009933",
                "粵語": "#9640B2",
                "日文": "#006B6B",
                "客家": "#FF9933",
                "英語": "#FF4D4D",
                "韓語": "#4D4DFF",
                language: "#66A666",
                sex: "#FFCC66",
                singer: "#336600",
                ordercount: "#DB4DB8",
                spell2: "",
                spell3: "",
                youtube: "#990000"
            }
        },
        o = function(n, r) {
            e("#inputsearch").val(r), t.listing("songList", {
                command: "singer",
                singerid: n + ""
            }, f, 8, "#bookPos")
        },
        u = function(i) {
            try {
                return e("<div>").addClass("listattr glyphicon glyphicon-book").css({
                    "margin-left": "3px"
                }).on("click", function() {
                    console.info(i), t.ajax({
                        data: JSON.stringify({
                            command: "getyoutubeinfo",
                            videoid: i.vid,
                            title: i.SongName,
                            level: 2,
                            duration: parseFloat(i.duration)
                        })
                    }).done(function(e) {
                        console.info(e), n.init(e, !0, r.renderBox)
                    })
                })
            } catch (s) {}
        },
        a = function(t, n, r) {
            return t == "" ? e("<div>") : e("<div>").addClass("listattr").css({
                "margin-left": "3px",
                "background-color": s.attrcolor[t] ? s.attrcolor[t] : s.attrcolor[n]
            }).on("click", function() {
                n == "singer" && o(r, t)
            }).attr("data-type", n).attr("data-type-id", r).html(t)
        };
    e("#cleardata").on("click", function() {
        e("#inputsearch").val(""), e("[group=songList]").empty()
    });
    var f = function(n, r) {
        r.SongNo ? (r.title = r.SongName, r.desc = e("<div>").append(r.vid != "" ? u(r) : "").append(parseInt(r.OrderCount) > 0 ? a("♪" + r.OrderCount, "ordercount", r.OrderCount) : "").append(a(r.SongLanguage, "language", r.SongLanguage)).append(a(r.Singer1Name, "singer", r.Singer1)).append(a(r.Singer2Name, "singer", r.Singer2)), r.first = r.Spell2.charAt(0)) : (r.title = r.Singer_Name, r.desc = e("<div>").append(a(r.Singer_Sex == 1 ? "男" : r.Singer_Sex == 0 ? "女" : "團體", "sex", r.Singer_Sex)), r.first = e("<div>").addClass("glyphicon glyphicon-user")), r.spell = e("<div>").append(a(r.Spell2, "spell2", r.Spell2)).append(a(r.Spell3, "spell3", r.Spell3)), r.color = s.firstcolor[r.first] ? s.firstcolor[r.first] : s.firstcolor["default"], itemH = 36, itemMarginTop = (n.height() - itemH * 2) / 2 * -1, n.unbind().append(e("<div>").css({
            position: "relative",
            top: 0,
            height: "100%",
            width: "100%",
            "margin-top": "0px",
            "margin-bottom": "0px"
        }).append(e("<div>").css({
            position: "absolute",
            width: itemH + "px",
            height: itemH + "px",
            left: "0px",
            "margin-left": "10px",
            "border-radius": "99em",
            "background-color": r.color,
            "text-align": "center",
            valign: "middle",
            "margin-top": parseInt((n.height() - itemH) / 2) + "px"
        })).append(e("<div>").css({
            position: "absolute",
            width: itemH + "px",
            height: itemH + "px",
            left: "0px",
            "margin-top": "1px",
            "font-size": "20px",
            "margin-left": "10px",
            "text-align": "center",
            valign: "middle"
        }).html(r.first)).append(e("<div>").css({
            position: "absolute",
            left: itemH + 15 + "px",
            top: "0px",
            "margin-top": "0px",
            "font-size": "20px",
            "margin-left": "5px"
        }).data("record", r).html(r.title).on("click", function() {
            e(this).css({
                opacity: "0.5"
            });
            var n = e(this).data("record");
            console.info("select item", n);
            if (n.SongNo) {
                var r = function(r) {
                    t.ajax({
                        data: JSON.stringify({
                            command: r,
                            songno: n.SongNo
                        })
                    }).done(function(t) {
                        console.info("add Song:" + n.SongNo), e("#btnosdshow").trigger("click")
                    })
                };
                if (t.cordova) {
                    var i = function(e) {
                        switch (e) {
                            case 1:
                                r("addsong");
                                break;
                            case 2:
                                r("insertsong")
                        }
                    };
                    navigator.notification.confirm("請確認歌曲 : " + n.SongName, i, "點播", ["確認", "插播", "取消"])
                } else {
                    var s = window.confirm("是否插播歌曲：" + n.SongName + "\n\n [確定] 插播" + "\n\n [取消] 標準點播");
                    s == 1 ? r("insertsong") : r("addsong")
                }
            } else o(n.Singer_Id, n.Singer_Name)
        })).append(e("<div>").css({
            position: "absolute",
            right: "10px",
            top: "-11px",
            "margin-left": "5px",
            "text-align": "right"
        }).html(r.spell)).append(e("<div>").css({
            position: "absolute",
            right: "10px",
            top: "13px",
            "margin-left": "5px",
            "text-align": "right"
        }).html(r.desc)).append(e("<hr>").css({
            position: "absolute",
            left: "10px",
            "margin-bottom": "0px",
            bottom: "0px",
            opacity: "0.1",
            width: n.width() - 20,
            border: "0px",
            height: "1px",
            "background-color": "#ffffff"
        })))
    };
    e(".NatureObject[id^=btn]").on("click", function() {
        t.ajax({
            data: JSON.stringify({
                command: e(this).attr("id")
            })
        })
    }), e("#moreoptions").on("click", function() {
        t.natureface.layer() == "options" ? t.natureface.target("search") : t.natureface.target("options")
    }), e("[layer=options]").on("click", function() {
        console.info("data-command:" + e(this).attr("data-command") + " type:" + e(this).attr("data-type")), t.natureface.target("search"), t.listing("songList", {
            command: e(this).attr("data-command"),
            type: e(this).attr("data-type")
        }, f, 8, "#bookPos")
    }), e("#inputsearch").on("blur", function() {
        t.currentkeyword == ""
    }).on("keypress", function() {
        if (event.which != 13) return;
        e(this).blur();
        if (e(this).val() == "" || t.currentkeyword == e(this).val()) return;
        var n = function(e) {
            if (t.currentkeyword == "") return;
            console.info("search [START] : ", e), t.searchisbusy = !0, t.listing("songList", {
                command: "search",
                keyword: e
            }, f, 8, "#bookPos").always(function() {
                console.info("search [END]:", e), t.searchisbusy = !1, t.currentkeyword != e && n(t.currentkeyword)
            })
        };
        t.currentkeyword = e(this).val(), t.searchisbusy || n(e(this).val())
    }), e("#icomenu").on("click", function() {
        t.inputip()
    });
    var l = function() {
        t.ajax({
            data: JSON.stringify({
                command: "status"
            }),
            async: !0
        }).done(function(n) {
            var r = "#lblMarquee",
                i = e("<div>").append(e("<div>").html("歡迎使用超級巨星App!"));
            for (var s = 0; s < n.length; s++) i.append(e("<div>").html(n[s].msg));
            if (t.marquee == i.html()) return;
            console.info("marquee changed."), t.marquee = i.html(), e(r).html(i.html()), e(r).unbind(), e(r).cycle({
                fx: "scrollLeft",
                speed: 2e3,
                timeout: 3e3,
                delay: -4e3
            })
        }).always(function() {
            setTimeout(l, 15e3)
        })
    };
    return setTimeout(l, 2e3), i.on("logon", function() {
        console.info("mq login trigger: logon(refresh marquee)"), l()
    }), {}
});