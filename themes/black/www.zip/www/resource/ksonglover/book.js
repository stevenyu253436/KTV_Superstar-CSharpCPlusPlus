require(["_book"], function(){
	return {};
});
