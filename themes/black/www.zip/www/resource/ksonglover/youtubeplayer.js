require(["_youtube"], function(){
	return {};
});
