require(["_default", "marqueeInput"], function(){
	return {};
});
